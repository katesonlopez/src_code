import {useState, useEffect} from "react";
import {useRouter} from 'next/router';
import {userService} from '/services';
import WalletCommon from '/components/WalletCommon';
import BtcBuy from '/components/BtcBuy';
import 'react-toastify/dist/ReactToastify.css';
import UserLayout from '../layout/UserLayout'
import Loading from "../../../components/Loading";

const buyPage = ({id}) => {

  const router = useRouter();
  const [user, setUserData] = useState(null);
  const [wallet, setWalletData] = useState(null);
  const [allwallet, setAllWalletData] = useState(null);
  const [exchangePairInfo, setExchangePairInfo] = useState([]);
  const [twofa, setTwofaData] = useState(null);
  const walletData = userService.getWalletOrder();

  useEffect(() => {
    async function fetchData() {
      const userJson = localStorage.getItem('user');
      if( userJson ){
        const userser = JSON.parse(userJson);
        const user = userser.res.data.signinResponse;
        setUserData(user);
        walletBalance(user);
        getExchangePairInfo();
        check2FA(user);
      }
    }

    fetchData();
  }, [router]);

  const check2FA = (user) => {
    userService.runApi('check2FA/', user).then((d) => {
      setTwofaData(d.data['2FAStatus'].status);
    })
  };

  const getExchangePairInfo = () => {
    userService.runApi('getExchangePairs/' , {'status':"1", "partner": "BITQUICK"}).then((d) => {
      setExchangePairInfo(d.data.response);
    });
  }

  const walletBalance = (user) => {
    userService.runApi('walletBalance/', user).then((d) => {
      const resd = d.data.wallet
      const order = userService.getCurrencyOrder();

      // Sort the array using the order
      resd.sort((a, b) => order.indexOf(a.currency) - order.indexOf(b.currency));
      resd.forEach(item => item.balance = parseFloat(item.balance.replace(",", "")) + '');
      setAllWalletData(resd);

      // Set id wallet data
      if(walletData[id]){
        walletData[id].data = resd[walletData[id].key];
        setWalletData(walletData[id]);
      }
      else{
        router.push('/user/dashboard');
      }
    }).catch((d) => {
      localStorage.removeItem('user')
      router.push('/');
      return null;
    })
  }

  return (
    <UserLayout>
      {user && wallet ? (
        <main>
          <WalletCommon wallet={wallet} id={id} user={user}/>
          <BtcBuy wallet={wallet} id={id} user={user} twofa={twofa} walletData={allwallet} exchangePairInfo={exchangePairInfo}/>
        </main>
      ) : (
        <Loading/>
      )}
    </UserLayout>

  )
}

export default buyPage;

export async function getServerSideProps({params}) {
  return {
    props: {id: params.id}
  }
}
