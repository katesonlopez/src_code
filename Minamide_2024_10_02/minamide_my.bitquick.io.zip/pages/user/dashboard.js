import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import UserLayout from "./layout/UserLayout";
import DashboardComponent from "../../components/DashboardComponent";
import CardIssue from "../../components/CardIssue/card_issue";

const Dashboard = () => {
  const router = useRouter();
  const { m, act } = router.query;
  const [renderPage, setRenderPage] = useState('dashboard');

  useEffect(() => {
    if (m === 'bank' && act === 'card') {
      setRenderPage('card-issue');
    } else if (m === 'bank' && act === 'member-card') {
      setRenderPage('member-card-issue');
    } else {
      setRenderPage('dashboard');
    }
  }, [m, act]);

  return (
    <UserLayout>
      {renderPage === 'card-issue' ? (
        <CardIssue memberCard={0}/>
      ) : renderPage === 'member-card-issue' ? (
        <CardIssue memberCard={1}/>
      ) : (
        <DashboardComponent />
      )}
    </UserLayout>
  );
};

export default Dashboard;
