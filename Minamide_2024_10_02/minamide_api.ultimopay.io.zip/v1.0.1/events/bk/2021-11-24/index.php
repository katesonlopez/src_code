<?php
mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}
$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
$clientSecret4 = 'climbpot api access key';
$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);

$found = 0;
$partner = '';
$allow_proc = 0;
$sandbox = 0;
foreach (getallheaders() as $name => $value) {
    //echo "$name: $value\n";
	if ($name == 'Authorization') {
		if ($value == $apikey) {
			$found=1;
			$partner = 'yous777.com';
			break;
		} else if ($value == $apikey3) {
			$found = 3;
			$partner = 'casino-wonder.com';
			break;
		} else if ($value == $apikey2) {
			$found = 2;
			$partner = 'alpha-gaming.asia';
			break;
		} else if ($value == $apikey4) {
			$found = 4;
			$partner = 'climbpot.com';
			break;
		} else if ($value == $apikey4_sanbox) {
			$found = 4;
			$partner = 'climbpot.com';
			$sandbox = 1;
			break;
		}
	}
}

if ($found > 0) {
	require '../include/dbconfig.php';
	require '../include/common.php';
	$ip = getUserIpAddr();
	$failed_rs = array('result' => 'failed', 'error' => 'invalid data');
	$req_payment_id = '';
	$json = file_get_contents('php://input');
	$data = json_decode($json, true);
	
	function _log($line) {
		global $fh;
		$fline = date('[Ymd H:i:s] ', time() + 32400) . $line."\n";
		fwrite($fh, $fline);
		//echo date('[Ymd H:i:s] ').$line."\n";
		//@ob_flush(); 
		//flush();
	}
	$fh = @fopen("/var/www/api.xbuy.io/v1/events/events.log" , 'a');
	
	if (!($json)) { //all events
		_log($ip . "::empty json object");
		$allow_proc = 1;
	} else {
		///////////////////////////
		if (!($data)) {
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					$failed_rs['error'] = 'Reached the maximum stack depth';
					break;
				case JSON_ERROR_STATE_MISMATCH:
					$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					break;
				case JSON_ERROR_CTRL_CHAR:
					$failed_rs['error'] = 'Incorrect control character';
					break;
				case JSON_ERROR_SYNTAX:
					$failed_rs['error'] = 'Syntax error or JSON invalid';
					break;
				case JSON_ERROR_UTF8:
					$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					break;
				default:
					$failed_rs['error'] = 'Unknown error';
			}

			//throw new Exception($error);
			$failed_rs['error'] = 'invalid payment ID';
			_log($ip . "::invalid payment id");
			@fclose($fh);
			header('Content-Type: application/json');				
			echo json_encode($failed_rs);
			die();
			
		} else {
			
			if ((!isset($data['payment_id'])) || (empty($data['payment_id']))) {
				$failed_rs['error'] = 'invalid payment ID';
				_log("invalid payment id");
				@fclose($fh);
				header('Content-Type: application/json');				
				echo json_encode($failed_rs);
				die();
			} else {
				$req_payment_id = $data['payment_id'];
				$allow_proc = 1;
				_log($ip. "::payment_id = " . $req_payment_id);
			}
		}
		///////////////////////////
	}
	
	if ($allow_proc == 1) { // all events or having valid payment id
		$payment_ids = array();
		//////////////////////////////////////////////
		$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
		if (mysqli_connect_errno() == 0) {
			mysqli_query($dbhandle, "set names utf8;");
			
			if ($req_payment_id != '') {
				$sql = "SELECT a.payment_id as a_payment_id, a.created_tm, a.partner, b.* FROM `youscasino_generated_payment` a, `xbuy_io_user_simplex_payment_details` b WHERE a.payment_id = b.payment_id AND a.payment_id = '$req_payment_id' AND a.partner='$partner' and a.sandbox = $sandbox order by a.created_tm desc";
								
			} else {
				$sql = "SELECT a.payment_id as a_payment_id, b.* FROM `youscasino_generated_payment` a, `xbuy_io_user_simplex_payment_details` b WHERE a.payment_id = b.payment_id AND a.partner='$partner' and a.sandbox = $sandbox order by a.created_tm desc";
				
			}
			_log($ip . "::" . $sql);
			$rs_payment_details = mysqli_query($dbhandle, $sql);	
			if (mysqli_num_rows($rs_payment_details) == 0) {
				if ($req_payment_id != '') {
					_log($ip . "::payment ID : " . $req_payment_id . " not found");
					@fclose($fh);
					@mysqli_close($dbhandle);
					$failed_rs['error'] = 'invalid payment ID';
					header('Content-Type: application/json');
					echo json_encode($failed_rs);
					die();
				}
				
			} else {
								
				while ($row_detail=mysqli_fetch_array($rs_payment_details, MYSQLI_ASSOC)) {
					unset($event_obj);
					$event_obj = array();
					$db_payment_created_tm = intval($row_detail['created_tm']);
					$db_partner = $row_detail['partner'];
					$db_payment_id = $row_detail['payment_id'];
					$db_invoice_id = $row_detail['invoice_id'];
					$db_quote_id = $row_detail['quote_id'];
					$db_fiat_total_amount = $row_detail['fiat_total_amount_amount'];
					$db_fiat_currency = $row_detail['fiat_total_currency'];
					$db_requested_digital_amount = $row_detail['requested_digital_amount_amount'];
					$db_requested_digital_currency = $row_detail['requested_digital_amount_currency'];
					$db_destination_wallet_address = $row_detail['destination_wallet_address'];
					$db_ip_address = $row_detail['ip_address'];
					$db_user_agent = $row_detail['user_agent'];
					$db_status = intval($row_detail['status']);
					$db_event_id = trim($row_detail['event_id']);
					$db_event_name = trim($row_detail['event_name']);
					$db_event_payment_status = trim($row_detail['event_payment_status']);
					$db_created_dt = $row_detail['created_dt'];
					
					unset($event_payment_obj);
					$event_payment_obj = array();
					$event_payment_obj['payment_id'] = $db_payment_id;
					if (($db_event_name == '') && ($db_event_payment_status == '')) {						
						$event_payment_obj['status'] = 'payment_submitted';				
						_log("(blank) " . $db_payment_id . ": " . $db_event_name . " / " . $db_event_payment_status) . " / " . $db_partner;						
					} else {
						if ($db_event_name != '') {
							if ($db_event_name == 'payment_request_submitted') {
								_log($db_payment_id . ": " . $db_event_name . " / " . $db_event_payment_status) . " / " . $db_partner;
								if ($db_event_payment_status == 'pending_simplexcc_approval') {									
									$cur_time = time();
									if ($cur_time - $db_payment_created_tm > 21600) {
										$event_payment_obj['status'] = 'payment_declined';	
									} else {
										$event_payment_obj['status'] = 'payment_submitted';
									}
								} else {									
									$cur_time = time();
									if ($cur_time - $db_payment_created_tm > 21600) {
										$event_payment_obj['status'] = 'payment_declined';	
									} else {
										$event_payment_obj['status'] = 'payment_submitted';
									}
								}
							} else if ($db_event_name == 'payment_simplexcc_declined') { 
								_log($db_payment_id . ": " . $db_event_name . " / " . $db_event_payment_status) . " / " . $db_partner;
								if ($db_event_payment_status == 'cancelled') {
									$event_payment_obj['status'] = 'payment_cancelled';									
								} else {
									$event_payment_obj['status'] = 'payment_declined';
								}
							} else if ($db_event_name == 'payment_simplexcc_approved') { 
								_log($db_payment_id . ": " . $db_event_name . " / " . $db_event_payment_status) . " / " . $db_partner;
								if (($db_event_payment_status == 'pending_simplexcc_payment_to_partner') || ($db_event_payment_status == 'pending_simplexcc_approval'))  {
									$event_payment_obj['status'] = 'payment_completed';
								}
							
							} else {
								_log($db_payment_id . ": " . $db_event_name . " / " . $db_event_payment_status) . " / " . $db_partner;	
								$event_payment_obj['status'] = 'unknown_status';
							}
						}
					}
					
					
					
					//$created_dt_timestamp = strtotime($db_created_dt);
					//$created_at = gmDate("Y-m-d\TH:i:s\Z", $created_dt_timestamp + 32400);
					$dt_pieces = explode(" ", $db_created_dt);
					$created_at = $dt_pieces[0] . "T" . $dt_pieces[1] . "Z";
					$event_payment_obj['created_at'] = $created_at;
					
					unset($crypto_currency_obj);
					$crypto_currency_obj = array();
					$crypto_currency_obj['approx_amount'] = $db_requested_digital_amount;
					if ($found==4)
						$crypto_currency_obj['currency'] = 'BTC';
					else 
						$crypto_currency_obj['currency'] = 'USDT';
					$event_payment_obj['crypto_currency'] = $crypto_currency_obj;
					
					unset($fiat_obj);
					$fiat_obj = array();
					$fiat_obj['amount'] = $db_fiat_total_amount;
					$fiat_obj['currency'] = 'USD';
					$event_payment_obj['fiat_total_amount'] = $fiat_obj;
					
					$event_obj['payment'] = $event_payment_obj;
					$payment_ids[] = $event_obj;
					
				}
				
			}
			@mysqli_close($dbhandle);
			//_log("success");			
			@fclose($fh);
			header('Content-Type: application/json');
			echo json_encode($payment_ids);
			die();
		} else {
			_log($ip . "::cannot connect db");
			@fclose($fh);
			$failed_rs['error'] = 'unknown error occured, please contact xbuy.io administrator';
			header('Content-Type: application/json');
			echo json_encode($failed_rs);
			die();
			
		}
		//////////////////////////////////////////////
	}
	
	
	
	

} else {
	header('HTTP/1.0 403 Forbidden');
}
?>