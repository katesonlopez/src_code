<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(
                    ' ', '-', ucwords(
                        strtolower(
                            str_replace(
                                '_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
    $fh2 = null;
    try {
        if ($email == "") {
            //if( file_exists("/var/www/api.ultimopay.io/v1/balanceCorrection/log/balance_correction.log")){
                $fh2 = fopen("/var/www/api.ultimopay.io/v1/balanceCorrection/log/balance_correction.log", 'a');
            //}
        } else {
			//if( file_exists("/var/www/api.ultimopay.io/v1/balanceCorrection/log/" . $email . ".log")){
                $fh2 = fopen("/var/www/api.ultimopay.io/v1/balanceCorrection/log/" . $email . ".log", 'a');
            //}
        }
        $fLine = date('[Ymd H:i:s] ') . $line . "\n";
        if ($fh2) {
            fwrite($fh2, $fLine);
            fclose($fh2);
        }
    }
    catch (Exception $e){

    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {


		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		_log("", "ket noi thanh cong");
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode(''/*$clientId5*/ . ':' . ''/*$clientSecret5*/);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$partner = "";
	$allowed_deposit_currency_arr = array('USDT');
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	
	foreach (getAllHeaders() as $name => $value) {
		if ($name == 'Authorization') {
			$req_api_key = trim($value);
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
				}
			} else {
				_log("", "not found in db");
			}
		}
	}

	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}

	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

		$json = file_get_contents('php://input');
        $strJSON = preg_replace('/\: *([0-9]+\.?[0-9e+\-]*)/', ':"\\1"', $json);
		$data = json_decode($strJSON, true );
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					//$failed_rs['error'] = 'Reached the maximum stack depth';
					_log("", 'Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					_log("", 'Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					//$failed_rs['error'] = 'Incorrect control character';
					_log("", 'Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					//$failed_rs['error'] = 'Syntax error or JSON invalid';
					_log("", 'Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					//$failed_rs['error'] = 'Unknown error';
					_log("", 'Unknown error');
					break;
			}
			
			_log("", 'A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			}

			//auth_token
			if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
				$error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
				$errors[] = $error_obj;
			}
			
			//amount
			if ((!isset($data['amount'])) || (empty($data['amount']))) {
				$error_obj = array('errorCode' => 4, 'errorMessage' => 'amount parameter is required.');
				$errors[] = $error_obj;
			}
			
            //target_address
            if ((!isset($data['target_address'])) || (empty($data['target_address']))) {
                $error_obj = array('errorCode' => 5, 'errorMessage' => 'target_address parameter is required.');
                $errors[] = $error_obj;
            }

            //target_account_currency
            if ((!isset($data['target_account_currency'])) || (empty($data['target_account_currency']))) {
                $error_obj = array('errorCode' => 6, 'errorMessage' => 'target_account_currency parameter is required.');
                $errors[] = $error_obj;
            }


            //target_user_id
            if ((!isset($data['target_user_id'])) || (empty($data['target_user_id']))) {
                $error_obj = array('errorCode' => 7, 'errorMessage' => 'target_user_id parameter is required.');
                $errors[] = $error_obj;
            }

            //target_account_id
            if ((!isset($data['target_account_id'])) || (empty($data['target_account_id']))) {
                $error_obj = array('errorCode' => 8, 'errorMessage' => 'target_account_id parameter is required.');
                $errors[] = $error_obj;
            }

            //comment
            if ((!isset($data['comment'])) || (empty($data['comment']))) {
                $error_obj = array('errorCode' => 9, 'errorMessage' => 'comment parameter is required.');
                $errors[] = $error_obj;
            }


            if (count($errors) == 0) {
				
				$errors_sub = array();
				
				//proceed to shift api
				require_once '../include/common.php';
				////////////////////////////////////////////////////
				//receive POST params
				$reg_email_address = trim($data['email_address']);
				$private_key = trim($data['auth_token']);
				$amount = trim($data['amount']);
                $target_address = trim($data['target_address']);
                $target_account_currency = trim($data['target_account_currency']);
                $target_user_id = trim($data['target_user_id']);
                $target_account_id = trim($data['target_account_id']);
                $comment = trim($data['comment']);
				_log($reg_email_address, "balance correction started...");

                $allow_access_api = 0;
                $my_db_private_key = '';
                $my_db_auth_token = '';
                $my_db_wallet_auth_token = '';
                $my_db_sigin_dt = '';
                $my_db_token_refresh_dt = '';

                $sql_check_signin = "select a.*, b.*, c.debit_card_id, c.acc_no, c.debit_card_num 
                                        from cryptocash_merchant_user_signin a, cryptocash_shift_wallet b, cryptocash_jdb_debit_card c 
                                        where a.email_address = '$reg_email_address' 
                                          AND a.merchant='" . $req_partner['partner'] . "' 
                                          AND a.email_address = b.shift_login_email";
                _log($reg_email_address, $sql_check_signin);
                $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
                if (mysqli_num_rows($rs_check_signin) > 0) { //allow access API
                    $allow_access_api = 1;
                    while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
                        $my_db_auth_token = trim($row_signin['auth_token']);
                        $my_db_wallet_auth_token = trim($row_signin['wallet_auth_token']);
                        $my_db_sigin_dt = $row_signin['signin_dt'];
                        $my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
                        $my_db_private_key = trim($row_signin['private_key']);
                    }
                }

                if ($allow_access_api == 1) {
                    if ($private_key != $my_db_private_key) {
                        @mysqli_close($dbhandle);
                        header('Content-Type: application/json');
                        http_response_code(500);
                        $ret_rs['result'] = 'failed';
                        $ret_rs['error'] = array('errorCode' => 11, 'errorMessage' => 'Unauthorized.');
                        echo json_encode($ret_rs);
                        die();
                    }
                    else {
						
						$dec_configurator_key = '';
						_log($reg_email_address, "::try call get_configurator_key api...");										
						$plusqo_configurator_info_res = get_configurator_key($reg_email_address, $my_db_auth_token, 'plusqo_configurator_key_salt', 'plusqo_configurator_ec_key');									
						if (($plusqo_configurator_info_res['http_code'] == "200") || ($plusqo_configurator_info_res['http_code'] == "200 OK")) {
							_log($reg_email_address, "::call get_configurator_key api success.");
							//_log($reg_email_address, "::target_key_value = " . $plusqo_configurator_info_res['result']['target_key_value']);
							if (!empty($plusqo_configurator_info_res['result']['target_key_value'])) {
								$dec_configurator_key = trim($plusqo_configurator_info_res['result']['target_key_value']);
								_log($reg_email_address, "::get dec_configurator_key success");
							}
							
						} else {
							_log($reg_email_address, "::call decrypt api failed.");
						}
						if ($dec_configurator_key == '') {											
							_log($reg_email_address, "::failed logging by Configurator Account (get dec_configurator_key failed)!");
							@mysqli_close($dbhandle);
							header('Content-Type: application/json');
							http_response_code(500);
							$ret_rs['result'] = 'failed';
							$ret_rs['error'] = array('errorCode' => 11, 'errorMessage' => 'error occurred. please contact administrator for help.');
							echo json_encode($ret_rs);
							die();
						}
						
                        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        _log($reg_email_address, "::try logging in by Configurator Account...");
                        $configurator_access_token = '';
                        ///////////////////////////////////////////////////////////////////////////////////////////////
                        //try login as configorator
                        $configurator_login_post_data = array();
                        $configurator_login_post_data['username'] = SHIFT_CONFIGURATOR_USERNAME;
                        $configurator_login_post_data['password'] = $dec_configurator_key;
                        $configurator_login_post_data['exchange'] = "CONFIGURATOR_PLUSQO";

                        $configurator_login_res = shift_configurator_api_call(
                            '/api/configurator_authentication/configuratorToken',
                            0,
                            '',
                            $configurator_login_post_data,
                            '');
                        if ($configurator_login_res['result']['result'] == 'success') {
                            $configurator_access_token = trim($configurator_login_res['result']['configurator_access_token']);
                            $configurator_auth_value = "Bearer " . $configurator_access_token;
                            if ($configurator_access_token != '') {
                                _log($reg_email_address, "::Configurator Account logged in successful. Try execute balancecorrection...");
                                _log($reg_email_address, "userId: ".$target_user_id);
                                _log($reg_email_address, "accountId: ".$target_account_id);
                                _log($reg_email_address, "currency: ".$target_account_currency);
                                _log($reg_email_address, "amount: ".$amount);
                                _log($reg_email_address, "comment: ".$comment);

                                //execute balance correction here
                                $balance_correction_dto_ex = array();
                                $balance_correction_dto_ex['userId'] = $target_user_id;
                                $balance_correction_dto_ex['accountId'] = $target_account_id;
                                $balance_correction_dto_ex['currency'] = $target_account_currency;
                                $balance_correction_dto_ex['amount'] = $amount;
                                $balance_correction_dto_ex['type'] = 5;
                                $balance_correction_dto_ex['comment'] = $comment;

                                $balance_correction_res = shift_configurator_api_call(
                                    'balancecorrection',
                                    0,
                                    '',
                                    $balance_correction_dto_ex,
                                    $configurator_auth_value
                                );
                                if (($balance_correction_res['http_code'] == "200") || ($balance_correction_res['http_code'] == "200 OK")) {
                                    _log($reg_email_address , "::executed balancecorrection successful.");
                                    $balance_correction_dt = date('Y-m-d H:i:s');
                                    $balance_correction_dt_utc = date('Y/m/d H:i:s', strtotime($balance_correction_dt) - 32400);
                                    @mysqli_close($dbhandle);
                                    $ret_rs['result'] = 'success';
                                    $ret_rs['email_address'] = $reg_email_address;
                                    header('Content-Type: application/json');
                                }
                                else  {
                                    _log($reg_email_address, "::balancecorrection execution failed");

                                    $insufficient_balance_err = 0;
                                    $error_message = '';
                                    $error_code = 999;
                                    if (!empty($balance_correction_res['result']['dtsStatus'])) {
                                        if (strtolower(trim($balance_correction_res['result']['dtsStatus'])) == 'insufficientbalance') {
                                            $insufficient_balance_err = 1;
                                        }
                                    }
                                    if ($insufficient_balance_err == 1) {
                                        $error_code = 12;
                                        $error_message = 'insufficient balance to correct. please check '.$target_account_currency.' wallet balance';
                                    } else {
                                        $error_code = 13;
                                        $error_message = 'error occurred. please contact administrator for help. The details are as follows: '.$balance_correction_res['error'];
                                    }

                                    @mysqli_close($dbhandle);
                                    header('Content-Type: application/json');
                                    http_response_code(500);
                                    $ret_rs['result'] = 'failed';
                                    $ret_rs['error'] = array(
                                        'errorCode' => $error_code,
                                        'errorMessage' => $error_message);
                                }
                                echo json_encode($ret_rs);
                                die();
                            }
                        }
                        else {
                            _log($reg_email_address, "::failed logging by Configurator Account!");
                            _log($reg_email_address, "::" . $configurator_login_res['error']);
                            @mysqli_close($dbhandle);
                            header('Content-Type: application/json');
                            http_response_code(500);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 14, 'errorMessage' => 'error occurred. please contact administrator for help.');
                            echo json_encode($ret_rs);
                            die();
                        }
                    }
                }
                else {
                    @mysqli_close($dbhandle);
                    header('Content-Type: application/json');
                    http_response_code(500);
                    $ret_rs['result'] = 'failed';
                    $ret_rs['error'] = array('errorCode' => 10, 'errorMessage' => 'you must sign in to use this API.');
                    echo json_encode($ret_rs);
                    die();
                }
			}
            else {
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors[0];
				_log("", $ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
		}
	}
    else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
	http_response_code(405); 
	die();
}
?>