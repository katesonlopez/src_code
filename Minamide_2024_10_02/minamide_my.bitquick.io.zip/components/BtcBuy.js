import {useRouter} from 'next/router';
import {useState} from "react";
import {useForm} from 'react-hook-form';
import {yupResolver} from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import {userService, alertService} from '/services';
import Swal from "sweetalert2";
import _ from 'lodash';
import 'react-toastify/dist/ReactToastify.css';
import {parseStringToFloat, toUsNumber, truncateFloat} from "./Utils/calc";

function BtcBuy({wallet, id, user, twofa, walletData, exchangePairInfo}) {
  let btcExchangeInfo = null;
  for( let i = 0; i < exchangePairInfo.length; i++ ){
    if(exchangePairInfo[i].pair_id === (id+'USD'))
      btcExchangeInfo = exchangePairInfo[i];
  }

  const router = useRouter();
  const [inputValue, setInputValue] = useState(0);
  const [haveToPay, setHaveToPay] = useState('0.00');
  const [receive, setReceive] = useState('0.00');
  const [ifNotValid, setIfNotValid] = useState(true);
  const balance = id === 'LTC' ? parseStringToFloat(walletData[0].balance) : parseStringToFloat(walletData[2].balance);
  const unit = id === 'LTC' ? 'USDT' : 'USD';
  const float = wallet.float;
  const minimum = btcExchangeInfo?.buy_min * 1 ?? 0.001;

  const handleInputChange = (event) => {
    let newValue = event.target.value;
    const decimalDigits = newValue.split(".");
    const isFloat = newValue.toString().includes(".");
    setIfNotValid(true);
    if (!isNaN(newValue)) {
      if (isFloat && decimalDigits[1].length >= float) {
        newValue = parseFloat(newValue).toFixed(float);
      }
      setInputValue(newValue);
      debounceApiCall(user, id, newValue, balance);
    }
    else{
      setError('amount', {message: `Amount is required`})
    }
  };

  const debounceApiCall = _.debounce((user, id, newValue, balance) => {
    if(newValue * 1 < minimum * 1 ){
      setError('amount', {message: `Amount should be greater than ${minimum} ${id}`});
      setIfNotValid(true);
    }
    else{
      userService.runApi('cryptoPrice/', user)
        .then((res) => {
          const input = document.getElementById('amount');
          newValue = input.value;
          if(newValue * 1 < minimum * 1 ){
            setError('amount', {message: `Amount should be greater than ${minimum} ${id}`});
            setIfNotValid(true);
          }
          else{
            const ress = res.data.cryptocurrencies;
            const filteredData = ress.filter((item) => item.pair.includes(id));
            const sell_price = filteredData[0].sell_price;

            // Calculate have to pay amount
            let calculatedValue = parseFloat(newValue) * parseFloat(sell_price);
            if( id === 'USDT' || id === 'USDC' ){
              calculatedValue = parseFloat(newValue) * parseFloat(sell_price) * ( 1 + parseFloat(btcExchangeInfo.sell_fee_percent) / 100);
            }
            calculatedValue > 0 ? setHaveToPay(`` + calculatedValue.toFixed(2)) : setHaveToPay('0.00');

            // Calculate receive amount
            setReceive((newValue * (1 - btcExchangeInfo.sell_fee_percent / 100)).toFixed(10) * 1);

            if (parseFloat(balance) < parseFloat(calculatedValue.toFixed(2))) {
              setError('amount', {message: `You don't have enough ${unit} to buy this`});
              setIfNotValid(true);
            } else {
              if (minimum > parseFloat(newValue)) {
                setError('amount', {message: `Please enter amount more than ${minimum} ${id}`});
                setIfNotValid(true);
                return;
              }
              if(errors.amount) {
                setError('amount', null);
                errors.amount = false;
              }
              setIfNotValid(false);
            }
          }
        })
        .catch(alertService.error);
    }
  }, 500); // debounce time in milliseconds

  const handleKeyDown = (event) => {
    if (event.key === '-' || event.key === '+') {
      event.preventDefault(); // prevent '-' or '+' from being entered
    }
    userService.PreventIncrement(event);
    debounceApiCall(user, id, event.target.value, balance);
  };

  const validationSchema = Yup.object().shape({
    amount: Yup.string()
      .required('amount is required'),
  });

  const formOptions = {
    resolver: yupResolver(validationSchema), defaultValues: {
      email_address: user.email_address,
      auth_token: user.auth_token,
      type: 'buy',
      pair: id + `USD`,
      amount: inputValue,
    },
  };

  // get functions to build form with useForm() hook
  const {register, handleSubmit, formState, setError} = useForm(formOptions);
  const {errors} = formState;

  function onSubmit(formData) {
    return Swal.fire({
      title: `Do you really want to Buy ${toUsNumber(inputValue)} ${id}?`,
      html: `You Pay ${toUsNumber(haveToPay)} ${unit}<br><em>The amount may vary slightly depending on the fluctuation.</em>`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Buy it",
      cancelButtonText: "No, cancel",
    }).then((result) => {
      if (result.isConfirmed) {
        userService.showLoader(true)
        return userService.runApi('cryptoExchange/', formData)
          .then((res) => {
            if (res.data.result === "success") {
              Swal.fire({
                title: "Success",
                text: "Amount Exchanged Successfully",
                icon: "success",
              }).then(function (/*result*/) {
                userService.showLoader(false)
                router.reload();
              });
            } else if (res.data.result === "failed") {
              Swal.fire({
                title: "Error",
                text: res.data.error.errorMessage,
                icon: "error",
              }).then(function (result) {
              });
            }
          })
          .catch((res) => {
            Swal.fire({
              title: "Error",
              text: res.response.data.error.errorMessage,
              icon: "error",
            }).then(function (result) {
            });
          });
      } else {
      }
    });
  }

  return (
    <>
      <div className="container-fluid px-4">
        <div className="row pse-5 pt-4 pb-5">
          <div className="col-sm-11 mt-1">
            <h4 className="mb-2">
              <b>IMPORTANT NOTICE</b>
            </h4>
            <label className="">
              Final amount of {unit} you have to pay is subject to be changed according
              to {id}/{unit} price at the time your buying order is submitted and
              executed.{" "}
            </label>
          </div>
          <div className="col-sm-12 mt-4">
            <form onSubmit={handleSubmit(onSubmit)}>
              <h4 className="mt-0">
                <b>AMOUNT YOU WANT TO BUY </b>
              </h4>
              <div className="mb-4">
                <input onKeyDown={handleKeyDown}
                       name="amount" step="0.000001"
                       {...register('amount')} className={`form-control ${errors.amount ? 'is-invalid' : ''}`}
                       type="text"
                       id="amount"
                       value={inputValue}
                       onChange={handleInputChange}
                       placeholder={`Enter ` + wallet.title + ` Amount`}
                />
                <div className="invalid-feedback ms-3">{errors.amount?.message}</div>
              </div>
              <h4 className="mt-4">
                <b>YOU HAVE TO PAY </b>
              </h4>
              <p className="amount-price amount-price-usd">
                {toUsNumber(haveToPay)} <font style={{fontSize: 14}}>{unit}</font>{" "}
              </p>
              <div className="mt-1 ms-3">Available amount
                : {toUsNumber(truncateFloat(balance, 2))} {unit}
              </div>
              { inputValue > 0 && id !== 'USDT' && id !== 'USDC' && (
                <div className="ms-3">Receive amount: {toUsNumber(truncateFloat(receive, wallet.float))} {id}</div>
              )}
              <button type="submit" className="size-xl button primary mt-4 col-sm-3"
                      disabled={formState.isSubmitting || ifNotValid}>
                BUY {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  )
}

export default BtcBuy;
