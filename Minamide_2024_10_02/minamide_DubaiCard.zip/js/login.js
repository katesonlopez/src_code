/* login.js */
$(document).ready(function () {
  $(document).ready(function() {
    // Toggle submenu
    $('.parent-menu').click(function(e) {
      e.preventDefault(); // Prevent default link behavior
      $(this).next('.submenu').slideToggle(); // Toggle submenu
      $(this).find('.rotate-icon').toggleClass('rotate'); // Rotate the chevron icon
    });
  });
});
