# mypays.io

```yaml
php: 7.2.34
composer: 2.7.9
```

```bash
$ composer install
```
