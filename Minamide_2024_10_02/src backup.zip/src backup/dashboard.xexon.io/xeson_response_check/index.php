<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, X-Requested-With, Authorization');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 3600');
mb_internal_encoding("UTF-8");
date_default_timezone_set('Asia/Tokyo');
ini_set('memory_limit', '50M');

$requestBodyString = file_get_contents('php://input');
$requestObject = json_decode( $requestBodyString, true );


$headers = [];
foreach ($_SERVER as $name => $value) {
    if (substr($name, 0, 5) == 'HTTP_') {
        $name = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))));
        $headers[$name] = $value;
    }
}
$cmd = $_GET['cmd'];

//=================   check jdb server =======================================================
/*$ip = '172.21.22.203';
$port = 5001;
if (!isIPPortAvailable($ip, $port)) {
    echo "IP address $ip and port $port are not available.";
    return;
}*/


$responseAuth = array();
$responseAuth['headers'] = $headers;
$responseAuth['timestamp'] = '2023-04-06T17:20:32.395901+07:00';
$responseAuth['success'] = true;
$responseAuth['status'] = 200;
$responseAuth['message'] = 'SUCCESS';
$responseAuth['data'] = array(array(
    'token'=>'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJKREJDQVJEIiwiaWF0IjoxNjgwNzc2NDMyLCJleHAiOjE2ODA3ODY0MzJ9.qQf0naosypLG0a48WYTmEzZ_piTHO6KXzlkjZN_kV4g',
    'expiresIn'=>'9999',
    'tokenType'=>'Bearer',
    'avl_Balance'=>300));

$responseCard = array();
$responseCard['headers'] = $headers;
$responseCard['timestamp'] = '2023-04-06T17:20:32.395901+07:00';
$responseCard['success'] = true;
$responseCard['status'] = 200;
$responseCard['message'] = 'SUCCESS';
$responseCard['data'] = array('avl_Balance'=>300);

$responseTransaction = array();
$responseTransaction['headers'] = $headers;
$responseTransaction['request'] = $requestObject;
$responseTransaction['timestamp'] = '2023-04-06T17:20:32.395901+07:00';
$responseTransaction['success'] = true;
$responseTransaction['status'] = 200;
$responseTransaction['message'] = 'SUCCESS';
$responseTransaction['data'] = array(
    array(
        'trnRefNo'=>'006DORMUSD000001',
        'txnDate'=>'04-MAR-2023 19:38:48',
        'cardNo'=>'4284710000023765',
        'accountNo'=>'00620010100001478',
        'srNo'=>2866505591,
        'description'=>'TR FEE DORMANT ACCOUNT',
        'trnCode'=>'DOR',
        'authstat'=>'A',
        'drAmount'=>'4',
        'crAmount'=>'0',
        'endBal'=>9.46,
        'userId'=>'SYSTEM'),
    array(
        'trnRefNo'=>'006DORMUSD000002',
        'txnDate'=>'04-MAR-2023 19:38:48',
        'cardNo'=>'4284710000023765',
        'accountNo'=>'00620010100001478',
        'srNo'=>2866505591,
        'description'=>'TR FEE DORMANT ACCOUNT',
        'trnCode'=>'DOR',
        'authstat'=>'A',
        'drAmount'=>'4',
        'crAmount'=>'0',
        'endBal'=>9.46,
        'userId'=>'SYSTEM')
);

if( $cmd == 'auth')
    echo json_encode( $responseAuth );
else if( $cmd == 'card')
    echo json_encode( $responseCard );
else if( $cmd == 'transaction')
    echo json_encode( $responseTransaction );

function isIPPortAvailable($ip, $port) {
    $connection = @fsockopen($ip, $port, $errno, $errstr, 1);

    if ($connection) {
        fclose($connection);
        return true; // IP address and port are available
    } else {
        return false; // IP address and port are not available
    }
}


/*// 1st, authentication
$requestData = [
    'requestId' => $requestId,
    'userId' => $AUTH_USER_ID,
    'secretId'=>$SECRET_ID
];

$jsonRequestData = json_encode( $requestData );

// generate curl command
$curlCommand = "curl --location --request $requestMethod ";
$requestHeaders = [
    "Content-Type: application/json",
    "SignedHash: ".generateHash($jsonRequestData)
];
foreach ($requestHeaders as $header) {
    $curlCommand .= "--header '$header' ";
}
$curlCommand .= "--data-raw '" . $jsonRequestData . "' ";
$curlCommand .= "'$AUTH_URL'";
echo '<br/>authentication curl cmd: '.$curlCommand;*/

