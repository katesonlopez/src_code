import {useRouter} from 'next/router';
import {useState} from "react";
import {useForm} from 'react-hook-form';
import {yupResolver} from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import {userService} from '/services';

function PaidSuccess({user, form2, userdata, form1, onNextClick, isMobile, memberCard}) {
  const router = useRouter();
  const [images, setImages] = useState([]);
  const [activateForm, setActivateForm] = useState(memberCard !== 0);
  const handleImageUpload = (event, index) => {
    const {name, files} = event.target;
    const file = files[0];

    const maxSize = 10 * 1024 * 1024; // 10MB
    const allowedTypes = ['image/jpeg', 'image/png', 'image/heic'];

    if (!file) {
      validationSchema
        .validateAt(name, {file})
        .then(() => {
        })
        .catch((error) => {
          console.log(error.message);
        });
      const newImages = [...images];
      newImages[index] = '';
      setImages(newImages);
      return;
    }

    if (!allowedTypes.includes(file.type)) {
      validationSchema
        .validateAt(name, {file})
        .then(() => {
          console.log('File is valid');
        })
        .catch((error) => {
          console.log(error.message);
        });
      const newImages = [...images];
      newImages[index] = '';
      setImages(newImages);
      return;
    }

    if (file.size > maxSize) {
      validationSchema
        .validateAt(name, {file})
        .then(() => {
          console.log('File is valid');
        })
        .catch((error) => {
          console.log(error.message);
        });
      const newImages = [...images];
      newImages[index] = '';
      setImages(newImages);
      return;
    }
    const url = URL.createObjectURL(file);
    const newImages = [...images];
    newImages[index] = url;
    setImages(newImages);
  };

  function activateCard() {
    setActivateForm(true)
  }

  const validationSchema = Yup.object().shape({
    debit_selfie: Yup.mixed()
      .required('Selfie is required')
      .test("fileType", "Selfie is required", (value) => {
        return value.length !== 0;
      })
      .test("fileSize", "The file is too large", (value) => {
        if (!value.length) return false // attachment is optional
        return value[0].size <= 10000000
      })
      .test("fileType", "Only JPEG, PNG, HEIC files are accepted", (value) => {
        if (!value.length) return false // attachment is optional
        return value[0].type === "image/jpeg" ||
          value[0].type === "image/png" ||
          value[0].type === "image/heic"
      })
  });
  const formOptions = {
    resolver: yupResolver(validationSchema), defaultValues: {
      email_address: user.email_address,
      auth_token: user.auth_token,
    },
    mode: 'onBlur'
  };

  // get functions to build form with useForm() hook
  const {register, handleSubmit, control, formState, setError, setValue} = useForm(formOptions);
  const {errors} = formState;

  async function onSubmit(frm) {
    const formData = new FormData();
    formData.append("email_address", frm.email_address);
    formData.append("debit_selfie", frm.debit_selfie[0]);
    return fetch(process.env.NEXT_PUBLIC_PDF_BACKEND + '/scripts/upload_selfie.php', {
      method: 'POST',
      body: formData
    })
      .then(response => response.json())
      .then(data => {
        if (!user.status) {
          user.status = {};
        }
        user.status['card_activation_file_url'] = data.debit_selfie;
        user.status['card_activation_status'] = memberCard === 0 ? 1 : 0;
        user.status['card_activation_upload_date'] = data.upload_date;

        // Member card case
        if( memberCard === 1 )
          user.member_card = 1;

        userService.runApi("updateUserStatus/", user)
          .then((res) => {
            if( memberCard === 0 )
              router.reload();
            else
              onNextClick(user, 7);
          })
      })
      .catch(error => {
      });
  }

  return (

    <>
      {activateForm ?
        <div className="row justify-content-center">
          <div className="col-md-8">
            <form className="row g-3" onSubmit={handleSubmit(onSubmit)} encType="multipart/form-data">
              <div className="card">
                <div className="card-header no-color">
                  <h3 className="mt-2 text-center text-white font-800"> {memberCard === 0 ? "Activate Your Debit Card" : "BITQUICK MEMBER CARD"}</h3>
                </div>
                <div className="card-body light-bg-color mb-2">
                  <p className="card-text">Have you already received the {memberCard === 0 ? "debit" : "member"} card sent to your residence address? If
                    so, you have to activate it before you can use it.</p>
                  <p className="card-text">* Use one hand to keep both {memberCard === 0 ? "debit" : "member"} card and {userdata.id_card_type === "ID card" ? "ID" : "passport"} like below
                    example</p>
                  <p className="card-text" style={{color: "#FF0000"}}>* Please make sure the side with the card number
                    is visible in the selfie image.</p>
                  <div className='preview-image ps-2 text-center'>
                    <img
                      src={userdata.id_card_type === "ID card" ? "/assets/img/activate_ID.png" : "/assets/img/activete_passport.png"}
                      style={{height: 180, width: 'auto'}}/>
                  </div>
                  <div className="row">
                    <div className="col-md-12">
                      <div className="mb-3 mt-3">
                        <label htmlFor="debit-card-photo" className="form-label">Select a selfie photo of you and the debit
                          card you noticed have received</label>
                        <div className="choose-file text-center">
                          {images && images[0] ?
                            <div className='preview-image text-center'><img src={images[0]} width={200}/></div>
                            : ''}
                          <div className="file-inner">
                            <i className="bi bi-cloud-arrow-up-fill"/>
                            <br/>
                            Click or drag and drop image <br/> file here
                            <input
                              type="File"
                              name="debit_selfie"
                              {...register('debit_selfie')}
                              className={`form-control ${errors.debit_selfie ? 'is-invalid' : ''}`}
                              onChange={(e) => handleImageUpload(e, 0)}
                              id="debit_selfie"
                            />
                            <div className="invalid-feedback">{errors.debit_selfie?.message}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {memberCard === 0 && (<p className="card-text">Make sure to upload the same ID you used before during. It can take 1-2
                    working days for this verification step after we receive your selfie photos. We will inform you the
                    result via email, as well as here in your dashboard.</p>)}
                  <button type="submit" className="button primary mt-2 float-end ps-4 pe-4" disabled={formState.isSubmitting}>
                    Upload and go next ›
                    {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div> :

        <div className="col-md-8 mx-auto mt-4">
          <div className="card mx-auto">
            <div className="card-body p-4">
              <h3 className="card-title text-center mb-4 text-white font-800">Activate Your {memberCard === 0 ? "Debit" : "Member"} Card</h3>
              <p className="card-text">Your card fee has been paid. create your card. Your {memberCard === 0 ? "Debit" : "Member"} Card is now
                on production. Expect the card delivered to your postal address in 10-15 days.</p>
              <p className="mt-4">Your Postal Address</p>
              <p
                className='card-text ps-3 pe-3'>{userdata.address} , {userdata.city}, {userdata.province}, {userdata.postal_code} , {userdata.country}</p>
              <p className='card-text pt-4'>Once you have recieved your card, please activate it.</p>
              <div className="col-md-12 mt-3 pe-4 ps-4" align="center">
                <button type="button" className='button primary size-xl-wider text-center' onClick={() => activateCard()}> Activate</button>
              </div>
            </div>
          </div>
        </div>
      }
    </>
  )
}

export {PaidSuccess};
