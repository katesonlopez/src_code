# Ultimo email bulk sender tool

```yaml
php: 7.2.34
composer: 2.7.9
```
