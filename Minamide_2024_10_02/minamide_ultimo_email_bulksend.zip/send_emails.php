<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Include PHPMailer's autoload file

$data = json_decode(file_get_contents('php://input'), true); // Decode the JSON data
if (!isset($data['emails'])) {
  echo json_encode(['error' => 'No emails provided']);
  exit;
}

// Get POST data
$emails = $data['emails'];
$host = $data['host'];
$username = $data['username'];
$password = $data['password'];
$port = $data['port'];
$senderAddress = $data['senderAddress'];
$senderName = $data['senderName'];
$subject = $data['subject'];
$body = $data['body'];

// Initialize PHPMailer
$mail = new PHPMailer(true);
$results = [];

foreach ($emails as $email) {
  try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = $host;
    $mail->SMTPAuth = true;
    $mail->Username = $username;
    $mail->Password = $password;
    $mail->SMTPSecure = $port == '465' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = $port;

    // Recipients
    $mail->setFrom($senderAddress, $senderName);
    $mail->addAddress($email); // Add a recipient

    // Content
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = '<pre>' . $body . '</pre>';

    // Send email
    $mail->send();
    $results[] = ['email' => $email, 'status' => 'success'];
  } catch (Exception $e) {
    $results[] = ['email' => $email, 'status' => 'failed'.$e->getMessage()];
  }

  $mail->clearAddresses(); // Clear the address for the next iteration
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($results);
