import { useRouter } from 'next/router';
import { useState, useEffect, useRef } from 'react';
import { userService } from '/services';
import cookie from 'js-cookie';

const withAuth = (WrappedComponent) => {
  const Authenticated = (props) => {
    const router = useRouter();
    const userStorage = typeof window !== 'undefined' && localStorage.getItem('user');
    const userObject = userStorage ? (JSON.parse(userStorage))?.res.data.signinResponse : null;
    const [user, setUser] = useState(userObject);
    const [authChecked, setAuthChecked] = useState(false);
    const refreshInProgress = useRef(false);

    const SignOut = () => {
      userService.runApi("signout/", user);
      localStorage.removeItem("user");
      cookie.remove("user", { path: "/" });
      router.push("/");
    };

    useEffect(() => {
      if (!userStorage) {
        router.push('/');
        return;
      }

      const checkAuthentication = async () => {
        if (refreshInProgress.current) return;
        refreshInProgress.current = true;

        try {
          let timeString = localStorage.getItem("loginTime");
          const loggedInTime = new Date(timeString);
          timeString = localStorage.getItem("lastAccessTime");
          const lastAccessTime = new Date(timeString);
          timeString = new Date().toLocaleString();
          const currentTime = new Date(timeString);
          const timeDiffFromLogin = (currentTime - loggedInTime) / 1000;
          const timeDiffFromLastAccess = (currentTime - lastAccessTime) / 1000;
          const expireDuration = localStorage.getItem("expires_second");
          const fullExpiresDuration = localStorage.getItem("full_expires_second");

          // console.log(`${timeDiffFromLogin}, ${timeDiffFromLastAccess} seconds have passed since the last login and the last access.`);

          // If expires from logged in time for 3600 seconds, will sign out.
          if (timeDiffFromLogin > fullExpiresDuration) {
            SignOut();
            // console.log(`Token has expired for ${fullExpiresDuration} seconds. You need to log in again.`);
          }
          // If expires from last accessed time for 600 seconds, will sign out.
          else if( timeDiffFromLastAccess > expireDuration ){
            SignOut();
            // console.log(`Token has expired for ${expireDuration} seconds. You need to log in again.`);
          }
          // Update last accessed time and keep all sessions
          else {
            timeString = Date().toLocaleString();
            localStorage.setItem("lastAccessTime", timeString);
            // console.log("Token is valid.");
            // console.log("Updated lastAccessTime.");
            /*const response = await userService.refreshToken(user);
            user.auth_token = response.data.refreshTokenResponse.auth_token;

            const newUserdata = { res: { data: { signinResponse: user } } };
            localStorage.setItem('user', JSON.stringify(newUserdata));
            cookie.set('user', JSON.stringify(newUserdata), { path: '/' });
            setUser(user);*/
          }
        } catch (error) {
          console.error("Error refreshing token:", error);
          localStorage.removeItem('user');
          cookie.remove('user');
          SignOut();
        } finally {
          setAuthChecked(true);
          refreshInProgress.current = false;
        }
      };

      checkAuthentication();
    }, [router, user]);

    if (!userStorage) {
      return null;
    }

    return <WrappedComponent {...props} user={user} />;
  };

  Authenticated.getInitialProps = async (ctx) => {
    const componentProps = WrappedComponent.getInitialProps && (await WrappedComponent.getInitialProps(ctx));
    return { ...componentProps };
  };

  return Authenticated;
};

export default withAuth;
