<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
	
	//global $fh;
	if ($email == "") {
		$fh2 = fopen("/var/www/api.ultimopay.io/v4/cryptoPrice/log/crypto_price.log" , 'a');
	} else {
		$fh2 = fopen("/var/www/api.ultimopay.io/v4/cryptoPrice/log/" . $email . ".log" , 'a');
	}		
	$fline = date('[Ymd H:i:s] ') . $line."\n";
	fwrite($fh2, $fline);
	fclose($fh2);
	//echo date('[Ymd H:i:s] ').$line."\n";
	//@ob_flush(); 
	//flush();
	
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		_log("", "ket noi thanh cong");
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$partner = "";
	$crypto_pair_arr = array('USDTUSD', 'BTCUSD', 'USDCUSD', 'BUSDUSDT');
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	
	
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			/*
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_freelancer) {
				$found = 7;
				$coin = 'USDT';
				break;			
			} else if ($value == $apikey_bos) {
				$found = 8;
				$coin = 'USDT';
				$partner = "BOS";
				break;
			}
			*/
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
					
				}
			} else {
				_log("", "not found in db");
			}
		}
	}
	//@mysqli_close($dbhandle);



	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}

	function get_crypto_price($_crypto_pair_arr, $_auth_token) {
		global $reg_email_address;
		global $api_graphql_host;
		global $api_host;
		$instruments_price_arr = array();
		$crypto_price_info = array('error' => '', 'raw_error' => '', 'http_code' => '');
		///////////////////////////////////////////////////
		$tmp_dto_price_arr = array();
		$instruments_price_query = '{"query":"query ($instrument_id: String, $is_active: ToggleSwitch) {\n  instruments(instrument_id: $instrument_id, is_active: $is_active) {\n    name\n    instrument_id\n    base_currency_id\n    quote_currency_id\n    price {\n      instrument_id\n      ask\n      bid\n      price_24h_change\n      ts\n    }\n  }\n}","variables":{}}';		
		unset($instruments_price_res);
		_log($reg_email_address, "chuan bi ....");
		$instruments_price_res = api_call('/api/v4/securities/statistics', 0, $instruments_price_query , $tmp_dto_price_arr, $_auth_token);
		_log($reg_email_address, "chuan bi xong :");
		$raw_res_body = json_encode($instruments_price_res);
		_log($reg_email_address, "chuan bi ke tiep : " . $raw_res_body);
		if (($instruments_price_res['http_code'] == "200") || ($instruments_price_res['http_code'] == "200 OK")) {
			if (is_array($instruments_price_res['result']['data']['instruments'])) {
				_log($reg_email_address, "phat hien array " . count($instruments_price_res['result']['data']['instruments']));
				for ($j=0; $j<count($_crypto_pair_arr); $j++) {
					_log($reg_email_address, $_crypto_pair_arr[$j]);
				}
				for ($pair_cnt=0; $pair_cnt<count($instruments_price_res['result']['data']['instruments']); $pair_cnt++) {
					unset($target_instrument);
					$target_instrument = $instruments_price_res['result']['data']['instruments'][$pair_cnt];
					if (!empty($target_instrument)) {
						if (!empty($target_instrument['price'])) {
							_log($reg_email_address, "vao phan tich... ");
							if (  (isset($target_instrument['price']['instrument_id'])) && (isset($target_instrument['price']['bid'])) && (isset($target_instrument['price']['ask']))  ) {								
								if (in_array(strtoupper($target_instrument['price']['instrument_id']), $_crypto_pair_arr)) {
									_log($reg_email_address, $target_instrument['price']['instrument_id'] . " co mat !");
									unset($child_crypto_item);
									$child_crypto_item = array();
									if(strtoupper($target_instrument['price']['instrument_id']) == 'BUSDUSDT'){
										$child_crypto_item['pair'] = 'BUSDUSD';
									} else {
										$child_crypto_item['pair'] = strtoupper($target_instrument['price']['instrument_id']);
									}
									$child_crypto_item['buy_price'] = 0;
									$child_crypto_item['sell_price'] = 0;
									
									if (!empty($target_instrument['price']['ask'])) {
										//$crypto_sell_min_price = number_format($cur_pair_stat['ask'],  8, '.', '');	
										$child_crypto_item['sell_price'] = $target_instrument['price']['ask'];
										_log($reg_email_address, $target_instrument['price']['instrument_id'] . " = " . $target_instrument['price']['ask'] . " (sell)");
									}													
									if (!empty($target_instrument['price']['bid'])) {
										$child_crypto_item['buy_price'] = $target_instrument['price']['bid'];
										_log($reg_email_address, $target_instrument['price']['instrument_id'] . " = " . $target_instrument['price']['ask'] . " (buy)");
									}
									$instruments_price_arr[] = $child_crypto_item;
								} else {
									_log($reg_email_address, $target_instrument['price']['instrument_id'] . " not in array");
								}
								/*
								if (strtoupper($target_instrument['price']['instrument_id']) == $_crypto_pair) {							
									$crypto_price_info['buy_price'] = $target_instrument['price']['bid'];
									$crypto_price_info['sell_price'] = $target_instrument['price']['ask'];								
								}
								*/
							} else {
								_log($reg_email_address, "api call /api/v4/securities/statistics ERROR: price.instrument_id or price.ask are empty.");
								//$crypto_price_info['error'] = 'data.instruments.price_bid_ask_are_empty';
								//$crypto_price_info['raw_error'] = $raw_res_body;
							}
						} else {
							_log($reg_email_address, "api call /api/v4/securities/statistics ERROR: price is empty.");
							//$crypto_price_info['error'] = 'data.instruments.price_is_empty';
							//$crypto_price_info['raw_error'] = $raw_res_body;
						}
					} else {
						_log($reg_email_address, "api call /api/v4/securities/statistics ERROR: array is empty day ne");
						//$crypto_price_info['error'] = 'data.instruments_array_is_empty';
						//$crypto_price_info['raw_error'] = $raw_res_body;
					}
				}
				$crypto_price_info['instruments_price_list'] = $instruments_price_arr;
				
			} else {
				_log($reg_email_address, "api call /api/v4/securities/statistics ERROR: is not array day ne");
				$crypto_price_info['error'] = 'data.instruments_is_not_array';
				$crypto_price_info['raw_error'] = $raw_res_body;				
			}
			
			
		} else {
			$crypto_price_info['error'] = 'ng_http_response_code';
			$crypto_price_info['raw_error'] = $raw_res_body;
			$crypto_price_info['http_code'] = $instruments_price_res['http_code'];
		}
		///////////////////////////////////////////////////
		return $crypto_price_info;
	}

	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	//_log("bat dau xu ly...");
	//if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6) || ($found==7) || ($found==8)) {
	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

		
		
		//$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);
		
		//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
		//echo "payment_id: " . $payment_id . "<br/>";
		$json = file_get_contents('php://input');
		$data = json_decode($json, true);
		
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					//$failed_rs['error'] = 'Reached the maximum stack depth';
					_log("", 'Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					_log("", 'Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					//$failed_rs['error'] = 'Incorrect control character';
					_log("", 'Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					//$failed_rs['error'] = 'Syntax error or JSON invalid';
					_log("", 'Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					//$failed_rs['error'] = 'Unknown error';
					_log("", 'Unknown error');
					break;
			}
			
			//throw new Exception($error);
			//_log($failed_rs['error']);
			@mysqli_close($dbhandle);
			_log("", 'A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			}
			
			
			//auth_token
			if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
				$error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
				$errors[] = $error_obj;
			}
			
						
			if (count($errors) == 0) {
				
				$errors_sub = array();
				
				
				//proceed to shift api
				require_once '../include/common.php';
				//require_once '../include/dbconfig.php';
				
				////////////////////////////////////////////////////
				
				//$allowed_currency_arr = array('USDT');
				$allowed_shift_currency_arr = array('USDT', 'BTC', 'USD');
				//receive POST params
				$reg_email_address = trim($data['email_address']);
				//$auth_token = trim($data['auth_token']);
				$private_key = trim($data['auth_token']);
				$currency = strtoupper(trim($data['currency']));
				$crypto_price_arr = array();
								
				_log($reg_email_address, "get crypto price started...");
				
				//$post_data = array();
				//$post_data['exchange'] = "PLUSQO";
				//$post_data['refreshToken'] = $auth_refresh_token;
								
				//$refresh_token_res = api_call('/authentication/user_authentication/refreshAccessToken', 0, '', $post_data, '');
				//if ($refresh_token_res['result']['result'] == 'success') {
					
					//$signin_user_data = array();
					
					//$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
					//if (mysqli_connect_errno() == 0) {
						//mysqli_query($dbhandle, "set names utf8;");
						$allow_access_api = 0;
						
						$my_db_private_key = '';
						$my_db_auth_token = '';
						$my_db_wallet_auth_token = '';
						$my_db_sigin_dt = '';
						$my_db_token_refresh_dt = '';
						$my_db_shift_user_id = '';
						$sql_check_signin = "select a.*, b.shift_user_id from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_email_address";
						//_log($sql_check_signin);
						$rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
						if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
							$allow_access_api = 1;
							while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
								$my_db_auth_token = trim($row_signin['auth_token']);
								$my_db_wallet_auth_token = trim($row_signin['wallet_auth_token']);
								$my_db_sigin_dt = $row_signin['signin_dt'];
								$my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
								$my_db_private_key = trim($row_signin['private_key']);
								$my_db_shift_user_id = $row_signin['shift_user_id'];
								
							}
						}
						//@mysqli_close($dbhandle);
						
						if ($allow_access_api == 1) {
							
							if ($private_key != $my_db_private_key) {
								@mysqli_close($dbhandle);
								header('Content-Type: application/json');
								http_response_code(500);
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'Unauthorized.');
								echo json_encode($ret_rs);
								die();
							} else {
								/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
								$authorization_value = "Bearer " . $my_db_auth_token;
								_log($reg_email_address, $my_db_auth_token);
								$crypto_price_data = get_crypto_price($crypto_pair_arr, $authorization_value);
								if ($crypto_price_data['error'] != '') {
									if ($crypto_price_data['error'] == 'ng_http_response_code') {
										
										$error_message = 'Unauthorized';
										$res_code = 200;
										$error_code = 5;
										if (($crypto_price_data['http_code'] == "401") || ($crypto_price_data['http_code'] == "401 Unauthorized")) {
											_log($reg_email_address, "/api/v4/securities/statistics error " . $crypto_price_data['http_code']);
											$res_code = 401;
										} else {
											if (($crypto_price_data['http_code'] == "500") || ($crypto_price_data['http_code'] == "500 Internal Server Error") || ($crypto_price_data['http_code'] == "503 Service Unavailable")) {
												//if (($statistics_res['http_code'] == "500") || ($statistics_res['http_code'] == "500 Internal Server Error")) {
												//	$error_message = 'invalid auth_token';
												//}
												if ($crypto_price_data['http_code'] == "503 Service Unavailable") {
													$error_code = 6;
													$error_message = 'system is under maintenance.';
													$res_code = 503;
												}
												if (($crypto_price_data['http_code'] == "500") || ($crypto_price_data['http_code'] == "500 Internal Server Error")) {
													
													$res_code = 401;
												}
												
												_log($reg_email_address, "/api/v4/securities/statistics error " . $crypto_price_data['http_code']);
											} else {
												_log($reg_email_address, "/api/v4/securities/statistics error unknown error code");
												$error_code = 6;
												$error_message = 'system is under maintenance fuck you !.';
												$res_code = 500;
											}
										}
										@mysqli_close($dbhandle);
										$ret_rs['result'] = 'failed';
										$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
										header('Content-Type: application/json');
										if ($res_code != 200) {
											http_response_code($res_code);
										}
										echo json_encode($ret_rs);
										die();
										
									} else if ($crypto_price_data['error'] == 'data.instruments_is_not_array') {
										_log($reg_email_address, "/api/v4/securities/statistics ERROR: is not array");
										//foreach($accounts_res['result'] as $key => $value) {
										//	_log($reg_email_address, $key . " = " . $value);
										//}
										@mysqli_close($dbhandle);
										header('Content-Type: application/json');
										http_response_code(500);
										$ret_rs['result'] = 'failed';
										$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'error occurred. please contact administrator for help.');
										echo json_encode($ret_rs);
										die();
									}
								} else {
									
								}
								
								
								//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							}
							
							
							
						} else {
							@mysqli_close($dbhandle);
							header('Content-Type: application/json');
							http_response_code(500);
							$ret_rs['result'] = 'failed';
							$ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'you must sign in to use this API.');
							echo json_encode($ret_rs);
							die();
						}
						
						
					//} else {			
					//	//_log($reg_email_address, "could not connect db !");
					//	@mysqli_close($dbhandle);
					//	header('Content-Type: application/json');
					//	http_response_code(500);
					//	$ret_rs['result'] = 'failed';
					//	$ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'system is under maintenance.');
					//	echo json_encode($ret_rs);
					//	die();
						
					//}
					
					
					//header('Content-Type: application/json');
					//echo json_encode($ret_rs);
					//die();
					@mysqli_close($dbhandle);
					$ret_rs['result'] = 'success';
					//$ret_rs['email_address'] = $reg_email_address;
					$ret_rs['cryptocurrencies'] = $crypto_price_data['instruments_price_list'];					
					header('Content-Type: application/json');
					echo json_encode($ret_rs);
					die();
					
					
					
				//} else {
				//	_log($reg_email_address . " : " . $refresh_token_res['result']['message']);
				//	$ret_rs['result'] = 'failed';
				//	$ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'failed to refresh auth_token');
				//	header('Content-Type: application/json');
				//	echo json_encode($ret_rs);
				//	die();
				//}
				
				
			} else {
				@mysqli_close($dbhandle);
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors[0];
				_log("", $ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
				
			
		}

	} else {
		@mysqli_close($dbhandle);
		header('HTTP/1.0 403 Forbidden');
		die();
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>