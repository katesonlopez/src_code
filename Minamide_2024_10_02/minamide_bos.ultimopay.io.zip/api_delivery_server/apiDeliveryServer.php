<?php

const BASE_API_URL = 'https://xapiserver.com/v4/';
const API_TOKEN = 'wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56';

// Function to make HTTP requests with custom headers
function makeRequest($url, $method, $data = null, $headers = array()) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    // Set request method
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }

    // Set request headers
    $requestHeaders = array();
    foreach ($headers as $key => $value) {
        $requestHeaders[] = "$key: $value";
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $requestHeaders);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return array('error' => $error);
    } else {
        return json_decode($response, true);
    }
}

/** ============      Prevent CORS issue =============**/
// Get the origin from the request headers
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : null;

// Check if the origin is one of the allowed origins
$allowedOrigins = ['http://localhost:3000', 'https://bos.ultimopay.io:3000'];
if (in_array($origin, $allowedOrigins)) {
    header("Access-Control-Allow-Origin: $origin");
}
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-Server-IP, Authorization");
header('Content-Type: application/json');

// Get request method (GET or POST)
$requestMethod = $_SERVER['REQUEST_METHOD'];

// Get request URI
extract($_GET);
$requestUrl = BASE_API_URL . $uri;

// Get request data
$requestData = file_get_contents('php://input');

// Define request headers
$requestHeaders = array(
    'Content-Type' => 'application/json',
    'Authorization' => 'Bearer '.API_TOKEN,
);

// Make request to external API
$response = makeRequest($requestUrl, $requestMethod, $requestData, $requestHeaders);

// Return response to Next.js project
echo json_encode($response);
