<?php

namespace App\Http\Controllers;

use App\FileDetail;
use App\UltimopayAPI_v4;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\File;
use App\User;
use App\Agent;
use App\Merchant;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use mysql_xdevapi\Exception;

class DashboardController extends Controller
{
  public function myPaysIo(Request  $request){
    return view('/pages/mypays_io');
  }

  public function login(Request $request)
  {
    $userName = $request->input("username");
    $password = $request->input("password");
    $response = UltimopayAPI_v4::signInForAjax( $userName, $password );
    $response = json_decode(json_encode($response), true);
    if ($response["result"] === "success") {
      $user = User::where('email', $userName)->first();
      if( $user == null ){
        $data["msg_ex"] = "You are not an agent. Please try another one.";
        $pageConfigs = [
          'bodyClass' => "bg-full-screen-image",
          'blankPage' => true
        ];
        return view('/pages/auth-login', [
          'pageConfigs' => $pageConfigs,
          'data' => $data
        ]);
      }
      else{
        session()->put('auth_token', $response['signinResponse']['auth_token']);
        session()->put("email", $userName);
        $agent = Agent::where("email", $userName)->first();
        if(!$agent){
          $data["msg_ex"] = "You are not an agent. Please try another one.";
          $pageConfigs = [
            'bodyClass' => "bg-full-screen-image",
            'blankPage' => true
          ];
          return view('/pages/auth-login', [
            'pageConfigs' => $pageConfigs,
            'data' => $data
          ]);
        }

        $user = User::where('email', $userName)->first();
        Auth::login($user);

        return redirect()->route("home");
      }
    }
    if(isset($response["error"]))
      $data["msg_ex"] = $response["error"]['errorMessage'];
    else
      $data["msg_ex"] = 'Unable to connect Api.Ultimopay.Io';

    $pageConfigs = [
      'bodyClass' => "bg-full-screen-image",
      'blankPage' => true
    ];
    return view('/pages/auth-login', [
      'pageConfigs' => $pageConfigs,
      'data' => $data
    ]);
  }

  public function home(Request $request){
    if(!auth()->check())
      return redirect()->route('login');

    $balanceUsdt = 0;
    $balanceUsd = 0;

    $merchants = Merchant::where('agent_id', '=', auth()->user()->email)->get();
    return view('/pages/data-list-view', [
      'balanceUsdt' => $balanceUsdt,
      'balanceUsd' => $balanceUsd,
      'breadcrumbs' => null,
      'merchants' => $merchants,
      'error'=>($rs['error'] ?? null)
    ]);
  }

  public function checkCsvFile(Request  $request): int
  {
    $dupCheckFileId = $request->input('dupCheckFileId');
    $fileCount = File::where('dup_check_id', '=', $dupCheckFileId)->count();
    if( $fileCount > 0 )
      return 1;// duplicate
    else
      return 0;
  }

  public function upload(Request $request): int
  {
    $file = $request->file('csvFile');
    if( $file && auth()->check()){
      $fileName = Str::random(20).'_'.$file->getClientOriginalName();
      $file->storeAs('uploads', $fileName);

      $newFile = File::create([
        'dup_check_id' => '',
        'agent_id' => auth()->user()->email,
        'date' => date('Y-m-d H:i:s'),
        'file_name' => $fileName,
        'success' => 0,
        'fail' => 0,
        'merchant' => $request->merchant,
        'usdt'=>0,
        'usd'=>0,
      ]);

      $filePath = storage_path('app/uploads') .'/'. $fileName;
      $fileHandle = fopen($filePath, "r");
      $totalAmountUsdt = 0;
      $totalAmountUsd = 0;
      $dupCheckFileId = '';
      if ( $fileHandle ) {
        $index = 0;
        while (($data = fgetcsv($fileHandle, 1000)) !== FALSE) {
          if( $index == 0 )
            $dupCheckFileId = $data[0];
          if( strtoupper($data[2]) == 'USDT' || strtoupper($data[2]) == 'USD' ){
            FileDetail::create([
              'file_id' => $newFile->id,
              'user_id' => $data[0],
              'amount' => $data[1],
              'currency' => strtoupper($data[2]),
              'comment' => auth()->user()->email.' '.date('Y-m-d H:i:s'),
              'result' => 'pending',
            ]);
            if( strtoupper($data[2]) == 'USDT')
              $totalAmountUsdt += $data[1];
            if( strtoupper($data[2]) == 'USD')
              $totalAmountUsd += $data[1];
          }
          $index++;
        }
        fclose($fileHandle);
      }

      $newFile->usdt = $totalAmountUsdt;
      $newFile->usd = $totalAmountUsd;
      $newFile->dup_check_id = $dupCheckFileId;
      $newFile->save();

      return $newFile->id;
    }

    return 0;
  }

  public function getFileList(Request $request){

    $draw = $request->input('draw');
    $start = $request->input('start');
    $length = $request->input('length');
    $search = $request->input('search')['value'];

    $query = File::query();
    if( strlen(trim($search)) > 0 ){
      $query->where('file_name', 'like', '%'.$search.'%')
        ->orWhere('merchant', 'like', '%'.$search.'%')
        ->orWhere('agent_id', 'like', '%'.$search.'%');
    }
    $query->orderBy('updated_at', 'desc')
      ->skip($start)
      ->take($length);
    $files = $query->get();

    $query = File::query();
    if( strlen(trim($search)) > 0 ){
      $query->where('file_name', 'like', '%'.$search.'%')
        ->orWhere('merchant', 'like', '%'.$search.'%')
        ->orWhere('agent_id', 'like', '%'.$search.'%');
    }
    $filteredCount = $query->orderBy('updated_at', 'desc')->count();
    $totalCount = File::count();
    $detailedData = array();
    $no = $start;
    foreach( $files as $file ){
      $row = array(
        ++$no,
        $file->updated_at,
        $this->formatString($file->file_name, 20),
        $file->success > 0 ? '<span class="success">'.$file->success.'</span>' : '',
        $file->fail > 0 ? '<span class="danger">'.$file->fail.'</span>' : '',
        $file->merchant,
        'USDT: '.$file->usdt.'<br>USD: '.$file->usd,
        /*(count($file->file_details->toArray()) == array_reduce($file->file_details->toArray(), function($carry, $item) {
          return $carry + ($item['result'] === 'success' ? 1 : 0);
        })) ? 'success' : 'failed'.*/
        '<button type="button" class="btn btn-flat-primary waves-effect waves-light detail-view-action"
         detailed_id="'.$file->id.'">
            <i class="feather icon-eye"></i>
         Detail</button>'
      );
      $detailedData[] = $row;
    }

    $result = array(
      "draw" => $draw,
      "recordsTotal" => $totalCount,
      "recordsFiltered" => $filteredCount,
      "data" => $detailedData
    );

    return json_encode( $result );
  }

  public function getFileSummery(Request $request): JsonResponse
  {
    $fileId = $request->input('fileId');
    $detailId = $request->input('detailId');

    if( $fileId == null || strlen(trim($fileId)) == 0 ){
      if( $detailId != null && $detailId > 0){
        $fileDetail = FileDetail::where('id', '=', $detailId)->first();
        $fileId = $fileDetail->file_id;
      }
    }

    $file = File::where('id', '=', $fileId)->first();
    $successCount = FileDetail::where('result', '=', 'success')
      ->where('file_id', '=', $file->id)->count();
    $failCount = FileDetail::where(function($query)
    {
      $query->where('result', '=', 'fail')
        ->orWhere('result', '=', 'fail_rollback');
    })->where('file_id', '=', $file->id)->count();
    $file->success = $successCount;
    $file->fail = $failCount;
    $file->save();

    return response()->json($file);
  }

  public function getFileDetails(Request $request): JsonResponse
  {
    $fileId = $request->input('fileId');
    $details = FileDetail::where('file_id', '=', $fileId)->get();
    return response()->json($details);
  }

  public function getWalletBalance(): JsonResponse
  {
    $result = array('USDT'=>0, 'USD'=>0, 'status'=>'fail');
    $response = UltimopayAPI_v4::walletBalanceForAjax();
    if( isset($response['result']) && $response['result'] === 'success' ){
      foreach($response['wallet'] as $wallet){
        if( $wallet->currency == 'USDT')
          $result['USDT'] = str_replace(',', '', $wallet->balance);
        if( $wallet->currency == 'USD')
          $result['USD'] = str_replace(',', '', $wallet->balance);
      }
      $result['status'] = 'success';
    }
    else{
      $result['status'] = $response['error']->errorMessage;
    }
    return response()->json($result);
  }

  public function returnErrorBalanceCorrection($detailId, $errorType, $reason): FileDetail
  {
    // save file detail log
    $details = FileDetail::where('id', '=', $detailId)->get()->first();
    $details->result = $errorType;
    $details->save();

    // save file summery log
    $failCount = FileDetail::where(function($query)
    {
      $query->where('result', '=', 'fail')
        ->orWhere('result', '=', 'fail_rollback');
    })->where('file_id', '=', $details->file_id)->count();
    $file = File::where('id', '=', $details->file_id)->first();
    $file->fail = $failCount;
    $file->save();

    $details->result = $errorType;
    $details->comment = $reason;
    return $details;
  }

  public function rollbackAndReturnErrorBalanceCorrection($detailId): bool
  {
    $details = FileDetail::where('id', '=', $detailId)->get()->first();
    if( $details == null )
      return false;

    // 1. Correct agent's balance
    // 1-1. Get agent's wallet info
    $agentUserId = '';
    try {
      $params = array(
        'email_address' => auth()->user()->email,
        'user_list' => auth()->user()->email);
      $response = UltimopayAPI_v4::searchUserWalletForAjax($params);
      if ($response["result"] === "success") {
        if (count($response['walletResponse']) == 0)
          return false;

        foreach ($response['walletResponse'] as $wallet) {
          if (strtoupper($wallet->currency) === strtoupper($details->currency)) {
            $agentUserId = $wallet->user_id;
            break;
          }
        }
      } else {
        return false;
      }
    }
    catch (Exception $e) {
      return false;
    }

    // 1-2. Correct agent's balance
    try {
      if (strlen($agentUserId) > 0 ) {
        $params = array(
          'email_address' => auth()->user()->email,
          'amount' => $details->amount,
          'target_address' => auth()->user()->email,
          'target_account_currency' => $details->currency,
          'target_user_id' => $agentUserId,
          'comment' => 'Rollback balance because failure to correct balance for user: '.$details->user_id.' at '.date('Y-m-d H-i-s'),
          'version' => 'sec.2.0.0.1');
        $response = UltimopayAPI_v4::balanceCorrection2ForAjax($params);
        if ($response["result"] !== "success")
          return false;
      } else {
        return false;
      }
    }
    catch (Exception $e) {
      return false;
    }

    return true;
  }

  public function balanceCorrection(Request $request): JsonResponse
  {
    $result = 0;

    $detailId = $request->input('detailId');
    $details = FileDetail::where('id', '=', $detailId)->get()->first();
    if( $details == null )
      return response()->json($this->returnErrorBalanceCorrection(
        $detailId,
        'fail',
        'Error 1: Invalid detail id'));

    // 1. Get user's wallet info
    $userId = '';
    try {
      $params = array(
        'email_address' => auth()->user()->email,
        'user_list' => $details->user_id);
      $response = UltimopayAPI_v4::searchUserWalletForAjax($params);
      if ($response["result"] === "success") {
        foreach ($response['walletResponse'] as $wallet) {
          if (strtoupper($wallet->currency) === strtoupper($details->currency) && $wallet->user_id != null && strlen(trim($wallet->user_id)) > 0) {
            $userId = $wallet->user_id;
            break;
          }
        }

        if (strlen(trim($userId)) == 0) {
          Log::error('userId is empty for: ' . $details->user_id);
          Log::error('searchUserWalletForAjax response:'.json_encode( $response));
          $details->reason = 'Error 2: There is no wallet information for user ' . $details->user_id;
          $details->result = 'fail';
          $details->save();
          return response()->json($this->returnErrorBalanceCorrection(
            $detailId,
            'fail',
            'Error 2: There is no wallet information for user ' . $details->user_id));
        }
      }
      else {
        $details->reason = 'Error 3: Error in get wallet information for user '.$details->user_id.'. Details: ' . $response['error']->errorMessage;
        $details->result = 'fail';
        $details->save();
        return response()->json($this->returnErrorBalanceCorrection(
          $detailId,
          'fail',
          'Error 3: Error in get wallet information for user '.$details->user_id.'. Details: ' . $response['error']->errorMessage));
      }
    }
    catch (Exception $e) {
      $details->reason = 'Exception 1: ' . $e->getMessage().', line:'.$e->getLine().', details: '.$e->getTraceAsString();
      $details->result = 'fail';
      $details->save();
      return response()->json($this->returnErrorBalanceCorrection(
        $detailId,
        'fail',
        'Exception 1: ' . $e->getMessage().', line:'.$e->getLine().', details: '.$e->getTraceAsString()));
    }

    // 2. Correct user's balance
    try {
      $params = array(
        'email_address' => auth()->user()->email,
        'amount' => $details->amount,
        'target_address' => $details->user_id,
        'target_account_currency' => $details->currency,
        'target_user_id' => $userId,
        'comment' => 'From ' . auth()->user()->email . ' to '.$details->user_id.' on agent tool at ' . date('Y-m-d H-i-s'),
        'version' => 'sec.2.0.0.1');
      $response = UltimopayAPI_v4::balanceCorrection2ForAjax($params);

      $details->comment = 'From ' . auth()->user()->email . ' to '.$details->user_id.' on agent tool at ' . date('Y-m-d H-i-s');
      if (!isset($response["result"]) || $response["result"] !== "success") {
        $reason = json_encode($response);
        if(isset($response["result"]))
          $reason = 'Error 4: Error in correct balance for user '.$details->user_id.'. Details: ' . $response['error']->errorMessage;
        $details->result = 'fail';
        $details->reason = $reason;
        $details->save();
        return response()->json($this->returnErrorBalanceCorrection(
          $detailId,
          'fail',
          $reason));
      }
    }
    catch (Exception $e) {
      $details->reason = 'Exception 2: ' . $e->getMessage().', line:'.$e->getLine().', details: '.$e->getTraceAsString();
      $details->result = 'fail';
      $details->save();
      return response()->json($this->returnErrorBalanceCorrection(
        $detailId,
        'fail',
        'Exception 2: ' . $e->getMessage().', line:'.$e->getLine().', details: '.$e->getTraceAsString()));
    }

    // save file detail log
    $details->result = 'success';
    $details->save();

    // save file summery log
    $successCount = FileDetail::where('result', '=', 'success')
      ->where('id', '=', $details->id)->count();
    $failCount = FileDetail::where('result', '=', 'fail')
      ->where('id', '=', $details->id)->count();
    $file = File::where('id', '=', $details->file_id)->first();
    $file->success = $successCount;
    $file->fail = $failCount;
    $file->save();

    return response()->json($details);
  }

  public function balanceCorrectionAgent(Request $request): JsonResponse
  {
    $result = array('result'=>'error', 'reason'=>'');

    $fileId = $request->input('fileId');

    $file = File::where('id', '=', $fileId)->get()->first();
    if( $file->agent_proc == 1 ){
      $result['result'] = 'error';
      $result['reason'] = 'Error 1: This file has already proceeded. Can not process again.';
      return response()->json($result);
    }

    $details = FileDetail::
      where('file_id', '=', $fileId)->
      where('result', '=', 'success')->get();

    if( $details == null || count($details) == 0 ) {
      $result['result'] = 'error';
      $result['reason'] = 'Error 2: There is no items to process';
      return response()->json($result);
    }

    // 1. Calculate total balance
    $usdtAmount = 0;
    $usdtCount = 0;
    $usdAmount = 0;
    $usdCount = 0;
    foreach( $details as $detail){
      if( $detail->result != 'success')
        continue;

      if( strtoupper($detail->currency) == 'USD' ) {
        $usdAmount += (-1) * $detail->amount;
        $usdCount++;
      }
      if( strtoupper($detail->currency) == 'USDT' ) {
        $usdtAmount += (-1) * $detail->amount;
        $usdtCount++;
      }
    }

    // 2. Get agent's wallet info
    $agentUserIdUsd = $agentUserIdUsdt = '';
    try {
      $params = array(
        'email_address' => auth()->user()->email,
        'user_list' => auth()->user()->email);
      $response = UltimopayAPI_v4::searchUserWalletForAjax($params);
      if ($response["result"] === "success") {
        foreach ($response['walletResponse'] as $wallet) {
          if (strtoupper($wallet->currency) === 'USD') {
            $agentUserIdUsd = $wallet->user_id;
          }
          if (strtoupper($wallet->currency) === 'USDT') {
            $agentUserIdUsdt = $wallet->user_id;
          }
        }

        if (strlen(trim($agentUserIdUsd)) == 0 ){
          $result['result'] = 'error';
          $result['reason'] = 'Error 3: There is no wallet information for agent '.auth()->user()->email;
          return response()->json($result);
        }
      }
      else {
        $result['result'] = 'error';
        $result['reason'] = 'Error 4: Error in get wallet information for agent '.auth()->user()->email.'. Details: ' . $response['error']->errorMessage;
        return response()->json($result);
      }
    }
    catch (Exception $e) {
      $result['result'] = 'error';
      $result['reason'] = 'Exception 1: ' . $e->getMessage().', line:'.$e->getLine().', details: '.$e->getTraceAsString();
      return response()->json($result);
    }

    // 3. Correct agent balance
    // 3-1. Correct USD balance
    if( $usdAmount != 0 ) {
      try {
        $params = array(
          'email_address' => auth()->user()->email,
          'amount' => $usdAmount,
          'target_address' => auth()->user()->email,
          'target_account_currency' => 'USD',
          'target_user_id' => $agentUserIdUsd,
          'comment' => 'To ' . $usdCount . ' of merchants on agent tool at ' . date('Y-m-d H-i-s'),
          'version' => 'sec.2.0.0.1');
        $response = UltimopayAPI_v4::balanceCorrection2ForAjax($params);
        if ($response["result"] !== "success") {
          $result['result'] = 'error';
          $result['reason'] = 'Error 5: Error in correct balance for agent ' . auth()->user()->email . '. Details: ' . $response['error']->errorMessage;
          return response()->json($result);
        }
      } catch (Exception $e) {
        $result['result'] = 'error';
        $result['reason'] = 'Exception 3: ' . $e->getMessage() . ', line:' . $e->getLine() . ', details: ' . $e->getTraceAsString();
        return response()->json($result);
      }
    }

    if( $usdtAmount != 0 ) {
      try {
        $params = array(
          'email_address' => auth()->user()->email,
          'amount' => $usdtAmount,
          'target_address' => auth()->user()->email,
          'target_account_currency' => 'USDT',
          'target_user_id' => $agentUserIdUsdt,
          'comment' => 'To ' . $usdtCount . ' of merchants on agent tool at ' . date('Y-m-d H-i-s'),
          'version' => 'sec.2.0.0.1');
        $response = UltimopayAPI_v4::balanceCorrection2ForAjax($params);
        if ($response["result"] !== "success") {
          $result['result'] = 'error';
          $result['reason'] = 'Error 6: Error in correct balance for agent ' . auth()->user()->email . '. Details: ' . $response['error']->errorMessage;
          return response()->json($result);
        }
      } catch (Exception $e) {
        $result['result'] = 'error';
        $result['reason'] = 'Exception 4: ' . $e->getMessage() . ', line:' . $e->getLine() . ', details: ' . $e->getTraceAsString();
        return response()->json($result);
      }
    }

    $file = File::where('id', '=', $fileId)->first();
    $file->agent_proc = 1;
    $file->save();

    $result['result'] = 'success';
    return response()->json($result);
  }

  function retryRollback(Request $request): JsonResponse
  {
    $result = array('result'=>'fail', 'reason'=>'');

    // Get rollback agent and amount
    $detailId = $request->input('detailId');
    $details = FileDetail::where('id', '=', $detailId)->get()->first();
    if( $details == null ) {
      $result['result'] = 'fail';
      $result['reason'] = 'Invalid detailId: '.$detailId;
      return response()->json($result);
    }

    $file = File::where('id', '=', $details->file_id)->first();
    if( $file == null ) {
      $result['result'] = 'fail';
      $result['reason'] = 'Invalid fileId: '.$details->file_id;
      return response()->json($result);
    }

    // Get agent info
    $agentUserId = '';
    try {
      $params = array(
        'email_address' => auth()->user()->email,
        'user_list' => $file->agent_id);
      $response = UltimopayAPI_v4::searchUserWalletForAjax($params);
      if ($response["result"] === "success") {
        foreach ($response['walletResponse'] as $wallet) {
          if (strtoupper($wallet->currency) === strtoupper($details->currency)) {
            $agentUserId = $wallet->user_id;
            break;
          }
        }

        if (strlen(trim($agentUserId)) == 0 ){
          $result['result'] = 'fail';
          $result['reason'] = 'There is no agent info: '.$file->agent_id;
          return response()->json($result);
        }
      }
      else {
        $result['result'] = 'fail';
        $result['reason'] = $response["error"]->errorMessage;
        return response()->json($result);
      }
    }
    catch (Exception $e) {
      $result['result'] = 'fail';
      $result['reason'] = 'Exception: 1' . $e->getMessage().', line:'.$e->getLine().', details: '.$e->getTraceAsString();
      return response()->json($result);
    }

    // Correct balance by increasing
    try {
      $params = array(
        'email_address' => auth()->user()->email,
        'amount' => $details->amount,
        'target_address' => $file->agent_id,
        'target_account_currency' => $details->currency,
        'target_user_id' => $agentUserId,
        'comment' => 'Rollback from ' . auth()->user()->email . ' on agent tool at ' . date('Y-m-d H-i-s'),
        'version' => 'sec.2.0.0.1');
      $response = UltimopayAPI_v4::balanceCorrection2ForAjax($params);
      if ($response["result"] !== "success") {
        $result['result'] = 'fail';
        $result['reason'] = $response["error"]->errorMessage;
        return response()->json($result);
      }
    }
    catch (Exception $e) {
      $result['result'] = 'fail';
      $result['reason'] = 'Exception: 2' . $e->getMessage().', line:'.$e->getLine().', details: '.$e->getTraceAsString();
      return response()->json($result);
    }

    // update database
    $details->result = 'fail';
    $details->save();

    $result['result'] = 'success';
    return response()->json($result);
  }

  function formatString($string, $maxLength = 15): string
  {
    if (strlen($string) <= $maxLength) {
      return $string;
    }

    $start = substr($string, 0, $maxLength / 2);
    $end = substr($string, -$maxLength / 2);

    return $start . '...' . $end;
  }
}

