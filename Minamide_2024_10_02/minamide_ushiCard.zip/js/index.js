$(document).ready(function() {
  // Initialize components
  init_components();

  // Initialize wallet menus
  init_crypto_menu();

  // Initialize wallet tiles
  init_crypto_tiles();

  // Hide zero crypto event handler
  $('#hideZeroBalancesCheckbox').change(function () {
    clearCryptoTiles();
    init_crypto_tiles($('#hideZeroBalancesCheckbox').is(':checked'), $('.wallet-filter').val());
  });

  // Keyword event handler
  $('.wallet-filter').on('input', function(event) {
    event.preventDefault(); // Prevent the default action (e.g., form submission)
    clearCryptoTiles();
    init_crypto_tiles($('#hideZeroBalancesCheckbox').is(':checked'), $('.wallet-filter').val());
  });

  // Keyword event handler
  $('.btn-clear').on('click', function(event) {
    event.preventDefault(); // Prevent the default action (e.g., form submission)
    $('.wallet-filter').val('');
    clearCryptoTiles();
    init_crypto_tiles($('#hideZeroBalancesCheckbox').is(':checked'), '');
  });
});

/**
 * Initialize crypto menu
 * **/
function init_crypto_menu(){
// Sort the CRYPTOS array based on the 'order' property
  CRYPTOS.sort((a, b) => a.order - b.order);

  // Iterate through the sorted CRYPTOS array
  CRYPTOS.forEach(function(crypto) {
    // Create the main currency menu item
    let menuItem = `
      <li>
       <a class="main-txt-color fs-6" data-toggle="collapse" href="#${crypto.title}SubMenu" role="button" aria-expanded="false" aria-controls="${crypto.title}SubMenu">
        <span class="menu-crypto-svg mr-2">${crypto.svg}</span>
        ${crypto.title}
        <i class="bi bi-chevron-down ml-2 float-right"></i>
      </a>
        <div class="collapse" id="${crypto.title}SubMenu">
          <ul class="list-unstyled ml-4">
            <li><a class="main-txt-color fs-6" href="#"><i class="bi bi-currency-exchange mr-2"></i> Sell</a></li>
            <li><a class="main-txt-color fs-6" href="#"><i class="bi bi-cart-check mr-2"></i> Buy</a></li>
            <li><a class="main-txt-color fs-6" href="#"><i class="bi bi-wallet2 mr-2"></i> Withdraw</a></li>
            <li><a class="main-txt-color fs-6" href="#"><i class="bi bi-piggy-bank mr-2"></i> Deposit</a></li>
          </ul>
        </div>
      </li>`;

    // Append the generated menu item to the currencyMenu list
    $('#currencyMenu').append(menuItem);
  });
}

function init_crypto_tiles(hideZero, keywords = ''){
  // Sort the CRYPTOS array based on the 'order' property
  CRYPTOS.sort((a, b) => a.order - b.order);
  let filteredCrypto = CRYPTOS;

  // Filter out zero currencies when it is necessary.
  if( hideZero )
    filteredCrypto = CRYPTOS.filter(crypto => crypto.balance > 0);

  // Filters according keywords
  if( keywords.trim().length > 0 ) {
    const keywordArray = keywords.toLowerCase().split(' ');

    // Create a fuzzy search instance
    const fuse = new Fuse(filteredCrypto, {
      keys: ['title'],
      includeScore: true,
      threshold: 0.3 // Adjust this threshold based on desired fuzziness
    });

    // Filter cryptocurrencies based on whether their title matches any of the keywords
    filteredCrypto = keywordArray.reduce((acc, keyword) => {
      const results = fuse.search(keyword);
      const matches = results.map(result => result.item);
      return [...new Set([...acc, ...matches])]; // Merge results and remove duplicates
    }, []);
  }

  // Iterate through the sorted CRYPTOS array
  filteredCrypto.forEach(function(crypto) {
    // Create the main currency menu item
    let cryptoItem = `
      <div class="currency-tile">
        <div class="currency-ring">
          <img src="assets/images/${crypto.icon}" alt="${crypto.title}" draggable="false">
        </div>
        <div class="mt--1 text-white fs-6">${crypto.balance.toFixed(crypto.float)}</div>
        <div class="light-txt-color fs-7">${crypto.title}</div>
        <a class="btn text-warning" data-toggle="dropdown"><i class="bi bi-list"></i><span>&nbsp</span></a>
        <div class="dropdown-menu dark-back-color">
          <a class="dropdown-item main-txt-color" href="#">Deposit</a>
          <a class="dropdown-item main-txt-color" href="#">Withdraw</a>
          <a class="dropdown-item main-txt-color" href="#">Buy</a>
          <a class="dropdown-item main-txt-color" href="#">Sell</a>
        </div>
      </div>`;

    // Append the generated menu item to the currencyMenu list
    $('.currency-tiles').append(cryptoItem);
  });
}

function clearCryptoTiles(){
  $('.currency-tiles').html('');
}

