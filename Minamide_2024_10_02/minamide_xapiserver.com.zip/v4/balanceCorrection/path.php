<?php 
$path = dirname(__FILE__) . '/log/balanceCorrection.log';
echo $path;
?>