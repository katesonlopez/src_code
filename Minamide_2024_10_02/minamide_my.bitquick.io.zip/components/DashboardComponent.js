// components/DashboardComponent.js
import Link from "next/link";
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from "next/router";
import { userService } from "/services";
import DataTable from "./DataTable";
import Loading from "./Loading";
import { toUsNumber } from "./Utils/calc";
import DataTableMobileDashboard from "./DataTableMobileDashboard";

const reportColumns = {
  default: [
    { Header: "Date/Time(UTC)", accessor: "created_date" },
    { Header: "Coin", accessor: "currency" },
    { Header: "Type", accessor: "type" },
    { Header: "Amount", accessor: "amount" },
    { Header: "Status", accessor: "status" },
  ],
  withdraw: [
    { Header: "Date/Time(UTC)", accessor: "created_date" },
    { Header: "Coin", accessor: "currency" },
    { Header: "Type", accessor: "type" },
    { Header: "Address", accessor: "address" },
    { Header: "Amount", accessor: "amount" },
    { Header: "Status", accessor: "status" },
  ],
  load: [
    { Header: "Date/Time(UTC)", accessor: "datetime" },
    { Header: "Type", accessor: "instant" },
    { Header: "Amount", accessor: "amount" },
    { Header: "Status", accessor: "status" },
  ],
  activity: [
    { Header: "Date/Time(UTC)", accessor: "datetime" },
    { Header: "Description", accessor: "description" },
    { Header: "Out(USD)", accessor: "money_out" },
    { Header: "In(USD)", accessor: "money_in" },
    { Header: "Balance(USD)", accessor: "post_balance" },
  ],
  mobile: [
    { Header: 'Table Data', accessor: 'Data' },
  ],
};

const DashboardComponent = () => {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [wallet, setWallet] = useState(null);
  const [reportData, setReportData] = useState([]);
  const [activeReport, setActiveReport] = useState(1);
  const [columns, setColumns] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [cardBalance, setCardBalance] = useState(0);
  const [pendingTotal, setPendingTotal] = useState(0);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);

  useEffect(() => {

    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const getCardBalance = useCallback(async (user) => {
    try {
      const response = await userService.runApi("cardBalance/", user);
      const { balance } = response.data.cardBalanceResponse;
      setCardBalance(balance);
    } catch {
      setCardBalance(0.0);
    }
  }, []);

  const getReport = useCallback(async (type, user) => {
    setIsLoading(true);
    let selectedColumns = reportColumns.default;

    if (type === 4) {
      await getLoad(type, user);
      return;
    }

    if (type === 5) {
      await getCardTransaction(type, user);
      return;
    }

    if (type === 2) {
      selectedColumns = reportColumns.withdraw;
    }

    try {
      user.type = type;
      user.currency = "USDT,BTC,USDC,SOL,BCH,ETH,LTC,XRP";
      const response = await userService.runApi("getReport/", user);
      if (response.data && response.data.reportResponse) {
        const modifiedReportData = response.data.reportResponse.map((item) => {
          const { updated_date, instrument_id, ...newItem } = item;

          if (user.type === 1 && !isMobile) {
            if (newItem.type === 'deposit' && newItem.crypto_transaction_id.length > 0) {
              const { created_date, crypto_transaction_id: txId, currency, crypto_network } = newItem;
              newItem.created_date = (
                <>
                  <div className="flex justify-content-between">
                    <div className="">{created_date}</div>
                    <button
                      className="button ghost size-smaller"
                      onClick={() => {
                        const addressRows = document.querySelectorAll('.txid');
                        addressRows.forEach(row => row.classList.add('hidden'));

                        const targetElement = document.querySelector(`.txid-${txId}`);
                        if (targetElement) {
                          targetElement.classList.remove('hidden');
                        }
                      }}
                    >
                      <i className="bi bi-chevron-right"></i>
                    </button>
                  </div>
                  <div className={`flex justify-content-between mt-1 hidden txid txid-${txId}`}>
                    <div className="mt-1">TXID: {txId}</div>
                    <button
                      className="button ghost size-smaller"
                      onClick={(event) => {
                        event.preventDefault();
                        let url = ``;
                        if( currency === 'USDT' && crypto_network === 'erc20')
                          url = `https://etherscan.io/tx/${txId}`;
                        if( currency === 'USDT' && crypto_network === 'tron')
                          url = `https://tronscan.org/#/transaction/${txId}`;
                        if( currency === 'USDC')
                          url = `https://etherscan.io/tx/${txId}`;
                        if (currency === 'BTC')
                          url = `https://www.blockchain.com/explorer/search?search=${txId}`;
                        if (currency === 'BCH')
                          url = `https://explorer.btc.com/bch/transaction/${txId}`;
                        if (currency === 'SOL')
                          url = `https://solscan.io/tx/${txId}`;
                        if (currency === 'ETH')
                          url = `https://etherscan.io/tx/${txId}`;
                        if (currency === 'XRP')
                          url = `https://xrpscan.com/tx/${txId}`;
                        if (currency === 'LTC')
                          url = `https://litecoinblockexplorer.net/tx/${txId}`;
                        window.open(url, '_blank');
                      }}
                    >
                      <i className="bi bi-box-arrow-up-right"></i>
                    </button>
                  </div>
                </>
              );
            }
          }

          if (user.type === 2 && !isMobile) {
            if (newItem.type === 'withdrawal' && newItem.crypto_transaction_id.length > 0) {
              const { address, crypto_transaction_id: txId, currency, crypto_network } = newItem;
              newItem.address = (
                <>
                  <div className="flex justify-content-between">
                    <div className="mt-1">{address}</div>
                    <button
                      className="button ghost size-smaller"
                      onClick={() => {
                        const addressRows = document.querySelectorAll('.txid');
                        addressRows.forEach(row => row.classList.add('hidden'));

                        const targetElement = document.querySelector(`.txid-${txId}`);
                        if (targetElement) {
                          targetElement.classList.remove('hidden');
                        }
                      }}
                    >
                      <i className="bi bi-chevron-right"></i>
                    </button>
                  </div>
                  <div className={`flex justify-content-between mt-1 hidden txid txid-${txId}`}>
                    <div className="mt-1">TXID: {txId}</div>
                    <button
                      className="button ghost size-smaller"
                      onClick={(event) => {
                        event.preventDefault();
                        let url = ``;
                        if( currency === 'USDT' && crypto_network === 'erc20')
                          url = `https://etherscan.io/tx/${txId}`;
                        if( currency === 'USDT' && crypto_network === 'tron')
                          url = `https://tronscan.org/#/transaction/${txId}`;
                        if( currency === 'USDC')
                          url = `https://etherscan.io/tx/${txId}`;
                        if (currency === 'BTC')
                          url = `https://www.blockchain.com/explorer/search?search=${txId}`;
                        if (currency === 'BCH')
                          url = `https://explorer.btc.com/bch/transaction/${txId}`;
                        if (currency === 'SOL')
                          url = `https://solscan.io/tx/${txId}`;
                        if (currency === 'ETH')
                          url = `https://etherscan.io/tx/${txId}`;
                        if (currency === 'XRP')
                          url = `https://xrpscan.com/tx/${txId}`;
                        if (currency === 'LTC')
                          url = `https://litecoinblockexplorer.net/tx/${txId}`;
                        window.open(url, '_blank');
                      }}
                    >
                      <i className="bi bi-box-arrow-up-right"></i>
                    </button>
                  </div>
                </>
              );
            }
          }

          if (user.type === 3) {
            newItem.type = newItem.side;
            const { amount, currency, side } = item;
            const txAmount = Number(item.tx_amount);
            const numericAmount = Number(amount);
            if (side === "Buy") {
              newItem.amount = `Buy ${numericAmount} ${currency} (Paid amount ${txAmount.toFixed(2)} USD)`;
              newItem.amountMobile = `${side} ${numericAmount} ${currency} <br/> (Paid ${txAmount.toFixed(2)} USD)`;
            } else if (side === "Sell") {
              newItem.amount = `Sell ${numericAmount} ${currency} (Received amount ${txAmount.toFixed(2)} USD)`;
              newItem.amountMobile = `${side} ${numericAmount} ${currency} <br/> (Received ${txAmount.toFixed(2)} USD)`;
            } else {
              newItem.amount = numericAmount.toFixed(2); // Fallback for other cases
              newItem.amountMobile = numericAmount.toFixed(2);
            }
          }

          return newItem;
        });
        setReportData(modifiedReportData);
      } else {
        setReportData([]);
      }
    } catch {
      setReportData([]);
    } finally {
      setColumns(selectedColumns);
      setActiveReport(type);
      setIsLoading(false);
    }
  }, [isMobile]);

  const getLoad = useCallback(async (type, user, isFirst = 0) => {
    try {
      const response = await userService.runApi("cardLoadHistory/", user);
      if (isFirst === 0) {
        const modifiedReportData = response.data.cardLoadHistoryResponse.map((item) => ({
          ...item,
          instant: item.instant * 1 === 1 ? 'Standard' : 'Delayed',
        }));
        setReportData(modifiedReportData);
        setActiveReport(type);
        setColumns(reportColumns.load);
        setIsLoading(false);
      }

      const transactions = response.data.cardLoadHistoryResponse || [];
      const pendingAmounts = transactions.filter(transaction => transaction.status === "PENDING");
      const pendingTotal1 = pendingAmounts.reduce((total, transaction) => total + parseFloat(transaction.amount), 0).toFixed(2);
      setPendingTotal(pendingTotal1);
    } catch {
      setReportData([]);
      setIsLoading(false);
    }
  }, []);

  const getCardTransaction = useCallback(async (type, user) => {
    try {
      const response = await userService.runApi("cardTransaction/", user);
      setReportData(response.data.cardTransactionResponse.transaction_history);
      setActiveReport(type);
      setColumns(reportColumns.activity);
      setIsLoading(false);
    } catch {
      setReportData([]);
      setIsLoading(false);
    }
  }, []);

  const walletBalance = useCallback(async (user) => {
    try {
      const response = await userService.walletBalance(user);
      const resd = response.data.wallet;
      const order = userService.getCurrencyOrder();

      // Sort the array using the order
      resd.sort((a, b) => order.indexOf(a.currency) - order.indexOf(b.currency));
      resd.forEach(item => item.balance = parseFloat(item.balance.replace(",", "")));
      setWallet(resd);
    } catch (error) {
      console.log(error);
      router.push("/");
    }
  }, [router]);

  const fetchUserData = useCallback(async () => {
    const userJson = localStorage.getItem("user");
    if (userJson) {
      const userSer = JSON.parse(userJson);
      const user = userSer.res.data.signinResponse;
      setUser(user);

      try {
        await Promise.all([
          walletBalance(user),
          getCardBalance(user),
          getReport(activeReport, user)
        ]);
      } catch (error) {
        console.error(error);
      }
    }
  }, []);

  useEffect(() => {
    fetchUserData();

    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [fetchUserData]);

  useEffect(() => {
    localStorage.removeItem('beforeSignIn');
  }, []);

  const handleMenuButtonClick = (event) => {
    const button = event.currentTarget;
    const dropdownMenu = button.nextElementSibling;

    // Close any other open dropdowns
    document.querySelectorAll('.dropdown-menu.show').forEach((menu) => {
      if (menu !== dropdownMenu) {
        menu.classList.remove('show');
        menu.removeAttribute('data-popper-placement');
        menu.removeAttribute('style');
      }
    });

    // Toggle the .show class on the clicked dropdown menu
    dropdownMenu.classList.add('show');
    dropdownMenu.setAttribute('data-popper-placement', 'bottom-start');
    dropdownMenu.style.position = 'absolute';
    dropdownMenu.style.inset = '0px auto auto 0px';
    dropdownMenu.style.margin = '0px';
    dropdownMenu.style.transform = 'translate3d(0px, 23px, 0px)';
  };

  if (!user) return <Loading />;

  return (
    <>
      {user && wallet ? (
        <main>
          <div className="container-fluid ppx-4 pb-4">
            <div className="row pt-3 justify-content-start">

              <div className="row align-items-center mt-4 mb-4">
                <div className="col-lg-6 col-md-12 d-flex flex-column align-items-center text-center text-lg-start mb-4 mb-lg-0">
                  <p className="blue-neon">bitquick</p>
                  <p className="white-neon mb-4">BANK CARD</p>
                  <div className="row w-100">
                    <div className={pendingTotal > 0 ? "col-6 text-center" : "col-12 text-center"}>
                      <p className="card-balance-label">Card Balance</p>
                      <div className="text-balance">
                        <span className="mb-3 card-balance-value">{toUsNumber(cardBalance)}</span>
                        <span className="text-white ms-2">USD</span>
                      </div>
                    </div>
                    { pendingTotal > 0 &&
                      <div className="col-6 text-center">
                        <p className="card-balance-label">Pending Load</p>
                        <div className="text-balance">
                          <span className="mb-3 card-balance-value">{toUsNumber(pendingTotal.toFixed(2))}</span>
                          <span className="text-white ms-2">USD</span>
                        </div>
                      </div>
                    }
                  </div>
                  <a className="button primary kyc-status ps-5 pe-5" href={`/user/card/load`}>Load</a>
                </div>
                <div className="col-lg-6 col-md-12 d-flex justify-content-center">
                  <img
                    src="/assets/img/card.png"
                    className="visa-card-img"
                    alt="logo"/>
                </div>
              </div>

              <hr/>

              <section className="tiles-container">
                <div align="center" className="tile">
                  <div className="main-frm card-frm">
                    <div className="flex justify-content-between">
                      <div className="p-0">
                        <p className="ttl-p white-stroke">BITCOIN</p>
                        <p className="p-0 m-0 amount-p text-start mt-4">
                          <b>
                            {wallet ? (
                              toUsNumber(Number(wallet[1].balance).toFixed(8))
                            ) : (
                              <i>loading..</i>
                            )}
                          </b>
                          <br />
                          <font>BTC</font>
                        </p>
                      </div>
                      <div align="right" className="sub-block">
                        <div className="icon_d">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width={20}
                            height={20}
                            fill="currentColor"
                            className="bi bi-currency-bitcoin"
                            viewBox="0 0 16 16"
                          >
                            <path d="M5.5 13v1.25c0 .138.112.25.25.25h1a.25.25 0 0 0 .25-.25V13h.5v1.25c0 .138.112.25.25.25h1a.25.25 0 0 0 .25-.25V13h.084c1.992 0 3.416-1.033 3.416-2.82 0-1.502-1.007-2.323-2.186-2.44v-.088c.97-.242 1.683-.974 1.683-2.19C11.997 3.93 10.847 3 9.092 3H9V1.75a.25.25 0 0 0-.25-.25h-1a.25.25 0 0 0-.25.25V3h-.573V1.75a.25.25 0 0 0-.25-.25H5.75a.25.25 0 0 0-.25.25V3l-1.998.011a.25.25 0 0 0-.25.25v.989c0 .137.11.25.248.25l.755-.005a.75.75 0 0 1 .745.75v5.505a.75.75 0 0 1-.75.75l-.748.011a.25.25 0 0 0-.25.25v1c0 .138.112.25.25.25L5.5 13zm1.427-8.513h1.719c.906 0 1.438.498 1.438 1.312 0 .871-.575 1.362-1.877 1.362h-1.28V4.487zm0 4.051h1.84c1.137 0 1.756.58 1.756 1.524 0 .953-.626 1.45-2.158 1.45H6.927V8.539z" />
                          </svg>
                        </div>
                        <div className="dropdown position-relative">
                          <a type="button" className="button tool ghost menu-button me-1 mt-2"
                             role="button"
                             id="btc-dropdown"
                             data-bs-toggle="dropdown"
                             aria-haspopup="true"
                             aria-expanded="false"
                             style={{ visibility: 'visible' }}
                             onClick={handleMenuButtonClick}
                             data-nsfw-filter-status="sfw">
                            <i className="bi bi-list"></i>
                          </a>
                          <ul className="dropdown-menu" aria-labelledby="btc-dropdown">
                            <li>
                              <Link className="dropdown-item" href={`/user/deposit/${
                                wallet ? wallet[1].currency : ""
                              }`}>
                                Deposit
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/withdraw/${
                                wallet ? wallet[1].currency : ""
                              }`}>
                                Withdraw
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/buy/${
                                wallet ? wallet[1].currency : ""
                              }`}>
                                Buy
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/sell/${
                                wallet ? wallet[1].currency : ""
                              }`}>
                                Sell
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div align="center" className="tile">
                  <div className="main-frm card-frm">
                    <div className="flex justify-content-between">
                      <div className="p-0">
                        <p className="ttl-p white-stroke">TETHER</p>
                        <p className="p-0 m-0 amount-p text-start mt-4">
                          <b>
                            {wallet ? (
                              toUsNumber(Number(wallet[0].balance).toFixed(6))
                            ) : (
                              <i>loading..</i>
                            )}
                          </b>
                          <br />
                          <font>USDT</font>
                        </p>
                      </div>
                      <div align="right" className="sub-block">
                        <div className="icon_d">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            x="0px"
                            y="0px"
                            fill="currentColor"
                            width="25"
                            height="25"
                            viewBox="0 0 24 24"
                          >
                            <path d="M 12 1 C 5.935 1 1 5.935 1 12 C 1 18.065 5.935 23 12 23 C 18.065 23 23 18.065 23 12 C 23 5.935 18.065 1 12 1 z M 12 3 C 16.963 3 21 7.038 21 12 C 21 16.963 16.963 21 12 21 C 7.038 21 3 16.963 3 12 C 3 7.038 7.038 3 12 3 z M 7 7 L 7 9 L 11 9 L 11 10.048828 C 8.7935403 10.157378 6 10.631324 6 12 C 6 13.368676 8.7935403 13.842622 11 13.951172 L 11 18 L 13 18 L 13 13.951172 C 15.20646 13.842622 18 13.368676 18 12 C 18 10.631324 15.20646 10.157378 13 10.048828 L 13 9 L 17 9 L 17 7 L 7 7 z M 11 11.027344 L 11 12 L 13 12 L 13 11.027344 C 15.42179 11.151768 16.880168 11.700988 17.003906 11.978516 C 16.863906 12.334516 15.021 13 12 13 C 8.978 13 7.1360937 12.335484 6.9960938 12.021484 C 7.1198324 11.706835 8.5777007 11.152269 11 11.027344 z"></path>
                          </svg>
                        </div>
                        <div className="dropdown position-relative">
                          <a type="button" className="button tool ghost menu-button me-1 mt-2"
                             role="button"
                             id="usdt-dropdown"
                             data-bs-toggle="dropdown"
                             aria-haspopup="true"
                             aria-expanded="false"
                             style={{ visibility: 'visible' }}
                             onClick={handleMenuButtonClick}
                             data-nsfw-filter-status="sfw">
                            <i className="bi bi-list"></i>
                          </a>
                          <ul className="dropdown-menu" aria-labelledby="usdt-dropdown">
                            <li>
                              <Link className="dropdown-item" href={`/user/deposit/${
                                wallet ? wallet[0].currency : ""
                              }`}>
                                Deposit
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/withdraw/${
                                wallet ? wallet[0].currency : ""
                              }`}>
                                Withdraw
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/buy/${
                                wallet ? wallet[0].currency : ""
                              }`}>
                                Buy
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/sell/${
                                wallet ? wallet[0].currency : ""
                              }`}>
                                Sell
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div align="center" className="tile">
                  <div className="main-frm card-frm">
                    <div className="flex justify-content-between">
                      <div className="p-0">
                        <p className="ttl-p white-stroke">USD COIN</p>
                        <p className="p-0 m-0 amount-p text-start mt-4">
                          <b>
                            {wallet ? (
                              toUsNumber(Number(wallet[3].balance).toFixed(6))
                            ) : (
                              <i>loading..</i>
                            )}
                          </b>
                          <br />
                          <font>USDC</font>
                        </p>
                      </div>
                      <div align="right" className="sub-block">
                        <div className="icon_d">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="25"
                            height="25"
                            fill="currentColor"
                            viewBox="0 0 808.05 774.52">
                            <g id="Layer_1"><path className="cls-1" d="m551.76,465.61c0-78.35-47.01-105.21-141.03-116.4-67.15-8.96-80.59-26.86-80.59-58.2s22.39-51.48,67.16-51.48c40.29,0,62.68,13.43,73.87,47.01,2.24,6.72,8.95,11.19,15.67,11.19h35.81c8.96,0,15.67-6.72,15.67-15.67v-2.24c-8.96-49.25-49.25-87.3-100.73-91.78v-53.72c0-8.96-6.72-15.67-17.91-17.91h-33.58c-8.95,0-15.67,6.72-17.91,17.91v51.48c-67.15,8.96-109.68,53.72-109.68,109.69,0,73.87,44.77,102.97,138.79,114.16,62.68,11.19,82.83,24.62,82.83,60.44s-31.34,60.44-73.87,60.44c-58.2,0-78.35-24.63-85.07-58.2-2.23-8.95-8.95-13.43-15.67-13.43h-38.06c-8.95,0-15.67,6.72-15.67,15.67v2.24c8.95,55.96,44.77,96.25,118.64,107.45v53.72c0,8.95,6.72,15.67,17.91,17.91h33.58c8.96,0,15.67-6.72,17.91-17.91v-53.72c67.16-11.2,111.92-58.2,111.92-118.64ZM90.63,270.86c-64.92,172.37,24.62,367.12,199.23,429.79,6.72,4.48,13.43,13.43,13.43,20.15v31.34c0,4.47,0,6.72-2.24,8.95-2.23,8.95-11.19,13.43-20.15,8.95-125.35-40.29-221.61-136.55-261.9-261.9C-48.16,295.48,68.25,69.39,280.9,2.23c2.24-2.23,6.72-2.23,8.96-2.23,8.96,2.23,13.43,8.95,13.43,17.91v31.34c0,11.2-4.48,17.91-13.43,22.39-91.78,33.58-165.65,105.21-199.23,199.23ZM507,11.19c2.23-8.95,11.19-13.43,20.15-8.95,123.11,40.29,221.61,136.55,261.9,264.14,67.16,212.66-49.25,438.75-261.9,505.9-2.24,2.23-6.72,2.23-8.95,2.23-8.96-2.23-13.43-8.95-13.43-17.91v-31.34c0-11.2,4.47-17.91,13.43-22.39,91.78-33.58,165.65-105.21,199.22-199.22,64.92-172.37-24.62-367.12-199.22-429.79-6.72-4.48-13.43-13.43-13.43-22.39v-31.34c0-4.48,0-6.72,2.24-8.96Z"/></g>
                          </svg>
                        </div>
                        <div className="dropdown position-relative">
                          <a type="button" className="button tool ghost menu-button me-1 mt-2"
                             role="button"
                             id="usdc-dropdown"
                             data-bs-toggle="dropdown"
                             aria-haspopup="true"
                             aria-expanded="false"
                             style={{ visibility: 'visible' }}
                             onClick={handleMenuButtonClick}
                             data-nsfw-filter-status="sfw">
                            <i className="bi bi-list"></i>
                          </a>
                          <ul className="dropdown-menu" aria-labelledby="usdc-dropdown">
                            <li>
                              <Link className="dropdown-item" href={`/user/deposit/${
                                wallet ? wallet[3].currency : ""
                              }`}>
                                Deposit
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/withdraw/${
                                wallet ? wallet[3].currency : ""
                              }`}>
                                Withdraw
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/buy/${
                                wallet ? wallet[3].currency : ""
                              }`}>
                                Buy
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/sell/${
                                wallet ? wallet[3].currency : ""
                              }`}>
                                Sell
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div align="center" className="tile">
                  <div className="main-frm card-frm">
                    <div className="flex justify-content-between">
                      <div className="p-0">
                        <p className="ttl-p white-stroke">SOLANA</p>
                        <p className="p-0 m-0 amount-p text-start mt-4">
                          <b>
                            {wallet ? (
                              toUsNumber(Number(wallet[4].balance).toFixed(6))
                            ) : (
                              <i>loading..</i>
                            )}
                          </b>
                          <br />
                          <font>SOL</font>
                        </p>
                      </div>
                      <div align="right" className="sub-block">
                        <div className="icon_d">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="25"
                            height="25"
                            fill="currentColor"
                            viewBox="0 0 24 24">
                            <path fillRule="evenodd" clipRule="evenodd" d="M7.08398 5.22265C7.17671 5.08355 7.33282 5 7.5 5H18.5C18.6844 5 18.8538 5.10149 18.9408 5.26407C19.0278 5.42665 19.0183 5.62392 18.916 5.77735L16.916 8.77735C16.8233 8.91645 16.6672 9 16.5 9H5.5C5.3156 9 5.14617 8.89851 5.05916 8.73593C4.97215 8.57335 4.98169 8.37608 5.08398 8.22265L7.08398 5.22265ZM7.76759 6L6.43426 8H16.2324L17.5657 6H7.76759Z"/><path fillRule="evenodd" clipRule="evenodd" d="M7.08398 15.2226C7.17671 15.0836 7.33282 15 7.5 15H18.5C18.6844 15 18.8538 15.1015 18.9408 15.2641C19.0278 15.4267 19.0183 15.6239 18.916 15.7774L16.916 18.7774C16.8233 18.9164 16.6672 19 16.5 19H5.5C5.3156 19 5.14617 18.8985 5.05916 18.7359C4.97215 18.5734 4.98169 18.3761 5.08398 18.2226L7.08398 15.2226ZM7.76759 16L6.43426 18H16.2324L17.5657 16H7.76759Z"/><path fillRule="evenodd" clipRule="evenodd" d="M7.08398 13.7774C7.17671 13.9164 7.33282 14 7.5 14H18.5C18.6844 14 18.8538 13.8985 18.9408 13.7359C19.0278 13.5733 19.0183 13.3761 18.916 13.2226L16.916 10.2226C16.8233 10.0836 16.6672 10 16.5 10H5.5C5.3156 10 5.14617 10.1015 5.05916 10.2641C4.97215 10.4267 4.98169 10.6239 5.08398 10.7774L7.08398 13.7774ZM7.76759 13L6.43426 11H16.2324L17.5657 13H7.76759Z"/>
                          </svg>
                        </div>
                        <div className="dropdown position-relative">
                          <a type="button" className="button tool ghost menu-button me-1 mt-2"
                             role="button"
                             id="sol-dropdown"
                             data-bs-toggle="dropdown"
                             aria-haspopup="true"
                             aria-expanded="false"
                             style={{ visibility: 'visible' }}
                             onClick={handleMenuButtonClick}
                             data-nsfw-filter-status="sfw">
                            <i className="bi bi-list"></i>
                          </a>
                          <ul className="dropdown-menu" aria-labelledby="sol-dropdown">
                            <li>
                              <Link className="dropdown-item" href={`/user/deposit/${
                                wallet ? wallet[4].currency : ""
                              }`}>
                                Deposit
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/withdraw/${
                                wallet ? wallet[4].currency : ""
                              }`}>
                                Withdraw
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/buy/${
                                wallet ? wallet[4].currency : ""
                              }`}>
                                Buy
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/sell/${
                                wallet ? wallet[4].currency : ""
                              }`}>
                                Sell
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div align="center" className="tile">
                  <div className="main-frm card-frm">
                    <div className="flex justify-content-between">
                      <div className="p-0">
                        <p className="ttl-p white-stroke">BITCOIN CASH</p>
                        <p className="p-0 m-0 amount-p text-start mt-4">
                          <b>
                            {wallet ? (
                              toUsNumber(Number(wallet[5].balance).toFixed(6))
                            ) : (
                              <i>loading..</i>
                            )}
                          </b>
                          <br />
                          <font>BCH</font>
                        </p>
                      </div>
                      <div align="right" className="sub-block">
                        <div className="icon_d">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="25"
                            height="25"
                            fill="currentColor"
                            viewBox="0 0 32 32">
                            <path d="M16 32C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16zm5.236-21.309c-.777-1.972-2.722-2.15-4.988-1.71l-.807-2.813-1.712.491.785 2.74c-.45.128-.907.269-1.362.41l-.79-2.758-1.712.49.806 2.813c-.369.114-.73.225-1.086.327l-.002-.008-2.362.676.525 1.829s1.257-.387 1.243-.357c.693-.2 1.035.139 1.2.467l.92 3.205c.047-.013.11-.03.184-.04l-.181.052 1.287 4.49c.032.227.003.612-.481.752.027.013-1.245.356-1.245.356l.246 2.143 2.229-.64c.414-.118.824-.228 1.226-.34l.816 2.845 1.71-.49-.806-2.815a65.74 65.74 0 001.371-.38l.803 2.803 1.712-.491-.813-2.84c2.831-.991 4.638-2.294 4.113-5.07-.422-2.234-1.725-2.912-3.472-2.836.848-.79 1.214-1.859.643-3.301zm-.651 6.77c.61 2.127-3.1 2.929-4.26 3.263l-1.08-3.77c1.16-.333 4.704-1.71 5.34.508zm-2.322-5.09c.554 1.935-2.547 2.58-3.513 2.857l-.98-3.419c.966-.277 3.914-1.455 4.493.562z" fillRule="oddeven"/>
                          </svg>
                        </div>
                        <div className="dropdown position-relative">
                          <a type="button" className="button tool ghost menu-button me-1 mt-2"
                             role="button"
                             id="bch-dropdown"
                             data-bs-toggle="dropdown"
                             aria-haspopup="true"
                             aria-expanded="false"
                             style={{ visibility: 'visible' }}
                             onClick={handleMenuButtonClick}
                             data-nsfw-filter-status="sfw">
                            <i className="bi bi-list"></i>
                          </a>
                          <ul className="dropdown-menu" aria-labelledby="bch-dropdown">
                            <li>
                              <Link className="dropdown-item" href={`/user/deposit/${
                                wallet ? wallet[5].currency : ""
                              }`}>
                                Deposit
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/withdraw/${
                                wallet ? wallet[5].currency : ""
                              }`}>
                                Withdraw
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/buy/${
                                wallet ? wallet[5].currency : ""
                              }`}>
                                Buy
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/sell/${
                                wallet ? wallet[5].currency : ""
                              }`}>
                                Sell
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div align="center" className="tile">
                  <div className="main-frm card-frm">
                    <div className="flex justify-content-between">
                      <div className="p-0">
                        <p className="ttl-p white-stroke">ETHEREUM</p>
                        <p className="p-0 m-0 amount-p text-start mt-4">
                          <b>
                            {wallet ? (
                              toUsNumber(Number(wallet[6].balance).toFixed(6))
                            ) : (
                              <i>loading..</i>
                            )}
                          </b>
                          <br />
                          <font>ETH</font>
                        </p>
                      </div>
                      <div align="right" className="sub-block">
                        <div className="icon_d">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="25"
                            height="25"
                            fill="currentColor"
                            viewBox="0 0 226.777 226.777">
                            <g><polygon points="112.553,157 112.553,86.977 44.158,116.937"/><polygon points="112.553,82.163 112.553,-0.056 46.362,111.156"/><polygon points="116.962,-0.09 116.962,82.163 184.083,111.566"/><polygon points="116.962,86.977 116.962,157.002 185.405,116.957"/><polygon points="112.553,227.406 112.553,171.085 44.618,131.31"/><polygon points="116.962,227.406 184.897,131.31 116.962,171.085"/></g></svg>
                        </div>
                        <div className="dropdown position-relative">
                          <a type="button" className="button tool ghost menu-button me-1 mt-2"
                             role="button"
                             id="eth-dropdown"
                             data-bs-toggle="dropdown"
                             aria-haspopup="true"
                             aria-expanded="false"
                             style={{ visibility: 'visible' }}
                             onClick={handleMenuButtonClick}
                             data-nsfw-filter-status="sfw">
                            <i className="bi bi-list"></i>
                          </a>
                          <ul className="dropdown-menu" aria-labelledby="eth-dropdown">
                            <li>
                              <Link className="dropdown-item" href={`/user/deposit/${
                                wallet ? wallet[6].currency : ""
                              }`}>
                                Deposit
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/withdraw/${
                                wallet ? wallet[6].currency : ""
                              }`}>
                                Withdraw
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/buy/${
                                wallet ? wallet[6].currency : ""
                              }`}>
                                Buy
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/sell/${
                                wallet ? wallet[6].currency : ""
                              }`}>
                                Sell
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div align="center" className="tile">
                  <div className="main-frm card-frm">
                    <div className="flex justify-content-between">
                      <div className="p-0">
                        <p className="ttl-p white-stroke">LITECOIN</p>
                        <p className="p-0 m-0 amount-p text-start mt-4">
                          <b>
                            {wallet ? (
                              toUsNumber(Number(wallet[7].balance).toFixed(6))
                            ) : (
                              <i>loading..</i>
                            )}
                          </b>
                          <br />
                          <font>LTC</font>
                        </p>
                      </div>
                      <div align="right" className="sub-block">
                        <div className="icon_d">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="25"
                            height="25"
                            fill="currentColor"
                            viewBox="0 0 226.777 226.777">
                            <polygon points="94.718,184.145 107.496,123.31 172.074,79.039 179.644,42.883 115.053,87.335 133.398,0 83.788,0 57.142,127.189 29.975,145.887 23.667,180.781 49.639,162.975 36.281,226.743 195.198,226.743 204.027,184.145"/>
                          </svg>
                        </div>
                        <div className="dropdown position-relative">
                          <a type="button" className="button tool ghost menu-button me-1 mt-2"
                             role="button"
                             id="ltc-dropdown"
                             data-bs-toggle="dropdown"
                             aria-haspopup="true"
                             aria-expanded="false"
                             style={{ visibility: 'visible' }}
                             onClick={handleMenuButtonClick}
                             data-nsfw-filter-status="sfw">
                            <i className="bi bi-list"></i>
                          </a>
                          <ul className="dropdown-menu" aria-labelledby="ltc-dropdown">
                            <li>
                              <Link className="dropdown-item" href={`/user/deposit/${
                                wallet ? wallet[7].currency : ""
                              }`}>
                                Deposit
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/withdraw/${
                                wallet ? wallet[7].currency : ""
                              }`}>
                                Withdraw
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/buy/${
                                wallet ? wallet[7].currency : ""
                              }`}>
                                Buy
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/sell/${
                                wallet ? wallet[7].currency : ""
                              }`}>
                                Sell
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div align="center" className="tile">
                  <div className="main-frm card-frm">
                    <div className="flex justify-content-between">
                      <div className="p-0">
                        <p className="ttl-p white-stroke">RIPPLE</p>
                        <p className="p-0 m-0 amount-p text-start mt-4">
                          <b>
                            {wallet ? (
                              toUsNumber(Number(wallet[8].balance).toFixed(6))
                            ) : (
                              <i>loading..</i>
                            )}
                          </b>
                          <br />
                          <font>XRP</font>
                        </p>
                      </div>
                      <div align="right" className="sub-block">
                        <div className="icon_d">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="23"
                            height="23"
                            fill="currentColor"
                            viewBox="0 0 512 424">
                            <g id="Layer_2" data-name="Layer 2">
                              <g id="Layer_1-2" data-name="Layer 1">
                                <path d="M437,0h74L357,152.48c-55.77,55.19-146.19,55.19-202,0L.94,0H75L192,115.83a91.11,91.11,0,0,0,127.91,0Z"/>
                                <path d="M74.05,424H0L155,270.58c55.77-55.19,146.19-55.19,202,0L512,424H438L320,307.23a91.11,91.11,0,0,0-127.91,0Z"/>
                              </g>
                            </g>
                          </svg>
                        </div>
                        <div className="dropdown position-relative">
                          <a type="button" className="button tool ghost menu-button me-1 mt-2"
                             role="button"
                             id="xrp-dropdown"
                             data-bs-toggle="dropdown"
                             aria-haspopup="true"
                             aria-expanded="false"
                             style={{ visibility: 'visible' }}
                             onClick={handleMenuButtonClick}
                             data-nsfw-filter-status="sfw">
                            <i className="bi bi-list"></i>
                          </a>
                          <ul className="dropdown-menu" aria-labelledby="xrp-dropdown">
                            <li>
                              <Link className="dropdown-item" href={`/user/deposit/${
                                wallet ? wallet[8].currency : ""
                              }`}>
                                Deposit
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/withdraw/${
                                wallet ? wallet[8].currency : ""
                              }`}>
                                Withdraw
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/buy/${
                                wallet ? wallet[8].currency : ""
                              }`}>
                                Buy
                              </Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" href={`/user/sell/${
                                wallet ? wallet[8].currency : ""
                              }`}>
                                Sell
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div align="center" className="tile">
                  <div className="main-frm card-frm">
                    <div className="flex justify-content-between">
                      <div className="p-0">
                        <p className="ttl-p white-stroke">US DOLLAR</p>
                        <p className="p-0 m-0 amount-p text-start mt-4">
                          <b>
                            {wallet ? (
                              toUsNumber(
                                (
                                  Math.floor(wallet[2].balance * 100) / 100
                                ).toFixed(2)
                              )
                            ) : (
                              <i>loading..</i>
                            )}
                          </b>
                          <br />
                          <font>USD</font>
                        </p>
                      </div>
                      <div align="center" className="sub-block">
                        <div className="icon_d">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width={20}
                            height={20}
                            fill="currentColor"
                            className="bi bi-currency-dollar"
                            viewBox="0 0 16 16"
                          >
                            <path d="M4 10.781c.148 1.667 1.513 2.85 3.591 3.003V15h1.043v-1.216c2.27-.179 3.678-1.438 3.678-3.3 0-1.59-.947-2.51-2.956-3.028l-.722-.187V3.467c1.122.11 1.879.714 2.07 1.616h1.47c-.166-1.6-1.54-2.748-3.54-2.875V1H7.591v1.233c-1.939.23-3.27 1.472-3.27 3.156 0 1.454.966 2.483 2.661 2.917l.61.162v4.031c-1.149-.17-1.94-.8-2.131-1.718H4zm3.391-3.836c-1.043-.263-1.6-.825-1.6-1.616 0-.944.704-1.641 1.8-1.828v3.495l-.2-.05zm1.591 1.872c1.287.323 1.852.859 1.852 1.769 0 1.097-.826 1.828-2.2 1.939V8.73l.348.086z" />
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </div>
          <div className="container-fluid px-4 all-rw">
            <div className="row pe-4 ps-4 mt-4 pb-3">
              <div className="col-sm-12">
                <label>ALL TIME TRANSACTION HISTORY</label>
              </div>
            </div>
          </div>
          <div className={`container-fluid ${isMobile ? "px-2" : "px-3"} mb-5`}>
            <div className="mt-1 all-btn pes-3">
              <div className="col-sm-12 flex center">
                <label className="">
                  <button
                    type="button"
                    onClick={() => getReport(1, user)}
                    className={`button size-xl tab-btn ${activeReport === 1 ? "active" : "ghost"} `}
                  >
                    Deposit
                  </button>
                </label>
                <label className="">
                  <button
                    type="button"
                    onClick={() => getReport(2, user)}
                    className={`button size-xl tab-btn ${activeReport === 2 ? "active" : "ghost"} `}
                  >
                    Withdraw
                  </button>
                </label>
                <label className="">
                  <button
                    type="button"
                    onClick={() => getReport(3, user)}
                    className={`button size-xl tab-btn ${activeReport === 3 ? "active" : "ghost"} `}
                  >
                    Exchange
                  </button>
                </label>
                <label className="">
                  <button
                    type="button"
                    onClick={() => getReport(4, user)}
                    className={`button size-xl tab-btn ${activeReport === 4 ? "active" : "ghost"} `}
                  >
                    Load
                  </button>
                </label>
                <label className={`${isMobile ? "w-100" : ""}`}>
                  <button
                    type="button"
                    onClick={() => getReport(5, user)}
                    className={`button size-xl tab-btn ${activeReport === 5 ? "active" : "ghost"} ${isMobile ? "w-100" : ""}`}
                  >
                    Card Activities
                  </button>
                </label>
              </div>
              <div className="tab-body mb-4">
                {isMobile ? (
                  <DataTableMobileDashboard data={reportData} col={reportColumns.mobile} isLoading={isLoading} reportType={activeReport}/>
                ) : (
                  <DataTable data={reportData} col={columns} isLoading={isLoading}/>
                )}
              </div>
            </div>
          </div>
        </main>
      ) : (
        <Loading />
      )}
    </>
  );
};

export default DashboardComponent;
