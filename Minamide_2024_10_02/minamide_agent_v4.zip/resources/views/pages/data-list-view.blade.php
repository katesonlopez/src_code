
@extends('layouts/contentLayoutMaster')

@section('title', 'Dashboard')

@section('vendor-style')
  {{-- vendor files --}}
  <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/datatables.min.css')) }}">
  <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection
@section('page-style')
  {{-- Page css files --}}
  {{-- <link rel="stylesheet" href="{{ asset(mix('css/pages/data-list-view.css')) }}"> --}}
@endsection

@section('content')
  <style>
    #DataTables_Table_0_length select{
      width: 50px;
      height: 30px;
      font-size: 11px;
    }
    .dataTables_length{
      float: left;
    }
    .dataTables_filter{
      float: right;
    }
    select.form-control:not([multiple=multiple]) {
      background-position: calc(100% - 6px) 7px, calc(100% - 20px) 13px, 100% 0;
    }
    .dataTables_length label select{
      padding-top: 6px !important;
    }
  </style>
  <div class="px-5 mx-5 mt-3">
    <form method="POST" id="uploadForm" action="{{url('upload/csvFile')}}" enctype="multipart/form-data">
      @csrf
      <div class="justify-content-around">
        <div class="row">
          <p class="col-sm-6 text-right">Agent USDT Balance: </p>
          <div class="col-sm-6 text-left">
            <span class="spinner-border spinner-border-sm balanceUsdt-load" role="status"></span>
            <span id="balanceUsdt">0</span>
            <span>&nbsp; USDT</span>
          </div>
        </div>
        <div class="row">
          <p class="col-sm-6 text-right">Agent USD Balance: </p>
          <div class="col-sm-6 text-left">
            <span class="spinner-border spinner-border-sm balanceUsd-load" role="status"></span>
            <span class="" id="balance_usd">0</span>
            <span>&nbsp; USD</span>
          </div>
        </div>
        <div class="row">
          <p class="col-sm-6 text-right">Upload Csv file here: </p>
          <input class="col-sm-6 text-left" type="file" name="csvFile" id="csvFile" required accept=".csv" />
        </div>
        <div class="row">
          <p class="col-sm-6 text-right">Merchant: </p>
          <div class="col-sm-6 text-left">
            <select name="merchant" id="merchant" class="ml-auto">
              @foreach ($merchants as $merchant)
                <option value="{{$merchant->merchant}}">{{$merchant->merchant}}</option>
              @endforeach
            </select>
          </div>
        </div>
      </div>
      <div class="d-flex mt-2">
        <button type="button" id="upload" class="btn btn-primary m-auto float-right btn-inline">Upload</button>
      </div>
    </form>

  </div>
  {{-- Data list view starts --}}
  <section id="data-list-view" class="data-list-view-header">
    {{-- DataTable starts --}}
    <div class="">
      <table class="table" id="file_list_table">
        <thead>
        <tr>
          <th>No</th>
          <th style="width: 120px;">Date</th>
          <th>File Name</th>
          <th>Success</th>
          <th>Fail</th>
          <th>Merchant</th>
          <th>Amount</th>
          <th>Detail</th>
        </tr>
        </thead>
        <tbody>
        </tbody>
      </table>
    </div>
    {{-- DataTable ends --}}

  </section>
  {{-- Data list view end --}}
@endsection

<input id="do_modal_confirmDialog" data-toggle="modal" href="#confirmDialog" style="display: none">
<div class="modal fade text-left" id="confirmDialog" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-info white">
        <h5 class="modal-title" id="myModalLabel130">Confirmation Modal</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body p-3">
        <div class="row justify-content-around">
          <div class="col-sm-12">
            <div class="row">
              <p class="col-sm-6 text-right">File Name: </p>
              <p class="col-sm-6 text-left" id="filename"> </p>
            </div>
            <div class="row">
              <p class="col-sm-6 text-right">Merchant:</p>
              <p class="col-sm-6 text-left" id="selectedMerchant"></p>
            </div>
            <div class="row">
              <p class="col-sm-6 text-right">Total Amount to be correct: </p>
              <div class="col-sm-3 text-left">
                <span id="totalAmountUsdt"></span><span>&nbsp; USDT</span>
              </div>
              <div class="col-sm-3 text-left">
                <span id="totalAmountUsd"></span><span>&nbsp; USD</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-info" id="uploadConfirm">Confirm</button>
        <button type="button" class="btn btn-gray" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>

{{-- Modal --}}
<input type="button" id="do_modal_errorDialog" data-toggle="modal" href="#errorDialog" style="display: none">
<div class="modal fade text-left" id="errorDialog" tabindex="-1" role="dialog" data-backdrop="static"
     data-keyboard="false" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header bg-danger white">
        <h5 class="modal-title" id="myModalLabel120">Error</h5>
        <button type="button" class="close"  aria-label="Close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="errorBody">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-gray" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

{{-- Modal --}}
<style>
  #file_detail td{
    padding: 0.3rem 0.3rem 0.3rem 1rem;
  }
  #file_detail{
    margin-bottom: 0;
  }
</style>
<input type="button" id="do_modal_detailDialog" data-toggle="modal" href="#detailDialog" style="display: none">
<div class="modal fade text-left" id="detailDialog" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
    <div class="modal-content" style="max-height: inherit">
      <div class="modal-header bg-info white">
        <h5 class="modal-title" id="detailModalName">Balance correction details view</h5>
        <span class="text-left">Success: <span id="detailModalSuccessCount">0</span></span>
        <span class="text-left">Fail: <span id="detailModalFailCount">0</span></span>
        <span></span>
      </div>
      <div class="modal-body" id="detailBody">
        <div class="table-responsive">
          <table class="table border mb-0">
            <thead>
            <tr>
              <th>Num</th>
              <th>User ID</th>
              <th>Amount</th>
              <th>Currency</th>
              <th>Result</th>
              <th>Action</th>
              <th>Reason</th>
            </tr>
            </thead>
            <tbody id="file_detail">
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-gray closeBtn" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
@section('vendor-script')
  {{-- vendor js files --}}
  <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.bootstrap4.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.select.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/ui/blockUI.min.js')) }}"></script>
@endsection
@section('page-script')
  <script>
    let base_url = '<?php echo url(""); ?>'
  </script>
  {{-- Page js files --}}
  <script src="{{ asset(mix('js/scripts/ui/data-list-view.js')) }}"></script>
@endsection
