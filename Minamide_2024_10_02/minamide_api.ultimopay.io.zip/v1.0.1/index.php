<?php
mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				break;
			}
		}
	}

	function _log($line) {
		//global $fh;
		$fh2 = fopen("/var/www/api.ultimopay.io/v1/signin/log/signin.log" , 'a');
		$fline = date('[Ymd H:i:s] ') . $line."\n";
		fwrite($fh2, $fline);
		fclose($fh2);
		//echo date('[Ymd H:i:s] ').$line."\n";
		//@ob_flush(); 
		//flush();
	}

	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}


	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	_log("bat dau xu ly...");
	if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6)) {


		
		
		//$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);
		
		//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
		//echo "payment_id: " . $payment_id . "<br/>";
		$json = file_get_contents('php://input');
		$data = json_decode($json, true);
		
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					//$failed_rs['error'] = 'Reached the maximum stack depth';
					_log('Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					_log('Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					//$failed_rs['error'] = 'Incorrect control character';
					_log('Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					//$failed_rs['error'] = 'Syntax error or JSON invalid';
					_log('Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					_log('Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					//$failed_rs['error'] = 'Unknown error';
					_log('Unknown error');
					break;
			}
			
			//throw new Exception($error);
			//_log($failed_rs['error']);
			_log('A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			}
			
			//password
			if ((!isset($data['password'])) || (empty($data['password']))) {
				$error_obj = array('errorCode' => 3, 'errorMessage' => 'password parameter is required.');
				$errors[] = $error_obj;
			}
			
			
			if (count($errors) == 0) {
				
				$errors_sub = array();
				
				
				//proceed to shift api
				require_once '../include/common.php';
				require_once '../include/dbconfig.php';
				require_once('../classes/PostAffiliatePro/PapApi.class.php');
				
				////////////////////////////////////////////////////
				function PapLogin($_pap_url, $_username, $_password, $_type){    

					try {

						if ($_type == "merchant") {
							$_merchant_session = new Pap_Api_Session($_pap_url); 
							if(!$_merchant_session->login($_username, $_password)) {
								//die("Cannot login. Message: ".$_merchant_session->getMessage());
								//_log("Merchant Cannot login: ".$_merchant_session->getMessage());
								return;
							}
							return $_merchant_session;

						} else if ($_type == "affiliate") {
							$_aff_session = new Pap_Api_Session($_pap_url); 
							if(!$_aff_session->login($_username,$_password, Pap_Api_Session::AFFILIATE)) {
								//die("Cannot login. Message: ".$_aff_session->getMessage());
								//_log("Affiliate (" . $_username . ") Cannot login: ".$_aff_session->getMessage());
								return;        
								
							}
							return $_aff_session;
							
						}
						
					} catch (Exception $e){
						//die('Error: '.$e->getMessage());
						return;
						
					}

				}

				function PapUserCheck($_username, $_merchant_session) {
					$affiliate_user = array('userid' => '', 'refid' => '', 'error' => '');
					$pap_user_check_request = new Pap_Api_AffiliatesGrid($_merchant_session);
					//Filtering affiliate with username
					$pap_user_check_request->addFilter('username', Gpf_Data_Filter::EQUALS, $_username);

					// sets limit to 30 rows, offset to 0 (first row starts)
					$pap_user_check_request->setLimit(0, 30);

					// sets columns, use it only if you want retrieve other as default columns
					$pap_user_check_request->addParam('columns', new Gpf_Rpc_Array(array(array('id'), array('refid'), array('userid'), 
					array('username'), array('firstname'), array('lastname'), array('rstatus'), array('parentuserid'),
					array('dateinserted'), array('salesCount'), array('clicksRaw'), array('clicksUnique'))));

					// send request
					try {
						$pap_user_check_request->sendNow();
						// request was successful, get the grid result
						$grid = $pap_user_check_request->getGrid();

						// get recordset from the grid
						$pap_user_check_recordset = $grid->getRecordset();	
						
						if (!empty($pap_user_check_recordset)) {
							foreach($pap_user_check_recordset as $rec) {
								if ((trim($rec->get('userid')) != '')  && (trim($rec->get('refid')) != '')){
									$affiliate_user['userid'] = $rec->get('userid');
									$affiliate_user['refid'] = $rec->get('refid');
									break;
								}
								
								//echo 'Affiliate userid: '.$rec->get('userid').', Affiliate name: '.$rec->get('firstname').' '.$rec->get('lastname'). ', refid = ' . $rec->get('refid') .'<br>';
							}
						}
					} catch(Exception $e) {
						//die("API call error: ".$e->getMessage());
						////_log("PapUserCheck::API call error: ".$e->getMessage());
						$affiliate_user['error'] = $e->getMessage();
						return $affiliate_user;
					}

					
					return $affiliate_user;
				}

				function PapCreateUser($_pap_url, $_username, $_first_name, $_last_name, $_password, $_visitor_id, $_merchant_session) {
					$affiliate_user = array('userid' => '', 'refid' => '', 'error' => '');
					$affiliate_parent_user_id = "";
					
					if ((!is_null($_merchant_session)) && (!empty($_merchant_session))) {
						$affiliate = new Pap_Api_Affiliate($_merchant_session);
						$affiliate->setUsername($_username);
						$affiliate->setFirstname($_first_name);
						$affiliate->setLastname($_last_name);
						$affiliate->setNotificationEmail($_username);		
						$affiliate->setPassword($_password);
						//$affiliate->setVisitorId($_visitor_id);
						
						try {
							if ($affiliate->add()) {
								//_log($reg_email_address . "::Affiliate saved successfuly id: " . $affiliate->getUserid() . " / refid: " . $affiliate->getRefid());
								$affiliate_user['userid'] = $affiliate->getUserid();
								$affiliate_user['refid'] = $affiliate->getRefid();
							} else {
								//_log($reg_email_address . "::Cannot save affiliate: ".$affiliate->getMessage());
								$affiliate_user['error'] = "Cannot save affiliate: ".$affiliate->getMessage();
							}
						} catch (Exception $e) {
							//_log("Error while communicating with PAP: ".$e->getMessage());
							$affiliate_user['error'] = $_username . "::Error while communicating with PAP: ".$e->getMessage();
							return $affiliate_user;
						}
						
					} else {
						////_log($_username . "::failed to login as merchant !");
						$affiliate_user['error'] = $_username . "::failed to login as merchant !";
					}

					return $affiliate_user;
				}
				
				
				//receive POST params
				$reg_email_address = trim($data['email_address']);
				$reg_password = trim($data['password']);
				
				if ((!isset($data['two_fa_code'])) || (empty($data['two_fa_code']))) {
					$reg_facode = "";
				} else {
					$reg_facode = $data['two_fa_code'];
				}
				
				
				_log($reg_email_address . ": sign in started...");
				_log($reg_email_address . " / ". $reg_password);
								
				$post_data = array();
				$post_data['username'] = $reg_email_address;
				$post_data['password'] = $reg_password;
				$post_data['exchange'] = "PLUSQO";
				//$post_data['twoFACode'] = $reg_facode;
				$db_add_cnt = 0;
								
				$login_res = api_call('/authentication/user_authentication/exchangeToken', 0, '', $post_data, '');
				if ($login_res['result']['result'] == 'success') {
					
					$signin_user_data = array();
					
					$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
					if (mysqli_connect_errno() == 0) {
						mysqli_query($dbhandle, "set names utf8;");
						
						//check there is data of my shift wallet?
						$shift_wallet_cnt = 0;
						$sql_check_shift_wallet = "select * from cryptocash_shift_wallet where shift_login_email='$reg_email_address'";
						$rs_check_shift_wallet = mysqli_query($dbhandle, $sql_check_shift_wallet);
						$shift_wallet_cnt = mysqli_num_rows($rs_check_shift_wallet);
						
						//check profile exists or not (add new if not exists)
						$has_shift_data = 0;
						$sql_check_profile = "select * from cryptocash_users_profile where email = '$reg_email_address'";
						$rs_check_profile = mysqli_query($dbhandle, $sql_check_profile);
						if (mysqli_num_rows($rs_check_profile) <= 0) {
							$sql_add_profile = "INSERT INTO cryptocash_users_profile (email) VALUES ('$reg_email_address')";
							mysqli_query($dbhandle, $sql_add_profile);
							if (mysqli_affected_rows($dbhandle) > 0) {
								_log($reg_email_address . ": insert new profile OK");
								//$db_add_cnt++;
							} else {								
								_log($reg_email_address . ": insert new profile FAILED: " . $sql_add_profile);
								@mysqli_close($dbhandle);
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact ultimo administrator for help.');
								header('Content-Type: application/json');
								echo json_encode($ret_rs);
								die();
							}
						}
												
						//save user id from shift
						$shift_user_id =  (isset($login_res['result']['user_id']))?strtoupper(trim($login_res['result']['user_id'])):'';
						_log($reg_email_address . "::shift user id = " . $login_res['result']['user_id']);
						if ($shift_user_id != '') {
							
							$sql_check_shift_user_ids = "select * from cryptocash_shift_user_ids where shift_email_address='$reg_email_address' limit 1";
							$rs_check_shift_user_ids = mysqli_query($dbhandle, $sql_check_shift_user_ids);
							if (mysqli_num_rows($rs_check_shift_user_ids) <= 0) {
								$sql_shift_user_id = "INSERT INTO cryptocash_shift_user_ids (shift_email_address, shift_user_id) VALUES ('$reg_email_address', '$shift_user_id')";
								mysqli_query($dbhandle, $sql_shift_user_id);
								if (mysqli_affected_rows($dbhandle) <= 0) {
									_log($reg_email_address . "::failed to cryptocash_shift_user_ids !");
									@mysqli_close($dbhandle);
									$ret_rs['result'] = 'failed';
									$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact ultimo administrator for help.');
									header('Content-Type: application/json');
									echo json_encode($ret_rs);
									die();
								} else {
									_log($reg_email_address . "::success added to cryptocash_shift_user_ids !");
									//$db_add_cnt++;
								}
							}
						}
						
						$user_data = array();
						$user_data['email_address'] = $reg_email_address;
						$user_data['auth_token'] = (isset($login_res['result']['exchange_access_token']))?trim($login_res['result']['exchange_access_token']):"";
						$user_data['auth_refresh_token'] = (isset($login_res['result']['exchange_refresh_token']))?trim($login_res['result']['exchange_refresh_token']):"";
						$user_data['wallet_auth_token'] = (isset($login_res['result']['client_access_token']))?trim($login_res['result']['client_access_token']):"";
						//$user_data['wallet_auth_refresh_token'] = (isset($login_res['result']['client_refresh_token']))?trim($login_res['result']['client_refresh_token']):"";
						$user_data['expires_in'] = (isset($login_res['result']['expires_in']))?intval($login_res['result']['expires_in']):0;
						
						//$ret_rs['result'] = 'success';
						//$ret_rs['signinResponse'] = $user_data;
						
						//add or update merchant_user_signin table
						$merchant = ($found==6)?'LUCKY8':'';
						$sql_check_signin = "select * from cryptocash_merchant_user_signin where email_address = '$reg_email_address'";
						$rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
						if (mysqli_num_rows($rs_check_signin) <= 0) {
							$sql_add_signin = "INSERT INTO cryptocash_merchant_user_signin (email_address, auth_token, auth_refresh_token, wallet_auth_token, merchant) VALUES ('$reg_email_address', '" . $user_data['auth_token'] . "', '" . $user_data['auth_refresh_token'] . "', '" . $user_data['wallet_auth_token'] . "', '$merchant')";
							mysqli_query($dbhandle, $sql_add_signin);
							if (mysqli_affected_rows($dbhandle) > 0) {
								_log("insert cryptocash_merchant_user_signin ok for " . $reg_email_address);								
							} else {
								@mysqli_close($dbhandle);
								_log("insert cryptocash_merchant_user_signin failed:: " . $sql_add_signin);
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact ultimo administrator for help.');
								header('Content-Type: application/json');
								echo json_encode($ret_rs);
								die();
							}
						} else { //update
							$cur_auth_token = "";
							while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
								$cur_auth_token = $row_signin['auth_token'];
							}
							$update_signin_dt = date('Y-m-d H:i:s');
							$sql_update_signin = "UPDATE cryptocash_merchant_user_signin SET auth_token='" . $user_data['auth_token'] . "', auth_refresh_token='" . $user_data['auth_refresh_token'] . "', wallet_auth_token='" . $user_data['wallet_auth_token'] . "', merchant='$merchant', signin_dt='$update_signin_dt' WHERE email_address='$reg_email_address' AND auth_token <> '$cur_auth_token' LIMIT 1";
							mysqli_query($dbhandle, $sql_update_signin);
							if (mysqli_affected_rows($dbhandle) > 0) {
								_log("update cryptocash_merchant_user_signin ok for " . $reg_email_address);								
							} else {								
								_log("update cryptocash_merchant_user_signin failed:: " . $sql_update_signin);
								@mysqli_close($dbhandle);
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact Ultimo administrator for help.');
								header('Content-Type: application/json');
								echo json_encode($ret_rs);
								die();
							}
							
						}
						
						//try to get account data (wallet address, balance)
						/////////////////////////////////////////////////////////////
						$shift_wallet_arr = array();
						$nonce = millitime();
						$nonce = $nonce + 1;
						$tmp_dto_arr = array();
            $auth_token = '';
            $authorization_value = "Bearer " . $auth_token;
						$accounts_res = api_call('/api/v1/accounts', $nonce, '', $tmp_dto_arr, $authorization_value);
						if (($accounts_res['http_code'] == "200") || ($accounts_res['http_code'] == "200 OK")) {
							if (is_array($accounts_res['result'])) {
								/////////////////////////////////////////////////////////
								$accounts_arr = $accounts_res['result'];
								if (count($accounts_arr) > 0) {
									_log($reg_email_address . "::/api/v1/accounts: ok vao roi");
									//$shift_wallet_arr = array();
									for ($coin_cnt=0; $coin_cnt<count($accounts_arr); $coin_cnt++) {
										$cur_coin_stat = $accounts_arr[$coin_cnt];
										unset($shift_wallet_obj);
										$shift_wallet_obj = array('id' => '', 'currency_id' => '', 'balance' => 0);											
										if (!is_null($cur_coin_stat['id']) && (!is_null($cur_coin_stat['balance']))) {
											$shift_wallet_obj['id'] = strtoupper($cur_coin_stat['id']);
											$shift_wallet_obj['currency_id'] = strtoupper($cur_coin_stat['currency_id']);
											$shift_wallet_obj['balance'] = format_coin(number_format($cur_coin_stat['balance'], 10, '.', ','));
											$shift_wallet_arr[] = $shift_wallet_obj;												
										}
										
									}
									if ($shift_wallet_cnt == 0) {
										if ((count($shift_wallet_arr) > 0) && ($shift_user_id != '')) {
											$shift_wallet_added_dt = date('Y-m-d H:i:s');
											for ($s=0; $s<count($shift_wallet_arr); $s++) {
												$cur_wallet = $shift_wallet_arr[$s];
												if (isset($cur_wallet['id'])) {
													$sql_save_shift_wallet = "INSERT INTO cryptocash_shift_wallet (shift_login_email, shift_user_id, shift_account_id, shift_account_currency, added_dt) VALUES ('" . $_SESSION['ultimopay_username'] . "', '" . $shift_user_id . "', '" . $cur_wallet['id'] . "', '" . $cur_wallet['currency_id'] . "', '" . $shift_wallet_added_dt . "')";
													mysqli_query($dbhandle, $sql_save_shift_wallet);
													if (mysqli_affected_rows($dbhandle) <= 0) {
														_log($_SESSION['ultimopay_username'] . "::failed save to cryptocash_shift_wallet ! " . $cur_wallet['currency_id']);
														@mysqli_close($dbhandle);
														$ret_rs['result'] = 'failed';
														$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact Ultimo administrator for help.');
														header('Content-Type: application/json');
														echo json_encode($ret_rs);
														die();
													}
												}
											}
										} else {
											_log($reg_email_address . ":: error::shift_wallet_arr empty or shift_user_id empty !!!");
											@mysqli_close($dbhandle);
											$ret_rs['result'] = 'failed';
											$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact Ultimo administrator for help.');
											header('Content-Type: application/json');
											echo json_encode($ret_rs);
											die();
										}
										
									} else {
										_log($reg_email_address . ":: already had data of shift wallet, no need to add more");
									}
									
								} else {
									_log($reg_email_address . ": /api/v1/accounts error array empty");
									@mysqli_close($dbhandle);
									$ret_rs['result'] = 'failed';
									$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact Ultimo administrator for help.');
									header('Content-Type: application/json');
									echo json_encode($ret_rs);
									die();									
								}
								
								/////////////////////////////////////////////////////////
							} else {
								_log($reg_email_address . ": /api/v1/accounts error not array");
								@mysqli_close($dbhandle);
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact Ultimo administrator for help.');
								header('Content-Type: application/json');
								echo json_encode($ret_rs);
								die();	
							}
						} else {
							if (($accounts_res['http_code'] == "401") || ($accounts_res['http_code'] == "401 Unauthorized")) {
								_log($reg_email_address . ": /api/v1/accounts error " . $accounts_res['http_code']);								
							} else {
								if (($accounts_res['http_code'] == "500") || ($accounts_res['http_code'] == "500 Internal Server Error") || ($accounts_res['http_code'] == "503 Service Unavailable")) {
									_log($reg_email_address . ": /api/v1/accounts error " . $accounts_res['http_code']);
								} else {
									_log($reg_email_address . ": /api/v1/accounts error unknown error code ");
								}
							}
							@mysqli_close($dbhandle);
							$ret_rs['result'] = 'failed';
							$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact Ultimo administrator for help.');
							header('Content-Type: application/json');
							echo json_encode($ret_rs);
							die();
						} 
						
						
						/////////////////////////////////////////////////////////////
						
						
						@mysqli_close($dbhandle);
						
						
					} else {			
						_log($reg_email_address . "::could not connect db when add to cryptocash_users_profile !");
						@mysqli_close($dbhandle);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact Ultimo administrator for help.');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
						
					}
					
					
					//PostAffiliatePro 
					$raw_pap_merchant_login_obj = PapLogin(PAP_URL, MERCHANT_USERNAME, MERCHANT_PASSWORD, "merchant");
					if ((!is_null($raw_pap_merchant_login_obj)) && (!empty($raw_pap_merchant_login_obj))) {
						$pap_affiliate_obj = PapUserCheck($reg_email_address, $raw_pap_merchant_login_obj);
						if ($pap_affiliate_obj['userid'] == '') { //user does not exist, create it (no parent) !			
							
							_log($reg_email_address . "::postaffiliate a/c not found, try to create one...");

              $password = '';
              $res_user = PapCreateUser(PAP_URL, $reg_email_address, $reg_email_address, $reg_email_address, $password, "", $raw_pap_merchant_login_obj);
							if (($res_user['userid'] != '') && ($res_user['refid'] != '')) {
								
								_log($reg_email_address . "::successfuly added affiliate : userid=" . $res_user['userid'] . " / refid=" . $res_user['refid']);
								
							} else {
								
								_log($res_user['error']);
								
							}
							
						} else {
							
							_log($reg_email_address . "::postaffiliate a/c existed, no need to create");
							
						}
					} else {
						_log($reg_email_address . "::failed to login as merchant !");
					}
					
					//if ($db_add_cnt > 0) {
						
						
						$ret_rs['result'] = 'success';
						$ret_rs['signinResponse'] = $user_data;
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					//}
					
				} else {
					if ( strpos(strtolower($login_res['result']['message']), "incorrect username or password") !== false ) {
						//$data['msg'] = 'proc_ng_shift';
						//$data['type'] = '2';
						//$data['msg_ex'] = "Incorrect login email or password";
						_log($reg_email_address . " : " . $login_res['result']['message']);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'invalid credentials.');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					} else if ( strpos(strtolower($login_res['result']['message']), "user does not exist") !== false ) {
						//$data['msg'] = 'proc_ng_shift';
						//$data['type'] = '2';
						//$data['msg_ex'] = "User does not exist";
						_log($reg_email_address . " : " . $login_res['result']['message']);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'invalid credentials.');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					} else if ( strpos(strtolower($login_res['result']['message']), "invalid credentials") !== false ) {
						//$data['msg'] = 'proc_ng_shift';
						//$data['type'] = '2';
						//$data['msg_ex'] = "Incorrect login email or password";
						_log($reg_email_address . " : " . $login_res['result']['message']);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'invalid credentials.');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					} else if ( strpos(strtolower($login_res['result']['message']), "could not connect to PLUSQO") !== false ) {
						//$data['msg'] = 'proc_ng_shift';
						//$data['type'] = '2';
						//$data['msg_ex'] = "Cannot login now, please try again later !";
						_log($reg_email_address . " : " . $login_res['result']['message']);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'system is under maintenance.');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					} else if ( strpos(strtolower($login_res['result']['message']), "2fa required") !== false ) {
						//$data['msg'] = 'proc_ng_shift';
						//$data['type'] = '2';
						//$data['msg_ex'] = "need_2fa_shift";			
						//_log("LOGIN:: " . $username . " " . $data['msg_ex'] . " " . $data['msg_ex2']);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => '2FA code is required.');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					} else if ( strpos(strtolower($login_res['result']['message']), "2fa code invalid") !== false ) {
						//$data['msg'] = 'proc_ng_shift';
						//$data['type'] = '2';
						//$data['msg_ex'] = "Invalid 2FA Code";
						//_log("LOGIN:: " . $username . " : invalid 2fa code");
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'invalid 2FA code.');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					} else if ( strpos(strtolower($login_res['result']['message']), "user is not confirmed") !== false ) {
						//$data['msg'] = 'proc_ng_not_completed';
						//$data['type'] = '2';
						//$data['msg_ex'] = "user is not confirmed";			
						//$_SESSION['temp_email'] = $username;
						//$_SESSION['signup_count'] = 0;
						//_log("LOGIN:: "  . $username . " : user is not confirmed");
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'user is not confirmed.');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					} else {
						//$data['msg'] = 'proc_ng_shift';
						//$data['type'] = '2';
						//$data['msg_ex'] = "Cannot login now due to system error, please try again later";
						_log($reg_email_address . " : " . $login_res['result']['message']);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'system is under maintenance.');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
						
					}
				}
				
				
			} else {
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors[0];
				_log($ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
				
			
		}

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>