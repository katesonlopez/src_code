@extends('layouts.app')

@section('content')
    <div class="row justify-content-center">
        <h5 class="text-secondary mb-3">{{ config('app.url', 'https://paymentapi.ultimopay.io') }}/api/prepayment</h5>
        <div class="row">
            <div class="error-box card border-danger mb-3 col-md-12" style="display: none">
                <div class="card-header bg-danger text-white" style="display: none;">Payment Unsuccessful</div>
                <div class="card-body text-danger">
                    <p>Payment was unsuccessful.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">Parameters of JDB pre-Payment API</div>
                <div class="card-body">
                    <form>
                        @csrf
                        <div class="mb-3">
                            <label for="amount" class="form-label">Amount</label>
                            <input type="text" class="form-control" id="amount" name="amount" placeholder="Enter amount">
                        </div>
                        <div class="mb-3">
                            <label for="product_name" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Enter product name">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" class="form-control" id="email" name="email" placeholder="Enter email address">
                        </div>
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Enter name of user">
                        </div>
                    </form>
                </div>
                <div class="card-footer">
                    <button type="button" class="pre-payment btn btn-primary">Call API</button>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">API Response</div>
                <div class="card-body api-response" style="height: 220px;">
                </div>
                <div class="card-footer" align="right">
                    <a type="button" class="redirect-btn btn btn-success">Redirect</a>
                </div>
            </div>
        </div>
    </div>

    <script src="{{ asset('js/http_code.jquery.com_jquery-3.6.0.js', config('app.env') == 'production') }}"></script>

    <script>
        $(document).ready(function(){
            $('.error-box').hide();

            $('.pre-payment').click(function (){
                $('.error-box').hide();

                let dataToSend = {
                    amount: $('#amount').val(),
                    product_name: $('#product_name').val(),
                    email: $('#email').val(),
                    name: $('#name').val(),
                };

                $.ajax({
                    url: window.location.origin + '/api/prepayment',
                    type: 'POST',
                    data: JSON.stringify(dataToSend),
                    contentType: 'application/json',
                    headers: {
                        'Authorization': API_KEY
                    },
                    success: function(response) {
                        var formattedJSON = JSON.stringify(response, null, 2);
                        $(".api-response").html('<pre>' + formattedJSON + '</pre>');

                        if( response['code'] !== 200 ){
                            $('.error-box').show();
                            $('.error-box .card-header').html(response['message']);
                            $('.error-box .card-body').html(response['body']);
                            $(".api-response").removeClass('text-danger').removeClass('text-success').addClass('text-danger');
                        }
                        else{
                            $('.redirect-btn').attr('href', response['body']);
                            $(".api-response").removeClass('text-danger').removeClass('text-success').addClass('text-success');
                        }
                    },
                    error: function(xhr, textStatus, errorThrown) {
                        var formattedJSON = JSON.stringify(xhr.responseJSON, null, 2);
                        $(".api-response").html('<pre>' + formattedJSON + '</pre>');
                        $(".api-response").removeClass('text-danger').removeClass('text-success').addClass('text-danger');

                        $('.error-box').show();
                        $('.error-box .card-header').html(xhr.responseJSON.message);
                        $('.error-box .card-body').html(xhr.responseJSON.body);
                    }
                });
            })
        });
    </script>
@endsection
