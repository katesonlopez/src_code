<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding("UTF-8");
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders')) {
  function getallheaders()
  {
    if (!is_array($_SERVER)) {
      return array();
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
      if (substr($name, 0, 5) == 'HTTP_') {
        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
      }
    }
    return $headers;
  }
}

function _log($email, $line)
{
  if ($email == "") {
    $fh2 = fopen("/var/www/api.ultimopay.io/v4/payCardFee/log/paycardfee.log", 'a');
  } else {
    $fh2 = fopen("/var/www/api.ultimopay.io/v4/payCardFee/log/" . $email . ".log", 'a');
  }
  $fline = date('[Ymd H:i:s] ') . $line . "\n";
  fwrite($fh2, $fline);
  fclose($fh2);
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../classes/PHPMailer/src/Exception.php';
require '../classes/PHPMailer/src/PHPMailer.php';
require '../classes/PHPMailer/src/SMTP.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_once '../include/dbconfig.php';
  $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
  if (mysqli_connect_errno() != 0) {
    header('Content-Type: application/json');
    http_response_code(500);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
    echo json_encode($ret_rs);
    die();
  } else {
    _log("", "ket noi thanh cong");
    mysqli_query($dbhandle, "set names utf8;");
  }

  $req_api_key = "";
  $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

  foreach (getallheaders() as $name => $value) {
    if ($name == 'Authorization') {
      $req_api_key = trim($value);
      $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
      $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
      if (mysqli_num_rows($partner_rs) > 0) {
        while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
          $cur_api_key = "Bearer " . $row_partner['api_key'];
          if ($req_api_key == $cur_api_key) {
            $req_partner['partner'] = trim($row_partner['partner']);
            $req_partner['api_key'] = trim($row_partner['api_key']);
            $req_partner['website'] = trim($row_partner['website']);
            $req_partner['campaign_id'] = trim($row_partner['campaign_id']);
            $req_partner['card_issue_fee'] = trim($row_partner['card_issue_fee']);
            $req_partner['commission_type_id'] = trim($row_partner['commission_type_id']);
            $selected_api_key = $req_api_key;
            break;
          }
        }
      } else {
        _log("", "not found in db");
      }
    }
  }

  function isValidPassword($password)
  {
    if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
      return FALSE;
    return TRUE;
  }

  function get_wallet_balance($_auth_token)
  {
    global $api_graphql_host;
    global $api_host;
    $wallet_balance_info = array('wallets' => '', 'error' => '');
    ///////////////////////////////////////////////////
    $wallets = array();
    $tmp_dto_arr = array();
    $my_account_balances_query = '{
      "query": "{\\n  accounts_balances {\\n    currency_id\\n    total_balance\\n    exposed_balance\\n    currency {\\n      type\\n      precision\\n      payment_routes {\\n        crypto_network\\n        crypto_address_tag_type\\n      }\\n    }\\n    free_balance\\n    free_balance_USD: free_balance_quoted(quote_currency_id: \\"USD\\")\\n    free_balance_BTC: free_balance_quoted(quote_currency_id: \\"BTC\\")\\n    free_balance_ETH: free_balance_quoted(quote_currency_id: \\"ETH\\")\\n    free_balance_USDT: free_balance_quoted(quote_currency_id: \\"USDT\\")\\n    free_balance_USDC: free_balance_quoted(quote_currency_id: \\"USDC\\")\\n    free_balance_SOL: free_balance_quoted(quote_currency_id: \\"SOL\\")\\n    free_balance_BCH: free_balance_quoted(quote_currency_id: \\"BCH\\")\\n    free_balance_LTC: free_balance_quoted(quote_currency_id: \\"LTC\\")\\n    free_balance_XRP: free_balance_quoted(quote_currency_id: \\"XRP\\")\\n  }\\n}",
      "variables": {}
    }';
    unset($accounts_res);
    $accounts_res = api_call('/api/v4/accounts', 0, $my_account_balances_query, $tmp_dto_arr, $_auth_token);
    if (($accounts_res['http_code'] == "200") || ($accounts_res['http_code'] == "200 OK")) {
      if (!empty($accounts_res['result']['errors'])) {
        $wallet_balance_info['error'] = 'access_token_expired';
      } else {
        if (is_array($accounts_res['result']['data']['accounts_balances'])) {
          $accounts_arr = $accounts_res['result']['data']['accounts_balances'];
          if (count($accounts_arr) > 0) {
            $found_currency = 0;
            for ($coin_cnt = 0; $coin_cnt < count($accounts_arr); $coin_cnt++) {
              $cur_coin_stat = $accounts_arr[$coin_cnt];
              unset($cur_wallet_account);
              $cur_wallet_account = array();
              $cur_wallet_account['currency_id'] = strtoupper($cur_coin_stat['currency_id']);
              $cur_wallet_account['balance'] = $cur_coin_stat['total_balance'];
              $wallets[] = $cur_wallet_account;
            }
            $wallet_balance_info['wallets'] = $wallets;
          }
        } else {
          $wallet_balance_info['error'] = 'data.account_balances_is_empty';
        }
      }
    } else {
      $wallet_balance_info['error'] = 'ng_http_response_code';
    }
    ///////////////////////////////////////////////////
    return $wallet_balance_info;
  }

  function isPossibleMemberCard($dbHandle, $partner, $emailAddress){
    $result = null;

    // Check user tried to issue a normal card or not.
    $sql_check_user_status = "SELECT * FROM cryptocash_user_status 
         WHERE email_address = '$emailAddress' AND created_from='$partner'";
    $rs_check_user_status = mysqli_query($dbHandle, $sql_check_user_status);
    if (mysqli_num_rows($rs_check_user_status) > 0) {
      while ($row_user_status = mysqli_fetch_array($rs_check_user_status, MYSQLI_ASSOC)) {
        _log($emailAddress, "user status in isMemberCardUser: ".json_encode($row_user_status));
        $kyc_status = (int)trim($row_user_status['kyc_status'] == null ? '0' : $row_user_status['kyc_status']);
        $card_activation_status = (int)trim($row_user_status['card_activation_status'] == null ? '0' : $row_user_status['card_activation_status']);
        $card_status = (int)trim($row_user_status['card_status'] == null ? '0' : $row_user_status['card_status']);
        $payment_status = (int)trim($row_user_status['payment_status'] == null ? '0' : $row_user_status['payment_status']);
        /*if( $kyc_status != 0 ){
          $result = 'Please complete KYC check';
          break;
        }*/
        if( $card_status != 0 ){
          $result = 'Because you did try to issue another card, can not apply to member card.';
          break;
        }
        if( $payment_status != 0 ){
          $result = 'Because you did try to payment another card, can not apply to member card.';
          break;
        }
        if( $card_activation_status != 0 ){
          $result = 'Because you did try to active another card, can not apply to member card.';
          break;
        }
      }
    }

    return $result;
  }

  if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!($data)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          _log("", 'Reached the maximum stack depth');
          break;
        case JSON_ERROR_STATE_MISMATCH:
          _log("", 'Incorrect discharges or mismatch mode');
          break;
        case JSON_ERROR_CTRL_CHAR:
          _log("", 'Incorrect control character');
          break;
        case JSON_ERROR_SYNTAX:
          _log("", 'Syntax error or JSON invalid');
          break;
        case JSON_ERROR_UTF8:
          _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
          break;
        default:
          _log("", 'Unknown error');
          break;
      }

      _log("", 'A non-empty request body is required.');
      header('Content-Type: application/json');
      http_response_code(400);
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
      echo json_encode($ret_rs);
      die();
    } else {
      unset($errors);
      $errors = array();

      //email
      if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
        $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
        $errors[] = $error_obj;
      }

      //auth_token
      if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
        $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
        $errors[] = $error_obj;
      }

      $member_card = (int)(trim(isset($data['member_card']) ? $data['member_card'] : "0"));
      //amount
      if ($member_card == 0 && ((!isset($data['amount'])) || (empty($data['amount'])))) {
        $error_obj = array('errorCode' => 4, 'errorMessage' => 'amount parameter is required.');
        $errors[] = $error_obj;
      }

      //currency
      if ($member_card == 0 && ((!isset($data['currency'])) || (empty($data['currency'])))) {
        $error_obj = array('errorCode' => 5, 'errorMessage' => 'currency parameter is required.');
        $errors[] = $error_obj;
      }

      if (count($errors) == 0) {
        $errors_sub = array();

        //proceed to shift api
        require_once '../include/common.php';
        require_once '../include/cognito.php';
        require_once('../classes/PostAffiliatePro/PapApi.class.php');

        function PapLogin($_pap_url, $_username, $_password, $_type)
        {

          try {

            if ($_type == "merchant") {
              $_merchant_session = new Pap_Api_Session($_pap_url);
              if (!$_merchant_session->login($_username, $_password)) {
                return;
              }
              return $_merchant_session;

            } else if ($_type == "affiliate") {
              $_aff_session = new Pap_Api_Session($_pap_url);
              if (!$_aff_session->login($_username, $_password, Pap_Api_Session::AFFILIATE)) {
                return;

              }
              return $_aff_session;

            }

          } catch (Exception $e) {
            return;

          }

        }

        function PapUserCheck($_username, $_merchant_session)
        {
          //$affiliate_user = array('userid' => '', 'refid' => '', 'error' => '');
          $affiliate_user = array('username' => '', 'userid' => '', 'refid' => '', 'parentuserid' => '', 'first_name' => '', 'last_name' => '', 'error' => '');
          $pap_user_check_request = new Pap_Api_AffiliatesGrid($_merchant_session);
          //Filtering affiliate with username
          $pap_user_check_request->addFilter('username', Gpf_Data_Filter::EQUALS, $_username);

          // sets limit to 30 rows, offset to 0 (first row starts)
          $pap_user_check_request->setLimit(0, 30);

          // sets columns, use it only if you want retrieve other as default columns
          $pap_user_check_request->addParam('columns', new Gpf_Rpc_Array(array(array('id'), array('refid'), array('userid'),
            array('username'), array('firstname'), array('lastname'), array('rstatus'), array('parentuserid'),
            array('dateinserted'), array('salesCount'), array('clicksRaw'), array('clicksUnique'))));

          // send request
          try {
            $pap_user_check_request->sendNow();
            // request was successful, get the grid result
            $grid = $pap_user_check_request->getGrid();

            // get recordset from the grid
            $pap_user_check_recordset = $grid->getRecordset();

            if (!empty($pap_user_check_recordset)) {
              foreach ($pap_user_check_recordset as $rec) {
                if ((trim($rec->get('userid')) != '') && (trim($rec->get('refid')) != '')) {
                  $affiliate_user['username'] = $rec->get('username');
                  $affiliate_user['userid'] = $rec->get('userid');
                  $affiliate_user['refid'] = $rec->get('refid');
                  $affiliate_user['parentuserid'] = $rec->get('parentuserid');
                  $affiliate_user['first_name'] = $rec->get('firstname');
                  $affiliate_user['last_name'] = $rec->get('lastname');
                  break;
                }

              }
            }
          } catch (Exception $e) {
            $affiliate_user['error'] = $e->getMessage();
            return $affiliate_user;
          }


          return $affiliate_user;
        }

        //receive POST params
        $reg_email_address = trim($data['email_address']);
        $private_key = trim($data['auth_token']);
        $amount_fee = trim(isset($data['amount']) ? $data['amount'] : '0');
        $used_currency = strtoupper(trim(isset($data['currency']) ? $data['currency'] : 'USD'));
        _log($reg_email_address, "pay card fee started...");

        $nonce = millitime();
        $allow_access_api = 0;
        $my_db_private_key = '';
        $my_db_auth_token = '';
        $my_db_shift_user_id = '';
        $my_db_wallet = array('currency' => '', 'user_id' => '', 'account_id' => '');
        $my_db_payment_status = 2;

        $sql_check_signin = "select a.*, b.*, c.debit_card_id, c.acc_no, c.debit_card_num from cryptocash_merchant_user_signin a, cryptocash_shift_wallet b, cryptocash_jdb_debit_card c where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_login_email AND a.email_address = c.email_address";
        _log($reg_email_address, $sql_check_signin);
        $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
        if (mysqli_num_rows($rs_check_signin) > 0) { //allow access API
          $allow_access_api = 1;
          while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
            $my_db_auth_token = trim($row_signin['auth_token']);
            $my_db_private_key = trim($row_signin['private_key']);
            if ($my_db_shift_user_id == '') {
              $my_db_shift_user_id = trim($row_signin['shift_user_id']);
            }
            if (strtoupper(trim($row_signin['shift_account_currency'])) == $used_currency) {
              $my_db_wallet['currency'] = $used_currency;
              $my_db_wallet['user_id'] = trim($row_signin['shift_user_id']);
              $my_db_wallet['account_id'] = trim($row_signin['shift_account_id']);
            }
          }
        }
        $authorization_value = "Bearer " . $my_db_auth_token;
        $sql_check_user_status = "SELECT payment_status FROM cryptocash_user_status WHERE email_address = '$reg_email_address' AND created_from='" . $req_partner['partner'] . "'";
        $rs_check_user_status = mysqli_query($dbhandle, $sql_check_user_status);
        if (mysqli_num_rows($rs_check_user_status) > 0) {
          while ($row_user_status = mysqli_fetch_array($rs_check_user_status, MYSQLI_ASSOC)) {
            $my_db_payment_status = intval($row_user_status['payment_status']);
          }
        }

        $shift_user_id = '';
        $sql_get_shift_user_id = "select * from cryptocash_shift_user_ids where shift_email_address='$reg_email_address' limit 1";
        $rs_get_shift_user_id = mysqli_query($dbhandle, $sql_get_shift_user_id);
        if (mysqli_num_rows($rs_get_shift_user_id) == 1) {
          while ($row_shift_user_id = mysqli_fetch_array($rs_get_shift_user_id, MYSQLI_ASSOC)) {
            $shift_user_id = $row_shift_user_id['shift_user_sub_id'];
          }
        }

        if ($my_db_payment_status == 0) {
          if ($allow_access_api == 1) {
            if ($private_key != $my_db_private_key) {
              @mysqli_close($dbhandle);
              header('Content-Type: application/json');
              http_response_code(500);
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'Unauthorized.');
              echo json_encode($ret_rs);
              die();
            } else {
              // If the user wants to pay member card fee, do it.
              if( $member_card == 1 ){
                // Check if user can pay membership fee
                $memberShipPossibility = isPossibleMemberCard(
                  $dbhandle, $req_partner['partner'], $data['email_address']);
                if( $memberShipPossibility != null ){
                  @mysqli_close($dbhandle);
                  header('Content-Type: application/json');
                  http_response_code(400);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => 17, 'errorMessage' => $memberShipPossibility);
                  echo json_encode($ret_rs);
                  die();
                }

                // Pay membership card fee without payment by update payment_status in 'cryptocash_user_status' table
                $payment_dt = date('Y-m-d H:i:s');
                $payment_dt_utc = date('Y/m/d H:i:s', strtotime($payment_dt) - 32400);
                _log($reg_email_address, "try update payment status in member card...");

                $sql_update_user_status = "UPDATE `cryptocash_user_status` 
                    SET `payment_status` = 2, `payment_dt` = '$payment_dt' 
                    WHERE `email_address` = '$reg_email_address' 
                      AND created_from != 'XEXON' 
                      AND created_from = '".$req_partner['partner']."'";
                _log($reg_email_address, "query to update payment status in member card: $sql_update_user_status");
                if (mysqli_query($dbhandle, $sql_update_user_status)) {

                  // Update 'cryptocash_jdb_debit_card' table including member_card status
                  $invoice_id = "XE" . generate_id();
                  $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card 
                    SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='$used_currency', amount_fee_fiat='$amount_fee', updated_dt='$payment_dt', member_card=1 
                    WHERE email_address='$reg_email_address' 
                      AND created_from != 'XEXON' 
                      AND created_from = '".$req_partner['partner']."'";
                  _log($reg_email_address, "query to update cryptocash_jdb_debit_card in member card: $sql_update_debit_card");
                  $send_mail_flag = 0;
                  if (mysqli_query($dbhandle, $sql_update_debit_card)) {
                    _log($reg_email_address, " update cryptocash_jdb_debit_card OK !");
                    $send_mail_flag = 1;
                  } else {
                    _log($reg_email_address, " update cryptocash_jdb_debit_card FAILED !");
                  }
                  _log($reg_email_address, "::" . $sql_update_debit_card);

                  // Update 'cryptocash_users_profile' table
                  $update_shift_profile_sql = "UPDATE cryptocash_users_profile 
                    SET shift_update_dt='$payment_dt' 
                    WHERE email='$reg_email_address' 
                      AND created_from='" . $req_partner['partner'] . "' LIMIT 1";
                  mysqli_query($dbhandle, $update_shift_profile_sql);
                  _log($reg_email_address, "::" . $update_shift_profile_sql);
                  @mysqli_close($dbhandle);

                  // Try adding commission PAP
                  $raw_pap_merchant_login_obj = PapLogin(PAP_URL, MERCHANT_USERNAME, MERCHANT_PASSWORD, "merchant");
                  if ((!is_null($raw_pap_merchant_login_obj)) && (!empty($raw_pap_merchant_login_obj))) {
                    $pap_affiliate_obj = PapUserCheck($reg_email_address, $raw_pap_merchant_login_obj);
                    if (trim($pap_affiliate_obj['refid']) != '') {
                      _log($reg_email_address, "::PapUserCheck::found user with refid = " . $pap_affiliate_obj['refid'] . ", parentuserid = " . $pap_affiliate_obj['parentuserid']);
                      if (trim($pap_affiliate_obj['parentuserid']) != '') {
                        //Create new transaction:
                        $transaction = new Pap_Api_Transaction($raw_pap_merchant_login_obj);
                        //Fill custom data:
                        $transaction->setCampaignid($req_partner['campaign_id']);
                        $transaction->setTotalCost($req_partner['card_issue_fee']);
                        $transaction->setCommTypeId($req_partner['commission_type_id']);
                        //$transaction->setStatus("A");
                        $transaction->setUserid($pap_affiliate_obj['parentuserid']);
                        $transaction->setOrderId($pap_affiliate_obj['username']);
                        $transaction->setProductId("Card Issue(" . $req_partner['partner'] . ")");
                        $transaction->setData(1, $pap_affiliate_obj['first_name'] . " " . $pap_affiliate_obj['last_name']);
                        //also count multi-tier commissions for parent affiliates
                        $transaction->setMultiTierCreation("Y");
                        //Adding transaction
                        if ($transaction->add()) {
                          _log($reg_email_address, "::commission added ok for user id: " . $pap_affiliate_obj['parentuserid'] . " / transaction id: " . $transaction->getTransId());
                        } else {
                          _log($reg_email_address, "::commission added error for user id: " . $pap_affiliate_obj['parentuserid'] . " / error message: " . $transaction->getMessage());
                        }
                      }
                    } else {
                      _log($reg_email_address, "::PapUserCheck::user does not exist!");
                    }
                  } else {
                    _log($reg_email_address, "::failed to login as merchant!");
                  }

                  http_response_code(200);
                  $ret_rs['result'] = 'success';
                  $ret_rs['payCardFeeResponse'] = array('email_address' => $reg_email_address, 'payment_status' => "2", 'payment_date' => $payment_dt_utc);
                  header('Content-Type: application/json');
                  echo json_encode($ret_rs);
                  die();
                } else {
                  _log($reg_email_address, "update failed :: " . $sql_update_user_status);
                  @mysqli_close($dbhandle);
                  header('Content-Type: application/json');
                  http_response_code(500);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => 14, 'errorMessage' => 'could not update payment status.');
                  echo json_encode($ret_rs);
                  die();
                }
              }

              $allow_go_next = 0;
              $wallet_info = get_wallet_balance($authorization_value);
              if (($wallet_info['error'] == '') && ($wallet_info['wallets'] !== '')) {
                $my_wallets = $wallet_info['wallets'];
                if (is_array($my_wallets)) {
                  for ($w = 0; $w < count($my_wallets); $w++) {
                    $cur_my_wallet = $my_wallets[$w];
                    if ($cur_my_wallet['currency_id'] == $used_currency) {
                      if ($cur_my_wallet['currency_id'] == 'BTC') {
                        $calculated_card_fee_in_btc = format_coin(number_format($amount_fee, 10, '.', ''));
                        if ($calculated_card_fee_in_btc <= $cur_my_wallet['balance']) {
                          $allow_go_next = 1;
                        }
                        break;
                      } else if ($cur_my_wallet['currency_id'] == 'USDT') {
                        $calculated_card_fee_in_usdt = format_fiat(number_format($amount_fee, 10, '.', ','), 6);
                        if ($calculated_card_fee_in_usdt <= $cur_my_wallet['balance']) {
                          $allow_go_next = 1;
                        }
                        break;
                      } else if ($cur_my_wallet['currency_id'] == 'BUSD') {
                        $calculated_card_fee_in_busd = format_fiat(number_format($amount_fee, 10, '.', ','), 6);
                        if ($calculated_card_fee_in_busd <= $cur_my_wallet['balance']) {
                          $allow_go_next = 1;
                        }
                        break;
                      } else if ($cur_my_wallet['currency_id'] == 'USDC') {
                        $calculated_card_fee_in_usdc = format_fiat(number_format($amount_fee, 10, '.', ','), 6);
                        if ($calculated_card_fee_in_usdc <= $cur_my_wallet['balance']) {
                          $allow_go_next = 1;
                        }
                        break;
                      } else if ($cur_my_wallet['currency_id'] == 'SOL') {
                        $calculated_card_fee_in_sol = format_fiat(number_format($amount_fee, 10, '.', ','), 6);
                        if ($calculated_card_fee_in_sol <= $cur_my_wallet['balance']) {
                          $allow_go_next = 1;
                        }
                        break;
                      } else if ($cur_my_wallet['currency_id'] == 'BCH') {
                        $calculated_card_fee_in_bch = format_fiat(number_format($amount_fee, 10, '.', ','), 6);
                        if ($calculated_card_fee_in_bch <= $cur_my_wallet['balance']) {
                          $allow_go_next = 1;
                        }
                        break;
                      } else if ($cur_my_wallet['currency_id'] == 'ETH') {
                        $calculated_card_fee_in_eth = format_fiat(number_format($amount_fee, 10, '.', ','), 6);
                        if ($calculated_card_fee_in_eth <= $cur_my_wallet['balance']) {
                          $allow_go_next = 1;
                        }
                        break;
                      } else if ($cur_my_wallet['currency_id'] == 'LTC') {
                        $calculated_card_fee_in_ltc = format_fiat(number_format($amount_fee, 10, '.', ','), 6);
                        if ($calculated_card_fee_in_ltc <= $cur_my_wallet['balance']) {
                          $allow_go_next = 1;
                        }
                        break;
                      } else if ($cur_my_wallet['currency_id'] == 'XRP') {
                        $calculated_card_fee_in_xrp = format_fiat(number_format($amount_fee, 10, '.', ','), 6);
                        if ($calculated_card_fee_in_xrp <= $cur_my_wallet['balance']) {
                          $allow_go_next = 1;
                        }
                        break;
                      }
                      else if ($cur_my_wallet['currency_id'] == 'USD') {
                        if ($amount_fee <= $cur_my_wallet['balance']) {
                          $allow_go_next = 1;
                        }
                        break;
                      }
                    }
                  }
                }
              } else {
                _log($reg_email_address, "get_wallet_balance error : " . $wallet_info['error']);
              }

              if ($allow_go_next == 1) {
                _log($reg_email_address, "try call get_configurator_key api...");
                $plusqo_configurator_info_res = get_configurator_key($reg_email_address, $my_db_auth_token, 'plusqo_backoffice_key_salt_v4', 'plusqo_backoffice_ec_key_v4');
                if (($plusqo_configurator_info_res['http_code'] == "200") || ($plusqo_configurator_info_res['http_code'] == "200 OK")) {
                  _log($reg_email_address, "call get_configurator_key api success.");
                  if (!empty($plusqo_configurator_info_res['result']['target_key_value'])) {
                    $dec_configurator_key = trim($plusqo_configurator_info_res['result']['target_key_value']);
                    _log($reg_email_address, "::get dec_configurator_key success : " . $dec_configurator_key);
                  }
                } else {
                  _log($reg_email_address, "call dec_configurator_key api failed.");
                }

                if ($dec_configurator_key == '') {
                  _log($reg_email_address, "failed logging by Configurator Account (get dec_configurator_key failed)! try use default value...");
                  $dec_configurator_key = BACKOFFICE_ADMIN_PWD;
                }

                _log($reg_email_address, "try logging in by Configurator Account...");
                $configurator_access_token = '';
                $admin_auth_res = _cognito_getAdminAuthToken();
                $configurator_access_token = '';
                if ($admin_auth_res['data'] != null) {
                  _log($reg_email_address, "Access Token (Backoffice) = " . $admin_auth_res['data']);
                  $configurator_access_token = trim($admin_auth_res['data']);
                  $configurator_auth_value = "Bearer " . $configurator_access_token;
                  if ($configurator_access_token != '') {
                    _log($reg_email_address, "Configurator Account logged in successful.Try execute balancecorrection (1)...");
                    if ($used_currency == 'BTC') {
                      $deduction_amount = $calculated_card_fee_in_btc;
                      $addition_amount = $calculated_card_fee_in_btc;
                      $payment_method_title = "YOUR BITCOIN WALLET";
                      $amount_fee_paid_title = $calculated_card_fee_in_btc . " BTC (equivalence of " . $req_partner['card_issue_fee'] . " USD)";
                    } else if ($used_currency == 'USDT') {
                      $deduction_amount = $calculated_card_fee_in_usdt;
                      $addition_amount = $calculated_card_fee_in_usdt;
                      $payment_method_title = "YOUR USDT WALLET";
                      $amount_fee_paid_title = $calculated_card_fee_in_usdt . " USDT (equivalence of " . $req_partner['card_issue_fee'] . " USD)";
                    } else if ($used_currency == 'BUSD') {
                      $deduction_amount = $calculated_card_fee_in_busd;
                      $addition_amount = $calculated_card_fee_in_busd;
                      $payment_method_title = "YOUR BUSD WALLET";
                      $amount_fee_paid_title = $calculated_card_fee_in_busd . " BUSD (equivalence of " . $req_partner['card_issue_fee'] . " USD)";
                    } else if ($used_currency == 'USDC') {
                      $deduction_amount = $calculated_card_fee_in_usdc;
                      $addition_amount = $calculated_card_fee_in_usdc;
                      $payment_method_title = "YOUR USDC WALLET";
                      $amount_fee_paid_title = $calculated_card_fee_in_usdc . " USDC (equivalence of " . $req_partner['card_issue_fee'] . " USD)";
                    } else if ($used_currency == 'SOL') {
                      $deduction_amount = $calculated_card_fee_in_sol;
                      $addition_amount = $calculated_card_fee_in_sol;
                      $payment_method_title = "YOUR SOL WALLET";
                      $amount_fee_paid_title = $calculated_card_fee_in_sol . " SOL (equivalence of " . $req_partner['card_issue_fee'] . " USD)";
                    } else if ($used_currency == 'BCH') {
                      $deduction_amount = $calculated_card_fee_in_bch;
                      $addition_amount = $calculated_card_fee_in_bch;
                      $payment_method_title = "YOUR BCH WALLET";
                      $amount_fee_paid_title = $calculated_card_fee_in_bch . " BCH (equivalence of " . $req_partner['card_issue_fee'] . " USD)";
                    } else if ($used_currency == 'ETH') {
                      $deduction_amount = $calculated_card_fee_in_eth;
                      $addition_amount = $calculated_card_fee_in_eth;
                      $payment_method_title = "YOUR ETH WALLET";
                      $amount_fee_paid_title = $calculated_card_fee_in_eth . " ETH (equivalence of " . $req_partner['card_issue_fee'] . " USD)";
                    } else if ($used_currency == 'LTC') {
                      $deduction_amount = $calculated_card_fee_in_ltc;
                      $addition_amount = $calculated_card_fee_in_ltc;
                      $payment_method_title = "YOUR LTC WALLET";
                      $amount_fee_paid_title = $calculated_card_fee_in_ltc . " LTC (equivalence of " . $req_partner['card_issue_fee'] . " USD)";
                    } else if ($used_currency == 'XRP') {
                      $deduction_amount = $calculated_card_fee_in_xrp;
                      $addition_amount = $calculated_card_fee_in_xrp;
                      $payment_method_title = "YOUR XRP WALLET";
                      $amount_fee_paid_title = $calculated_card_fee_in_xrp . " XRP (equivalence of " . $req_partner['card_issue_fee'] . " USD)";
                    } else if ($used_currency == 'USD') {
                      $deduction_amount = $amount_fee;
                      $addition_amount = $amount_fee;
                      $payment_method_title = "YOUR USD WALLET";
                      $amount_fee_paid_title = $amount_fee . " USD";
                    }
                    $create_account_transaction_comment = $reg_email_address . " pays for Card Issuance Fee (" . $req_partner['partner'] . ")";
                    $create_account_transaction_debit_query = sprintf('{"query":"mutation ($items: [RecordTransactionItem!]!) {\\n  create_account_transaction(items: $items) {\\n    parent_transaction_id\\n    account_transactions {\\n      account_transaction_id\\n      type\\n      amount\\n    }\\n  }\\n}","variables":{"items":[{"user_id":"%s","currency_id":"%s","type":"debit","transaction_class":"payment","amount":%s,"comment":"%s"}]}}', $shift_user_id, $used_currency, $deduction_amount, $create_account_transaction_comment);
                    $create_account_transaction_credit_query = sprintf('{"query":"mutation ($items: [RecordTransactionItem!]!) {\\n  create_account_transaction(items: $items) {\\n    parent_transaction_id\\n    account_transactions {\\n      account_transaction_id\\n      type\\n      amount\\n    }\\n  }\\n}","variables":{"items":[{"user_id":"%s","currency_id":"%s","type":"credit","transaction_class":"payment","amount":%s,"comment":"%s"}]}}', PLUSQO_FEE_RECEIVER_USER_ID, $used_currency, $addition_amount, $create_account_transaction_comment);
                    unset($create_account_transaction_debit_res);
                    _log($reg_email_address, $create_account_transaction_debit_query);
                    $tmp_dto_debit_arr = array();
                    $create_account_transaction_debit_res = api_call('/api/v4/create_account_transaction', 0, $create_account_transaction_debit_query, $tmp_dto_debit_arr, $configurator_auth_value);
                    if (($create_account_transaction_debit_res['http_code'] == "200") || ($create_account_transaction_debit_res['http_code'] == "200 OK")) {
                      _log($reg_email_address, "/api/v4/create_account_transaction vao toi day");
                      if (!empty($create_account_transaction_debit_res['result']['errors'])) {
                        _log($reg_email_address, "balancecorrection execution (1) failed : " . $create_account_transaction_debit_res['result']['errors'][0]['message']);
                        if (!is_null($create_account_transaction_debit_res['result']['errors'][0]['message'])) {
                          if (strpos(strtoupper($create_account_transaction_debit_res['result']['errors'][0]['message']), "INSUFFICIENT BALANCE") !== false) {
                            @mysqli_close($dbhandle);
                            header('Content-Type: application/json');
                            http_response_code(500);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 15, 'errorMessage' => 'insufficient balance to make payment. please check your wallet balance');
                            echo json_encode($ret_rs);
                            die();
                          } else {
                            @mysqli_close($dbhandle);
                            header('Content-Type: application/json');
                            http_response_code(500);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 15, 'errorMessage' => 'error occurred. please contact administrator for help.');
                            echo json_encode($ret_rs);
                            die();
                          }
                        } else {
                          _log($reg_email_address, "balancecorrection execution(1) failed: result.errors.message is null");
                          @mysqli_close($dbhandle);
                          header('Content-Type: application/json');
                          http_response_code(500);
                          $ret_rs['result'] = 'failed';
                          $ret_rs['error'] = array('errorCode' => 15, 'errorMessage' => 'balancecorrection(1) execution failed');
                          echo json_encode($ret_rs);
                          die();
                        }
                      } else {
                        _log($reg_email_address, "::executed balancecorrection(1) successful. Try execute balancecorrection(2)...");
                        unset($create_account_transaction_credit_res);
                        _log($reg_email_address, $create_account_transaction_credit_query);
                        $tmp_dto_credit_arr = array();
                        $create_account_transaction_credit_res = api_call('/api/v4/create_account_transaction', 0, $create_account_transaction_credit_query, $tmp_dto_credit_arr, $configurator_auth_value);
                        if (($create_account_transaction_credit_res['http_code'] == "200") || ($create_account_transaction_credit_res['http_code'] == "200 OK")) {
                          _log($reg_email_address, "/api/v4/create_account_transaction vao toi day (2)");
                          if (!empty($create_account_transaction_credit_res['result']['errors'])) {
                            _log($reg_email_address, "balancecorrection execution (2) failed : " . $create_account_transaction_credit_res['result']['errors'][0]['message']);
                            @mysqli_close($dbhandle);
                            header('Content-Type: application/json');
                            http_response_code(500);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 16, 'errorMessage' => 'balancecorrection(2) execution failed');
                            echo json_encode($ret_rs);
                            die();
                          } else {
                            //success
                            $payment_dt = date('Y-m-d H:i:s');
                            $payment_dt_utc = date('Y/m/d H:i:s', strtotime($payment_dt) - 32400);
                            _log($reg_email_address, "executed balancecorrection(2) successful. " . $amount_fee_paid_title);
                            _log($reg_email_address, "try update status...");

                            $sql_update_user_status = "UPDATE `cryptocash_user_status` 
                              SET `payment_status` = 2, `payment_dt` = '$payment_dt' 
                              WHERE `email_address` = '$reg_email_address' 
                                AND created_from != 'XEXON' 
                                AND created_from ='".$req_partner['partner']."'";
                            if (mysqli_query($dbhandle, $sql_update_user_status)) {
                              //get profile
                              $rs_jdb_profile = mysqli_query($dbhandle, "select * from cryptocash_jdb_profile where email_address = '" . $reg_email_address . "' and created_from='" . $req_partner['partner'] . "' LIMIT 1");
                              if (mysqli_num_rows($rs_jdb_profile) > 0) {
                                while ($row_jdb_profile = mysqli_fetch_array($rs_jdb_profile, MYSQLI_ASSOC)) {
                                  _log($reg_email_address, "row_jdb_profile: ".json_encode($row_jdb_profile));
                                  $profile['profile_id'] = trim($row_jdb_profile['profile_id']);
                                  $profile['gender'] = trim("" . $row_jdb_profile['gender']);
                                  $profile['name_kanji_kana'] = trim($row_jdb_profile['name_kanji_kana']);
                                  $profile['name_romaji'] = trim($row_jdb_profile['name_romaji']);
                                  $profile['marriage_status'] = trim("" . $row_jdb_profile['marriage_status']);
                                  $profile['occupation'] = trim($row_jdb_profile['occupation']);
                                  $profile['country'] = trim($row_jdb_profile['country']);
                                  $profile['date_of_birth'] = $row_jdb_profile['date_of_birth'];
                                  $raw_date_of_birth = explode("-", $profile['date_of_birth']);
                                  $profile['date_of_birth_year'] = $raw_date_of_birth[0];
                                  $profile['date_of_birth_month'] = $raw_date_of_birth[1];
                                  $profile['date_of_birth_day'] = $raw_date_of_birth[2];
                                  $profile['place_of_birth'] = trim($row_jdb_profile['place_of_birth']);
                                  $profile['id_card_number'] = trim($row_jdb_profile['id_card_number']);
                                  $profile['id_card_issued_dt'] = $row_jdb_profile['id_card_issued_dt'];
                                  $raw_id_card_issued_dt = explode("-", $profile['id_card_issued_dt']);
                                  $profile['id_card_issued_dt_year'] = $raw_id_card_issued_dt[0];
                                  $profile['id_card_issued_dt_month'] = $raw_id_card_issued_dt[1];
                                  $profile['id_card_issued_dt_day'] = $raw_id_card_issued_dt[2];
                                  $profile['id_card_expired_dt'] = $row_jdb_profile['id_card_expired_dt'];
                                  $raw_id_card_expired_dt = explode("-", $profile['id_card_expired_dt']);
                                  $profile['id_card_expired_dt_year'] = $raw_id_card_expired_dt[0];
                                  $profile['id_card_expired_dt_month'] = $raw_id_card_expired_dt[1];
                                  $profile['id_card_expired_dt_day'] = $raw_id_card_expired_dt[2];
                                  $profile['id_card_issuer'] = trim($row_jdb_profile['id_card_issuer']);
                                  $profile['id_card_type'] = trim($row_jdb_profile['id_card_type']);
                                  if ($profile['id_card_type'] == '') {
                                    $profile['id_card_type'] = 'passport'; //default
                                  }
                                  $profile['residence_address'] = trim($row_jdb_profile['residence_address']);
                                  $profile['district'] = trim($row_jdb_profile['district']);
                                  $profile['province'] = trim($row_jdb_profile['province']);
                                  $profile['postal_code'] = trim($row_jdb_profile['postal_code']);
                                  $profile['home_telephone_country_code'] = trim($row_jdb_profile['home_telephone_country_code']);
                                  $profile['home_telephone_number'] = trim($row_jdb_profile['home_telephone_number']);
                                  $profile['cellphone_country_code'] = trim($row_jdb_profile['cellphone_country_code']);
                                  $profile['cellphone_number'] = trim($row_jdb_profile['cellphone_number']);
                                  $profile['consent_name'] = trim($row_jdb_profile['consent_name']);
                                  $profile['email_address'] = trim($row_jdb_profile['email_address']);
                                  $profile['status'] = intval($row_jdb_profile['status']);

                                  $profile['date_of_birth'] = date('Y/m/d', strtotime($profile['date_of_birth']));
                                  $profile['id_card_issued_dt'] = date('Y/m/d', strtotime($profile['id_card_issued_dt']));
                                  $profile['id_card_expired_dt'] = date('Y/m/d', strtotime($profile['id_card_expired_dt']));
                                  _log($reg_email_address, "profile: ".json_encode($profile));
                                }
                              }

                              $invoice_id = "XE" . generate_id();
                              if ($used_currency == 'USD') {
                                $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='usd', amount_fee_fiat='$amount_fee', updated_dt='$payment_dt' WHERE email_address='" . $reg_email_address . "' AND created_from!='XEXON'";
                              } else if ($used_currency == 'BTC') {
                                $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='btc', amount_fee_crypto='$calculated_card_fee_in_btc', updated_dt='$payment_dt' WHERE email_address='" . $reg_email_address . "' AND created_from!='XEXON'";
                              } else if ($used_currency == 'USDT') {
                                $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='usdt', amount_fee_crypto='$calculated_card_fee_in_usdt', updated_dt='$payment_dt' WHERE email_address='" . $reg_email_address . "' AND created_from!='XEXON'";
                              } else if ($used_currency == 'BUSD') {
                                $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='busd', amount_fee_crypto='$calculated_card_fee_in_busd', updated_dt='$payment_dt' WHERE email_address='" . $reg_email_address . "' AND created_from!='XEXON'";
                              } else if ($used_currency == 'USDC') {
                                $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='usdc', amount_fee_crypto='$calculated_card_fee_in_usdc', updated_dt='$payment_dt' WHERE email_address='" . $reg_email_address . "' AND created_from!='XEXON'";
                              } else if ($used_currency == 'SOL') {
                                $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='sol', amount_fee_crypto='$calculated_card_fee_in_sol', updated_dt='$payment_dt' WHERE email_address='" . $reg_email_address . "' AND created_from!='XEXON'";
                              } else if ($used_currency == 'BCH') {
                                $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='bch', amount_fee_crypto='$calculated_card_fee_in_bch', updated_dt='$payment_dt' WHERE email_address='" . $reg_email_address . "' AND created_from!='XEXON'";
                              } else if ($used_currency == 'ETH') {
                                $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='eth', amount_fee_crypto='$calculated_card_fee_in_eth', updated_dt='$payment_dt' WHERE email_address='" . $reg_email_address . "' AND created_from!='XEXON'";
                              } else if ($used_currency == 'LTC') {
                                $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='ltc', amount_fee_crypto='$calculated_card_fee_in_ltc', updated_dt='$payment_dt' WHERE email_address='" . $reg_email_address . "' AND created_from!='XEXON'";
                              } else if ($used_currency == 'XRP') {
                                $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card SET invoice_id='$invoice_id', has_paid_fee=1, payment_method='xrp', amount_fee_crypto='$calculated_card_fee_in_xrp', updated_dt='$payment_dt' WHERE email_address='" . $reg_email_address . "' AND created_from!='XEXON'";
                              }
                              $send_mail_flag = 0;
                              if (mysqli_query($dbhandle, $sql_update_debit_card)) {
                                _log($reg_email_address, " update cryptocash_jdb_debit_card OK !");
                                $send_mail_flag = 1;
                              } else {
                                _log($reg_email_address, " update cryptocash_jdb_debit_card FAILED !");
                              }
                              _log($reg_email_address, "::" . $sql_update_debit_card);
                              $update_shift_profile_sql = "UPDATE cryptocash_users_profile SET shift_update_dt='$payment_dt' WHERE email='" . $reg_email_address . "' AND created_from='" . $req_partner['partner'] . "' LIMIT 1";
                              mysqli_query($dbhandle, $update_shift_profile_sql);
                              _log($reg_email_address, "::" . $update_shift_profile_sql);
                              @mysqli_close($dbhandle);

                              if ($send_mail_flag == 1) {
                                //try adding commission PAP
                                $raw_pap_merchant_login_obj = PapLogin(PAP_URL, MERCHANT_USERNAME, MERCHANT_PASSWORD, "merchant");
                                if ((!is_null($raw_pap_merchant_login_obj)) && (!empty($raw_pap_merchant_login_obj))) {
                                  $pap_affiliate_obj = PapUserCheck($reg_email_address, $raw_pap_merchant_login_obj);
                                  if (trim($pap_affiliate_obj['refid']) != '') {
                                    _log($reg_email_address, "::PapUserCheck::found user with refid = " . $pap_affiliate_obj['refid'] . ", parentuserid = " . $pap_affiliate_obj['parentuserid']);
                                    if (trim($pap_affiliate_obj['parentuserid']) != '') {
                                      //Create new transaction:
                                      $transaction = new Pap_Api_Transaction($raw_pap_merchant_login_obj);
                                      //Fill custom data:
                                      $transaction->setCampaignid($req_partner['campaign_id']);
                                      $transaction->setTotalCost($req_partner['card_issue_fee']);
                                      $transaction->setCommTypeId($req_partner['commission_type_id']);
                                      //$transaction->setStatus("A");
                                      $transaction->setUserid($pap_affiliate_obj['parentuserid']);
                                      $transaction->setOrderId($pap_affiliate_obj['username']);
                                      $transaction->setProductId("Card Issue(" . $req_partner['partner'] . ")");
                                      $transaction->setData(1, $pap_affiliate_obj['first_name'] . " " . $pap_affiliate_obj['last_name']);
                                      //also count multi-tier commissions for parent affiliates
                                      $transaction->setMultiTierCreation("Y");
                                      //Adding transaction
                                      if ($transaction->add()) {
                                        _log($reg_email_address, "::commission added ok for user id: " . $pap_affiliate_obj['parentuserid'] . " / transaction id: " . $transaction->getTransId());
                                      } else {
                                        _log($reg_email_address, "::commission added error for user id: " . $pap_affiliate_obj['parentuserid'] . " / error message: " . $transaction->getMessage());
                                      }
                                    }
                                  } else {
                                    _log($reg_email_address, "::PapUserCheck::user does not exist!");
                                  }
                                } else {
                                  _log($reg_email_address, "::failed to login as merchant!");
                                }

                                //send invoice
                                $cur_time = time();
                                $dpart_month = gmDate("M", $cur_time);
                                $dpart_day = gmDate("j", $cur_time);
                                $dpart_year = gmDate("Y", $cur_time);
                                $dpart_rest = gmDate("\@ H:i:s \U\T\C", $cur_time);
                                if ($dpart_day == 1) {
                                  $dpart_day = $dpart_day . "st";
                                } else if ($dpart_day == 2) {
                                  $dpart_day = $dpart_day . "nd";
                                } else if ($dpart_day == 3) {
                                  $dpart_day = $dpart_day . "rd";
                                } else {
                                  $dpart_day = $dpart_day . "th";
                                }
                                $gmt_dt = $dpart_month . " " . $dpart_day . " " . $dpart_year . " " . $dpart_rest;
                                $mail = new PHPMailer(true);
                                try {
                                  $mail->isSMTP();                                            // Send using SMTP
                                  $mail->Mailer = 'smtp';
                                  $mail->SMTPAuth = true;                                     // Enable SMTP authentication
                                  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                                  $mail->Port = 587;
                                  if ($req_partner['partner'] == 'COINSWIPE') {
                                    $mail->Host = 'mail.privateemail.com';                    // Set the SMTP server to send through
                                    $mail->Username = 'support@coinswipe.io';                 // SMTP username
                                    $mail->Password = 'r9GdNQvr';                             // SMTP password

                                    //Recipients
                                    $mail->setFrom('support@coinswipe.io', $req_partner['partner']);
                                    $mail->addReplyTo('support@coinswipe.io', $req_partner['partner']);
                                    $mail->addBCC('verification@coinswipe.io');
                                    $mail->MessageID = "<" . md5('adminultimopayio' . (idate("U") - 1000000000) . uniqid()) . '@coinswipe.io>';
                                  } else if ($req_partner['partner'] == 'BITQUICK') {
                                    $mail->Host = 'mail.privateemail.com';                    // Set the SMTP server to send through
                                    $mail->Username = 'support@bitquick.io';                  // SMTP username
                                    $mail->Password = 'Zc95kRex';                             // SMTP password

                                    //Recipients
                                    $mail->setFrom('support@bitquick.io', $req_partner['partner']);
                                    $mail->addReplyTo('support@bitquick.io', $req_partner['partner']);
                                    $mail->addBCC('verification@bitquick.io');
                                    $mail->MessageID = "<" . md5('adminultimopayio' . (idate("U") - 1000000000) . uniqid()) . '@bitquick.io>';
                                  } else {
                                    $mail->Host = 'mail.privateemail.com';                    // Set the SMTP server to send through
                                    $mail->Username = 'support@ultimopay.io';                 // SMTP username
                                    $mail->Password = 'DrUHdhww7rMN2023#';                    // SMTP password

                                    //Recipients
                                    $mail->setFrom('support@ultimopay.io', $req_partner['partner']);
                                    $mail->addReplyTo('support@ultimopay.io', $req_partner['partner']);
                                    $mail->addBCC('verification@ultimopay.io');
                                  }
                                  $mail->addAddress($reg_email_address);     // Add a recipient
                                  $user_fullname = $profile['name_romaji'];
                                  $full_residence_address = $profile['residence_address'] . ", " . $profile['district'] . ", " . $profile['province'] . ", " . $profile['country'];

                                  $confirm_body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">";
                                  $confirm_body .= "<html xmlns:v=\"urn:schemas-microsoft-com:vml\">";
                                  $confirm_body .= "<head>";
                                  $confirm_body .= "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />";
                                  $confirm_body .= "    <meta name=\"viewport\" content=\"width=device-width; initial-scale=1.0; maximum-scale=1.0;\" />";
                                  $confirm_body .= "    <!--[if !mso]--><!-- -->";
                                  $confirm_body .= "    <!-- <![endif]-->";
                                  $confirm_body .= "    <title>" . $req_partner['partner'] . " - RECEIPT FOR DEBIT CARD ISSUANCE FEE</title>";
                                  $confirm_body .= "    <style type=\"text/css\">";
                                  $confirm_body .= "        body {";
                                  $confirm_body .= "            width: 100%; font-weight: normal";
                                  $confirm_body .= "            background-color: #ffffff;";
                                  $confirm_body .= "            margin: 0;";
                                  $confirm_body .= "            padding: 0;";
                                  $confirm_body .= "            mso-margin-top-alt: 0px;";
                                  $confirm_body .= "            mso-margin-bottom-alt: 0px;";
                                  $confirm_body .= "            mso-padding-alt: 0px 0px 0px 0px;";
                                  $confirm_body .= "        }";
                                  $confirm_body .= "        p,";
                                  $confirm_body .= "        h1,";
                                  $confirm_body .= "        h2,";
                                  $confirm_body .= "        h3,";
                                  $confirm_body .= "        h4 {";
                                  $confirm_body .= "            margin-top: 0;";
                                  $confirm_body .= "            margin-bottom: 0;";
                                  $confirm_body .= "            padding-top: 0;";
                                  $confirm_body .= "            padding-bottom: 0;";
                                  $confirm_body .= "        }";
                                  $confirm_body .= "        span.preheader {";
                                  $confirm_body .= "            display: none;";
                                  $confirm_body .= "            font-size: 1px;";
                                  $confirm_body .= "        }";
                                  $confirm_body .= "        html {";
                                  $confirm_body .= "            width: 100%;";
                                  $confirm_body .= "        }";
                                  $confirm_body .= "        table {";
                                  $confirm_body .= "            font-size: 14px;";
                                  $confirm_body .= "            border: 0;";
                                  $confirm_body .= "        }";
                                  $confirm_body .= "        /* ----------- responsivity ----------- */";
                                  $confirm_body .= "        @media only screen and (max-width: 640px) {";
                                  $confirm_body .= "            /*------ top header ------ */";
                                  $confirm_body .= "            .main-header {";
                                  $confirm_body .= "                font-size: 20px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .main-section-header {";
                                  $confirm_body .= "                font-size: 28px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .show {";
                                  $confirm_body .= "                display: block !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .hide {";
                                  $confirm_body .= "                display: none !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .align-center {";
                                  $confirm_body .= "                text-align: center !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .no-bg {";
                                  $confirm_body .= "                background: none !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            /*----- main image -------*/";
                                  $confirm_body .= "            .main-image img {";
                                  $confirm_body .= "                width: 440px !important;";
                                  $confirm_body .= "                height: auto !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            /* ====== divider ====== */";
                                  $confirm_body .= "            .divider img {";
                                  $confirm_body .= "                width: 440px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            /*-------- container --------*/";
                                  $confirm_body .= "            .container590 {";
                                  $confirm_body .= "                width: 440px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .container580 {";
                                  $confirm_body .= "                width: 400px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .main-button {";
                                  $confirm_body .= "                width: 220px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            /*-------- secions ----------*/";
                                  $confirm_body .= "            .section-img img {";
                                  $confirm_body .= "                width: 320px !important;";
                                  $confirm_body .= "                height: auto !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .team-img img {";
                                  $confirm_body .= "                width: 100% !important;";
                                  $confirm_body .= "                height: auto !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "        }";
                                  $confirm_body .= "        @media only screen and (max-width: 479px) {";
                                  $confirm_body .= "            /*------ top header ------ */";
                                  $confirm_body .= "            .main-header {";
                                  $confirm_body .= "                font-size: 18px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .main-section-header {";
                                  $confirm_body .= "                font-size: 26px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            /* ====== divider ====== */";
                                  $confirm_body .= "            .divider img {";
                                  $confirm_body .= "                width: 280px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            /*-------- container --------*/";
                                  $confirm_body .= "            .container590 {";
                                  $confirm_body .= "                width: 280px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .container590 {";
                                  $confirm_body .= "                width: 280px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            .container580 {";
                                  $confirm_body .= "                width: 260px !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "            /*-------- secions ----------*/";
                                  $confirm_body .= "            .section-img img {";
                                  $confirm_body .= "                width: 280px !important;";
                                  $confirm_body .= "                height: auto !important;";
                                  $confirm_body .= "            }";
                                  $confirm_body .= "        }";
                                  $confirm_body .= "#customers {";
                                  $confirm_body .= "  border-collapse: collapse;";
                                  $confirm_body .= "  width: 100%; font-weight: normal";
                                  $confirm_body .= "}";
                                  $confirm_body .= "#customers td, #customers th {";
                                  $confirm_body .= "  border-bottom: 1px solid #ddd;";
                                  $confirm_body .= "  padding: 8px;";
                                  $confirm_body .= "}";
                                  $confirm_body .= "#customers tr:hover {background-color: #ddd;}";
                                  $confirm_body .= "#customers th {";
                                  $confirm_body .= "  padding-top: 12px;";
                                  $confirm_body .= "  padding-bottom: 12px;";
                                  $confirm_body .= "  text-align: left;";
                                  $confirm_body .= "  background-color: #4CAF50;";
                                  $confirm_body .= "  color: white;";
                                  $confirm_body .= "}";
                                  $confirm_body .= ".header-wrapper{";
                                  $confirm_body .= "    width: 100%;";
                                  $confirm_body .= "    margin: 24px auto 12px;";
                                  $confirm_body .= "}";
                                  $confirm_body .= ".header{";
                                  $confirm_body .= "    max-width: 590px;";
                                  $confirm_body .= "    margin: 0 auto;";
                                  $confirm_body .= "    background: #000;";
                                  $confirm_body .= "    text-align: center;";
                                  $confirm_body .= "    padding: 15px;";
                                  $confirm_body .= "    box-sizing: border-box;";
                                  $confirm_body .= "}";
                                  $confirm_body .= ".header a{";
                                  $confirm_body .= "    color: #fff;";
                                  $confirm_body .= "    font-weight: bold;";
                                  $confirm_body .= "    text-decoration: none;";
                                  $confirm_body .= "}";
                                  $confirm_body .= "    </style>";
                                  $confirm_body .= "    <!-- [if gte mso 9]><style type=text/css";
                                  $confirm_body .= "        body {";
                                  $confirm_body .= "        }";
                                  $confirm_body .= "        </style>";
                                  $confirm_body .= "    <![endif]-->";
                                  $confirm_body .= "</head>";
                                  $confirm_body .= "<body class=\"respond\" leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" marginheight=\"0\">";
                                  $confirm_body .= "    <!-- pre-header -->";
                                  $confirm_body .= "    <table style=\"display:none!important;\">";
                                  $confirm_body .= "        <tr>";
                                  $confirm_body .= "            <td>";
                                  $confirm_body .= "                <div style=\"overflow:hidden;display:none;font-size:1px;color:#ffffff;line-height:1px;font-family:Arial;maxheight:0px;max-width:0px;opacity:0;\">";
                                  $confirm_body .= "                    Pre-header for the RECEIPT";
                                  $confirm_body .= "                </div>";
                                  $confirm_body .= "            </td>";
                                  $confirm_body .= "        </tr>";
                                  $confirm_body .= "    </table>";
                                  $confirm_body .= "    <!-- pre-header end -->";
                                  $confirm_body .= "    <table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"ffffff\" class=\"bg_color\">";
                                  $confirm_body .= "        <tr>";
                                  $confirm_body .= "            <td align=\"center\">";
                                  $confirm_body .= "                <table border=\"0\" align=\"center\" width=\"590\" cellpadding=\"0\" cellspacing=\"0\" class=\"container590\">";
                                  $confirm_body .= "                    <tr>";
                                  $confirm_body .= "                        <td align=\"center\">";
                                  $confirm_body .= "                            <table border=\"0\" width=\"95%\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" class=\"container590\">";
                                  $confirm_body .= "                                <tr>";
                                  $confirm_body .= "                                    <td style=\"color: #000000; font-size: 1.0em; line-height: 24px;\">";
                                  $confirm_body .= "                                        <div style=\"line-height: 200%; padding-top: 15px;\">";
                                  if ($user_fullname != "") {
                                    $confirm_body .= "											<strong>Hello " . $user_fullname . ",</strong><br/><br/>";
                                  }
                                  $confirm_body .= "                                            Thank you for your payment. Please see your receipt details below:";
                                  $confirm_body .= "                                        </div>";
                                  $confirm_body .= "                                    </td>";
                                  $confirm_body .= "                                </tr>";
                                  $confirm_body .= "                            </table>";
                                  $confirm_body .= "                        </td>";
                                  $confirm_body .= "                    </tr>";
                                  $confirm_body .= "                </table>";
                                  $confirm_body .= "            </td>";
                                  $confirm_body .= "        </tr>";
                                  $confirm_body .= "        <tr class=\"hide\">";
                                  $confirm_body .= "            <td height=\"25\" style=\"font-size: 25px; line-height: 25px;\">&nbsp;</td>";
                                  $confirm_body .= "        </tr>";
                                  $confirm_body .= "    </table>";
                                  $confirm_body .= "    <!-- end section -->";
                                  $confirm_body .= "    <table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"ffffff\" class=\"bg_color\">";
                                  $confirm_body .= "        <tr>";
                                  $confirm_body .= "            <td align=\"center\">";
                                  $confirm_body .= "                <table border=\"0\" align=\"center\" width=\"590\" cellpadding=\"0\" cellspacing=\"0\" class=\"container590\">";
                                  $confirm_body .= "                    <tr>";
                                  $confirm_body .= "                        <td align=\"center\">";
                                  $confirm_body .= "                            <table border=\"0\" width=\"95%\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" class=\"container590\">";
                                  $confirm_body .= "                                <tr>";
                                  $confirm_body .= "                                    <td style=\"color: #000000; font-size: 1.0em; line-height: 24px;\">";
                                  $confirm_body .= "                                        <table id=\"customers\">";
                                  $confirm_body .= "												<tr>";
                                  $confirm_body .= "													<td width=\"50%\" align=\"right\"><strong>INVOICE</strong></td>";
                                  $confirm_body .= "													<td width=\"50%\">" . $invoice_id . "</td>";
                                  $confirm_body .= "												 </tr>";
                                  $confirm_body .= "												<tr>";
                                  $confirm_body .= "													<td width=\"50%\" align=\"right\"><strong>YOU PAID</strong></td>";
                                  $confirm_body .= "													<td width=\"50%\">" . $amount_fee_paid_title . "</td>";
                                  $confirm_body .= "												 </tr>";
                                  $confirm_body .= "												<tr>";
                                  $confirm_body .= "													<td width=\"50%\" align=\"right\"><strong>YOU PAID BY</strong></td>";
                                  $confirm_body .= "													<td width=\"50%\">" . $payment_method_title . "</td>";
                                  $confirm_body .= "												 </tr>";
                                  $confirm_body .= "												<tr>";
                                  $confirm_body .= "													<td width=\"50%\" align=\"right\"><strong>FULL NAME</strong></td>";
                                  $confirm_body .= "													<td width=\"50%\">" . $user_fullname . "</td>";
                                  $confirm_body .= "												 </tr>";
                                  $confirm_body .= "												<tr>";
                                  $confirm_body .= "													<td width=\"50%\" align=\"right\"><strong>EMAIL</strong></td>";
                                  $confirm_body .= "													<td width=\"50%\">" . $reg_email_address . "</td>";
                                  $confirm_body .= "												 </tr>";
                                  $confirm_body .= "												<tr>";
                                  $confirm_body .= "													<td width=\"50%\" align=\"right\"><strong>CREATED ON</strong></td>";
                                  $confirm_body .= "													<td width=\"50%\">" . $gmt_dt . "</td>";
                                  $confirm_body .= "												 </tr>";
                                  $confirm_body .= "											</table>";
                                  $confirm_body .= "                                    </td>";
                                  $confirm_body .= "                                </tr>";
                                  $confirm_body .= "                            </table>";
                                  $confirm_body .= "                        </td>";
                                  $confirm_body .= "                    </tr>";
                                  $confirm_body .= "                </table>";
                                  $confirm_body .= "            </td>";
                                  $confirm_body .= "        </tr>";
                                  $confirm_body .= "        <tr class=\"hide\">";
                                  $confirm_body .= "            <td height=\"25\" style=\"font-size: 25px; line-height: 25px;\">&nbsp;</td>";
                                  $confirm_body .= "        </tr>";
                                  $confirm_body .= "    </table>";
                                  $confirm_body .= "    <table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"ffffff\" class=\"bg_color\">";
                                  $confirm_body .= "        <tr>";
                                  $confirm_body .= "            <td align=\"center\">";
                                  $confirm_body .= "                <table border=\"0\" align=\"center\" width=\"590\" cellpadding=\"0\" cellspacing=\"0\" class=\"container590\">";
                                  $confirm_body .= "                    <tr>";
                                  $confirm_body .= "                        <td align=\"center\">";
                                  $confirm_body .= "                            <table border=\"0\" width=\"95%\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" class=\"container590\">";
                                  $confirm_body .= "                                <tr>";
                                  $confirm_body .= "                                    <td style=\"color: #000000; font-size: 1.0em;  line-height: 24px;\">";
                                  $confirm_body .= "                                        <div style=\"line-height: 200%; padding-top: 15px;\">";
                                  $confirm_body .= "                                            Your Platinum Debit card is now on production. Expect the card delivered to your postal address in 10-15 banking days.<br/><br/><span style=\"font-weight: 600\">" . $full_residence_address . "</span>";
                                  $confirm_body .= "                                        </div>";
                                  $confirm_body .= "                                    </td>";
                                  $confirm_body .= "                                </tr>";
                                  $confirm_body .= "                                <tr>";
                                  $confirm_body .= "                                    <td style=\"color: #000000; font-size: 1.0em;  line-height: 24px;\">";
                                  $confirm_body .= "                                        <div style=\"line-height: 200%; padding-top: 15px;\">";
                                  $confirm_body .= "                                            Activate the card upon receipt. <a href='https://" . $req_partner['website'] . "'>See activation.</a>";
                                  $confirm_body .= "                                        </div>";
                                  $confirm_body .= "                                    </td>";
                                  $confirm_body .= "                                </tr>";
                                  $confirm_body .= "                                <tr>";
                                  $confirm_body .= "                                    <td style=\"color: #000000; font-size: 1.0em;  line-height: 24px;\">";
                                  $confirm_body .= "                                        <div style=\"line-height: 200%; padding-top: 15px;\">";
                                  $confirm_body .= "                                            <br/><br/><br/><br/>Regards,<br/><br/>Offshore Debit Card Department<br/>" . $req_partner['partner'];
                                  $confirm_body .= "                                        </div>";
                                  $confirm_body .= "                                    </td>";
                                  $confirm_body .= "                                </tr>";
                                  $confirm_body .= "                            </table>";
                                  $confirm_body .= "                        </td>";
                                  $confirm_body .= "                    </tr>";
                                  $confirm_body .= "                </table>";
                                  $confirm_body .= "            </td>";
                                  $confirm_body .= "        </tr>";
                                  $confirm_body .= "        <tr class=\"hide\">";
                                  $confirm_body .= "            <td height=\"25\" style=\"font-size: 25px; line-height: 25px;\">&nbsp;</td>";
                                  $confirm_body .= "        </tr>";
                                  $confirm_body .= "    </table>";
                                  $confirm_body .= "</body>";
                                  $confirm_body .= "</html>";
                                  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                                  // Content
                                  $mail->isHTML(true);                                  // Set email format to HTML
                                  $card_design = 'Ultimo';
                                  if ($req_partner['partner'] == 'COINSWIPE') {
                                    $card_design = 'CoinSwipe';
                                  } else if ($req_partner['partner'] == 'BITQUICK') {
                                    $card_design = 'BitQuick';
                                  }
                                  $mail->Subject = "[" . $card_design . "] RECEIPT FOR DEBIT CARD ISSUANCE FEE";
                                  $mail->Body = $confirm_body;

                                  _log($reg_email_address, "email receipt address: ".$profile['email_address']);

                                  if (!$mail->Send()) {
                                    _log($reg_email_address, ":: " . $mail->ErrorInfo);
                                    http_response_code(500);
                                    $ret_rs['result'] = 'failed';
                                    $ret_rs['error'] = array('errorCode' => 12, 'errorMessage' => 'receipt could not be sent.');
                                  } else {
                                    _log($reg_email_address, "::receipt has been sent");
                                    $ret_rs['result'] = 'success';
                                    $ret_rs['payCardFeeResponse'] = array('email_address' => $reg_email_address, 'payment_status' => "2", 'payment_date' => $payment_dt_utc);
                                  }
                                } catch (Exception $e) {
                                  _log($reg_email_address, "::receipt could not be sent. Mailer Error: {$mail->ErrorInfo}");
                                  http_response_code(500);
                                  $ret_rs['result'] = 'failed';
                                  $ret_rs['error'] = array('errorCode' => 12, 'errorMessage' => 'receipt could not be sent.');
                                }
                                header('Content-Type: application/json');
                                echo json_encode($ret_rs);
                                die();
                              } else {
                                _log($reg_email_address, "::send mail failed");
                                header('Content-Type: application/json');
                                http_response_code(500);
                                $ret_rs['result'] = 'failed';
                                $ret_rs['error'] = array('errorCode' => 13, 'errorMessage' => 'could not update paid status.');
                                echo json_encode($ret_rs);
                                die();
                              }
                            } else {
                              _log($reg_email_address, "update failed :: " . $sql_update_user_status);
                              @mysqli_close($dbhandle);
                              header('Content-Type: application/json');
                              http_response_code(500);
                              $ret_rs['result'] = 'failed';
                              $ret_rs['error'] = array('errorCode' => 14, 'errorMessage' => 'could not update payment status.');
                              echo json_encode($ret_rs);
                              die();
                            }
                          }
                        } else {
                          _log($reg_email_address, "balancecorrection execution(2) failed: not 200 ok");
                          _log($reg_email_address, json_decode($create_account_transaction_credit_res));
                          @mysqli_close($dbhandle);
                          header('Content-Type: application/json');
                          http_response_code(500);
                          $ret_rs['result'] = 'failed';
                          $ret_rs['error'] = array('errorCode' => 16, 'errorMessage' => 'balancecorrection(2) execution failed');
                          echo json_encode($ret_rs);
                          die();
                        }
                      }
                    } else {
                      _log($reg_email_address, "balancecorrection execution(1) failed: not 200 ok");
                      @mysqli_close($dbhandle);
                      header('Content-Type: application/json');
                      http_response_code(500);
                      $ret_rs['result'] = 'failed';
                      $ret_rs['error'] = array('errorCode' => 15, 'errorMessage' => 'balancecorrection(1) execution failed');
                      echo json_encode($ret_rs);
                      die();
                    }
                  }
                } else {
                  _log($reg_email_address, "::failed logging by Configurator Account!");
                  _log($reg_email_address, "::" . $configurator_login_res['error'] ?? '');
                  @mysqli_close($dbhandle);
                  header('Content-Type: application/json');
                  http_response_code(500);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'error occurred. please contact administrator for help.');
                  echo json_encode($ret_rs);
                  die();
                }
              } else {
                @mysqli_close($dbhandle);
                header('Content-Type: application/json');
                http_response_code(500);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 8, 'errorMessage' => 'You do not have enough ' . $used_currency . ' to make payment.');
                echo json_encode($ret_rs);
                die();
              }
            }
          } else {
            @mysqli_close($dbhandle);
            header('Content-Type: application/json');
            http_response_code(500);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'you must sign in to use this API.');
            echo json_encode($ret_rs);
            die();
          }
        } else {
          @mysqli_close($dbhandle);
          header('Content-Type: application/json');
          http_response_code(500);
          $ret_rs['result'] = 'failed';
          $ret_rs['error'] = array('errorCode' => 9, 'errorMessage' => 'This user account has been already paid card fee.');
          echo json_encode($ret_rs);
          die();
        }
      } else {
        @mysqli_close($dbhandle);
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = $errors[0];
        _log("", $ret_rs['error']['errorMessage']);
        header('Content-Type: application/json');
        echo json_encode($ret_rs);
        die();
      }
    }
  } else {
    @mysqli_close($dbhandle);
    header('HTTP/1.0 403 Forbidden');
    die();
  }
} else {
  http_response_code(405);
  die();
}
?>
