@extends('layouts.purchaseCheckerLayoutMaster')

@section('content')
<!--  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.2/bootbox.min.js"></script>-->
  <script src="{{ asset('vendor/bootbox.min.js') }}"></script>
  <div class="narrow-container d-flex justify-content-center">
    <!--  Setting table  -->
    <div class="setting-table">
      <table class="table caption-top" id="settingTable">
        <caption class="table-caption-top text-start fs-5 fw-bold">Partner Settings</caption>
        <thead>
        <tr class="bg-more-light">
          <th style="width: 30px;">No</th>
          <th style="width: 200px;">Partner Name</th>
          <th style="width: 80px;">Fee %</th>
          <th>Other</th>
          <th style="width: 210px;">
            Operations
          </th>
        </tr>
        </thead>
        <tbody class="tbody" id="partners">
          <!--<tr>
            <td>1</td>
            <td>Test partner name</td>
            <td>8</td>
            <td>WplnqqVaWtH29...N3Nk2iLIRJo2oRL9p</td>
            <td>
              <div class="btn-group w-100" role="group">
                <button data-bs-toggle="modal" data-bs-target="#updateModal" type="button" class="btn btn-outline-primary d-flex align-items-center justify-content-between">
                  <i class="bi bi-floppy me-2"></i>
                  <span class="text-end">Update</span>
                </button>
                <button type="button" class="btn btn-outline-danger d-flex align-items-center justify-content-between">
                  <i class="bi bi-trash me-2"></i>
                  <span class="text-end">Remove</span>
                </button>
              </div>
            </td>
          </tr>-->
        </tbody>
        <tfoot class="bg-more-light">
          <tr>
            <td></td>
            <td>
              <input type="text" class="form-control" id="partnerNameNew" placeholder="Enter partner name">
            </td>
            <td>
              <input type="number" class="form-control" id="feeNew" placeholder="Enter fee percent value">
            </td>
            <td>
              <input type="text" class="form-control" id="otherNew" placeholder="Enter other data">
            </td>
            <td class="text-center">
              <button class="btn btn-outline-success" id="addBtn">
                <span class="spinner-anim spinner-border spinner-border-sm text-success" role="status" style="display: none"></span>
                <span class="spinner-text"><i class="bi bi-plus-circle"></i> Add New Check User</span>
              </button>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>

  <!-- Update modal -->
  <div class="modal fade" id="updateModal" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="apiKeyLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h5 class="modal-title text-white">Update Search User Setting</h5>
          <button class="close btn-close" data-bs-dismiss="modal" aria-label="Close">
          </button>
        </div>
        <div class="modal-body">
          <form class="mb-3 px-0 px-md-4">
            <!-- Partner Id -->
            <input type="hidden" id="id">

            <!-- User Name -->
            <div class="mb-3">
              <label for="partnerName" class="form-label">User Name</label>
              <input type="text" class="form-control" id="partnerName" placeholder="Enter partner name">
            </div>

            <!-- Fee Value -->
            <div class="mb-3">
              <label for="fee" class="form-label">Fee Value</label>
              <input type="number" class="form-control" id="fee" placeholder="Enter fee value">
            </div>

            <!-- Password -->
            <div class="mb-3">
              <label for="other" class="form-label">Other</label>
              <input type="text" class="form-control" id="other" placeholder="Enter other data">
            </div>
          </form>
        </div>
        <div class="modal-footer d-flex align-items-center justify-content-end pe-md-5">
          <button id="updateBtn" class="btn btn-primary px-4">
            <span class="spinner-anim spinner-border spinner-border-sm text-white" role="status" style="display: none"></span>
            <span class="spinner-text"><i class="bi bi-floppy me-2"></i>Save</span>
          </button>
        </div>
      </div>
    </div>
  </div>
  <script>
    $(document).ready(function(){
      // Fill partner table
      getPartners();

      // Event handlers
      $('#addBtn').click(addNewPartner);
      $('#updateBtn').click(updatePartner);
    });

    function addNewPartner(){
      SpinBtnCtrl('addBtn', true);
      const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
      const partner_name = $('#partnerNameNew').val();
      const fee_percent = $('#feeNew').val();
      const other = $('#otherNew').val();

      $.ajax({
        url: g_siteUrl + '/purchaseChecker/partner',
        type: "POST",
        data: JSON.stringify({
          partner_name: partner_name,
          fee_percent: fee_percent,
          other: other
        }),
        contentType: "application/json",
        headers: {
          'X-CSRF-TOKEN': csrfToken
        },
        success: function(response) {
          SpinBtnCtrl('addBtn', false);
          getPartners();
          $('#partnerNameNew').val('');
          $('#feeNew').val('');
          $('#otherNew').val('');
          doAlert('Save Partner Settings', response.message);
        },
        error: function(xhr, status, error) {
          console.log(xhr, status, error);
          SpinBtnCtrl('addBtn', false);
          const response = JSON.parse(xhr.responseText);
          doError('Save Partner Settings', response.message);
        }
      });
    }

    function updatePartner(){
      doConfirm("Update Partner Setting", "Do you really want to update this partner?", function(result) {
        if( result ){
          SpinBtnCtrl('updateBtn', true);
          const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
          const id = $('#id').val();
          const partner_name = $('#partnerName').val();
          const fee_percent = $('#fee').val();
          const other = $('#other').val();

          $.ajax({
            url: g_siteUrl + '/purchaseChecker/partner',
            type: "POST",
            data: JSON.stringify({
              id: id,
              partner_name: partner_name,
              fee_percent: fee_percent,
              other: other
            }),
            contentType: "application/json",
            headers: {
              'X-CSRF-TOKEN': csrfToken
            },
            success: function(response) {
              SpinBtnCtrl('updateBtn', false);
              getPartners();
              doAlert('Update Partner Settings', response.message);
              $('.close').trigger('click');
            },
            error: function(xhr, status, error) {
              console.log(xhr, status, error);
              SpinBtnCtrl('updateBtn', false);
              const response = JSON.parse(xhr.responseText);
              doError('Update Partner Settings', response.message);
            }
          });
        }
      });
    }

    function getPartners(){
      const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

      $.ajax({
        url: g_siteUrl + '/purchaseChecker/partners',
        type: "GET",
        contentType: "application/json",
        headers: {
          'X-CSRF-TOKEN': csrfToken
        },
        success: function(response) {
          const partners = response.data;

          let html = ``;
          let id = 0;
          partners.forEach(partner => {
            html += `<tr>
              <td>${++id}</td>
              <td>${partner.partner_name}</td>
              <td>${partner.fee_percent}</td>
              <td>${partner.other}</td>
              <td>
                <div class="btn-group w-100" role="group">
                  <button onclick="setPartnerInfo(${partner.id}, '${partner.partner_name}', ${partner.fee_percent}, '${partner.other}')" data-bs-toggle="modal" data-bs-target="#updateModal" type="button" class="btn btn-outline-primary d-flex align-items-center justify-content-between">
                    <i class="bi bi-floppy me-2"></i>
                    <span class="text-end">Update</span>
                  </button>
                  <button onclick="removePartner(${partner.id})" type="button" class="btn btn-outline-danger d-flex align-items-center justify-content-between">
                    <i class="bi bi-trash me-2"></i>
                    <span class="text-end">Remove</span>
                  </button>
                </div>
              </td>
            </tr>`;
          });

          $('#partners').html(html);
        },
        error: function(xhr, status, error) {
          console.log(xhr, status, error);
          const response = JSON.parse(xhr.responseText);
          doError('Retrieve Partner Settings', response.message ?? 'Can not retrieve partner settings. Please try again.');
        }
      });
    }

    function removePartner(id){
      doConfirm("Remove Partner Setting", "Do you really want to remove this partner?", function(result){
        if( result ){
          const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
          $.ajax({
            url: g_siteUrl + '/purchaseChecker/partner',
            type: "DELETE",
            contentType: "application/json",
            data: JSON.stringify({
              id: id,
            }),
            headers: {
              'X-CSRF-TOKEN': csrfToken
            },
            success: function(response) {
              getPartners();
              doAlert('Remove Partner Settings', response.message);
            },
            error: function(xhr, status, error) {
              console.log(xhr, status, error);
              const response = JSON.parse(xhr.responseText);
              doError('Remove Partner Settings', response.message ?? 'Can not remove partner settings. Please try again.');
            }
          });
        }
      });
    }

    function setPartnerInfo(id, partner_name, fee_percent, other){
      $('#id').val(id);
      $('#partnerName').val(partner_name);
      $('#fee').val(fee_percent);
      $('#other').val(other);
    }

    function doError(title, message){
      bootbox.alert({
        title: title,
        message: message,
        centerVertical: true,
        className: 'rubberBand animated'
      });
    }

    function doAlert(title, message){
      bootbox.alert({
        title: title,
        message: message,
        centerVertical: true,
        className: 'bounceIn animated'
      });
    }

    function doConfirm(title, message, callback){
      bootbox.confirm({
        title: title,
        message: message,
        centerVertical: true,
        buttons: {
          cancel: {
            label: '<i class="bi bi-x-circle"></i> Cancel'
          },
          confirm: {
            label: '<i class="bi bi-check-circle"></i> Confirm'
          }
        },
        callback: callback
      });
    }

    function SpinBtnCtrl(btnID, showSpin) {
      let button = document.getElementById(btnID);
      let spinner = button.querySelector('.spinner-anim');

      if (showSpin) {
        spinner.style.display = 'inline-block';
        button.disabled = true;
      } else {
        spinner.style.display = 'none';
        button.disabled = false;
      }
    }
  </script>
@endsection
