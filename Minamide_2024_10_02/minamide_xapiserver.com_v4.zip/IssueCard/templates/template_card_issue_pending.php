<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ultimopay Card Application</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <!--<link href="../vendor/bootstrap.min.css" rel="stylesheet">
  <script src="../vendor/jquery-3.6.0.min.js"></script>-->
  <style>
      /* KYC check loading start*/

      @keyframes rotate-loading {
          0% {
              transform: rotate(0deg);
              -ms-transform: rotate(0deg);
              -webkit-transform: rotate(0deg);
              -o-transform: rotate(0deg);
              -moz-transform: rotate(0deg);
          }

          100% {
              transform: rotate(360deg);
              -ms-transform: rotate(360deg);
              -webkit-transform: rotate(360deg);
              -o-transform: rotate(360deg);
              -moz-transform: rotate(360deg);
          }
      }

      @-moz-keyframes rotate-loading {
          0% {
              transform: rotate(0deg);
              -ms-transform: rotate(0deg);
              -webkit-transform: rotate(0deg);
              -o-transform: rotate(0deg);
              -moz-transform: rotate(0deg);
          }

          100% {
              transform: rotate(360deg);
              -ms-transform: rotate(360deg);
              -webkit-transform: rotate(360deg);
              -o-transform: rotate(360deg);
              -moz-transform: rotate(360deg);
          }
      }

      @-webkit-keyframes rotate-loading {
          0% {
              transform: rotate(0deg);
              -ms-transform: rotate(0deg);
              -webkit-transform: rotate(0deg);
              -o-transform: rotate(0deg);
              -moz-transform: rotate(0deg);
          }

          100% {
              transform: rotate(360deg);
              -ms-transform: rotate(360deg);
              -webkit-transform: rotate(360deg);
              -o-transform: rotate(360deg);
              -moz-transform: rotate(360deg);
          }
      }

      @-o-keyframes rotate-loading {
          0% {
              transform: rotate(0deg);
              -ms-transform: rotate(0deg);
              -webkit-transform: rotate(0deg);
              -o-transform: rotate(0deg);
              -moz-transform: rotate(0deg);
          }

          100% {
              transform: rotate(360deg);
              -ms-transform: rotate(360deg);
              -webkit-transform: rotate(360deg);
              -o-transform: rotate(360deg);
              -moz-transform: rotate(360deg);
          }
      }

      @keyframes rotate-loading {
          0% {
              transform: rotate(0deg);
              -ms-transform: rotate(0deg);
              -webkit-transform: rotate(0deg);
              -o-transform: rotate(0deg);
              -moz-transform: rotate(0deg);
          }

          100% {
              transform: rotate(360deg);
              -ms-transform: rotate(360deg);
              -webkit-transform: rotate(360deg);
              -o-transform: rotate(360deg);
              -moz-transform: rotate(360deg);
          }
      }

      @-moz-keyframes rotate-loading {
          0% {
              transform: rotate(0deg);
              -ms-transform: rotate(0deg);
              -webkit-transform: rotate(0deg);
              -o-transform: rotate(0deg);
              -moz-transform: rotate(0deg);
          }

          100% {
              transform: rotate(360deg);
              -ms-transform: rotate(360deg);
              -webkit-transform: rotate(360deg);
              -o-transform: rotate(360deg);
              -moz-transform: rotate(360deg);
          }
      }

      @-webkit-keyframes rotate-loading {
          0% {
              transform: rotate(0deg);
              -ms-transform: rotate(0deg);
              -webkit-transform: rotate(0deg);
              -o-transform: rotate(0deg);
              -moz-transform: rotate(0deg);
          }

          100% {
              transform: rotate(360deg);
              -ms-transform: rotate(360deg);
              -webkit-transform: rotate(360deg);
              -o-transform: rotate(360deg);
              -moz-transform: rotate(360deg);
          }
      }

      @-o-keyframes rotate-loading {
          0% {
              transform: rotate(0deg);
              -ms-transform: rotate(0deg);
              -webkit-transform: rotate(0deg);
              -o-transform: rotate(0deg);
              -moz-transform: rotate(0deg);
          }

          100% {
              transform: rotate(360deg);
              -ms-transform: rotate(360deg);
              -webkit-transform: rotate(360deg);
              -o-transform: rotate(360deg);
              -moz-transform: rotate(360deg);
          }
      }

      @keyframes loading-text-opacity {
          0% {
              opacity: 0
          }

          20% {
              opacity: 0
          }

          50% {
              opacity: 1
          }

          100% {
              opacity: 0
          }
      }

      @-moz-keyframes loading-text-opacity {
          0% {
              opacity: 0
          }

          20% {
              opacity: 0
          }

          50% {
              opacity: 1
          }

          100% {
              opacity: 0
          }
      }

      @-webkit-keyframes loading-text-opacity {
          0% {
              opacity: 0
          }

          20% {
              opacity: 0
          }

          50% {
              opacity: 1
          }

          100% {
              opacity: 0
          }
      }

      @-o-keyframes loading-text-opacity {
          0% {
              opacity: 0
          }

          20% {
              opacity: 0
          }

          50% {
              opacity: 1
          }

          100% {
              opacity: 0
          }
      }

      .loading-container,
      .loading {
          height: 100px;
          position: relative;
          width: 100px;
          border-radius: 100%;
      }


      .loading-container {
          margin: 10px auto
      }

      .loading {
          border: 2px solid transparent;
          border-color: transparent #a2a2a2 transparent #a2a2a2 ;
          -moz-animation: rotate-loading 1.5s linear 0s infinite normal;
          -moz-transform-origin: 50% 50%;
          -o-animation: rotate-loading 1.5s linear 0s infinite normal;
          -o-transform-origin: 50% 50%;
          -webkit-animation: rotate-loading 1.5s linear 0s infinite normal;
          -webkit-transform-origin: 50% 50%;
          animation: rotate-loading 1.5s linear 0s infinite normal;
          transform-origin: 50% 50%;
      }

      .loading-container .loading {
          -webkit-transition: all 0.5s ease-in-out;
          -moz-transition: all 0.5s ease-in-out;
          -ms-transition: all 0.5s ease-in-out;
          -o-transition: all 0.5s ease-in-out;
          transition: all 0.5s ease-in-out;
      }

      .loading-text {
          -moz-animation: loading-text-opacity 2s linear 0s infinite normal;
          -o-animation: loading-text-opacity 2s linear 0s infinite normal;
          -webkit-animation: loading-text-opacity 2s linear 0s infinite normal;
          animation: loading-text-opacity 2s linear 0s infinite normal;
          color: gray;
          font-size: 12px;
          font-weight: bold;
          opacity: 0;
          position: absolute;
          text-align: center;
          text-transform: uppercase;
          top: 50%;
          transform: translateY(-50%);
          width: 100px;
      }
      .container-sm{
          max-width: 800px;
      }
      body, html {
          height: 100%;
          margin: 0;
      }
      .centered-container {
          height: 100vh; /* Full viewport height */
      }
      .hide{
          display: none;
      }
  </style>
</head>
<body class="d-flex justify-content-center align-items-center">
<div class="container-sm centered-container d-flex flex-column justify-content-center align-items-center">
  <div class="card">
    <div class="card-header">
      Congratulations!
    </div>
    <div class="card-body doc-area">
      <div class="row pending">
        <div class="col-md-12">
          <h4 class="mb-3">Your profile and all required documents have been uploaded.</h4>
          <h6 class="ms-3">Thank you for completing this step!</h6>
          <h6 class="ms-3">Your debit card application has been submitted and is currently under review.</h6>
          <p class="ms-5">to complete the verification within 5 to 10 minutes.</p>

          <h6 class="ms-3">Please Note:</h6>
          <p class="ms-5">*In some cases, the review process might take longer than 10 minutes.</p>
          <p class="ms-5">*If you leave this page, the review will still continue, and we'll notify you of the outcome via email</p>
        </div>
        <div class="d-flex justify-content-between">
          <div class="loading-container">
            <div class="loading"></div>
            <div class="loading-text">Please<br>Wait...</div>
          </div>
        </div>
      </div>
      <div class="row approved hide text-success py-5">
        <div class="col-md-12">
          <h4 class="ms-3">Congratulations! Your application for issuance Debit Card has been approved!</h4>
          <p class="ms-5">Next step, please make a payment for the Debit Card Issuance Fee.</p>
        </div>
      </div>
      <div class="row declined hide text-danger py-5">
        <div class="col-md-12">
          <h4 class="mb-3">Your application for issuance debit card has been rejected!</h4>
          <h6 class="ms-3">The reason:</h6>
          <p class="ms-5 reason"></p>
          <p class="ms-3 mt-2">Please correct above issues and submit your information again (You have to do the process from beginning)</p>
        </div>
      </div>
    </div>
    <div class="card-footer d-flex justify-content-end hide">
      <button class="btn btn-outline-dark back-btn">
        <i class="bi bi-house"></i> Back
      </button>
    </div>
  </div>
</div>
<script>
  let g_timerID = 0;
  const g_interval = 1000;
  $(document).ready(function(){
    g_timerID = setInterval(onTimer, g_interval);

    $('.back-btn').click(function(){
      window.close();
      $('body').html('');
    });
  });

  async function onTimer() {
    let userStatus = await getUserStatus();
    console.log(userStatus.updateStatusResponse.kyc_status * 1);
    if (userStatus && userStatus.result === "success" && userStatus.updateStatusResponse) {
      if (userStatus.updateStatusResponse.kyc_status * 1 === 9) {
        $('.declined').show();
        $('.pending').hide();
        $('.approved').hide();
        $('.card-footer').show();
        clearInterval(g_timerID);

        $('.card-header').html('Sorry...');
        let userInfo = await getUserInfo();
        if (userInfo && userInfo.result === "success" && userInfo.userInfoResponse) {
          $('.reason').html(userInfo.userInfoResponse.kyc_deny_message);
        }
      } else if (userStatus.updateStatusResponse.kyc_status * 1 === 2) {
        $('.declined').hide();
        $('.pending').hide();
        $('.approved').show();
        $('.card-footer').show();
        clearInterval(g_timerID);
      }
    }
  }

  // Get user's status
  async function getUserStatus() {
    const auth_token = getCookie('auth_token');
    const apiKey = getCookie('apiKey');
    const base_url = getCookie('base_url');
    const email_address = getCookie('email_address');

    try {
      // Use await to wait for the AJAX request to complete
      const response = await $.ajax({
        url: base_url + "/updateUserStatus/",
        //url: base_url + "/updateUserStatus_local/",
        type: "POST",
        headers: {
          "Authorization": "Bearer " + apiKey,
          "Content-Type": "application/json"
        },
        data: JSON.stringify({
          auth_token: auth_token,
          email_address: email_address
        }),
        dataType: "json"  // Ensure the response is parsed as JSON
      });

      console.log(response);
      // Return the actual response object
      return response;
    } catch (error) {
      // Handle and log the error if the request fails
      console.error('Error during get user status:', error);
      return null;
    }
  }

  // Get user's status
  async function getUserInfo() {
    const auth_token = getCookie('auth_token');
    const apiKey = getCookie('apiKey');
    const base_url = getCookie('base_url');
    const email_address = getCookie('email_address');

    try {
      // Use await to wait for the AJAX request to complete
      const response = await $.ajax({
        url: base_url + "/userInfo/",
        //url: base_url + "/userInfo_local/",
        type: "POST",
        headers: {
          "Authorization": "Bearer " + apiKey,
          "Content-Type": "application/json"
        },
        data: JSON.stringify({
          auth_token: auth_token,
          email_address: email_address
        }),
        dataType: "json"  // Ensure the response is parsed as JSON
      });

      console.log(response);
      // Return the actual response object
      return response;
    } catch (error) {
      // Handle and log the error if the request fails
      console.error('Error during get user info:', error);
      return null;
    }
  }

  function getCookie(key) {
    let name = key + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let cookieArray = decodedCookie.split(';');
    for (let i = 0; i < cookieArray.length; i++) {
      let cookie = cookieArray[i].trim();
      if (cookie.indexOf(name) === 0) {
        return cookie.substring(name.length, cookie.length);
      }
    }
    return null;
  }
</script>
</body>
</html>
