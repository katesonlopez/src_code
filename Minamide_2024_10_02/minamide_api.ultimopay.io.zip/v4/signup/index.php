<?php

require_once("../include/cognito.php");

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($line) {
	//global $fh;
	$fh2 = fopen("/var/www/api.ultimopay.io/v4/signup/log/signup.log" , 'a');
	$fline = date('[Ymd H:i:s] ') . $line."\n";
	fwrite($fh2, $fline);
	fclose($fh2);
	//echo date('[Ymd H:i:s] ').$line."\n";
	//@ob_flush(); 
	//flush();
}
	
	
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	//$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$partner = "";
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			/*
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) { //UltimoCasino
				$found = 6;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_bos) { //BOS
				$found = 7;
				$coin = 'USDT';
				$partner = "BOS";
				break;
			}
			*/
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
					
				}
			} else {
				_log("not found in db");
			}
		}
	}
	@mysqli_close($dbhandle);
	

	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{6,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}


	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	_log("bat dau xu ly...");
	//if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6) || ($found==7)) {
	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

		
		
		//$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);
		
		//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
		//echo "payment_id: " . $payment_id . "<br/>";
		$json = file_get_contents('php://input');
		$data = json_decode($json, true);
		
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					//$failed_rs['error'] = 'Reached the maximum stack depth';
					_log('Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					_log('Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					//$failed_rs['error'] = 'Incorrect control character';
					_log('Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					//$failed_rs['error'] = 'Syntax error or JSON invalid';
					_log('Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					_log('Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					//$failed_rs['error'] = 'Unknown error';
					_log('Unknown error');
					break;
			}
			
			//throw new Exception($error);
			//_log($failed_rs['error']);
			_log('A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			} else {
				if (!filter_var($data['email_address'], FILTER_VALIDATE_EMAIL)) {
					//echo "<br>invalid email format !";
					$error_obj = array('errorCode' => 3, 'errorMessage' => 'invalid email address format.');
					$errors[] = $error_obj;
				} else {
					//echo "<br>" . $email . " is valid !";
				}
			}
			
			//password
			if ((!isset($data['password'])) || (empty($data['password']))) {
				$error_obj = array('errorCode' => 4, 'errorMessage' => 'password parameter is required.');
				$errors[] = $error_obj;
			} else {
				if (strlen($data['password'])<6) {
					$error_obj = array('errorCode' => 5, 'errorMessage' => 'password must have at least 6 characters');
					$errors[] = $error_obj;
				} else {
					if (strlen($data['password'])>60) {
						$error_obj = array('errorCode' => 6, 'errorMessage' => 'password cannot be longer than 60 characters');
						$errors[] = $error_obj;
					} else {
						if(!isValidPassword($data['password'])) { 
							$error_obj = array('errorCode' => 7, 'errorMessage' => 'password must have least 1 numeric character, 1 upper case character, 1 symbol character.');
							$errors[] = $error_obj;
						} else {


							//TODO

						}
					}
				}
			}
			
			//first name
			if ((!isset($data['first_name'])) || (empty($data['first_name']))) {

				$error_obj = array('errorCode' => 8, 'errorMessage' => 'first_name parameter is required.');
				$errors[] = $error_obj;
			} else {
				//if(!preg_match("/[^[:alnum:]\#?!@$%^&*-_ ]/", $data['first_name']))  {
				if (preg_match("/^[a-zA-Z ]+$/", $data['first_name'])) {
					//echo "<br>" . $myname . " is a valid name";
				} else {
					$error_obj = array('errorCode' => 9, 'errorMessage' => 'first_name contains invalid characters.');
					$errors[] = $error_obj;
				}
			}
			
			//middle name
			if (!empty($data['middle_name'])) {	
					
				if (preg_match("/^[a-zA-Z ]+$/", $data['middle_name'])) {
					//echo "<br>" . $myname . " is a valid name";
				} else {
					$error_obj = array('errorCode' => 17, 'errorMessage' => 'middle_name contains invalid characters.');
					$errors[] = $error_obj;
				}
				
			}
			
			//last name
			if ((!isset($data['last_name'])) || (empty($data['last_name']))) {
				
				$error_obj = array('errorCode' => 10, 'errorMessage' => 'last_name parameter is required.');
				$errors[] = $error_obj;
			} else {
				//if(!preg_match("/[^[:alnum:]\#?!@$%^&*-_ ]/", $data['last_name']))  {
				if (preg_match("/^[a-zA-Z ]+$/", $data['last_name'])) {
					//echo "<br>" . $myname . " is a valid name";
				} else {
					$error_obj = array('errorCode' => 11, 'errorMessage' => 'last_name contains invalid characters.');
					$errors[] = $error_obj;
				}
			}
			
			
			//country
			if ((!isset($data['country'])) || (empty($data['country']))) {
				
				$error_obj = array('errorCode' => 12, 'errorMessage' => 'country parameter is required.');
				$errors[] = $error_obj;
			} else {
				//if(!preg_match("/[^[:alnum:]\#?!@$%^&-_ ]/",$data['country']))  {
				//if (preg_match("/^[a-zA-Z0-9 ]+$/", $data['country'])) {
				//if (!preg_match ("/^[a-zA-Z0-9 \.+-\']*$/", $data['country']) ){  
				if (!preg_match ("/^[\'\+\-\w\s]*$/", $data['country']) ){  
					//echo "<br>" . $myname . " is a valid name";
					$error_obj = array('errorCode' => 13, 'errorMessage' => 'country contains invalid characters.');
					$errors[] = $error_obj;
				} else {
					
				}
			}
			
			// user_check
			$reg_user_check = trim($data['user_check'] ?? '');
			if ($reg_user_check == '1') {
				//check user exists
				$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
				if (mysqli_connect_errno() == 0) {
					mysqli_query($dbhandle, "set names utf8;");
					$sql_users_profile = "SELECT created_from FROM cryptocash_users_profile WHERE email = '" . strtolower(trim($data['email_address'])) . "'";
					_log("", $sql_users_profile);
					$rs_users_profile = mysqli_query($dbhandle, $sql_users_profile);
                    if (mysqli_num_rows($rs_users_profile) > 0) {
                        $user_check_err = true;
                        while ($row_users_profile = mysqli_fetch_array($rs_users_profile, MYSQLI_ASSOC)) {
                            if (($row_users_profile['created_from'] ?? '') == $req_partner['partner']) {
                                $user_check_err = false;
                                break;
                            }
                        }
                        if ($user_check_err) {
							$error_obj = array('errorCode' => 18, 'errorMessage' => 'That email address cannot be used with this service.');
							$errors[] = $error_obj;
						}
					}
					@mysqli_close($dbhandle);
				} else {
					@mysqli_close($dbhandle);
					header('Content-Type: application/json');
					http_response_code(500);
					$ret_rs['result'] = 'failed';
					$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
					echo json_encode($ret_rs);
					die();
				}
			}
					
			
			if (count($errors) == 0) {
				
				$errors_sub = array();
				
				
				//proceed to shift api
				require_once '../include/common.php';
				//require_once '../include/dbconfig.php';
				require_once('../classes/PostAffiliatePro/PapApi.class.php');
				
				////////////////////////////////////////////////////
				function PapLogin($_pap_url, $_username, $_password, $_type){    

					try {

						if ($_type == "merchant") {
							$_merchant_session = new Pap_Api_Session($_pap_url); 
							if(!$_merchant_session->login($_username, $_password)) {
								//die("Cannot login. Message: ".$_merchant_session->getMessage());
								//_log("Merchant Cannot login: ".$_merchant_session->getMessage());
								return;
							}
							return $_merchant_session;

						} else if ($_type == "affiliate") {
							$_aff_session = new Pap_Api_Session($_pap_url); 
							if(!$_aff_session->login($_username,$_password, Pap_Api_Session::AFFILIATE)) {
								//die("Cannot login. Message: ".$_aff_session->getMessage());
								//_log("Affiliate (" . $_username . ") Cannot login: ".$_aff_session->getMessage());
								return;        
								
							}
							return $_aff_session;
							
						}
						
					} catch (Exception $e){
						//die('Error: '.$e->getMessage());
						//_log('Error: '.$e->getMessage());
						return;
						
					}

				}

				function GetUserIdByRefId($_refid, $_merchant_session) {
					$affiliate_user = array('userid' => '', 'username' => '', 'refid' => '', 'error' => '');
					$pap_user_check_request = new Pap_Api_AffiliatesGrid($_merchant_session);
					//Filtering affiliate with refid
					$pap_user_check_request->addFilter('refid', Gpf_Data_Filter::EQUALS, $_refid);

					// sets limit to 30 rows, offset to 0 (first row starts)
					$pap_user_check_request->setLimit(0, 30);

					// sets columns, use it only if you want retrieve other as default columns
					$pap_user_check_request->addParam('columns', new Gpf_Rpc_Array(array(array('id'), array('refid'), array('userid'), 
					array('username'), array('firstname'), array('lastname'), array('rstatus'), array('parentuserid'),
					array('dateinserted'), array('salesCount'), array('clicksRaw'), array('clicksUnique'))));

					// send request
					try {
						$pap_user_check_request->sendNow();
						// request was successful, get the grid result
						$grid = $pap_user_check_request->getGrid();

						// get recordset from the grid
						$pap_user_check_recordset = $grid->getRecordset();	
						
						if (!empty($pap_user_check_recordset)) {
							foreach($pap_user_check_recordset as $rec) {
								if ((trim($rec->get('userid')) != '')  && (trim($rec->get('username')) != '')){
									$affiliate_user['userid'] = $rec->get('userid');
									$affiliate_user['refid'] = $rec->get('refid');
									$affiliate_user['username'] = $rec->get('username');
									break;
								}				
							}
						}
					} catch(Exception $e) {
						//die("API call error: ".$e->getMessage());
						//_log("GetUserIdByRefId::API call error: ".$e->getMessage());
						$affiliate_user['error'] = $e->getMessage();
						return $affiliate_user;
					}

					
					return $affiliate_user;
				}
				
				$affiliate_parent_user_id = "";
				$affiliate_parent_user_name = "";
				$allow_countries = array("Abkhazia", "Cape Verde", "Cook Islands", "Ethiopia", "Artsakh", "Niue", "Pakistan", "Palestine", "Transnistria", "Serbia", "Somaliland", "South Ossetia", "Sri Lanka", "Syria", "Trinidad and Tobago", "Tunisia", "Venezuela", "Western Sahara", "Yemen", "Zimbabwe", "Iran", "Curacao");
				
				$country_arr = array('United States', 'Abkhazia', 'Afghanistan', 'Albania', 'Algeria', 'Andorra', 'Angola', 'Antigua and Barbuda', 'Argentina', 'Armenia', 'Artsakh', 'Australia', 'Austria', 'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bhutan', 'Bolivia', 'Bosnia and Herzegovina', 'Brazil', 'Brunei', 'Bulgaria', 'Burkina Faso', 'Burundi', 'Cabo Verde', 'Cambodia', 'Cameroon', 'Canada', 'Central African Republic', 'Chad', 'Chile', 'China', 'Colombia', 'Comoros', 'Congo', 'Cook Islands', 'Costa Rica', 'Cote d\'Ivoire', 'Croatia', 'Cuba', 'Curacao', 'Cyprus', 'Czech Republic', 'Denmark', 'Djibouti', 'Dominica', 'Dominican Republic', 'East Timor', 'Egypt', 'El Salvador', 'Equatorial Guinea', 'Eritrea', 'Estonia', 'Ethiopia', 'Fiji', 'Finland', 'France', 'Gabon', 'Gambia', 'Georgia', 'Germany', 'Ghana', 'Gibraltar', 'Greece', 'Grenada', 'Guatemala', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Honduras', 'Hong Kong', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iraq', 'Iran', 'Ireland', 'Israel', 'Italy', 'Jamaica', 'Japan', 'Jordan', 'Kazakhstan', 'Kenya', 'Kiribati', 'South Korea', 'Kosovo', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Latvia', 'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Macedonia', 'Madagascar', 'Malawi', 'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Mauritania', 'Mauritius', 'Mexico', 'Federated States of Micronesia', 'Moldova', 'Monaco', 'Mongolia', 'Montenegro', 'Montserrat', 'Morocco', 'Mozambique', 'Myanmar', 'Namibia', 'Nauru', 'Nepal', 'Netherlands', 'New Zealand', 'Nicaragua', 'Niger', 'Nigeria', 'Niue', 'Norway', 'Oman', 'Pakistan', 'Palau', 'Palestine', 'Panama', 'Papua New Guinea', 'Paraguay', 'Peru', 'Philippines', 'Poland', 'Portugal', 'Qatar', 'Romania', 'Russia', 'Rwanda', 'Saint Kitts and Nevis', 'Saint Lucia', 'Saint Vincent and the Grenadines', 'Samoa', 'San Marino', 'Serbia', 'Sao Tome and Principe', 'Saudi Arabia', 'Senegal', 'Seychelles', 'Sierra Leone', 'Singapore', 'Slovakia', 'Slovenia', 'Solomon Islands', 'Somalia', 'Somaliland', 'South Africa', 'South Ossetia', 'Spain', 'Sri Lanka', 'Sudan', 'South Sudan', 'Suriname', 'Syria', 'Swaziland', 'Sweden', 'Switzerland', 'Taiwan', 'Tajikistan', 'Tanzania', 'Thailand', 'Togo', 'Tonga', 'Transnistria', 'Trinidad and Tobago', 'Tunisia', 'Turkey', 'Turkmenistan', 'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'Uruguay', 'Uzbekistan', 'Vanuatu', 'Vatican City', 'Venezuela', 'Vietnam', 'Yemen', 'Zambia', 'Zimbabwe', 'Western Sahara');
				
				
				//receive POST params
				$reg_email_address = strtolower(trim($data['email_address']));
				$reg_password = trim($data['password']);
				$reg_first_name = trim($data['first_name']);
				$reg_middle_name = "";
				if (!empty($data['middle_name'])) {
					$reg_middle_name = trim($data['middle_name']);
				}
				$reg_last_name = trim($data['last_name']);
				$reg_country = trim($data['country']);
				$reg_country_shift = $reg_country;				
				$req_affiliation = (!empty($data['affiliation']))?trim($data['affiliation']):"";
				$req_ref_id = (!empty($data['ref_id']))?trim($data['ref_id']):"";
				// if (isset($_COOKIE['UltimopayAffRefId'])) {
				// 	_log($_COOKIE['UltimopayAffRefId']);
				// 	$req_ref_id = $_COOKIE['UltimopayAffRefId'];
				// }
				//if ($found == 7) {
				//	$req_affiliation = (!empty($data['affiliation']))?trim($data['affiliation']):"";
				//}				
				_log("sign up started...");
				_log($reg_email_address . " / ". $reg_password . " / " . $reg_first_name . " / " . $reg_last_name . " / " . $reg_country  . " / " . $req_affiliation  . " / " . $req_ref_id);
				if (!in_array($reg_country, $country_arr))  {
					$reg_country_shift = "Philippines";
				} else {
					if ((strtoupper($reg_country) == "GIBRALTAR") || (strtoupper($reg_country) == "MONTSERRAT")) {
						$reg_country_shift = "United Kingdom";
					}
					if (strtoupper($reg_country) == "HONG KONG") {
						$reg_country_shift = "China";
					}				
					if (in_array($reg_country, $allow_countries))  {
						$reg_country_shift = "Philippines";				
					}
				}
				
				$post_data = array();				
				$post_data['ClientId'] = $aws_cognito_app_client_id;		
				$post_data['Username'] = $reg_email_address;
				$post_data['Password'] = $reg_password;
				$post_data['ValidationData'] = null;
				$post_data['exchange'] = "PLUSQO";
				
				$attributes = array();
				
				//email
				$email_arr = array();
				$email_arr['name'] = "email";
				$email_arr['value'] = $email;
				$attributes[] = $email_arr;
				
				//given name
				$given_name_arr = array();
				$given_name_arr['name'] = "given_name";
				$given_name_arr['value'] = $reg_first_name;
				$attributes[] = $given_name_arr;
				
				//middle name
				if (trim($reg_middle_name) != "") {
					$middle_name_arr = array();
					$middle_name_arr['name'] = "middle_name";
					$middle_name_arr['value'] = $reg_middle_name;
					$attributes[] = $middle_name_arr;
				}
				
				//family name
				$surname_arr = array();
				$surname_arr['name'] = "family_name";
				$surname_arr['value'] = $reg_last_name;
				$attributes[] = $surname_arr;
				
				//country
				$country_arr = array();
				$country_arr['name'] = "custom:country";
				$country_arr['value'] = $reg_country_shift;
				$attributes[] = $country_arr;
				
				
				$post_data['userAttributes'] = $attributes;
				$signup_res = api_call('/authentication/user_authentication/signUp', 0, '', $post_data, '');
        _log("signup_res for /authentication/user_authentication/signUp");
        _log(json_encode($signup_res));
				if (($signup_res['http_code'] == "200") || ($signup_res['http_code'] == "200 OK")) {
					///////////////////////////////////////////////////////////////////////////////////
					//PostAffiliatePro (SignUp)
					//sleep(1);				
					$raw_pap_merchant_login_obj = PapLogin(PAP_URL, MERCHANT_USERNAME, MERCHANT_PASSWORD, "merchant");
					if ((!is_null($raw_pap_merchant_login_obj)) && (!empty($raw_pap_merchant_login_obj))) {
						$pap_affiliate_obj = GetUserIdByRefId($req_ref_id, $raw_pap_merchant_login_obj);
						if ($pap_affiliate_obj['userid'] == '') {
							_log("User with refid=" . $req_ref_id . " not found !");
						} else {
							_log("found userid = " . $pap_affiliate_obj['userid'] . " for refid=" . $req_ref_id);
							$affiliate_parent_user_id = $pap_affiliate_obj['userid'];
							$affiliate_parent_user_name = $pap_affiliate_obj['username'];
						}
						$affiliate = new Pap_Api_Affiliate($raw_pap_merchant_login_obj);
						$affiliate->setUsername($reg_email_address);
						$affiliate->setFirstname($reg_first_name);
						$affiliate->setLastname($reg_last_name);
						$affiliate->setNotificationEmail($reg_email_address);
						if ($affiliate_parent_user_id != "") {
							$affiliate->setParentUserId($affiliate_parent_user_id);
						}
						
						$affiliate->setPassword($reg_password);
						// $affiliate->setParentUserId($req_visitor_id);
						try {
							if ($affiliate->add()) {
								_log($reg_email_address . "::Affiliate saved successfuly id: " . $affiliate->getUserid() . " / refid: " . $affiliate->getRefid());
							} else {
								_log($reg_email_address . "::Cannot save affiliate: ".$affiliate->getMessage());
							}
						} catch (Exception $e) {
							_log("Error while communicating with PAP: ".$e->getMessage());
						}

					} else {
						_log($email . "::failed to login as merchant !");
					}
					
					//add data to users_profile
					$shift_full_name = $reg_first_name . " " . $reg_last_name;
					$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
					if (mysqli_connect_errno() == 0) {
						mysqli_query($dbhandle, "set names utf8;");
						$sql_add_profile = "INSERT INTO cryptocash_users_profile (email, given_name, middle_name, sur_name, shift_full_name, country, add_dt, pap_cookie, refid, parent_userid, parent_email, created_from, affiliation) VALUES ('$reg_email_address', '$reg_first_name', '$reg_middle_name', '$reg_last_name', '$shift_full_name', '$reg_country', NOW(), '', '$req_ref_id', '$affiliate_parent_user_id', '$affiliate_parent_user_name', '" . $req_partner['partner'] . "', '$req_affiliation')";
						_log($sql_add_profile);
						mysqli_query($dbhandle, $sql_add_profile);
						if (mysqli_affected_rows($dbhandle) <= 0) {
							
							_log($reg_email_address . ": insert cryptocash_users_profile failed");
						}
						// bigin add 20230323 k.o.
						$sql_add_user_status = "INSERT INTO cryptocash_user_status (email_address, created_from) VALUES ('$reg_email_address', '" . $req_partner['partner'] . "')";
						_log($sql_add_user_status);
						mysqli_query($dbhandle, $sql_add_user_status);
						if (mysqli_affected_rows($dbhandle) <= 0) {
							
							_log($reg_email_address . ": insert cryptocash_user_status failed");
						}
						// end add 20230323 k.o.
						@mysqli_close($dbhandle);
						
					} else {			
						_log($reg_email_address . "::could not connect db when add to cryptocash_users_profile !");
						
					}
					
					
					$signup_response = array('email_address' => $reg_email_address, 'signupConfirmed' => false);
					$ret_rs['result'] = 'success';
					$ret_rs['signupResponse'] = $signup_response;
					//$ret_rs['signupDateTime'] = $reg_email_address;
					header('Content-Type: application/json');
					echo json_encode($ret_rs);
					die();
					///////////////////////////////////////////////////////////////////////////////////
				} else {
					$_signup_error_type = (!empty($signup_res['result']['__type']))?trim($signup_res['result']['__type']):'';
					$_signup_error_message = (!empty($signup_res['result']['message']))?trim($signup_res['result']['message']):'';

          $ret_rs['result'] = 'failed';

					if (($_signup_error_type == 'UsernameExistsException') ||
              (str_contains(strtolower($_signup_error_message), "already exists"))) {

            // Try to sign in to check if this user completed confirmation or not.
            _log("signin started... $reg_email_address, $reg_password");

            $login_first_res = _cognito_signIn($reg_email_address, $reg_password);
            _log( "signin res: ".json_encode($login_first_res));
            if ($login_first_res['result'] != 'success') {
              if (str_contains(strtolower($login_first_res['message']), "user is not confirmed")) {
                $ret_rs['error'] = array('errorCode' => 15, 'errorMessage' => 'user is not confirmed.');
              }
              else{
                $ret_rs['error'] = array('errorCode' => 14, 'errorMessage' => 'An account with the given email already exists.');
              }
            }
            else{
              $ret_rs['error'] = array('errorCode' => 14, 'errorMessage' => 'An account with the given email already exists.');
            }
          } else {
						$ret_rs['error'] = array('errorCode' => 16, 'errorMessage' => 'Password length must be between 6 and 60 characters, and contains at least 1 numeric character, 1 lowercase character, 1 uppercase character, and 1 symbol character');
					}

          header('Content-Type: application/json');
          echo json_encode($ret_rs);
          die();
        }

				/*
				$signup_res = api_call('/authentication/user_authentication/signUp', 0, '', $post_data, '');
				if (($signup_res['result']['message'] == "") &&  (!is_null($signup_res['result']['signUpResponse'])))   {	
				//if ( (isset($signup_res['result']['client_user_id'])) && (isset($signup_res['result']['username'])) && (isset($signup_res['result']['user_id'])) ) {
					
					
					
					//PostAffiliatePro (SignUp)
					//sleep(1);				
					$raw_pap_merchant_login_obj = PapLogin(PAP_URL, MERCHANT_USERNAME, MERCHANT_PASSWORD, "merchant");
					if ((!is_null($raw_pap_merchant_login_obj)) && (!empty($raw_pap_merchant_login_obj))) {
						$pap_affiliate_obj = GetUserIdByRefId($req_ref_id, $raw_pap_merchant_login_obj);
						if ($pap_affiliate_obj['userid'] == '') {
							_log("User with refid=" . $req_ref_id . " not found !");
						} else {
							_log("found userid = " . $pap_affiliate_obj['userid'] . " for refid=" . $req_ref_id);
							$affiliate_parent_user_id = $pap_affiliate_obj['userid'];
							$affiliate_parent_user_name = $pap_affiliate_obj['username'];
						}
						$affiliate = new Pap_Api_Affiliate($raw_pap_merchant_login_obj);
						$affiliate->setUsername($reg_email_address);
						$affiliate->setFirstname($reg_first_name);
						$affiliate->setLastname($reg_last_name);
						$affiliate->setNotificationEmail($reg_email_address);
						if ($affiliate_parent_user_id != "") {
							$affiliate->setParentUserId($affiliate_parent_user_id);
						}
						
						$affiliate->setPassword($reg_password);
						// $affiliate->setParentUserId($req_visitor_id);
						try {
							if ($affiliate->add()) {
								_log($reg_email_address . "::Affiliate saved successfuly id: " . $affiliate->getUserid() . " / refid: " . $affiliate->getRefid());
							} else {
								_log($reg_email_address . "::Cannot save affiliate: ".$affiliate->getMessage());
							}
						} catch (Exception $e) {
							_log("Error while communicating with PAP: ".$e->getMessage());
						}

					} else {
						_log($email . "::failed to login as merchant !");
					}
					
					//add data to users_profile		
					$shift_full_name = $reg_first_name . " " . $reg_last_name;
					$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
					if (mysqli_connect_errno() == 0) {
						mysqli_query($dbhandle, "set names utf8;");
						$sql_add_profile = "INSERT INTO cryptocash_users_profile (email, given_name, middle_name, sur_name, shift_full_name, country, add_dt, pap_cookie, refid, parent_userid, parent_email, created_from, affiliation) VALUES ('$reg_email_address', '$reg_first_name', '$reg_middle_name', '$reg_last_name', '$shift_full_name', '$reg_country', NOW(), '', '$req_ref_id', '$affiliate_parent_user_id', '$affiliate_parent_user_name', '" . $req_partner['partner'] . "', '$req_affiliation')";
						_log($sql_add_profile);
						mysqli_query($dbhandle, $sql_add_profile);
						if (mysqli_affected_rows($dbhandle) <= 0) {
							
							_log($reg_email_address . ": insert cryptocash_users_profile failed");
						}
						// bigin add 20230323 k.o.
						$sql_add_user_status = "INSERT INTO cryptocash_user_status (email_address, created_from) VALUES ('$reg_email_address', '" . $req_partner['partner'] . "')";
						_log($sql_add_user_status);
						mysqli_query($dbhandle, $sql_add_user_status);
						if (mysqli_affected_rows($dbhandle) <= 0) {
							
							_log($reg_email_address . ": insert cryptocash_user_status failed");
						}
						// end add 20230323 k.o.
						@mysqli_close($dbhandle);
						
					} else {			
						_log($reg_email_address . "::could not connect db when add to cryptocash_users_profile !");
						
					}
					
					
					$signup_response = array('email_address' => $reg_email_address, 'signupConfirmed' => false);
					$ret_rs['result'] = 'success';
					$ret_rs['signupResponse'] = $signup_response;
					//$ret_rs['signupDateTime'] = $reg_email_address;
					header('Content-Type: application/json');
					echo json_encode($ret_rs);
					die();
					/////////////////////////////////////////////////////////////////////////////////////
					//old code add db
					
				} else {
					
					if ( strpos(strtolower($signup_res['result']['message']), "already exists") !== false ) {
						
						$post_data_ex = array();
						$post_data_ex['username'] = $reg_email_address;
						$post_data_ex['code'] = "12345678";
						$post_data_ex['exchange'] = "PLUSQO";
						///////////////////////////////////////////////////////
						$verify_res = api_call('/authentication/user_authentication/confirmSignUp', 0, '', $post_data_ex, '');
						if ($verify_res['result']['result'] === true) {
						//if (($verify_res['result']['message'] == "") &&  (!is_null($verify_res['result']['confirmSignUpResponse'])))   {	
						//if ( (isset($signup_res['result']['client_user_id'])) && (isset($signup_res['result']['username'])) && (isset($signup_res['result']['user_id'])) ) {
							_log("vao day ok...");
							_log("shift message : " . $verify_res['result']['message']);
							
							
						} else {
							_log("vao day NG...");
							_log("shift message : " . $verify_res['result']['message']);
							if (( strpos(strtolower($verify_res['result']['message']), "user cannot be confirmed") !== false ) || ( strpos(strtolower($verify_res['result']['message']), "current status is confirmed") !== false )) { //already been a confimed user
								//$data['msg_ex'] = $signup_res['result']['message'];					
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => 14, 'errorMessage' => 'An account with the given email address already exists. Please use another email address.');
								header('Content-Type: application/json');
								echo json_encode($ret_rs);
								die();
							} else {
								if (( strpos(strtolower($verify_res['result']['message']), "not found") !== false )) {
									
								} else if (( strpos(strtolower($verify_res['result']['message']), "invalid verification code") !== false )) {
									
									$ret_rs['result'] = 'failed';
									$ret_rs['error'] = array('errorCode' => 15, 'errorMessage' => 'This account has not completed sign up yet.');
									header('Content-Type: application/json');
									echo json_encode($ret_rs);
									die();
								} else if (( strpos(strtolower($verify_res['result']['message']), "invalid code") !== false )) {
									$ret_rs['result'] = 'failed';
									$ret_rs['error'] = array('errorCode' => 15, 'errorMessage' => 'This account has not completed sign up yet.');
									header('Content-Type: application/json');
									echo json_encode($ret_rs);
									die();
								}
								
							}
							
							
						}
						
						///////////////////////////////////////////////////////
					} else {
						//$data['msg_ex'] = "Password must be 6 characters or more and combine numbers, lowercase letters, uppercase letters, and symbols.<br/>For example: abc1A#";
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 16, 'errorMessage' => 'Password length must be between 6 and 60 characters, and contains at least 1 numeric character, 1 lowercase character, 1 uppercase character, and 1 symbol character');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					}
					
					//if (isset($signup_res['result']['message'])) {
					//	_log($signup_res['result']['message']);	
					//} else {
					//	_log($email . "::unknown shift error");	
					//}
					

				}
				*/
				
				
				
			} else {
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors[0];
				_log($ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
				
			
		}

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>