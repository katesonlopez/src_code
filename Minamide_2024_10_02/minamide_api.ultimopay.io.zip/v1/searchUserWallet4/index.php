<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {

    // Determine the log file path based on the operating system
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // Windows
        if ($email == "") {
            $logFilePath = 'C:' . DIRECTORY_SEPARATOR . '_searchUserWallet.log';
        } else {
            $logFilePath = 'C:' . DIRECTORY_SEPARATOR . $email . '_searchUserWallet.log';
        }
    } else {
        // Non-Windows (e.g., Unix/Linux)
        if ($email == "") {
            $logFilePath = '/var/www/api.ultimopay.io/v4/searchUserWallet/log/searchUserWallet.log';
        } else {
            $logFilePath = '/var/www/api.ultimopay.io/v4/searchUserWallet/log/' . $email . '.log';
        }
    }

    // Open the log file for appending (or create it if it doesn't exist)
    $fh2 = fopen($logFilePath, 'a');

    if ($fh2) {
        $fLine = date('[Ymd H:i:s] ') . $line . "\n";

        // Write the log line to the file
        fwrite($fh2, $fLine);

        // Close the log file
        fclose($fh2);
    } else {
        // Handle any errors that may occur while opening the file
        echo "Error opening the log file.";
    }
	
}
	
	
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		_log("", "ket noi thanh cong");
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	//$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$partner = "";
	$allowed_deposit_currency_arr = array('USDT');
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	
	foreach (getallheaders() as $name => $value) {
		
		if ($name == 'Authorization') {
			
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
					
				}
			} else {
				_log("", "not found in db");
			}
		}
	}

	function generateRandomString($length, $bitmask) {
		$uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$lowercase = 'abcdefghijklmnopqrstuvwxyz';
		$numbers = '0123456789';
		$special  = '_.-';   
		$characters = '';
		$characters .= $uppercase . $lowercase . $numbers;
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
		  $randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	function validateDate($date, $format = 'Y-m-d'){
		$d = DateTime::createFromFormat($format, $date);
		return $d && $d->format($format) === $date;
	}

	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}

	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

		
		$json = file_get_contents('php://input');
		$data = json_decode($json, true);
		
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					_log("", 'Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					_log("", 'Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					_log("", 'Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					_log("", 'Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					_log("", 'Unknown error');
					break;
			}
			
			_log("", 'A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email_address
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			}
			//auth_token
			if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
				$error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
				$errors[] = $error_obj;
			}

			if (count($errors) == 0) {
				
				$errors_sub = array();
				
				require_once '../include/common.php';
				
				////////////////////////////////////////////////////
				
				//receive POST params
				$email_address = mysqli_real_escape_string($dbhandle, trim($data['email_address']));
				$private_key = mysqli_real_escape_string($dbhandle, trim($data['auth_token']));
				$user_list = mysqli_real_escape_string($dbhandle, trim($data['user_list']));
				$user_list_arr = explode(",", $user_list);
				
				$where_query = "";
				if ($user_list_arr[0]) {
					$where_query  .= " WHERE shift_login_email='" . trim($user_list_arr[0]) . "'";
				}
				for($i = 1; $i < count($user_list_arr); ++$i) {
					$where_query  .= " OR shift_login_email='" . trim($user_list_arr[$i]) . "'";
				}
					
				$allow_access_api = 0;
				
				$my_db_private_key = '';
				$my_db_auth_token = '';
				$sql_check_signin = "select a.* from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b where a.email_address = '$email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_email_address";
				//_log($sql_check_signin);
				$rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
				if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
					$allow_access_api = 1;
					while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
						$my_db_private_key = trim($row_signin['private_key']);
						$my_db_auth_token = trim($row_signin['auth_token']);
					}
				}
				
				if ($allow_access_api == 1) {
					
					if ($private_key != $my_db_private_key) {
						@mysqli_close($dbhandle);
						header('Content-Type: application/json');
						http_response_code(500);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'Unauthorized.');
						echo json_encode($ret_rs);
						die();
					} else {
						/////////////////////////////////////////////////////////////////////////////

						$authorization_value = "Bearer " . $my_db_auth_token;
						$wallet_ret_arr = array();
						
						//check there is data of my shift wallet?
						$sql_check_shift_wallet = "select * from cryptocash_shift_wallet" . $where_query . " ORDER BY shift_login_email ASC, shift_account_currency ASC";
						_log("", $sql_check_shift_wallet);
						$rs_check_shift_wallet = mysqli_query($dbhandle, $sql_check_shift_wallet);
						while ($row_shift_wallet = mysqli_fetch_array($rs_check_shift_wallet, MYSQLI_ASSOC)) {
							unset($my_currency_wallet);
							$my_currency_wallet = array();
							$my_currency_wallet['email_address'] = trim($row_shift_wallet['shift_login_email']);
							$my_currency_wallet['currency'] = strtoupper(trim($row_shift_wallet['shift_account_currency']));
							$my_currency_wallet['user_id'] = trim($row_shift_wallet['shift_user_id']);
							$my_currency_wallet['account_id'] = trim($row_shift_wallet['shift_account_id']);
							$wallet_ret_arr[] = $my_currency_wallet;
						}
						
						@mysqli_close($dbhandle);
						
						// if ($report_type) {
						// 	$tx_history_ret_arr = array_filter($tx_history_ret_arr, function($item) use ($report_type_arr) {
						// 		return in_array($item['type'], $report_type_arr);
						// 	});
						// 	$tx_history_ret_arr = array_values($tx_history_ret_arr);
						// }

						$ret_rs['result'] = 'success';
						// $ret_rs['email_address'] = $email_address;
						$ret_rs['walletResponse'] = $wallet_ret_arr;
						echo json_encode($ret_rs);
						die();
						/////////////////////////////////////////////////////////////////////////////
					}
					
					
					
				} else {
					@mysqli_close($dbhandle);
					header('Content-Type: application/json');
					http_response_code(500);
					$ret_rs['result'] = 'failed';
					$ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'you must sign in to use this API.');
					echo json_encode($ret_rs);
					die();
				}
				
			} else {
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors;
				//_log("", $ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
				
			
		}

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>