<?php
global $baseUrl;
include 'includes/header.php';
?>
<!-- Necessary js start-->
<link rel="stylesheet" href="<?php echo $baseUrl; ?>assets/css/jquery.dataTables.min.css">
<script src="<?php echo $baseUrl; ?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $baseUrl; ?>assets/js/auth.js"></script>
<!-- Necessary js end -->

<!-- Container start -->
<div class="main-content container d-flex">
  <div class="col-12 col-md-10 col-lg-12">
    <h3 class="text-center mt-4 mb-4">Payments Report</h3>

    <!-- Start report section -->
    <div class="card blue-boarder mt-4 mb-4">
      <div class="card-header bg-primary-opacity">
        <div class="panel-list">
          <div class="panel-list-left font-weight-bold fs-6">
            Card Payments Report
          </div>
        </div>
      </div>

      <div class="card-body">
        <table id="card_report_table" class="table">
          <thead id="card_report_thead" class="bg-primary-opacity">
          <tr>
            <th>Amount</th>
            <th>Product Name</th>
            <th>Email Address</th>
            <th>Name</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
          </thead>
          <tbody id="card_report_tbody">
          </tbody>
        </table>
      </div>
    </div>
    <!-- End report section -->
  </div>
</div>
<!-- Container end -->

<script>
  $(document).ready(function() {

    loadCardReport();

    $(window).resize(function() {

    });
  });

  function loadCardReport(){
    /*const tHeader = $('#card_report_thead');
    const tBody = $('#card_report_tbody');
    if( isMobileView()) {
      tHeader.hide();
    }
    else {
      tHeader.show();
    }*/

    // Initialize DataTable
    let dataTable = $('#card_report_table').DataTable({
      searching: true, // Hide the search menu
      processing: true,
      serverSide: true,
      scrollCollapse: true,
      scrollX: true,
      columnDefs: [
        { targets: '_all', orderable: false } // Disable sorting for all columns
      ],
      ajax: {
        url: window.location.origin + BASE_URL + 'pay_with_card_report.php',
        data: function (d) {
          d.orderNo = $('#orderNo').val();
          d.fromDate = $('#fromDate').val();
          d.toDate = $('#toDate').val();
          d.email = $('#email').val();
          d.name = $('#name').val();
          d.status = $('#status').val();
          d.pageNo = (parseInt(d.start / d.length) + 1); // Calculate page number
          d.pageSize = d.length;
        },
        dataSrc: function (response) {
          var formattedJSON = JSON.stringify(response, null, 2);
          $('.error-box').hide();
          $(".api-response").removeClass('text-danger').removeClass('text-success').addClass('text-success');
          $(".api-response").html('<pre>' + formattedJSON + '</pre>');

          // Map the expected keys
          response.recordsTotal = response.body.total_data_size;
          response.recordsFiltered = response.body.searched_data_size;

          return response.body.data;
        },
        beforeSend: function (xhr) {
          xhr.setRequestHeader('Authorization', API_KEY);
        },
        error: function(jqXHR, textStatus, errorThrown) {
          $('.error-box').show();
          $('.error-box .card-header').html("Error");
          if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
            // Display the error message if available
            $('.error-box .card-body').html(jqXHR.responseJSON.message);
          } else {
            // If 'message' is not available, display a generic error message
            $('.error-box .card-body').html("An error occurred.");
          }
          $(".api-response").removeClass('text-danger').removeClass('text-success').addClass('text-danger');
          return null;
        }
      },
      columns: [
        {
          data: null,
          render: function (data, type, row, meta) {
            return meta.row + 1 + (meta.settings._iDisplayStart || 0);
          }
        },
        {
          data: 'orderNo',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              return data === null ? '' : data;
            }
            return data;
          },
        },
        {
          data: 'name',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              return data === null ? '' : data;
            }
            return data;
          },
        },
        {
          data: 'email_address',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              return data === null ? '' : data;
            }
            return data;
          },
        },
        {
          data: 'email_sent',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              if (data === null) {
                return '';
              } else if (data === 'draft') {
                return '<span style="color: darkgray"><span><i class="fas fa-envelope"></i></span></span>';
              } else if (data === 'sent') {
                return '<span style="color: green"><span><i class="fas fa-envelope"></i></span><sup><i class="fas fa-check-circle"></i></sup></span>';
              } else if (data === 'failed') {
                return '<span style="color: #d70000"><span><i class="fas fa-envelope"></i></span><sup><i class="fas fa-times-circle"></i></sup></span>';
              } else {
                return data;
              }
            }
            return data;
          },
        },
        {
          data: 'created_at',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              return data === null ? '' : convertDateString(data);
            }
            return data;
          },
        },
        {
          data: 'amount',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              return (data === null || data*1 === 0) ? '' : data;
            }
            return data;
          },
        },
        {
          data: 'fee',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              return (data === null || data*1 === 0) ? '' : data;
            }
            return data;
          },
        },
        {
          data: 'fee_percent',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              return (data === null || data*1 === 0) ? '' : data;
            }
            return data;
          },
        },
        {
          data: 'product_name',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              return data === null ? '' : data;
            }
            return data;
          },
        },
        {
          data: 'card_holder_name',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              return data === null ? '' : data;
            }
            return data;
          },
        },
        {
          data: 'status',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              if (data === null) {
                return '';
              } else if (data === 'Pre-stage') {
                return '<span class="badge" style="background-color: grey; color: white">'+ data +'</span>';
              } else if (data === 'Initial') {
                return '<span class="badge" style="background-color: dodgerblue; color: white">'+ data +'</span>';
              } else if (data === 'Approved') {
                return '<span class="badge" style="background-color: #008c00; color: white">'+ data +'</span>';
              } else if (data === 'Voided') {
                return '<span class="badge" style="background-color: orange; color: white">'+ data +'</span>';
              } else if (data === 'Settled') {
                return '<span class="badge" style="background-color: #00b900; color: white">'+ data +'</span>';
              } else if (data === 'Refund') {
                return '<span class="badge" style="background-color: darkorchid; color: white">'+ data +'</span>';
              } else if (data === 'Pending Payment') {
                return '<span class="badge" style="background-color: lightseagreen; color: white">'+ data +'</span>';
              } else if (data === 'Rejected') {
                return '<span class="badge" style="background-color: #da0000; color: white">'+ data +'</span>';
              } else if (data === 'Expired') {
                return '<span class="badge" style="background-color: darkred; color: white">'+ data +'</span>';
              } else if (data === 'Cancelled') {
                return '<span class="badge" style="background-color: orange; color: white">'+ data +'</span>';
              } else {
                return data;
              }
            }
            return data;
          },
        },
        {
          data: 'domain',
          render: function (data, type, row, meta) {
            if (type === 'display') {
              return data === null ? '' : data;
            }
            return data;
          },
        },
      ],
      // Use the new key names for total records and filtered records
      recordsTotal: 'total_data_size',
      recordsFiltered: 'searched_data_size',
    });
  }
</script>
<?php include 'includes/footer.php'; ?>
