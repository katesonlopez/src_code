<?php

namespace App\Http\Controllers;

use App\Utils;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AuthenticationController extends Controller
{
  // Login
  public function login(Request $request){
    // Check the referer if it from dashboard page
    $referer = $request->headers->get('referer');
    $domain = parse_url($referer, PHP_URL_HOST);
    Log::info("domain:$domain");

    // Get the allowed referers from the environment variable
    $allowedReferers = explode(',', env('ALLOWED_REFERERS', 'dashboard.ultimopay.io'));

    if (!in_array($domain, $allowedReferers)) {
      abort(403, 'Access denied');
    }

    // Do main action
    $merchant = Utils::getInputValue('merchant') ?? env("MERCHANT");
    $full = Utils::getInputValue('withdraw') ?? "off";
    $deposit = Utils::getInputValue('deposit') ?? "off";
    $buy = Utils::getInputValue('buy') ?? "off";
    $request->session()->put('merchant',$merchant);
    $request->session()->put('withdraw',$full);
    $request->session()->put('deposit',$deposit);
    $request->session()->put('buy',$buy);
    $request->session()->put('login_type', env('LOGIN_1'));

    $pageConfigs = [
      'bodyClass' => "bg-full-screen-image",
      'blankPage' => true
    ];

    return view('/pages/auth-login', [
      'pageConfigs' => $pageConfigs,
      'data' => ""
    ]);
  }

  public function login2(Request $request){
    // Check the referer if it from dashboard page
    $referer = $request->headers->get('referer');
    $domain = parse_url($referer, PHP_URL_HOST);

    // Get the allowed referers from the environment variable
    $allowedReferers = explode(',', env('ALLOWED_REFERERS', 'dashboard.ultimopay.io'));

    if (!in_array($domain, $allowedReferers)) {
      abort(403, 'Access denied');
    }

    // Do main action
    // $request->input() method did not work for this situation.
    $id = Utils::getInputValue('id') ?? env('');
    $merchant = Utils::getInputValue('merchant') ?? env('MERCHANT');
    $full = Utils::getInputValue('withdraw') ?? env('off');
    $deposit = Utils::getInputValue('deposit') ?? env('off');
    $buy = Utils::getInputValue('buy') ?? env('off');

    $request->session()->put('merchant', $merchant);
    $request->session()->put('id', $id);
    $request->session()->put('withdraw', $full);
    $request->session()->put('deposit', $deposit);
    $request->session()->put('buy', $buy);
    $request->session()->put('login_type', env('LOGIN_2'));

    $pageConfigs = [
      'bodyClass' => "bg-full-screen-image",
      'blankPage' => true
    ];

    return view('/pages/auth-login2', [
      'pageConfigs' => $pageConfigs,
      'data' => session()->has('data') ? session()->get('data') : []
    ]);
  }

  // Register
  public function register(){
    $pageConfigs = [
      'bodyClass' => "bg-full-screen-image",
      'blankPage' => true
    ];

    return view('/pages/auth-register', [
      'pageConfigs' => $pageConfigs
    ]);
  }

  // Forgot Password
  public function forgot_password(){
    $pageConfigs = [
      'bodyClass' => "bg-full-screen-image",
      'blankPage' => true
    ];

    return view('/pages/auth-forgot-password', [
      'pageConfigs' => $pageConfigs
    ]);
  }

  // Reset Password
  public function reset_password(){
    $pageConfigs = [
      'bodyClass' => "bg-full-screen-image",
      'blankPage' => true
    ];

    return view('/pages/auth-reset-password', [
      'pageConfigs' => $pageConfigs
    ]);
  }

  // Lock Screen
  public function lock_screen(){
    $pageConfigs = [
      'bodyClass' => "bg-full-screen-image",
      'blankPage' => true
    ];

    return view('/pages/auth-lock-screen', [
      'pageConfigs' => $pageConfigs
    ]);
  }
}
