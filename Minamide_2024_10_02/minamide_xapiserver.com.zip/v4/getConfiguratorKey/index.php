<?php
header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function getUserIpAddr(){
	if(!empty($_SERVER['CF_CONNECTING_IP'])){
		//ip pass from proxy
		$ip = $_SERVER['CF_CONNECTING_IP'];
	} elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
		//ip from share internet
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} elseif(!empty($_SERVER['HTTP_X_REAL_IP'])){
		//ip from share internet
		$ip = $_SERVER['HTTP_X_REAL_IP'];
	} else{
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}
$remote_ip = getUserIpAddr();
if ($remote_ip != '241.179.104.16') {
	http_response_code(403); 
	die();
} else {
	//$ret_rs['result'] = 'success';
	
	//echo json_encode($ret_rs);
	//die();
}

function _log($email, $line) {
	//global $fh;
	if ($email == "") {
		$fh2 = fopen("/var/www/api.ultimopay.io/v4-dev/getConfiguratorKey/log/debug.log" , 'a');
	} else {
		$fh2 = fopen("/var/www/api.ultimopay.io/v4-dev/getConfiguratorKey/log/" . $email . ".log" , 'a');
	}		
	$fline = date('[Ymd H:i:s] ') . $line."\n";
	fwrite($fh2, $fline);
	fclose($fh2);
	//echo date('[Ymd H:i:s] ').$line."\n";
	//@ob_flush(); 
	//flush();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		_log("", "ket noi thanh cong");
		mysqli_query($dbhandle, "set names utf8;");
	}
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			/*
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_freelancer) {
				$found = 7;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_bos) {
				$found = 8;
				$coin = 'USDT';
				$partner = "BOS";
				break;
			} else if ($value == $apikey_ultimo) {
				$found = 9;
				$coin = 'USDT';
				$partner = "ULTIMO";
				break;
			}
			*/
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
					
				}
			} else {
				_log("", "not found in db");
			}
		}
	}
	@mysqli_close($dbhandle);
	
	$json = file_get_contents('php://input');
	$data = json_decode($json, true);
	
	if (!($data)) {
		
		switch (json_last_error()) {
			case JSON_ERROR_DEPTH:
				//$failed_rs['error'] = 'Reached the maximum stack depth';
				_log("", 'Reached the maximum stack depth');
				break;
			case JSON_ERROR_STATE_MISMATCH:
				//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
				_log("", 'Incorrect discharges or mismatch mode');
				break;
			case JSON_ERROR_CTRL_CHAR:
				//$failed_rs['error'] = 'Incorrect control character';
				_log("", 'Incorrect control character');
				break;
			case JSON_ERROR_SYNTAX:
				//$failed_rs['error'] = 'Syntax error or JSON invalid';
				_log("", 'Syntax error or JSON invalid');
				break;
			case JSON_ERROR_UTF8:
				//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
				_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
				break;
			default:
				//$failed_rs['error'] = 'Unknown error';
				_log("", 'Unknown error');
				break;
		}
		
		//throw new Exception($error);
		//_log($failed_rs['error']);
		_log("", 'A non-empty request body is required.');
		header('Content-Type: application/json');
		http_response_code(400);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
		echo json_encode($ret_rs);
		die();
		
	} else {
		unset($errors);
		$errors = array();
		
		//email
		if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
			$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
			$errors[] = $error_obj;
		}
		
		//auth_token
		if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
			$error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
			$errors[] = $error_obj;
		}
		
		if (count($errors) == 0) {
			
		} else {
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = $errors[0];
			_log("", $ret_rs['error']['errorMessage']);	
			header('Content-Type: application/json');
			echo json_encode($ret_rs);
			die();
		}
		
	}
	
} else {
	http_response_code(405); 
	die();
}


?>