function decodeBase64( encodedString ){
  // Replace invalid URL characters with valid Base64 ones
  let sanitizedStr = encodedString.replace(/-/g, '+').replace(/_/g, '/');

  // Add padding if necessary
  while (sanitizedStr.length % 4 !== 0) {
    sanitizedStr += '=';
  }
  let decodedString = atob(sanitizedStr); // Decode Base64
  let utf8Decoder = new TextDecoder('utf-8');
  return utf8Decoder.decode(new Uint8Array([...decodedString].map(c => c.charCodeAt(0))));
}
