<?php $__env->startSection('content'); ?>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/4.3.0/css/fixedColumns.dataTables.min.css">
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
  <script src="https://cdn.datatables.net/fixedcolumns/4.3.0/js/dataTables.fixedColumns.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.2/bootbox.min.js"></script>

  <!-- DataTables Buttons extension for export -->
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css">
  <script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>

  <!-- JSZip for XLSX export -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>

  <!-- PDFMake for PDF export (if needed) -->
  <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.pdfmake.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.7.1/js/vfs_fonts.js"></script>

  <!--<link rel="stylesheet" href="<?php echo e(asset('vendor/dataTables.bootstrap5.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendor/fixedColumns.dataTables.min.css')); ?>">
  <script src="<?php echo e(asset('vendor/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/dataTables.bootstrap5.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/moment.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/dataTables.fixedColumns.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/bootbox.min.js')); ?>"></script>-->

  <div class="">
    <!-- Search Option Panel -->
    <div class="search-panel">
      <form class="row align-items-center">
        <!-- Email Address and Order No Buttons -->
        <div class="col-12 col-md-3">
          <div class="btn-group w-100" role="group">
            <button onclick="onOpenEmailAddress();" data-bs-toggle="modal" data-bs-target="#emailModal" type="button" class="search-ctrl btn btn-outline-primary d-flex align-items-center justify-content-center">
              <i class="bi bi-envelope fs-3"></i>
              <span class="badge bg-danger icon-badge email_count_info email_count hide">0</span>
              <span class="text-end tool-label ms-4">Input<br/>Email Address</span>
            </button>
          </div>
        </div>

        <!-- Date Range Controls in One Row on Mobile -->
        <div class="col-12 col-md-3 d-flex flex-column flex-md-row align-items-center">
          <div class="row">
            <div class="col-6">
              <label for="fromDate" class="form-label">
                <i class="bi bi-calendar2-event"></i> <span class="tool-label">From</span>
              </label>
              <input type="date" class="search-ctrl form-control" id="fromDate">
            </div>
            <div class="col-6">
              <label for="toDate" class="form-label">
                <i class="bi bi-calendar2-range"></i> <span class="tool-label">To</span>
              </label>
              <input type="date" class="search-ctrl form-control" id="toDate">
            </div>
          </div>
        </div>

        <!-- Min and Max Amount Controls in One Row -->
        <div class="col-12 col-md-3 d-flex flex-column flex-md-row align-items-center">
          <div class="row">
            <div class="col-6">
              <label for="minAmount" class="form-label">
                <i class="bi bi-reception-1"></i> <span class="tool-label">Min Amount</span>
              </label>
              <input type="number" class="search-ctrl form-control" id="minAmount" placeholder="Min Amount" value="0">
            </div>
            <div class="col-6">
              <label for="maxAmount" class="form-label">
                <i class="bi bi-reception-4"></i> <span class="tool-label">Max Amount</span>
              </label>
              <input type="number" class="search-ctrl form-control" id="maxAmount" placeholder="Max Amount" value="0">
            </div>
          </div>
        </div>

        <!-- Reset and Search Buttons -->
        <div class="col-12 col-md-3 d-flex align-items-center justify-content-center">
          <div class="btn-group w-100" role="group">
            <button onclick="onStart();" type="button" class="search-ctrl btn btn-primary d-flex align-items-center justify-content-center">
              <span class="spinner-anim spinner-border spinner-border-sm text-white me-2" role="status" style="display: none"></span>
              <div class="me-3">
                <i class="bi bi-credit-card small"></i>
                <i class="bi bi-search fs-3"></i>
              </div>
              <span class="text-end tool-label ms-2">Search<br/>Purchase</span>
            </button>
          </div>
        </div>
      </form>
    </div>

    <!--  Result table  -->
    <div class="result-table mt-3">
      <table class="table table-bordered table-hover-animation table-hover row-border order-column nowrap" id="checkTable">
        <thead>
          <tr>
            <th rowspan="2" class="text-center">No.</th>
            <th rowspan="2" class="text-center">Email Address</th>
            <th rowspan="2" class="text-center">Order No.</th>
            <th colspan="3" class="text-center shift-data">Shift Data</th>
            <th colspan="6" class="text-center local-data">Payment.ultimopay.io Database</th>
            <th colspan="6" class="text-center jdb-data">JDB Transactions</th>
            <th rowspan="2" class="text-center">Result</th>
          </tr>
          <tr>
            <th class="shift-data">USD</th>
            <th class="shift-data">USDT</th>
            <th class="shift-data">Date/Time</th>

            <th class="local-data">PID</th>
            <th class="local-data">Order No.</th>
            <th class="local-data">USD</th>
            <th class="local-data">USDT</th>
            <th class="local-data">Date/Time</th>
            <th class="local-data">Status</th>

            <th class="jdb-data">Order No.</th>
            <th class="jdb-data">Amount</th>
            <th class="jdb-data">Card Number</th>
            <th class="jdb-data">Name</th>
            <th class="jdb-data">Date/Time</th>
            <th class="jdb-data">Status</th>
          </tr>
        </thead>
        <tbody class="my-tbody">
        </tbody>
      </table>
    </div>

    <!--  Progress bar  -->
    <div align="center" class="w-100 mt-4 my-progress-bar" style="display: none;">
      <div class="progress-outer text-center">
        <div class="progress">
          <div class="progress-bar progress-bar-info progress-bar-striped active" style="width:0; box-shadow:-1px 10px 10px rgba(91, 192, 222, 0.7); margin-right: -100%"></div>
          <div class="progress-value">0%</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Email address input modal -->
  <div class="modal fade" id="emailModal" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="apiKeyLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h5 class="modal-title text-white">Input Email Addresses To Search & Compare</h5>
          <button class="close btn-close" data-bs-dismiss="modal" aria-label="Close">
          </button>
        </div>
        <div class="modal-body">
          <textarea id="email_address" rows="6" class="w-100 p-3" oninput="onChangeEmailAddressList();" placeholder="Please type email addresses here..."></textarea>
        </div>
        <div class="modal-footer d-flex align-items-center justify-content-between">
          <div>
            <span class="email_count_info hide"><span class="email_count">0</span> email addresses</span>
          </div>
          <div>
            <button class="btn btn-primary" id="btnEmailList" data-bs-dismiss="modal" onclick="onSelectEmailAddress()">
              <span class="spinner-text ps-4 pe-4">Ok</span>
            </button>
            <button class="btn btn-outline-secondary" data-bs-dismiss="modal">
              <span class="spinner-text ps-4 pe-4">Cancel</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Detail view modal -->
  <div class="modal fade" id="detailModal" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="apiKeyLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-full-width" role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h5 class="modal-title text-white">Review the detailed data</h5>
          <button class="close btn-close" data-bs-dismiss="modal" aria-label="Close">
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-4 col-sm-12">
              <div class="card">
                <div class="card-header">
                  Shift transaction data <sup class="shiftFeeValue"></sup>
                </div>
                <div class="card-body">
                  <div class="text-danger compareMsg compareMsg-shift mb-3"></div>
                  <pre class="shift-detail">
                  </pre>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="card">
                <div class="card-header">
                  Local database data <sup class="localFeeValue"></sup>
                </div>
                <div class="card-body">
                  <div class="text-danger compareMsg compareMsg-local mb-3"></div>
                  <pre class="local-detail">
                  </pre>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="card">
                <div class="card-header">
                  JDB transaction data
                </div>
                <div class="card-body">
                  <div class="text-danger compareMsg compareMsg-jdb mb-3"></div>
                  <pre class="jdb-detail">
                  </pre>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer d-flex align-items-center justify-content-end">
          <button class="btn btn-outline-secondary px-4" data-bs-dismiss="modal">
            Close
          </button>
        </div>
      </div>
    </div>
  </div>
  <script>
    let g_emails = [];
    let g_dataTable = null;
    let g_fullData = [];
    let g_tableData = [];

    $(document).ready(function(){
      buildDataTable(g_tableData);

      onResize();
      $(window).resize(function() {
        onResize();
      });
    });

    /**
     * Start searching and comparing
     * **/
    async function onStart() {

      if( g_emails.length <= 0 ){
        doError("No Emails", "Please input email address list, first");
        return;
      }

      // Initialize
      g_fullData = {};
      SpinBtnCtrl('search-ctrl', true);
      progressBarCtrl('', true, 0);
      buildDataTable([]);

      // Get auth token
      let interval = progressBarCtrlAnim('Getting auth token', 10000, 20);
      const authToken = await getAuthToken();
      if (!authToken) {
        console.error('No valid auth token found.');
        return;
      }
      progressBarCtrl('Getting auth token', true, 20, interval);

      // Get shift data and merge it to full data
      interval = progressBarCtrlAnim('Retrieving shift data', 10000, 40);
      let shiftData = await retrieveShiftData(g_emails, authToken);
      progressBarCtrl('Retrieving shift data', true, 40, interval);
      console.log('g_shiftData: ', shiftData.length, shiftData);

      // Get payment.ultimopay.io database data.
      interval = progressBarCtrlAnim('Retrieving local data', 2000, 60);
      let localData = await retrieveLocalData(g_emails);
      progressBarCtrl('Retrieving local data', true, 60, interval);
      console.log('g_localData: ', localData.length, localData);

      // Get JDB data
      const shiftDataIds = shiftData.map(item => item.orderNo);
      const localDataIds = localData.map(item => item.transaction_id);
      const combinedIds = [...shiftDataIds, ...localDataIds];
      const distinctOrderNos = [...new Set(combinedIds)];

      interval = progressBarCtrlAnim('Retrieving jdb data', 10000, 80);
      let jdbData = await retrieveJdbData(distinctOrderNos);
      progressBarCtrl('Retrieving jdb data', true, 90, interval);
      console.log('g_jdbData: ', jdbData.length, jdbData);

      // Merge all data
      interval = progressBarCtrlAnim('Merge all data', 1000, 95);
      g_fullData = mergeAllData(shiftData, localData, jdbData);
      progressBarCtrl('Merge all data', true, 95, interval);
      console.log('g_fullData: ', g_fullData.length, g_fullData);

      // Compare and out comparing result
      interval = progressBarCtrlAnim('Comparing data', 1000, 100);
      g_tableData = compareData(g_fullData, g_emails);
      buildDataTable(g_tableData);
      progressBarCtrl('Comparing data', true, 100, interval);
      console.log('g_fullData: ', g_fullData.length, g_fullData);

      progressBarCtrl('complete', false, 100);
      SpinBtnCtrl('search-ctrl', false);
    }

    /**
     * Batch the email addresses
     * **/
    function batchEmails(emails, batchSize) {
      const batches = [];
      for (let i = 0; i < emails.length; i += batchSize) {
        batches.push(emails.slice(i, i + batchSize));
      }
      return batches;
    }

    /**
     * ========================================================================
     * Get shift transaction data
     * ========================================================================
     * **/
    async function retrieveShiftData(emails, authToken) {
      let result = [];

      // Function to start a new request
      const startRequest = async () => {
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        return $.ajax({
          url: g_siteUrl + '/purchaseChecker/getShiftTransactions',
          method: 'POST',
          headers: {
            'X-CSRF-TOKEN': csrfToken
          },
          data: {
            target_address: '',
            auth_token: authToken,
            time_from: '2024-01-01'/*$('#fromDate').val()*/,
            time_to: ''/*$('#toDate').val()*/,
            comment: 'Buy with Card'
          },
          dataType: 'json',
        });
      };

      try {
        // Await the request and assign the response to result
        const response = await startRequest();

        if (!response || !response.data) {
          console.error('Invalid response structure');
          return [];
        }

        // Iterate through shiftResult['data'], filter by emails, and map into desired objects
        result = response.data
          .filter(transaction => emails.includes(transaction.user.username)) // Filter based on emails
          .map(transaction => {
            // Extract order number from comment
            let match = transaction.comment.match(/order number (\d+)/);
            let orderNo = match ? match[1] : Math.floor(100000 + Math.random() * 900000);
            match = transaction.comment.match(/([\d,.]+)\s*USD/);
            let usd = match ? match[1] : 0;

            // Construct object with email, orderNo, and other transaction data
            return {
              email: transaction.user.username,
              orderNo: orderNo,
              usd: usd,
              ...transaction
            };
          });

      } catch (error) {
        console.error('Error fetching transaction data:', error);
      }

      return result;
    }

    // Get user's auth token
    async function getAuthToken() {
      try {
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        const response = await $.ajax({
          url: g_siteUrl + '/purchaseChecker/shiftSignIn',
          method: 'POST',
          dataType: 'json',
          headers: {
            'X-CSRF-TOKEN': csrfToken
          },
        });

        if (response.result === 'success') {
          return response.signinResponse.auth_token;
        } else {
          console.log(response);
          return null;
        }
      } catch (error) {
        console.error('Error during sign-in:', error);
        return null;
      }
    }

    /**
     * ========================================================================
     * Get payment.ultimopay.io data
     * ========================================================================
     * **/
    async function retrieveLocalData(emails){
      try {
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        const response = await $.ajax({
          url: g_siteUrl + '/purchaseChecker/getLocalData',
          method: 'POST',
          dataType: 'json',
          headers: {
            'X-CSRF-TOKEN': csrfToken
          },
          data: {
            emails: emails,
          },
        });

        if (response.result === 'success') {
          return response.data;
        } else {
          console.log(response);
          return null;
        }
      } catch (error) {
        console.error('Error during get local data:', error);
        return null;
      }
    }

    /**
     * ========================================================================
     * Get JDB data
     * ========================================================================
     * **/
    async function retrieveJdbData(orderIds){
      if( orderIds.length <= 0 )
        return [];

      try {
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        const response = await $.ajax({
          url: g_siteUrl + '/purchaseChecker/getJdbData',
          method: 'POST',
          dataType: 'json',
          headers: {
            'X-CSRF-TOKEN': csrfToken
          },
          data: {
            orderIds: orderIds,
          },
        });

        if (response.result === 'success') {
          let transactions = response.data['data'].map(jdb => {
            let {transactionDateTime} = jdb;

            // Convert transactionDateTime to ISO format with 'Z' if it is missing
            if (transactionDateTime && !transactionDateTime.endsWith('Z')) {
              // Format the date to ISO 8601 with milliseconds and 'Z'
              transactionDateTime += '.000000Z';
            }

            // Return the updated jdb object with the formatted transactionDateTime
            return {
              ...jdb,
              transactionDateTime
            };
          });

          // Extract the orderNos from the response
          const receivedOrderNos = transactions.map(transaction => transaction.orderNo);

          // Find missing orderNos by comparing with the original orderIds
          const missingOrderNos = orderIds.filter(orderId => !receivedOrderNos.includes(orderId));

          // Check if any transaction's cardHolderName and payerName are null, and add those to the missing orders list
          for (let i = transactions.length - 1; i >= 0; i--) {
            const transaction = transactions[i];
            const cardHolderName = transaction.creditCardDetails?.cardHolderName;
            const payerName = transaction.creditCardDetails?.payerName;
            const paymentStatus = transaction.paymentStatusInfo?.paymentStatus ?? null;

            // If both cardHolderName and payerName are null, consider this order as missing
            if ((!cardHolderName && !payerName) && (paymentStatus === null || paymentStatus === 'A' || paymentStatus === 'S')) {
              missingOrderNos.push(transaction.orderNo);
              // Remove the transaction from the list
              transactions.splice(i, 1);
            }
          }

          console.log("Count of missing orders: ", missingOrderNos.length);

          // If there are missing orders, call the second API to retrieve them
          if (missingOrderNos.length > 0) {
            let i = 0;
            for (const missingOrderNo of missingOrderNos) {
              const missingTransaction = await retrieveMissingOrder(missingOrderNo);
              if (missingTransaction) {
                const paymentStatus = missingTransaction.paymentStatusInfo?.paymentStatus ?? null;
                if( paymentStatus === 'A' || paymentStatus === 'S')
                  transactions.push(missingTransaction);
              }
              progressBarCtrl('Retrieving missed jdb data', true, 80 + (i++) * 10 / missingOrderNos.length, 0);
            }
          }

          return transactions;
        } else {
          console.log(response);
          return null;
        }
      } catch (error) {
        console.error('Error during get local data:', error);
        return null;
      }

      // Nested function to call the second API to retrieve missing transaction details
      async function retrieveMissingOrder(orderNo) {
        try {
          const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

          const response = await $.ajax({
            url: g_siteUrl + '/purchaseChecker/getOneJdbData',
            method: 'POST',
            dataType: 'json',
            headers: {
              'X-CSRF-TOKEN': csrfToken
            },
            data: {
              orderNo: orderNo,
            },
          });

          if (response.result === 'success' && response.data['data'] && response.data['data'].length > 0) {
            let { transactionDateTime } = response.data['data'][0];

            // Format the transactionDateTime if necessary
            if (transactionDateTime && !transactionDateTime.endsWith('Z')) {
              transactionDateTime += '.000000Z';
            }

            // Return the missing transaction object
            return {
              ...response.data['data'][0],
              transactionDateTime
            };
          } else {
            console.log(`Error retrieving missing order ${orderNo}:`, response);
            return null;
          }
        } catch (error) {
          console.error('Error retrieving missing order:', error);
          return null;
        }
      }
    }

    /**
     * ========================================================================
     * Merge shift, local and jdb data
     * ========================================================================
     * **/
    function mergeAllData(shiftData, localData, jdbData) {
      // Determine the master array (the one with the maximum size)
      let masterArray, masterType;
      if (shiftData.length >= localData.length && shiftData.length >= jdbData.length) {
        masterArray = shiftData;
        masterType = 'shift';
        // Sort shiftData by 'email' first, then by 'created_at_iso' in descending order
        masterArray.sort((a, b) => {
          if (a.email === b.email) {
            return new Date(b.created_at_iso) - new Date(a.created_at_iso);
          }
          return a.email.localeCompare(b.email);
        });
      } else if (localData.length >= shiftData.length && localData.length >= jdbData.length) {
        masterArray = localData;
        masterType = 'local';
        // Sort localData by 'email' first, then by 'updated_at' in descending order
        masterArray.sort((a, b) => {
          if (a.email === b.email) {
            return new Date(b.updated_at) - new Date(a.updated_at);
          }
          return a.email.localeCompare(b.email);
        });
      } else {
        masterArray = jdbData;
        masterType = 'jdb';
        // Sort jdbData by 'transactionDateTime' in descending order
        masterArray.sort((a, b) => new Date(b.transactionDateTime) - new Date(a.transactionDateTime));
      }

      // Initialize fullData array
      const fullData = [];

      // Keep track of already processed order numbers
      const processedOrderNos = new Set();

      // Loop through the sorted master array
      for (let i = 0; i < masterArray.length; i++) {
        let masterRecord = masterArray[i];
        let orderNo;

        // Determine the orderNo based on the masterType
        if (masterType === 'shift') {
          orderNo = masterRecord.orderNo;
        } else if (masterType === 'local') {
          orderNo = masterRecord.transaction_id;
        } else {
          orderNo = masterRecord.orderNo;
        }

        // If the orderNo is already processed, skip to the next iteration
        if (processedOrderNos.has(orderNo)) {
          continue;
        }

        // Fetch all matching records for the same orderNo from shiftData
        const matchingShiftData = shiftData.filter(record => record.orderNo === orderNo);
        // Fetch all matching records for the same orderNo from localData
        const matchingLocalData = localData.filter(record => record.transaction_id === orderNo);
        // Fetch all matching records for the same orderNo from jdbData
        const matchingJdbData = jdbData.filter(record => record.orderNo === orderNo);

        // Determine the maximum number of records to add for this orderNo
        const maxCount = Math.max(matchingShiftData.length, matchingLocalData.length, matchingJdbData.length);

        // Loop over maxCount to add records to fullData
        for (let j = 0; j < maxCount; j++) {
          fullData.push({
            shift: matchingShiftData[j] || null, // If no more shiftData records, insert null
            local: matchingLocalData[j] || null, // If no more localData records, insert null
            jdb: matchingJdbData[j] || null      // If no more jdbData records, insert null
          });
        }

        // Mark this orderNo as processed
        processedOrderNos.add(orderNo);
      }

      return fullData;
    }

    /**
     * ========================================================================
     * Compare shift, local and jdb data and preparing table data
     * ========================================================================
     * **/
    function compareData(fullData, emails){

      // Initialize tableData array
      let tableData = [];
      let existingEmails = new Set();

      // Iterate over g_fullData and map its values to the desired table format
      fullData.forEach((data, index) => {

        // Extract data from g_fullData entries
        const shiftData = data.shift || {};
        const localData = data.local || {};
        const jdbData = data.jdb || {};

        // Store email to existingEmails set
        existingEmails.add(shiftData.email || localData.email || '');

        // Comparing...
        let compareResult_shift = '';
        let compareResult_local = '';
        let compareResult_jdb = '';

        // Check if any of shiftData, localData, or jdbData is null
        if (isEmpty(shiftData)) {
          compareResult_shift = "Data from Shift is empty.";
        }
        if (isEmpty(localData)) {
          compareResult_local = "Data from Local is empty.";
        }
        if (isEmpty(jdbData)) {
          compareResult_jdb = "Data from JDB is empty.";
        }

        // Check if amounts from shift, local, jdb are different
        if (!isEmpty(localData) && !isEmpty(shiftData) && shiftData.amount*1 !== localData.usdt*1) {
          if( compareResult_local.length > 0 )
            compareResult_local += '<br/>';
          compareResult_local += "USDT amounts mismatch between Shift and Local.";
        }
        if (!isEmpty(localData) && !isEmpty(shiftData) && shiftData.usd*1 !== localData.usd*1) {
          if( compareResult_local.length > 0 )
            compareResult_local += '<br/>';
          compareResult_local += "USD amounts mismatch between Shift and Local.";
        }
        if (!isEmpty(localData) && !isEmpty(jdbData) && localData.usd*1 !== jdbData.transactionAmount?.amount*1) {
          if( compareResult_jdb.length > 0 )
            compareResult_jdb += '<br/>';
          compareResult_jdb += "USD amounts mismatch between the Local and JDB.";
        }

        // Check if the intervals between shiftData, localData, and jdbData are longer than 30 minutes
        const createdAt = shiftData?.created_at_iso ? new Date(shiftData.created_at_iso).getTime() : null;
        const updatedAt = localData?.updated_at ? new Date(localData.updated_at).getTime() : null;
        const transactionDateTime = jdbData?.transactionDateTime ? new Date(jdbData.transactionDateTime).getTime() : null;

        // Function to check time interval (in milliseconds, 30 minutes = 30 * 60 * 1000)
        const THIRTY_MINUTES = 30 * 60 * 1000;

        // Check if the time difference between shiftData, localData, and jdbData is greater than 30 minutes
        if (createdAt && updatedAt && Math.abs(createdAt - updatedAt) > THIRTY_MINUTES) {
          if( compareResult_local.length > 0 )
            compareResult_local += '<br/>';
          compareResult_local += "Shift and Local are 30+ minutes apart.";
        }

        if (createdAt && transactionDateTime && Math.abs(createdAt - transactionDateTime) > THIRTY_MINUTES) {
          if( compareResult_shift.length > 0 )
            compareResult_shift += '<br/>';
          compareResult_shift += "Shift and JDB are 30+ minutes apart.";
        }

        if (updatedAt && transactionDateTime && Math.abs(updatedAt - transactionDateTime) > THIRTY_MINUTES) {
          if( compareResult_jdb.length > 0 )
            compareResult_jdb += '<br/>';
          compareResult_jdb += "Local and JDB are 30+ minutes apart.";
        }

        // Check if USDT is not 8% of USD in local or shift
        const usdtToUsdRatioShift = (shiftData?.usd && shiftData?.amount) ? (shiftData.amount / shiftData.usd) : null;
        const usdtToUsdRatioLocal = (localData?.usd && localData?.usdt) ? (localData.usdt / localData.usd) : null;

        if (!isEmpty(shiftData) && usdtToUsdRatioShift !== null && usdtToUsdRatioShift.toFixed(2) * 1 !== (1 - 0.08)) {
          if (compareResult_shift.length > 0) compareResult_shift += '<br/>';
          compareResult_shift += "The USD to USDT fee rate isn't 8%.";
        }
        if (!isEmpty(localData) && usdtToUsdRatioLocal !== null && usdtToUsdRatioLocal.toFixed(2) * 1 !== (1 - 0.08)) {
          if (compareResult_local.length > 0) compareResult_local += '<br/>';
          compareResult_local += "The USD to USDT fee rate isn't 8%.";
        }

        // Check if localData.status is not 'complete'
        if (!isEmpty(localData) && localData?.status !== 'complete') {
          if (compareResult_local.length > 0) compareResult_local += '<br/>';
          compareResult_local += "The status is not [complete].";
        }

        // Check if jdbData.paymentStatusInfo?.paymentStatus is not 'S' or 'A'
        if (!isEmpty(jdbData) && jdbData?.paymentStatusInfo?.paymentStatus !== 'S' && jdbData?.paymentStatusInfo?.paymentStatus !== 'A') {
          if (compareResult_jdb.length > 0) compareResult_jdb += '<br/>';
          compareResult_jdb += "The status isn't [settled] or [approved].";
        }

        // Push the new array structure into tableData
        const compareResults = [compareResult_shift, compareResult_local, compareResult_jdb];
        const isAnyCompareResultNotEmpty = compareResults.some(result => result);
        const finalCompareResults = isAnyCompareResultNotEmpty ? compareResults : null;

        tableData.push([
          index + 1, // Unique auto increment natural number
          shiftData.email || localData.email, // Email from shift
          shiftData.orderNo || localData.transaction_id || jdbData.orderNo, // OrderNo value from shift
          shiftData.usd || '', // USD value from shift
          shiftData.amount || '', // USDT amount value from shift
          shiftData.created_at_iso || '', // created_at_iso from shift
          localData.id || '', // id from local
          localData.transaction_id || '', // transaction_id from local
          localData.usd || '', // usd from local
          localData.usdt || '', // usdt from local
          localData.updated_at || '', // updated_at from local
          localData.status || '', // status from local
          jdbData.orderNo || '', // orderNo from jdb
          jdbData.transactionAmount?.amount || '', // transactionAmount.amount from jdb
          jdbData.creditCardDetails?.cardNumber || '', // creditCardDetails.cardNumber from jdb
          jdbData.creditCardDetails?.cardHolderName || jdbData.creditCardDetails?.payerName || '', // creditCardDetails.cardHolderName from jdb
          jdbData.transactionDateTime || '', // transactionDateTime from jdb
          jdbData.paymentStatusInfo?.paymentStatus || '', // paymentStatus from jdb
          finalCompareResults // Compare result
        ]);
      });

      // Check for emails in the emails array that do not exist in fullData
      emails.forEach(email => {
        if (!existingEmails.has(email)) {
          tableData.push([
            tableData.length + 1, // Unique auto increment natural number
            email, // Email from emails
            'No Data', // OrderNo value (empty)
            '', // USD value (empty)
            '', // USDT amount (empty)
            '', // created_at_iso (empty)
            '', // id (empty)
            '', // transaction_id (empty)
            '', // usd (empty)
            '', // usdt (empty)
            '', // updated_at (empty)
            '', // status (empty)
            '', // orderNo (empty)
            '', // transactionAmount.amount (empty)
            '', // creditCardDetails.cardNumber (empty)
            '', // creditCardDetails.cardHolderName (empty)
            '', // transactionDateTime (empty)
            '', // paymentStatus (empty)
            null // Compare result (empty)
          ]);

          // Add missing email entry to fullData
          /*fullData.push({
            shift: { email: email }, // Assume shift data only has email
            local: {}, // Empty local data
            jdb: {} // Empty JDB data
          });*/
        }
      });

      return tableData;
    }

    function showDetails(fullDataId){
      const compareResults = g_tableData[fullDataId][18];
      if( compareResults ){
        $('.compareMsg-shift').html(compareResults[0] ?? null);
        $('.compareMsg-local').html(compareResults[1] ?? null);
        $('.compareMsg-jdb').html(compareResults[2] ?? null);
      }
      else{
        $('.compareMsg-shift').html('');
        $('.compareMsg-local').html('');
        $('.compareMsg-jdb').html('');
      }

      $('.shift-detail').html(JSON.stringify(g_fullData?.[fullDataId]?.['shift'] ?? null, null, 2));
      $('.local-detail').html(JSON.stringify(g_fullData?.[fullDataId]?.['local'] ?? null, null, 2));
      $('.jdb-detail').html(JSON.stringify(g_fullData?.[fullDataId]?.['jdb'] ?? null, null, 2));
      if(g_fullData[fullDataId]?.['shift']){
        let shiftFee = 0;
        if(g_fullData?.[fullDataId]['shift']['usd']*1 > 0)
          shiftFee = (g_fullData[fullDataId]['shift']['usd'] * 1 - g_fullData[fullDataId]['shift']['amount'] * 1) / g_fullData[fullDataId]['shift']['usd'];

        $('.shiftFeeValue').text(` (fee: ${(shiftFee * 100).toFixed(1)} %)`);
      }
      else{
        $('.shiftFeeValue').text(``);
      }
      if(g_fullData?.[fullDataId]?.['local']){
        let localFee = 0;
        if(g_fullData[fullDataId]['local']['usd']*1 > 0)
          localFee = (g_fullData[fullDataId]['local']['usd'] * 1 - g_fullData[fullDataId]['local']['usdt'] * 1) / g_fullData[fullDataId]['local']['usd'];

        $('.localFeeValue').text(` (fee: ${(localFee * 100).toFixed(1)} %)`);
      }
      else{
        $('.localFeeValue').text(``);
      }
    }


    /**
     * Trigger when user open email address input modal
     * **/
    function onOpenEmailAddress(){
      const emailText = g_emails.join('\n');
      $('#email_address').val(emailText);
    }

    /**
     * Trigger when user click 'Ok' on email address input modal
     * **/
    function onSelectEmailAddress(){
      g_emails = getEmailAddresses();
      $('.badge.email_count').text(g_emails.length);
      if( g_emails.length > 0 )
        $('.badge.email_count_info').show();
      else
        $('.badge.email_count_info').hide();
    }

    /**
     * Trigger when user type on email address input modal
     * **/
    function onChangeEmailAddressList(){
      let emailAddressList = getEmailAddresses();

      $('.modal-footer .email_count').text(emailAddressList.length);
      if( emailAddressList.length > 0 )
        $('.modal-footer .email_count_info').show();
      else
        $('.modal-footer .email_count_info').hide();
    }

    /**
     * Get email addresses what user typed
     * **/
    function getEmailAddresses() {
      // Get the textarea value
      let emailText = $('#email_address').val();

      // Split the input by commas, spaces, or new lines, and remove any empty values
      let emails = emailText.split(/[\s,]+/).filter(function(email) {
        return email.trim().length > 0; // Filter out empty strings
      });

      // Create a Set to remove duplicates and filter valid emails
      // Return the unique, valid emails
      return [...new Set(emails.filter(function (email) {
        return validateEmail(email.trim());
      }))];
    }

    function validateEmail(email) {
      let re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return re.test(email);
    }


    /**
     * Construct or re-construct data table
     * **/
    function buildDataTable(tableData = []){
      const STATUS_LIST = {
        "PCPS": "Pre-stage",
        "I": "Initial",
        "A": "Approved",
        "V": "Voided",
        "S": "Settled",
        "R": "Refund",
        "P": "Pending Payment",
        "F": "Rejected",
        "E": "Expired",
        "C": "Cancelled"
      };


      let browserWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
      let browserHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

      if( g_dataTable )
        g_dataTable.destroy();

      g_dataTable = $('#checkTable').DataTable({
        data: tableData,
        searching: true,
        processing: false,
        serverSide: false,
        paging: false,
        info: false,
        scrollX: true,
        scrollY: (browserHeight - 360) + 'px',
        scrollCollapse: true,
        fixedColumns: {
          leftColumns: 3,
          rightColumns: 1
        },
        columnDefs: [
          { targets: '_all', orderable: false }
        ],
        columns: [
          { // Column 1: Auto increment number
            data: 0,
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[18]) {
                $(td).addClass('bg-danger');
              }
            },
          },
          { // Column 2: Email from shift
            data: 1,
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[18]) {
                $(td).addClass('bg-danger');
              }
            },
          },
          { // Column 3: OrderNo from shift
            data: 2,
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[18]) {
                $(td).addClass('bg-danger');
              }
            },
          },
          { // Column 4: USD from shift
            data: 3,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('shift-data');
            },
          },
          { // Column 5: USDT amount from shift
            data: 4,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('shift-data');
            },
          },
          { // Column 6: Created_at_iso from shift
            data: 5,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('shift-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                const date = new Date(data.toString());
                return `${date.toLocaleDateString()} <sup>${date.toLocaleTimeString()}</sup>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 7: Local id
            data: 6,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('local-data');
            },
          },
          { // Column 8: Local transaction_id
            data: 7,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('local-data');
            },
          },
          { // Column 9: Local usd
            data: 8,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('local-data');
            },
          },
          { // Column 10 Local usdt
            data: 9,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('local-data');
            },
          },
          { // Column 11: Local updated_at
            data: 10,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('local-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                const date = new Date(data.toString());
                return `${date.toLocaleDateString()} <sup>${date.toLocaleTimeString()}</sup>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 12: Local status with badge
            data: 11,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('local-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                let badgeClass = 'bg-warning';
                if (data.toString() === 'Input Code')
                  badgeClass = 'bg-primary';
                if (data.toString() === 'failed')
                  badgeClass = 'bg-danger';
                if (data.toString() === 'None')
                  badgeClass = 'bg-secondary';
                if (data.toString() === 'complete')
                  badgeClass = 'bg-success';
                return `<span class="badge ${badgeClass}">${data}</span>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 13: JDB orderNo
            data: 12,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
          },
          { // Column 14: JDB transactionAmount.amount
            data: 13,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
          },
          { // Column 15: JDB creditCardDetails.cardNumber
            data: 14,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
          },
          { // Column 16: JDB creditCardDetails.cardHolderName
            data: 15,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
          },
          { // Column 17: JDB transactionDateTime
            data: 16,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                const date = new Date(data.toString());
                return `${date.toLocaleDateString()} <sup>${date.toLocaleTimeString()}</sup>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 18: JDB paymentStatus with badge
            data: 17,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                let badgeClass = 'bg-danger';
                if (data.toString() === 'PCPS')
                  badgeClass = 'bg-primary';
                if (data.toString() === 'P')
                  badgeClass = 'bg-warning';
                if (data.toString() === 'S' || data.toString() === 'A')
                  badgeClass = 'bg-success';
                return `<span class="badge ${badgeClass}">${STATUS_LIST[data]}</span>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 19: Action button
            data: 18,
            render: function (data, type, row, meta) {
              let btnClass = 'btn-outline-success';
              let iconClass = 'bi-circle';
              if(data) {
                btnClass = 'btn-danger';
                iconClass = 'bi-triangle';
              }
              return `<button data-bs-toggle="modal" data-bs-target="#detailModal" onclick="showDetails(${row[0] - 1})" class="btn ${btnClass} btn-result"><i class="bi ${iconClass}"></i></button>`;
            }
          }
        ],
        rowCallback: function(row, data) {
          $(row).addClass('dataTableRow');  // Add the CSS class to each row
        },
        initComplete: function() {
          $('div.dataTables_wrapper').css('width', (browserWidth - 50) + 'px');
        },
        dom: 'Bfrtip',
        buttons: [
          {
            extend: 'csvHtml5',
            text: 'Download CSV',
            title: 'Data export',
            className: 'btn btn-outline-success mb-2 mb-md-0',
            init: function(api, node, config) {
              $(node).removeClass('dt-button buttons-csv buttons-html5');
            }
          },
          {
            extend: 'excelHtml5',
            text: 'Download Excel',
            title: 'Data export',
            className: 'btn btn-outline-success mb-2 mb-md-0',
            init: function(api, node, config) {
              $(node).removeClass('dt-button buttons-excel buttons-html5');
            }
          }
        ]
      });
    }

    /**
     * Control progress bar
     * **/
    function progressBarCtrl(sLabel, bShow, nProgress, interval = 0){
      clearInterval(interval);

      $('.progress-value').html(sLabel + ' ' + (parseFloat(nProgress).toFixed(1)) + ' %');
      $('.progress-bar').css('width', nProgress + '%');
      if( !bShow ){
        setTimeout(function(){
          $('.my-progress-bar').hide();
        }, 1000);
      }
      else{
        $('.my-progress-bar').show();
      }
    }
    function progressBarCtrlAnim(label, duration, toPercent) {
      const $progressBar = $('.my-progress-bar .progress-bar');
      const $progressValue = $('.my-progress-bar .progress-value');
      const currentPercent = parseInt($progressBar.width() / $progressBar.parent().width() * 100, 10);
      const increment = (toPercent - currentPercent) / (duration / 10); // Updates every 10ms

      let current = currentPercent;

      // Show the progress bar if hidden
      $('.my-progress-bar').show();

      const interval = setInterval(() => {
        current += increment;
        if ((increment > 0 && current >= toPercent) || (increment < 0 && current <= toPercent)) {
          current = toPercent;
          clearInterval(interval);
        }

        // Update progress bar width and label
        $progressBar.css('width', `${current}%`);
        $progressValue.text(`${label} ${current.toFixed(1)} %`);
      }, 10);

      return interval;
    }

    /**
     * Spin control
     * **/
    function SpinBtnCtrl(className, showSpin) {

      let ctrlObjs = $('.' + className);
      let spinnerObj = $('.' + className + ' ' + '.spinner-anim');

      if (showSpin) {
        spinnerObj.css('display', 'inline-block');
        ctrlObjs.attr('disabled', showSpin);
      } else {
        spinnerObj.css('display', 'none');
        ctrlObjs.removeAttr('disabled');
      }
    }

    function doAlert(title, message){
      bootbox.alert({
        title: title,
        message: message,
        centerVertical: true,
        className: 'bounceIn animated'
      });
    }

    function doError(title, message){
      bootbox.alert({
        title: title,
        message: message,
        centerVertical: true,
        className: 'rubberBand animated'
      });
    }

    function isEmpty(obj) {
      return Object.keys(obj).length === 0;
    }

    function onResize(){
      let resultTable = $('.result-table');
      const clientWidth = ($(window).width() * 1) - 20;
      if( clientWidth < 1024 ){
        resultTable.css('max-width', clientWidth + 'px');
        resultTable.css('overflow-x', 'scroll');
      }
      else{
        resultTable.css('max-width', clientWidth + 'px');
        resultTable.css('overflow-x', 'unset');
      }

      buildDataTable(g_tableData);
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.purchaseCheckerLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Minamide\minamide_agent_v4\resources\views//purchase-checker/home.blade.php ENDPATH**/ ?>