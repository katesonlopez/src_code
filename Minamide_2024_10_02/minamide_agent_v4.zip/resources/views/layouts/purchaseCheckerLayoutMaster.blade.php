<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>PurchaseCheck</title>

  <!-- Favicon -->
  <link rel="icon" href="{{ asset('favicon_purchase_checker.ico') }}" type="image/x-icon">

  <!-- jQuery and Bootstrap JS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://icons.getbootstrap.com/assets/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.1/animate.min.css" rel="stylesheet">
  <link href="{{ asset('css/purchase-checker.css') }}" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
  <!--<link href="{{ asset('vendor/bootstrap.min.css') }}" rel="stylesheet">
  <link href="{{ asset('vendor/bootstrap-icons.min.css') }}" rel="stylesheet">
  <link href="{{ asset('vendor/animate.min.css') }}" rel="stylesheet">
  <link href="{{ asset('css/purchase-checker.css') }}" rel="stylesheet">
  <script src="{{ asset('vendor/jquery-3.6.0.min.js') }}"></script>
  <script src="{{ asset('vendor/popper.min.js') }}"></script>
  <script src="{{ asset('vendor/bootstrap.min.js') }}"></script>-->
</head>
<body>
<!-- Top Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light ps-4 pe-4">
  <a class="navbar-brand fw-bold" href="{{ route('purchaseChecker.home') }}">Payment Check Tool</a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="{{ route('purchaseChecker.home') }}">Check Purchase History</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{ route('purchaseChecker.checkTxID') }}">Check TxID & Deposit Address</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{ route('purchaseChecker.setting') }}">Setting</a>
      </li>
    </ul>
  </div>
</nav>
<input type="hidden" id="base_url" value="{{ url('/') }}">
<script>
  let g_siteUrl = '';
  $(document).ready(function(){
    g_siteUrl = $('#base_url').val();
  });
</script>
<!-- Body Section -->
<div class="container content my-4 d-flex justify-content-center">
  @yield('content')
</div>

<!-- Footer Section -->
<footer class="footer mt-auto">
  <div class="container text-end">
    <span class="text-muted">© 2024 Payment Check Tool. All rights reserved.</span>
  </div>
</footer>

</body>
</html>
