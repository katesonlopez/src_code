<?php

namespace App\Http\Controllers;

use App\Jdb;
use App\PaymentUltimiopay_v4;
use App\Purchase_check_tool_setting_partner;
use App\XApiServer_V4;
use FireblocksSdkPhp\FireblocksSDK;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class CheckPurchaseToolController extends Controller
{
  public function home(/*Request $request*/)
  {
    return view('/purchase-checker/home', []);
  }

  public function checkTxID(/*Request $request*/)
  {
    return view('/purchase-checker/checkTxID', []);
  }
  public function setting(/*Request $request*/)
  {
    return view('/purchase-checker/setting', []);
  }

  public function savePartner(Request $request): JsonResponse
  {
    $ret = [
      'result' => 'failed',
      'data' => []
    ];

    $id = $request->input('id');
    $partner_name = $request->input('partner_name');
    $fee_percent = $request->input('fee_percent');
    $other= $request->input('other');

    if( $partner_name == null || strlen(trim($partner_name)) == 0 ){
      $ret['message'] = 'The partner name is required.';
      return response()->json($ret, 400);
    }
    else if( $fee_percent == null || strlen(trim($fee_percent)) == 0 ){
      $ret['message'] = 'The fee percent value is required.';
      return response()->json($ret, 400);
    }
    else{
      if ($id) {
        $partner = Purchase_check_tool_setting_partner::find($id);

        if ($partner) {
          // Update the existing partner
          $partner->partner_name = $partner_name;
          $partner->fee_percent = $fee_percent;
          $partner->other = $other;
          $partner->save();

          $ret['result'] = 'success';
          $ret['message'] = 'Partner updated successfully.';
          $ret['data'] = $partner;
        } else {
          $ret['message'] = 'Invalid partner ID.';
        }
      } else {
        // Add a new partner
        $partner = new Purchase_check_tool_setting_partner();
        $partner->partner_name = $partner_name;
        $partner->fee_percent = $fee_percent;
        $partner->other = $other;
        $partner->save();

        $ret['result'] = 'success';
        $ret['message'] = 'Partner added successfully.';
        $ret['data'] = $partner;
      }

      return response()->json($ret, $ret['result'] === 'success' ? 200 : 400);
    }
  }

  // Retrieve all partners
  public function partners(Request $request){
    $partners = Purchase_check_tool_setting_partner::all();

    return response()->json([
      'result' => 'success',
      'message' => 'All partners retrieved successfully.',
      'data' => $partners
    ], 200);
  }

  public function removePartner(Request $request){
    $partnerId = $request->input('id');

    // Check if the partner ID is provided
    if (!$partnerId) {
      return response()->json([
        'result' => 'failed',
        'message' => 'Partner ID is required.'
      ], 400);
    }

    // Find the partner by ID
    $partner = Purchase_check_tool_setting_partner::find($partnerId);

    // Check if the partner exists
    if (!$partner) {
      return response()->json([
        'result' => 'failed',
        'message' => 'Partner not found.'
      ], 404); // 404 Not Found
    }

    // Delete the partner
    $partner->delete();

    // Return a success response
    return response()->json([
      'result' => 'success',
      'message' => 'Partner deleted successfully.'
    ], 200);
  }

  public function shiftSignIn(){
    $response = XApiServer_V4::baseApiCall(
      'signin/',
      config('purchaseCheckToolSetting.userName'),
      null,
      [
        'email_address'=>config('purchaseCheckToolSetting.userName'),
        'password'=>config('purchaseCheckToolSetting.userPassword')
      ]
    );

    return json_encode($response);
  }

  public function getShiftTransactions(Request $request){
    $authToken = $request->input('auth_token');
    $target_address = $request->input('target_address');
    $time_from = $request->input('time_from');
    $time_to = $request->input('time_to');
    $comment = $request->input('comment');
    $response = XApiServer_V4::baseApiCall(
      'getTransaction/',
      config('purchaseCheckToolSetting.userName'),
      $authToken,
      [
        'target_address'=>$target_address,
        'comment'=>$comment,
        'time_from'=>$time_from,
        'time_to'=>$time_to
      ]
    );

    return json_encode($response);
  }

  public function getShiftTransactionDetails(Request $request){
    $authToken = $request->input('auth_token');
    $time_from = $request->input('time_from');
    $time_to = $request->input('time_to');
    $offset = $request->input('offset') ?? 0;
    $limit = $request->input('limit') ?? 10;
    $type = 'deposit';
    $status = 'completed';
    $response = XApiServer_V4::baseApiCall(
      'getTransactionDetails/',
      config('purchaseCheckToolSetting.userName'),
      $authToken,
      [
        'type'=>$type,
        'status'=>$status,
        'time_from'=>$time_from,
        'time_to'=>$time_to,
        'offset'=>$offset,
        'limit'=>$limit
      ]
    );

    return json_encode($response);
  }

  public function getLocalData(Request $request){
    try {
      $params = $request->all();
      $response = PaymentUltimiopay_v4::baseApiCall('getReportData', $params);

      return response()->json([
        'result' => 'success',
        'data' => $response
      ]);
    } catch (\Exception $e) {
      // Handle connection or query error
      return response()->json([
        'result' => 'error',
        'message' => 'Failed to retrieve data: ' . $e->getMessage(),
      ]);
    }
  }

  public function getJdbData(Request $request){
    try {
      $orderIds = $request->input('orderIds');
      $response = Jdb::getTransactions('Inquiry/transactionList', $orderIds);

      return response()->json([
        'result' => 'success',
        'data' => $response
      ]);
    } catch (\Exception $e) {
      // Handle connection or query error
      return response()->json([
        'result' => 'error',
        'message' => 'Failed to retrieve data: ' . $e->getMessage(),
      ]);
    }
  }

  public function getOneJdbData(Request $request){
    try {
      $orderNo = $request->input('orderNo');
      $response = Jdb::getOneTransaction('Inquiry/transactionDetails', $orderNo);

      return response()->json([
        'result' => 'success',
        'data' => $response
      ]);
    } catch (\Exception $e) {
      // Handle connection or query error
      return response()->json([
        'result' => 'error',
        'message' => 'Failed to retrieve data: ' . $e->getMessage(),
      ]);
    }
  }

  public function getFireBlocksData(Request $request){
    try {
      $crypto_transaction_id = $request->input('crypto_transaction_id');
      $fireBlocks = $this->getFireBlocks();
      //$response = $fireBlocks->get_transaction_by_id($crypto_transaction_id);
      /*$response = $fireBlocks->get_transaction_by_external_id($crypto_transaction_id);*/
      $response = $fireBlocks->get_transactions(
        0,
        0,
        null,
        null,
        null,
        $crypto_transaction_id
      );

      return response()->json([
        'result' => 'success',
        'data' => $response
      ]);
    } catch (\Exception $e) {
      // Handle connection or query error
      return response()->json([
        'result' => 'error',
        'message' => 'Failed to retrieve data: ' . $e->getMessage(),
      ]);
    }
  }

  public static function getFireBlocks(): FireblocksSDK
  {
    $relativePath = config('fireblocks.private_key_path');
    $absolutePath = base_path($relativePath);
    $private_key = file_get_contents($absolutePath);
    //Log::info("private_key: $private_key");
    $api_key = config('fireblocks.api_key');
    //Log::info("api_key: $api_key");
    //Log::info("config('fireblocks.api_base_url'): ".config('fireblocks.api_base_url'));
    return new FireblocksSDK($private_key, $api_key, config('fireblocks.api_base_url'));
  }
}
