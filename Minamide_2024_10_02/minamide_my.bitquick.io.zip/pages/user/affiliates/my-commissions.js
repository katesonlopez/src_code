import { useState, useEffect } from "react";
import { useRouter } from 'next/router';
import { userService, alertService } from '/services';
import withAuth from '/hooks/withAuth';
import UserLayout from '/pages/user/layout/UserLayout'
import DataTable from '/components/DataTable';
import DataTableMobile from '/components/DataTableMobile';
import Loading from "../../../components/Loading";
import {maskEmail} from "../../../components/Utils/calc";

const page = () => {
  const router = useRouter();

  const [user, setUserData] = useState(null)
  const [userdata, setUserrData] = useState(null)
  const [status, setstatus] = useState(1);
  const [isLoading, setisLoading] = useState(true)
  const [kycData, setKycData] = useState([]);
  const [reportData, setReportData] = useState([])
  const [approvedTotal, setApprovedTotal] = useState(0)
  const [pendingTotal, setPendingTotal] = useState(0)
  const [totalCost, setTotalCost] = useState(0)
  const [isMobile, setIsMobile] = useState(false);
  const col = [
    {
      Header: 'Date/Time',
      accessor: 'Date',
    },
    {
      Header: 'USER',
      accessor: 'OrderID',
    },
    {
      Header: 'COMMISSION',
      accessor: 'Commission',
    },
    {
      Header: 'AMOUNT',
      accessor: 'TotalCost',
    },
    {
      Header: 'PRODUCT',
      accessor: 'ProductID',
    },
    {
      Header: 'APPROVAL STATUS',
      accessor: 'Status',
    },
    {
      Header: 'PAYOUT STATUS',
      accessor: 'PaidStatus',
    },
  ];

  const mobileCol = [
    {
      Header: 'Commissions',
      accessor: 'Data',
    },
  ];

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    async function fetchData() {
      const userJson = localStorage.getItem('user');
      if(userJson){
        const userser = JSON.parse(userJson);
        const user = userser.res.data.signinResponse;
        setUserData(user);
        await getUserInfo(user , true)
        getUserStatus(user)
        getAffiliateReport(user)
      }
    }

    fetchData();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [router])

  const getUserStatus = (userrr ) => {
    delete userrr.expires_in;
    delete userrr.wallet;

    userService.getUserStatus(userrr , 'both').then((d) => {
      setKycData(d.data)
      setstatus(d.status)
    }).catch((d) => {
    })
  }

  const getAffiliateReport = (userrr ) => {
    delete userrr.expires_in;
    delete userrr.wallet;
    userrr.affiliate_name = userrr.email_address
    userService.runApi(`getAffiliateReport/` , userrr).then((d) => {
      let orders = d.data.apiResponse;
      orders = orders.map(record => ({
        ...record,
        OrderID: maskEmail(record.OrderID)
      }));

      setReportData(orders);

      const tc = orders.reduce((acc, order) => {
        return acc + order.Commission;
      }, 0);

      let at = 0;
      let pt = 0;

      orders.forEach((item) => {
        if (item.Status === 'APPROVED') {
          at += item.Commission;
        } else if (item.Status === 'PENDING') {
          pt += item.Commission;
        }
      });

      setApprovedTotal(at)
      setPendingTotal(pt)
      setTotalCost(tc)
      setisLoading(false)
    }).catch((d) => {
    })
  }

  const getUserInfo = (userrr , is_open_popup=false) => {
    delete userrr.expires_in;
    delete userrr.wallet;
    setUserrData(false)
    userService.runApi(`userInfo/` , userrr).then((d) => {
      const resd = d.data.userInfoResponse;
      const { protocol, host } = window.location;
      const baseUrl = `${protocol}//${host}`;
      setUserrData(resd);
    }).catch((d) => {
    })
  }

  return (
    <UserLayout>
      {user && userdata && kycData ? (
        <main className="p-3">
          <div className={isMobile ? "container-fluid px-1 mb-3 p-1" : "container-fluid px-4"}>
            <div className='mt-4'>
              <div className="card">
                <h5 className="card-header text-white font-800">MY COMMISSIONS</h5>
                <div className="card-body p-4">
                  <table className="table table-borderless">
                    <tr>
                      <th className='border-0'>Pending payout commission:</th>
                      <td className='border-0'>{approvedTotal.toFixed(2)} USD</td>
                    </tr>
                    <tr>
                      <th className='border-0'>Pending approval commission:</th>
                      <td className='border-0'>{pendingTotal.toFixed(2)} USD</td>
                    </tr>
                    <tr>
                      <th className='border-0'>Total paid commission:</th>
                      <td className='border-0'>{totalCost.toFixed(2)} USD</td>
                    </tr>
                  </table>

                  <div className="table-responsive mt-3">
                    {isLoading ? (
                      <p>Loading...</p>
                    ) : isMobile ? (
                      <DataTableMobile data={reportData} col={mobileCol} />
                    ) : (
                      <DataTable data={reportData} col={col} />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      ): (
        <Loading />
      )}
    </UserLayout>
  )
}

export default withAuth(page);