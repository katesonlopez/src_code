<?php
require_once '../includes/config.php';
require_once '../includes/authentication.php';
require_once "../includes/common.php";
$baseUrl = getBaseUrl();

header('Content-Type: application/json');

/**
 * Basic API calling module
 **/
function callApi($action, $body = null) {

  $response = null;

  // Check email address is registered in local database
  $conn = getDbConnection();

  // Escape the email address to prevent SQL injection
  $emailAddressEscaped = $conn->real_escape_string($body['email_address']);

  $sql = "SELECT * FROM users WHERE email_address = '$emailAddressEscaped' AND deleted_at IS NULL";
  $result = $conn->query($sql);

  // Call Ultimo API
  if ($result->num_rows > 0) {

    // Encoding the request data as JSON which will be sent in POST
    $encodedData = json_encode($body);

    // Initiate curl with the url to send request
    $curl = curl_init(ULTIMO_API_URL.$action.'/');

    // Return CURL response
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    // Send request data using POST method
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

    // Data content-type is sent as JSON
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
      'Content-Type:application/json',
      'Authorization:Bearer '.ULTIMO_API_KEY
    ));
    curl_setopt($curl, CURLOPT_POST, true);

    // Curl POST the JSON data to send the request
    curl_setopt($curl, CURLOPT_POSTFIELDS, $encodedData);

    // execute the curl POST request and send data
    $response = curl_exec($curl);
    $error = curl_error($curl);

    curl_close($curl);
  } else {
    $error = 'Invalid email address to sign in';
  }

  // Error handling
  if( $response == null )
    $error = 'Invalid user. Please check your credentials and try again.';

  if ($error) {
    return json_encode(['result' => 'failed', 'error' => ['errorMessage' => $error]]);
  }

  // Return response
  return $response;
}

/**
 * Start to call api
**/
// Process AJAX request
$requestBody = json_decode(file_get_contents('php://input'), true);

if (isset($requestBody['action'])) {

  // Check request parameters
  $action = $requestBody['action'] ?? null;
  $emailAddress = $requestBody['email_address'] ?? null;
  $auth_token = $requestBody['auth_token'] ?? null;
  $jwt = $requestBody['jwt'] ?? null;

  // Check jwt validation <=> Check if logged in
  if( $action != 'signin' )
    $emailAddress = checkAuthentication( $jwt );

  // Call Ultimo APIs
  $requestBody['email_address'] = $emailAddress;
  $response = callApi($action, $requestBody);

  // If signin API, set auth_token and jwt into response.
  if( $action == 'signin' ){
    $responseObj = json_decode( $response, true);
    if( $responseObj['result'] == 'success' ){
      $jwt = generateJwt($emailAddress);
      $responseObj['signinResponse']['jwt'] = $jwt;
      $response = json_encode( $responseObj);
    }
  }
  echo $response;
}
else {
  echo json_encode(['result' => 'failed', 'error' => ['errorMessage' => 'Invalid action.']]);
}
