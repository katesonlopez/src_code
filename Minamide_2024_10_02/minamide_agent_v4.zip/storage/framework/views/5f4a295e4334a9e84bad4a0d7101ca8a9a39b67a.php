<?php $__env->startSection('content'); ?>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/4.3.0/css/fixedColumns.dataTables.min.css">
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
  <script src="https://cdn.datatables.net/fixedcolumns/4.3.0/js/dataTables.fixedColumns.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.2/bootbox.min.js"></script>

  <!-- DataTables Buttons extension for export -->
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css">
  <script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>

  <!-- JSZip for XLSX export -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>

  <!-- PDFMake for PDF export (if needed) -->
  <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.pdfmake.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.7.1/js/vfs_fonts.js"></script>

  <!--<link rel="stylesheet" href="<?php echo e(asset('vendor/dataTables.bootstrap5.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendor/fixedColumns.dataTables.min.css')); ?>">
  <script src="<?php echo e(asset('vendor/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/dataTables.bootstrap5.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/moment.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/dataTables.fixedColumns.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/bootbox.min.js')); ?>"></script>-->

  <div class="">
    <!-- Search Option Panel -->
    <div class="search-panel">
      <form class="row align-items-center">
        <!-- Email Address and Order No Buttons -->
        <div class="col-12 col-md-3">
          <div class="btn-group w-100" role="group">
            <button onclick="onOpenEmailAddress();" data-bs-toggle="modal" data-bs-target="#emailModal" type="button" class="search-ctrl btn btn-outline-primary d-flex align-items-center justify-content-center">
              <i class="bi bi-envelope fs-3"></i>
              <span class="badge bg-danger icon-badge email_count_info email_count hide">0</span>
              <span class="text-end tool-label ms-3">Input Email Address</span>
            </button>
          </div>
        </div>

        <!-- Date Range Controls in One Row on Mobile -->
        <div class="col-12 col-md-3 d-flex flex-column flex-md-row align-items-center">
          <div class="row">
            <div class="col-6">
              <label for="fromDate" class="form-label">
                <i class="bi bi-calendar2-event"></i> <span class="tool-label">From</span>
              </label>
              <input type="date" class="search-ctrl form-control" id="fromDate">
            </div>
            <div class="col-6">
              <label for="toDate" class="form-label">
                <i class="bi bi-calendar2-range"></i> <span class="tool-label">To</span>
              </label>
              <input type="date" class="search-ctrl form-control" id="toDate">
            </div>
          </div>
        </div>

        <!-- Status Controls in One Row -->
        <div class="col-12 col-md-3 d-flex flex-column flex-md-row align-items-center">
          <div class="row">
            <div class="col-6">
              <label for="status" class="form-label">
                <i class="bi bi-gear"></i> <span class="tool-label">Status</span>
              </label>
              <select class="search-ctrl form-control" id="status">
                <option value="completed">completed</option>
              </select>
            </div>
            <div class="col-6">
              <label for="type" class="form-label">
                <i class="bi bi-card-checklist"></i> <span class="tool-label">Type</span>
              </label>
              <select class="search-ctrl form-control" id="type">
                <option value="deposit">deposit</option>
              </select>
            </div>
          </div>
        </div>

        <!-- Reset and Search Buttons -->
        <div class="col-12 col-md-3 d-flex align-items-center justify-content-center">
          <div class="btn-group w-100" role="group">
            <button onclick="onStart();" type="button" class="search-ctrl btn btn-primary d-flex align-items-center justify-content-center">
              <span class="spinner-anim spinner-border spinner-border-sm text-white me-2" role="status" style="display: none"></span>
              <div>
                <i class="bi bi-caret-up-square-fill small"></i>
                <i class="bi bi-search fs-3"></i>
              </div>
              <span class="text-end tool-label ms-2">Search TxID</span>
            </button>
          </div>
        </div>
      </form>
    </div>

    <!--  Result table  -->
    <div class="result-table mt-3">
      <table class="table table-bordered table-hover-animation table-hover row-border order-column nowrap" id="checkTable">
        <thead>
          <tr>
            <th rowspan="2" class="text-center">No.</th>
            <th rowspan="2" class="text-center">Email Address</th>
            <th rowspan="2" class="text-center">Currency</th>
            <th colspan="5" class="text-center shift-data">Shift Data</th>
            <th colspan="5" class="text-center local-data">Fireblocks Data</th>
            <th rowspan="2" class="text-center">Result</th>
          </tr>
          <tr>
            <th class="shift-data">Amount</th>
            <th class="shift-data">TxID</th>
            <th class="shift-data">Deposit Address</th>
            <th class="shift-data">Status</th>
            <th class="shift-data">Date/Time</th>

            <th class="local-data">TxID</th>
            <th class="local-data">Deposit Address</th>
            <th class="local-data">Currency</th>
            <th class="local-data">Amount</th>
            <th class="local-data">Date/Time</th>
          </tr>
        </thead>
        <tbody class="my-tbody">
        </tbody>
      </table>
    </div>

    <!--  Progress bar  -->
    <div align="center" class="w-100 mt-4 my-progress-bar" style="display: none;">
      <div class="progress-outer text-center">
        <div class="progress">
          <div class="progress-bar progress-bar-info progress-bar-striped active" style="width:0; box-shadow:-1px 10px 10px rgba(91, 192, 222, 0.7); margin-right: -100%"></div>
          <div class="progress-value">0%</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Email address input modal -->
  <div class="modal fade" id="emailModal" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="apiKeyLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h5 class="modal-title text-white">Input Email Addresses To Search & Compare</h5>
          <button class="close btn-close" data-bs-dismiss="modal" aria-label="Close">
          </button>
        </div>
        <div class="modal-body">
          <textarea id="email_address" rows="6" class="w-100 p-3" oninput="onChangeEmailAddressList();" placeholder="Please type email addresses here..."></textarea>
        </div>
        <div class="modal-footer d-flex align-items-center justify-content-between">
          <div>
            <span class="email_count_info hide"><span class="email_count">0</span> email addresses</span>
          </div>
          <div>
            <button class="btn btn-primary" id="btnEmailList" data-bs-dismiss="modal" onclick="onSelectEmailAddress()">
              <span class="spinner-text ps-4 pe-4">Ok</span>
            </button>
            <button class="btn btn-outline-secondary" data-bs-dismiss="modal">
              <span class="spinner-text ps-4 pe-4">Cancel</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Detail view modal -->
  <div class="modal fade" id="detailModal" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="apiKeyLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-full-width" role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h5 class="modal-title text-white">Review the detailed data</h5>
          <button class="close btn-close" data-bs-dismiss="modal" aria-label="Close">
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-4 col-sm-12">
              <div class="card">
                <div class="card-header">
                  Shift transaction data <sup class="shiftFeeValue"></sup>
                </div>
                <div class="card-body">
                  <div class="text-danger compareMsg compareMsg-shift mb-3"></div>
                  <pre class="shift-detail">
                  </pre>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="card">
                <div class="card-header">
                  Shift txID data <sup class="shiftTxIDValue"></sup>
                </div>
                <div class="card-body">
                  <div class="text-danger compareMsg compareMsg-txid mb-3"></div>
                  <pre class="txid-detail">
                  </pre>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="card">
                <div class="card-header">
                  Fireblocks transaction data
                </div>
                <div class="card-body">
                  <div class="text-danger compareMsg compareMsg-fireBlocks mb-3"></div>
                  <pre class="fireblocks-detail">
                  </pre>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer d-flex align-items-center justify-content-end">
          <button class="btn btn-outline-secondary px-4" data-bs-dismiss="modal">
            Close
          </button>
        </div>
      </div>
    </div>
  </div>
  <script>
    let g_emails = [];
    let g_dataTable = null;
    let g_fullData = [];
    let g_tableData = [];
    let g_progressBarInterval = 0;

    $(document).ready(function(){
      buildDataTable(g_tableData);

      onResize();
      $(window).resize(function() {
        onResize();
      });
    });

    /**
     * Start searching and comparing
     * **/
    async function onStart() {

      if( g_emails.length <= 0 ){
        doError("No Emails", "Please input email address list, first");
        return;
      }

      // Initialize
      g_fullData = {};
      SpinBtnCtrl('search-ctrl', true);
      progressBarCtrl('', true);
      buildDataTable([]);

      // Get auth token
      progressBarCtrlAnim('Getting auth token', 10000, 0, 20);
      const authToken = await getAuthToken();
      if (!authToken) {
        console.error('No valid auth token found.');
        return;
      }
      progressBarCtrl('Getting auth token', true, 20);

      // Get shift data and merge it to full data
      let shiftData = await retrieveShiftData(g_emails, authToken, 20, 40);
      progressBarCtrl('Retrieving shift data', true, 40);
      console.log('shiftData: ', shiftData.length, shiftData);

      // Get shift data and merge it to full data
      let shiftTxIDData = await retrieveShiftTxIDData(g_emails, authToken, 40, 60);
      progressBarCtrl('Retrieving shift txID data', true, 60);
      console.log('shiftTxIDData: ', shiftTxIDData.length, shiftTxIDData);

      // Filter the shiftTxIDData to only include transactions with matching payment_ids
      const paymentIds = shiftData.map(transaction => transaction.payment_id).filter(id => id);
      let filteredTxIDData = shiftTxIDData.filter(transaction => paymentIds.includes(transaction.payment_id));
      filteredTxIDData = filteredTxIDData
        .filter(transaction => {
          return shiftData.some(shift => shift.payment_id === transaction.payment_id);
        })
        .map(transaction => {
          const matchingShiftData = shiftData.find(shift => shift.payment_id === transaction.payment_id);
          return {
            ...transaction,
            username: matchingShiftData.user.username // Add the 'username' property
          };
        });

      console.log('filteredTxIDData: ', filteredTxIDData.length, filteredTxIDData);

      // Get Fireblocks data.
      let fireblocksData = await retrieveFireBlocksData(filteredTxIDData, 60, 80);
      progressBarCtrl('Retrieving fireblocks data', true, 80);
      console.log('fireblocksData: ', fireblocksData.length, fireblocksData);

      // Merge all data
      progressBarCtrlAnim('Merge all data', 1000, 80, 90);
      g_fullData = mergeAllData(shiftData, filteredTxIDData, fireblocksData);
      progressBarCtrl('Merge all data', true, 90);
      console.log('g_fullData: ', g_fullData.length, g_fullData);

      // Compare and out comparing result
      progressBarCtrlAnim('Comparing data', 1000, 90, 100);
      g_tableData = compareData(g_fullData, g_emails);
      buildDataTable(g_tableData);
      progressBarCtrl('Comparing data', true, 100);
      console.log('g_fullData: ', g_fullData.length, g_fullData);

      progressBarCtrl('complete', false, 100);
      SpinBtnCtrl('search-ctrl', false);
    }

    /**
     * Batch the email addresses
     * **/
    function batchEmails(emails, batchSize) {
      const batches = [];
      for (let i = 0; i < emails.length; i += batchSize) {
        batches.push(emails.slice(i, i + batchSize));
      }
      return batches;
    }

    /**
     * ========================================================================
     * Get shift transaction data
     * ========================================================================
     * **/
    async function retrieveShiftData(emails, authToken, startPercent, endPercent) {
      let result = [];
      const limit = 10000; // Set limit for each API call
      let offset = 0;      // Initialize offset

      // Function to start a new request
      const startRequest = async (email) => {
        if( emails.length <= 0 )
          return [];

        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        return $.ajax({
          url: g_siteUrl + '/purchaseChecker/getShiftTransactions',
          method: 'POST',
          headers: {
            'X-CSRF-TOKEN': csrfToken
          },
          data: {
            target_address: email,
            auth_token: authToken,
            comment: 'deposit',
            time_from: '2024-01-01'/*$('#fromDate').val()*/,
            time_to: ''/*$('#toDate').val()*/,
            offset: offset,
            limit: limit
          },
          dataType: 'json',
        });
      };

      try {
        let stepPercent = (endPercent - startPercent) / emails.length;
        let curPercent = startPercent;
        for (const email of emails) {
          progressBarCtrlAnim('Retrieving shift data', 10000, curPercent, curPercent + stepPercent);

          const response = await startRequest(email);

          curPercent += stepPercent;
          progressBarCtrl('Retrieving shift data', true, curPercent);

          if( response.result !== 'success' )
            continue;

          // Iterate through shiftResult['data'], filter by emails, and map into desired objects
          result = result.concat(
            response.data
              .filter(transaction => transaction.transaction_class !== 'fee')
              .map(transaction => {
                // Extract order number from comment
                let match = transaction.comment.match(/order number (\d+)/);
                let orderNo = match ? match[1] : Math.floor(100000 + Math.random() * 900000);
                match = transaction.comment.match(/([\d,.]+)\s*USD/);
                let usd = match ? match[1] : 0;

                // Construct object with email, orderNo, and other transaction data
                return {
                  email: transaction.user.username,
                  orderNo: orderNo,
                  usd: usd,
                  ...transaction
                };
              })
          );
        }
      } catch (error) {
        console.error('Error fetching transaction data:', error);
      }

      return result;
    }

    /**
     * ========================================================================
     * Get shift txID transaction data with repeated API calls
     * ========================================================================
     **/
    async function retrieveShiftTxIDData(emails, authToken, startPercent, endPercent) {
      let result = [];
      const limit = 10000; // Set limit for each API call
      let offset = 0;      // Initialize offset

      // Function to start a new request with the given offset and limit
      const startRequest = async (offset, limit) => {
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        return $.ajax({
          url: g_siteUrl + '/purchaseChecker/getShiftTransactionDetails',
          method: 'POST',
          headers: {
            'X-CSRF-TOKEN': csrfToken
          },
          data: {
            status: 'completed',
            type: 'deposit',
            auth_token: authToken,
            time_from: '2024-01-01', // Replace with dynamic value if necessary
            time_to: '',              // Replace with dynamic value if necessary
            offset: offset,
            limit: limit
          },
          dataType: 'json',
        });
      };

      try {
        let hasMoreTransactions = true;
        let curPercent = startPercent;
        const stepPercent = (endPercent - startPercent) / 10;

        // Loop to retrieve all transactions
        while (hasMoreTransactions) {
          progressBarCtrlAnim('Retrieving shift txID data', 60000, curPercent, curPercent + stepPercent );

          const response = await startRequest(offset, limit);

          curPercent += stepPercent;
          progressBarCtrl('Retrieving shift txID data', true, curPercent);

          if (!response || !response.data) {
            console.error('Invalid response structure');
            return [];
          }

          // Add the transactions to the result
          result = result.concat(response.data);

          // Check if we need to fetch more transactions
          if (response.data.length < limit) {
            hasMoreTransactions = false;
          } else {
            offset += limit;
          }
        }
      } catch (error) {
        console.error('Error fetching transaction data:', error);
      }

      return result;
    }

    // Get user's auth token
    async function getAuthToken() {
      try {
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        const response = await $.ajax({
          url: g_siteUrl + '/purchaseChecker/shiftSignIn',
          method: 'POST',
          dataType: 'json',
          headers: {
            'X-CSRF-TOKEN': csrfToken
          },
        });

        if (response.result === 'success') {
          return response.signinResponse.auth_token;
        } else {
          console.log(response);
          return null;
        }
      } catch (error) {
        console.error('Error during sign-in:', error);
        return null;
      }
    }

    /**
     * ========================================================================
     * Get Fireblocks data
     * ========================================================================
     * **/
    async function retrieveFireBlocksData(txIDData, startPercent, endPercent) {
      let result = [];

      // Correct condition to handle null or empty array
      if (!txIDData || txIDData.length <= 0) {
        return result;
      }

      // Function to start a new request
      const startRequest = async (crypto_transaction_id) => {
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        return await $.ajax({
          url: g_siteUrl + '/purchaseChecker/getFireBlocksData',
          method: 'POST',
          dataType: 'json',
          headers: {
            'X-CSRF-TOKEN': csrfToken
          },
          data: {
            crypto_transaction_id: crypto_transaction_id,
          },
        });
      };

      try {
        let curPercent = startPercent;
        const stepPercent = (endPercent - startPercent) / txIDData.length;

        // Use for...of to handle async/await correctly
        for (const transaction of txIDData) {
          progressBarCtrlAnim('Retrieving fireblocks data', 2000, curPercent, curPercent + stepPercent );

          if( !transaction.crypto_transaction_id ){
            console.log("empty txid:", transaction);
            continue;
          }
          const response = await startRequest(transaction.crypto_transaction_id);

          curPercent += stepPercent;
          progressBarCtrl('Retrieving fireblocks data', true, curPercent);

          if (!response || !response.data) {
            console.error('Invalid response structure');
            continue; // Skip this iteration if response is invalid
          }

          // If response.data is an array, iterate and add properties
          response.data = response.data.map(item => {
            return {
              ...item, // Spread the original item properties
              username: transaction.username, // Add username from transaction
              currency_id: transaction.currency_id // Add currency_id from transaction
            };
          });

          result = result.concat(response.data);
        }

        return result;
      } catch (error) {
        console.error('Error during get fireblocks data:', error);
        return null;
      }
    }

    /**
     * ========================================================================
     * Merge shift, local and jdb data
     * ========================================================================
     * **/
    function mergeAllData(shiftData, shiftTxIDData, fireblocksData) {
      // Determine the master array (the one with the maximum size)
      let masterArray, masterType;
      if (shiftData.length >= shiftTxIDData.length /*&& shiftData.length >= fireblocksData.length*/) {
        masterArray = shiftData;
        masterType = 'shift';
        // Sort shiftData by 'user.username' first, then by 'created_at_iso' in descending order
        masterArray.sort((a, b) => {
          if (a.user.username === b.user.username) {
            return new Date(b.created_at_iso) - new Date(a.created_at_iso);
          }
          return a.user.username.localeCompare(b.user.username);
        });
      } else if (shiftTxIDData.length >= shiftData.length /*&& shiftTxIDData.length >= fireblocksData.length*/) {
        masterArray = shiftTxIDData;
        masterType = 'txID';
        // Sort shiftData by 'username' first, then by 'updated_at' in descending order
        masterArray.sort((a, b) => {
          if (a.username === b.username) {
            return new Date(b.updated_at) - new Date(a.updated_at);
          }
          return a.username.localeCompare(b.username);
        });
      }/* else {
        masterArray = fireblocksData;
        masterType = 'fireblocks';
        // Sort shiftData by 'username' first, then by 'updated_at' in descending order
        masterArray.sort((a, b) => {
          if (a.username === b.username) {
            return new Date(b.lastUpdated) - new Date(a.lastUpdated);
          }
          return a.username.localeCompare(b.username);
        });
      }*/

      // Initialize fullData array
      const fullData = [];

      // Loop through the sorted master array
      for (let i = 0; i < masterArray.length; i++) {

        let matchingShiftData = [];
        let matchingTxIDData = [];
        let matchingFireblocksData = [];

        if (masterType === 'shift') {
          matchingShiftData.push(masterArray[i]);
          matchingTxIDData = matchingTxIDData.concat(shiftTxIDData.filter(record => record.payment_id === masterArray[i].payment_id));
          if (matchingTxIDData.length > 0)
            matchingFireblocksData = fireblocksData.filter(
              record => record.txHash === matchingTxIDData[0].crypto_transaction_id &&
              record.destinationAddress === matchingTxIDData[0].crypto_address
            );
        } else if (masterType === 'txID') {
          matchingTxIDData.push(masterArray[i]);
          matchingShiftData = shiftData.filter(record => record.payment_id === masterArray[i].payment_id);
          if( matchingTxIDData.length > 0 )
            matchingFireblocksData = fireblocksData.filter(record => record.txHash === matchingTxIDData[0].crypto_transaction_id);
        } else {
          matchingFireblocksData.push(masterArray[i]);
          matchingTxIDData = shiftTxIDData.filter(record => record.crypto_transaction_id === masterArray[i].txHash);
          if( matchingTxIDData.length > 0 )
            matchingShiftData = shiftData.filter(record => record.payment_id === matchingTxIDData[0].payment_id);
        }

        // Determine the maximum number of records to add for this orderNo
        const maxCount = Math.max(matchingShiftData.length, matchingTxIDData.length, matchingFireblocksData.length);

        // Loop over maxCount to add records to fullData
        for (let j = 0; j < maxCount; j++) {
          fullData.push({
            shift: matchingShiftData[j] || null, // If no more shiftData records, insert null
            txID: matchingTxIDData[j] || null, // If no more txID records, insert null
            fireblocks: matchingFireblocksData[j] || null // If no more fireblocks records, insert null
          });
        }
      }

      return fullData;
    }

    /**
     * ========================================================================
     * Compare shift, txID and fireblocks data and preparing table data
     * ========================================================================
     * **/
    function compareData(fullData, emails){

      // Initialize tableData array
      let tableData = [];
      let existingEmails = new Set();

      // Iterate over g_fullData and map its values to the desired table format
      fullData.forEach((data, index) => {

        // Extract data from g_fullData entries
        const shiftData = data.shift || {};
        const txID = data.txID || {};
        const fireblocks = data.fireblocks || {};

        // Store email to existingEmails set
        existingEmails.add(shiftData.email || '');

        // Comparing...
        let compareResult_shift = '';
        let compareResult_txID = '';
        let compareResult_fireblocks = '';

        // Check if any of shiftData, txIDData, or fireblocksData is null
        if (isEmpty(shiftData)) {
          compareResult_shift = "Data from Shift is empty.";
        }
        if (isEmpty(txID)) {
          compareResult_txID = "TxID Data from Shift is empty.";
        }
        if (isEmpty(fireblocks)) {
          compareResult_fireblocks = "Data from Fireblocks is empty.";
        }

        // Check if valid payment id
        if (!isEmpty(txID) && !isEmpty(shiftData) && shiftData.payment_id !== txID.payment_id) {
          if( compareResult_shift.length > 0 )
            compareResult_shift += '<br/>';
          compareResult_shift += `Can't fetch the exact payment_id from Shift.`;
        }

        // Check if valid txID
        if (!isEmpty(txID) && !isEmpty(fireblocks) && txID.crypto_transaction_id !== fireblocks.txHash) {
          if( compareResult_fireblocks.length > 0 )
            compareResult_fireblocks += '<br/>';
          compareResult_fireblocks += `The TxIDs mismatch between Shift and Fireblocks.`;
        }

        // Check if valid deposit address
        if (!isEmpty(txID) && !isEmpty(fireblocks) && txID.crypto_address !== fireblocks.destinationAddress) {
          if( compareResult_fireblocks.length > 0 )
            compareResult_fireblocks += '<br/>';
          compareResult_fireblocks += `The Deposit Addresses mismatch between Shift and Fireblocks.`;
        }

        // Check if valid currency
        if (!isEmpty(txID) && !isEmpty(shiftData) && txID.currency_id !== shiftData.currency_id) {
          if( compareResult_shift.length > 0 )
            compareResult_shift += '<br/>';
          compareResult_shift += `Can't fetch the exact currency from Shift.`;
        }

        // Check if valid amount
        if (!isEmpty(txID) && !isEmpty(shiftData) && Math.abs(txID.amount*1 - shiftData.amount*1) > 0.00000001) {
          if( compareResult_shift.length > 0 )
            compareResult_shift += '<br/>';
          compareResult_shift += `Can't fetch the exact amount from Shift`;
        }
        if (!isEmpty(txID) && !isEmpty(fireblocks) && Math.abs(fireblocks.amount*1 - shiftData.amount*1) > 0.00000001) {
          if( compareResult_fireblocks.length > 0 )
            compareResult_fireblocks += '<br/>';
          compareResult_fireblocks += `The Amounts mismatch between Shift and Fireblocks.`;
        }

        // Check if the intervals between shiftData, localData, and jdbData are longer than 30 minutes
        const created_at_iso = shiftData?.created_at_iso ? new Date(shiftData.created_at_iso).getTime() : null;
        const updated_at = txID?.updated_at ? new Date(formatTimezoneString(txID.updated_at)).getTime() : null;
        const lastUpdated = fireblocks?.lastUpdated ? (fireblocks.lastUpdated)*1 : null;

        // Function to check time interval (in milliseconds, 30 minutes = 30 * 60 * 1000)
        const THIRTY_MINUTES = 30 * 60 * 1000;

        // Check if the time difference between shiftData, txID, and fireblocks is greater than 30 minutes
        if (created_at_iso && updated_at && Math.abs(created_at_iso - updated_at) > THIRTY_MINUTES) {
          if( compareResult_shift.length > 0 )
            compareResult_shift += '<br/>';
          compareResult_shift += "Shift's timestamps are 30+ minutes apart.";
        }

        if (created_at_iso && lastUpdated && Math.abs(created_at_iso - lastUpdated) > THIRTY_MINUTES) {
          if( compareResult_shift.length > 0 )
            compareResult_shift += '<br/>';
          compareResult_shift += "Shift's transaction data and Fireblocks are 30+ minutes apart.";
        }

        if (updated_at && lastUpdated && Math.abs(updated_at - lastUpdated) > THIRTY_MINUTES) {
          if( compareResult_fireblocks.length > 0 )
            compareResult_fireblocks += '<br/>';
          compareResult_fireblocks += "Shift's txID data and Fireblocks are 30+ minutes apart.";
        }

        // Check if txID.status is not 'complete'
        if (!isEmpty(txID) && txID?.status !== "completed") {
          if (compareResult_txID.length > 0) compareResult_txID += '<br/>';
          compareResult_txID += "The status is not [complete].";
        }

        // Check if fireblock.status is not "COMPLETED"
        if (!isEmpty(fireblocks) && fireblocks?.status !== 'COMPLETED') {
          if (compareResult_fireblocks.length > 0) compareResult_fireblocks += '<br/>';
          compareResult_fireblocks += "The status isn't [COMPLETED].";
        }

        // Push the new array structure into tableData
        const compareResults = [compareResult_shift, compareResult_txID, compareResult_fireblocks];
        const isAnyCompareResultNotEmpty = compareResults.some(result => result);
        const finalCompareResults = isAnyCompareResultNotEmpty ? compareResults : null;

        tableData.push([
          index + 1, // Unique auto increment natural number
          shiftData.email || txID.username || fireblocks.username || '', // Email from shift
          shiftData.currency_id || txID.currency_id || fireblocks.currency_id, // currency from all
          shiftData.amount || txID.amount || '', // amount value from shift and txID
          txID.crypto_transaction_id || '', // crypto_transaction_id from txID
          txID.crypto_address || '', // deposit address from txID
          txID.status || '', // status from txID
          shiftData.created_at_iso || '', // created_at_iso from shift
          fireblocks.txHash || '', // txHash from fireblocks
          fireblocks.destinationAddress || '', // destinationAddress from fireblocks
          fireblocks.assetId || '', // currency_id from fireblocks
          fireblocks.amount || '', // amount from fireblocks
          fireblocks.lastUpdated || '', // lastUpdated from fireblocks
          finalCompareResults // Compare result
        ]);
      });

      // Check for emails in the emails array that do not exist in fullData
      emails.forEach(email => {
        if (!existingEmails.has(email)) {
          tableData.push([
            tableData.length + 1, // Unique auto increment natural number
            email, // Email from emails
            'No Data', // currency from all
            '', // amount value from shift and txID
            '', // crypto_transaction_id from txID
            '', // deposit address from txID
            '', // status from txID
            '', // created_at_iso from shift
            '', // txHash from fireblocks
            '', // destinationAddress from fireblocks
            '', // currency_id from fireblocks
            '', // amount from fireblocks
            '', // lastUpdated from fireblocks
            null // Compare result (empty)
          ]);
        }
      });

      return tableData;
    }

    function showDetails(fullDataId){
      const compareResults = g_tableData[fullDataId][13];
      if( compareResults ){
        $('.compareMsg-shift').html(compareResults[0] ?? null);
        $('.compareMsg-txid').html(compareResults[1] ?? null);
        $('.compareMsg-fireBlocks').html(compareResults[2] ?? null);
      }
      else{
        $('.compareMsg-shift').html('');
        $('.compareMsg-txid').html('');
        $('.compareMsg-fireBlocks').html('');
      }

      $('.shift-detail').html(JSON.stringify(g_fullData?.[fullDataId]?.['shift'] ?? null, null, 2));
      $('.txid-detail').html(JSON.stringify(g_fullData?.[fullDataId]?.['txID'] ?? null, null, 2));
      $('.fireblocks-detail').html(JSON.stringify(g_fullData?.[fullDataId]?.['fireblocks'] ?? null, null, 2));
    }


    /**
     * Trigger when user open email address input modal
     * **/
    function onOpenEmailAddress(){
      const emailText = g_emails.join('\n');
      $('#email_address').val(emailText);
    }

    /**
     * Trigger when user click 'Ok' on email address input modal
     * **/
    function onSelectEmailAddress(){
      g_emails = getEmailAddresses();
      $('.badge.email_count').text(g_emails.length);
      if( g_emails.length > 0 )
        $('.badge.email_count_info').show();
      else
        $('.badge.email_count_info').hide();
    }

    /**
     * Trigger when user type on email address input modal
     * **/
    function onChangeEmailAddressList(){
      let emailAddressList = getEmailAddresses();

      $('.modal-footer .email_count').text(emailAddressList.length);
      if( emailAddressList.length > 0 )
        $('.modal-footer .email_count_info').show();
      else
        $('.modal-footer .email_count_info').hide();
    }

    /**
     * Get email addresses what user typed
     * **/
    function getEmailAddresses() {
      // Get the textarea value
      let emailText = $('#email_address').val();

      // Split the input by commas, spaces, or new lines, and remove any empty values
      let emails = emailText.split(/[\s,]+/).filter(function(email) {
        return email.trim().length > 0; // Filter out empty strings
      });

      // Create a Set to remove duplicates and filter valid emails
      // Return the unique, valid emails
      return [...new Set(emails.filter(function (email) {
        return validateEmail(email.trim());
      }))];
    }

    function validateEmail(email) {
      let re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return re.test(email);
    }


    /**
     * Construct or re-construct data table
     * **/
    function buildDataTable(tableData = []){

      let browserWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
      let browserHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

      if( g_dataTable )
        g_dataTable.destroy();

      g_dataTable = $('#checkTable').DataTable({
        data: tableData,
        searching: true,
        processing: false,
        serverSide: false,
        paging: false,
        info: false,
        scrollX: true,
        scrollY: (browserHeight - 360) + 'px',
        scrollCollapse: true,
        fixedColumns: {
          leftColumns: 3,
          rightColumns: 1
        },
        columnDefs: [
          { targets: '_all', orderable: false }
        ],
        columns: [
          { // Column 1: Auto increment number
            data: 0,
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[13]) {
                $(td).addClass('bg-danger');
              }
            },
          },
          { // Column 2: Email from shift
            data: 1,
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[13]) {
                $(td).addClass('bg-danger');
              }
            },
          },
          { // Column 3: Currency from shift
            data: 2,
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[13]) {
                $(td).addClass('bg-danger');
              }
            },
          },
          { // Column 4: Amount from shift
            data: 3,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('shift-data');
            },
          },
          { // Column 5: TxID amount from shift
            data: 4,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('shift-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                return `<div class="d-flex align-items-center justify-content-between">
                          <span data-bs-toggle="tooltip" data-bs-placement="top" title="${data}">
                            ${shortenString(data)}
                          </span>
                          <i class="bi bi-clipboard copy-btn ms-2 pointer-cursor"
                             data-copy="${data}"
                             data-bs-toggle="tooltip"
                             data-bs-placement="top"
                             title="Copy to clipboard"></i>
                        </div>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 6: Deposit address from shift
            data: 5,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('shift-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                return `<div class="d-flex align-items-center justify-content-between">
                          <span data-bs-toggle="tooltip" data-bs-placement="top" title="${data}">
                            ${shortenString(data)}
                          </span>
                          <i class="bi bi-clipboard copy-btn ms-2 pointer-cursor"
                             data-copy="${data}"
                             data-bs-toggle="tooltip"
                             data-bs-placement="top"
                             title="Copy to clipboard"></i>
                        </div>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 7: Status from shift
            data: 6,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('shift-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                let badgeClass = 'bg-danger';
                if (data.toString().toLowerCase() === 'completed')
                  badgeClass = 'bg-success';

                return `<span class="badge ${badgeClass}">${data}</span>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 8: date/time from shift
            data: 7,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('shift-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                const date = new Date(data.toString());
                return `${date.toLocaleDateString()} <sup>${date.toLocaleTimeString()}</sup>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 9: TxID from fireblocks
            data: 8,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                return `<div class="d-flex align-items-center justify-content-between">
                          <span data-bs-toggle="tooltip" data-bs-placement="top" title="${data}">
                            ${shortenString(data)}
                          </span>
                          <i class="bi bi-clipboard copy-btn ms-2 pointer-cursor"
                             data-copy="${data}"
                             data-bs-toggle="tooltip"
                             data-bs-placement="top"
                             title="Copy to clipboard"></i>
                        </div>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 10: Deposit Address from fireblocks
            data: 9,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                return `<div class="d-flex align-items-center justify-content-between">
                          <span data-bs-toggle="tooltip" data-bs-placement="top" title="${data}">
                            ${shortenString(data)}
                          </span>
                          <i class="bi bi-clipboard copy-btn ms-2 pointer-cursor"
                             data-copy="${data}"
                             data-bs-toggle="tooltip"
                             data-bs-placement="top"
                             title="Copy to clipboard"></i>
                        </div>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 11: Currency from fireblocks
            data: 10,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
          },
          { // Column 12: Amount from fireblocks
            data: 11,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
          },
          { // Column 13: date/time from fireblocks
            data: 12,
            createdCell: function (td, cellData, rowData, row, col) {
              $(td).addClass('jdb-data');
            },
            render: function (data, type, row, meta) {
              if( data !== null && data !== undefined && data.toString().trim().length > 0 ) {
                const date = new Date(Number(data.toString()));
                return `${date.toLocaleDateString()} <sup>${date.toLocaleTimeString()}</sup>`;
              }
              else{
                return '';
              }
            }
          },
          { // Column 14: Action button
            data: 13,
            render: function (data, type, row, meta) {
              let btnClass = 'btn-outline-success';
              let iconClass = 'bi-circle';
              if(data) {
                btnClass = 'btn-danger';
                iconClass = 'bi-triangle';
              }
              return `<button data-bs-toggle="modal" data-bs-target="#detailModal" onclick="showDetails(${row[0] - 1})" class="btn ${btnClass} btn-result"><i class="bi ${iconClass}"></i></button>`;
            }
          }
        ],
        rowCallback: function(row, data) {
          $(row).addClass('dataTableRow');  // Add the CSS class to each row
        },
        initComplete: function() {
          $('div.dataTables_wrapper').css('width', (browserWidth - 50) + 'px');

          // tooltip initialization
          /*$('[data-bs-toggle="tooltip"]').each(function () {
            $(this).tooltip();
          });*/

          // copy button event handler
          $('.copy-btn').click(function() {
            var $btn = $(this);
            var dataToCopy = $btn.data('copy');

            // Use Clipboard API to copy the text
            navigator.clipboard.writeText(dataToCopy).then(() => {
              // Update tooltip to show 'Copied!'
              $btn.attr('data-bs-original-title', 'Copied!')
                .tooltip('show');  // Manually show updated tooltip

              // Reset tooltip text back to 'Copy to clipboard' after 2 seconds
              setTimeout(() => {
                $btn.attr('data-bs-original-title', 'Copy to clipboard');
              }, 1000);
            }).catch(err => {
              console.error('Error copying text: ', err);
            });
          });
        },
        dom: 'Bfrtip',
        buttons: [
          {
            extend: 'csvHtml5',
            text: 'Download CSV',
            title: 'Data export',
            className: 'btn btn-outline-success mb-2 mb-md-0',
            init: function(api, node, config) {
              $(node).removeClass('dt-button buttons-csv buttons-html5');
            }
          },
          {
            extend: 'excelHtml5',
            text: 'Download Excel',
            title: 'Data export',
            className: 'btn btn-outline-success mb-2 mb-md-0',
            init: function(api, node, config) {
              $(node).removeClass('dt-button buttons-excel buttons-html5');
            }
          }
        ]
      });
    }

    /**
     * Control progress bar
     * **/
    function progressBarCtrl(sLabel, bShow, nProgress){
      clearInterval(g_progressBarInterval);

      $('.progress-value').html(sLabel + ' ' + (parseFloat(nProgress).toFixed(1)) + ' %');
      $('.progress-bar').css('width', nProgress + '%');
      if( !bShow ){
        setTimeout(function(){
          $('.my-progress-bar').hide();
        }, 1000);
      }
      else{
        $('.my-progress-bar').show();
      }
    }
    function progressBarCtrlAnim(label, duration, currentPercent, toPercent) {
      const $progressBar = $('.my-progress-bar .progress-bar');
      const $progressValue = $('.my-progress-bar .progress-value');
      const increment = (toPercent - currentPercent) / (duration / 10); // Updates every 10ms

      let current = currentPercent;

      // Show the progress bar if hidden
      $('.my-progress-bar').show();

      clearInterval(g_progressBarInterval);
      g_progressBarInterval = setInterval(() => {
        current += increment;
        if ((increment > 0 && current >= toPercent) || (increment < 0 && current <= toPercent)) {
          current = toPercent;
          clearInterval(g_progressBarInterval);
        }

        // Update progress bar width and label
        $progressBar.css('width', `${current}%`);
        $progressValue.text(`${label} ${current.toFixed(1)} %`);
      }, 10);
    }

    // Function to wait until the width of the progress bar matches the target percent
    function waitForProgressBar(targetPercent) {
      return new Promise((resolve) => {
        const checkInterval = setInterval(() => {
          const currentWidth = parseFloat($('.progress-bar').css('width'));

          if (currentWidth >= targetPercent) {
            clearInterval(checkInterval);
            resolve(); // Proceed once the width matches the target
          }
        }, 50); // Check every 50ms
      });
    }


    /**
     * Spin control
     * **/
    function SpinBtnCtrl(className, showSpin) {

      let ctrlObjs = $('.' + className);
      let spinnerObj = $('.' + className + ' ' + '.spinner-anim');

      if (showSpin) {
        spinnerObj.css('display', 'inline-block');
        ctrlObjs.attr('disabled', showSpin);
      } else {
        spinnerObj.css('display', 'none');
        ctrlObjs.removeAttr('disabled');
      }
    }

    function doAlert(title, message){
      bootbox.alert({
        title: title,
        message: message,
        centerVertical: true,
        className: 'bounceIn animated'
      });
    }

    function doError(title, message){
      bootbox.alert({
        title: title,
        message: message,
        centerVertical: true,
        className: 'rubberBand animated'
      });
    }

    function isEmpty(obj) {
      return Object.keys(obj).length === 0;
    }

    function onResize(){
      let resultTable = $('.result-table');
      const clientWidth = ($(window).width() * 1) - 20;
      if( clientWidth < 1024 ){
        resultTable.css('max-width', clientWidth + 'px');
        resultTable.css('overflow-x', 'scroll');
      }
      else{
        resultTable.css('max-width', clientWidth + 'px');
        resultTable.css('overflow-x', 'unset');
      }

      buildDataTable(g_tableData);
    }

    function shortenString(str) {
      const cutLen = 8;
      if (str.length <= 2 * cutLen) {
        return str; // No need to shorten if the string is less than or equal to 10 characters
      }
      return str.substring(0, cutLen) + '...' + str.substring(str.length - cutLen);
    }

    function formatDate(timestamp) {
      if( timestamp.trim().length <= 0 )
        return '';

      const date = new Date(timestamp);
      const pad = (num) => String(num).padStart(2, '0');
      const year = date.getUTCFullYear();
      const month = pad(date.getUTCMonth() + 1); // Months are zero-based
      const day = pad(date.getUTCDate());
      const hours = pad(date.getUTCHours());
      const minutes = pad(date.getUTCMinutes());
      const seconds = pad(date.getUTCSeconds());
      const timezoneOffset = -date.getTimezoneOffset(); // Get the offset in minutes
      const tzHours = pad(Math.floor(Math.abs(timezoneOffset) / 60));
      const tzMinutes = pad(Math.abs(timezoneOffset) % 60);
      const tzSign = timezoneOffset >= 0 ? '+' : '-';

      return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}${tzSign}${tzHours}:${tzMinutes}`;
    }

    function formatTimezoneString(dateString){
      // Check if 'T' is present and '+00:00' is present
      if (!dateString.includes('T')) {
        dateString = dateString.replace(' ', 'T');  // Add 'T' if not present
        dateString += '+00:00';
      }

      return dateString;
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.purchaseCheckerLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Minamide\minamide_agent_v4\resources\views//purchase-checker/checkTxID.blade.php ENDPATH**/ ?>