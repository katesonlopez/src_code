import {useState, useEffect} from 'react';
import {useRouter} from 'next/router';
import {userService} from '/services';

function FormPending({user, form2, fullUserData, onNextClick, isMobile, memberCard}) {
  const [kycStatus, setKycStatus] = useState(1);
  const [intervalId, setIntervalId] = useState(null)
  const router = useRouter();
  const [kycDenyMessage, setKycDenyMessage] = useState('');

  useEffect(() => {
    const _intervalId = setInterval(() => {
      fetchUserData();
    }, 30000);

    setIntervalId(_intervalId)

    // Fetch user data initially
    fetchUserData();

    return () => clearInterval(_intervalId);
  }, []);

  const fetchUserData = async () => {
    try {
      const res = await userService.runApi("updateUserStatus/", user);
      if (res.data.updateStatusResponse.kyc_status * 1 === 9) {
        const resUserInfo = await userService.runApi("userInfo/", user);
        setKycDenyMessage(resUserInfo.data.userInfoResponse.kyc_deny_message);
      }
      setKycStatus(Number(res.data.updateStatusResponse.kyc_status));
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };


  useEffect(()=> {
    if (kycStatus !== 1) {
      clearInterval(intervalId * 1);

      // Remove all elements with class 'kyc-status'
      document.querySelectorAll('.kyc-status').forEach(element => {
        element.remove();
      });

      // Display elements with class 'status-kycStatus'
      document.querySelectorAll('.status-' + kycStatus).forEach(element => {
        element.style.display = 'block';
      });
    }
  }, [kycStatus])

  return (
    <>
      {kycStatus === 1 && (
        <div className="col-md-8 mx-auto mt-3">
          <div className="card mx-auto">
            <div className="card-body" align="center">
              <h3 className="card-title text-center mb-4 font-800 text-white">APPLY FOR A {memberCard === 0 ? "DEBIT" : "MEMBER"} CARD</h3>
              <label className="text-left p-2">
                <p className="card-text">Congratulations!</p>
                <p className="card-text">Your {memberCard === 0 ? "debit" : "member"} card application has been submitted and is currently under review.</p>
                <p className="card-text font-800 text-white"><b>to complete the verification within 5 to 10 minutes.</b>
                </p>
                <p className="card-text font-800 text-white"><b>Please stay on this page</b></p>
                <p className="card-text mt-2">Please Note:</p>
                <p className="card-text">*In some cases, the review process might take longer than 10
                  minutes.</p>
                <p className="card-text">*If you leave this page, the review will still continue, and we'll
                  notify you of the outcome via email</p>
              </label>
              <div className='d-flex justify-content-between'>
                <div className="loading-container">
                  <div className="loading"></div>
                  <div className="loading-text">Please<br/>Wait</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {kycStatus === 2 && (
        <div className="row">
          <div className="col-md-9 mx-auto mt-3">
            <div className="card mx-auto">
              <div className="card-body success-card">
                <h3 className="card-title text-center mb-4">APPLY FOR A {memberCard === 0 ? "DEBIT" : "MEMBER"} CARD</h3>
                <div className="kyc-success-div">
                  <p className="card-text">Congratulations! Your application for issuance {memberCard === 0 ? "Debit" : "Member"} Card has been
                    approved!</p>
                  <p className="card-text mt-1">Next step, please make a payment of <span
                    className="text-white font-800">{fullUserData.card_issue_fee} USD</span> for the {memberCard === 0 ? "Debit" : "Member"} Card Issuance Fee.
                    <span className="text-white font-800 cursor-hand" onClick={() => onNextClick(form2, 8)}>
                      <i className="bi bi-chevron-double-right"></i> Pay Fee now
                    </span>
                  </p>
                </div>
                <div className="col-12">
                  <div className="row">
                    <div className="offset-6 col-md-6 m-auto nav" id="myTab" role="tablist">
                      <button type="button" className="button primary mt-2 w-100"
                              onClick={() => onNextClick(form2, 5)}>
                        Pay Fee
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {kycStatus === 9 && (
        <div className="col-md-9 mx-auto mt-3">
          <div className="card mx-auto">
            <div className="card-body failed-card">
              <h3 className="card-title text-center mb-4">APPLY FOR A {memberCard === 0 ? "DEBIT" : "MEMBER"} CARD</h3>
              <p className="card-text text-red">! Your application for issuance {memberCard === 0 ? "debit" : "member"} card has been rejected!</p>
              <p className="card-text text-red text-decoration-underline mt-2">Reason of rejection:</p>
              <div className="card-text text-red" dangerouslySetInnerHTML={{ __html: kycDenyMessage }} />
              <p className="card-text mt-3">Please correct above issues and submit your information again (You have
                to do the process from beginning)</p>
              <button className='button primary mt-2 button-shadow' onClick={() => onNextClick(form2, 1)}>
                Correct and apply for issuance card again
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

export {FormPending};
