<?php
global $baseUrl;
include 'includes/header.php';

// Check currency parameter
if (isset($_GET['id']))
  $id = $_GET['id'];
else
  header('Location: '.$baseUrl);
?>
<!-- Necessary js start-->
<script src="<?php echo $baseUrl; ?>assets/js/auth.js"></script>
<!-- Necessary js end -->

<!-- Container start -->
<div class="main-content container d-flex justify-content-center">
  <div class="col-md-6 col-lg-6">
    <h3 class="text-center mt-4 mb-4">Deposit <?php echo $id; ?></h3>

    <!-- Start define parameters -->
    <input type="hidden" id="id" value="<?php echo $id; ?>"/>
    <!-- End define parameters -->

    <!-- Start deposit section -->
    <div class="card blue-boarder mt-4 mb-4">
      <div class="card-header bg-primary-opacity">
        <div class="panel-list">
          <div class="panel-list-left font-weight-bold fs-6">
            Deposit <?php echo ($id != 'BTC') ? 'Network /' : ''; ?> Address
          </div>
        </div>
      </div>
      <div class="card-body justify-content-center align-content-center">

        <!-- Start deposit network selection -->
        <?php if($id == 'USDT') :?>
          <div class="mb-4 text-dark-primary">
            <label for="network" class="form-label">Network</label>
            <select id="network" name="network" class="form-control" onchange="loadDepositAddress();">
              <option value>--Select Network--</option>
              <option value="Ethereum_ERC20">Ethereum (ERC20)</option>
              <option value="Tron_TRC20">Tron (TRC20)</option>
              <option value="BNB_SMART_CHAIN_BEP20">BNB Smart Chain (BEP20)</option>
            </select>
            <div class="invalid-feedback">
              Please select network!
            </div>
          </div>
        <?php endif ?>
        <!-- End deposit network selection -->

        <!-- Start deposit address body -->
        <div class="address-body">
          <p>Please deposit <?php echo $id; ?> to below address</p>
          <h6 class="font-weight-bold text-dark-primary">Important Notice</h6>
          <p>Sending any other coins and/or chain may result in permanent loss.</p>

          <!-- Start deposit address generation -->
          <div class="justify-content-center text-center">
            <div class="qr-code p-4" id="qrCodeContainer"></div>
            <div>
              <button id="btnNewGen" class="btn btn-primary p-3 pl-4 pr-4">
                <span class="spinner-anim spinner-border spinner-border-sm text-white" role="status" style="display: none"></span>
                <span class="spinner-text">Generate New Address</span>
              </button>
            </div>
            <div>
              <div class="form-group">
                <label for="address_txt"></label>
                <div class="input-group">
                  <div class="form-control" id="address_txt">Wallet Address...</div>
                  <div class="input-group-append">
                    <button class="btn btn-primary" type="button" id="btnAddressCopy">
                      <i class="fa fa-copy"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- End deposit address generation -->

        </div>
        <!-- End deposit address body -->
      </div>
    </div>
    <!-- End deposit section -->

    <!-- Start calculator section -->
    <?php if($id == 'BTC') : ?>
      <div class="card blue-boarder mt-4 mb-4">
      <div class="card-header bg-primary-opacity">
        <div class="panel-list">
          <div class="panel-list-left font-weight-bold fs-6">
            <i class="fa fa-calculator mt-1"></i>&nbspCalculator
          </div>
        </div>
      </div>
      <div class="card-body justify-content-center align-content-center">

        <!-- Start calculator body -->
        <div class="">
          <p class="text-secondary">How much BTC can I buy with USD?</p>

          <div class="justify-content-center">
            <div class="form-group">
              <label for="btc">USD</label>
              <div class="input-group">
                <input type="text" class="form-control" id="usd" name="usd" placeholder="Enter usd amount" oninput="calculateBtc(false);">
                <div class="input-group-append">
                  <button class="btn btn-primary" type="button" onclick="calculateBtc(usd);">
                    <i class="fa fa-calculator"></i>
                  </button>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="btc">BTC</label>
              <div class="input-group">
                <input type="text" class="form-control" id="btc" name="btc" placeholder="Enter btc amount" oninput="calculateBtc(true);">
                <div class="input-group-append">
                  <button class="btn btn-primary" type="button" onclick="calculateBtc(true);">
                    <i class="fa fa-calculator"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>

        </div>
        <!-- End calculator body -->
      </div>
    </div>
    <?php endif ?>
    <!-- End calculator section -->
  </div>
</div>
<!-- Container end -->

<script>
  let BTC_BUY_PRICE = 0;

  $(document).ready(function() {

    // Event handler for new address generation
    $('#btnNewGen').click(function () {
      loadDepositAddress(1);
    });

    // Event handler for new address generation
    $('#btnAddressCopy').click(function () {
      addressCopy();
    });

    // Load deposit address and qr-code
    loadDepositAddress();

    // Load prices
    if( $('#id').val() === 'BTC')
      cryptoPrice();
  });

  // Get wallet balance via API and update UIs
  function loadDepositAddress(reGeneration = 0) {

    // Check validation
    const invalidFeedbackObj = $('.invalid-feedback');
    const addressBodyObj = $('.address-body');
    const network = $('#network').val();
    const id = $('#id').val();
    if( id === 'USDT' && !network ){
      invalidFeedbackObj.show();
      addressBodyObj.hide();
      return;
    }

    // Getting or new generate address
    invalidFeedbackObj.hide();
    addressBodyObj.show();

    if( reGeneration === 0 )
      disableWithSpinner('btnNewGen', 'Getting address...');
    else
      disableWithSpinner('btnNewGen', 'Generating new address...');

    const jwt = localStorage.getItem('jwt');
    const auth_token = localStorage.getItem('auth_token');

    $.ajax({
      url: API_URL + 'ultimoApi.php',
      type: 'POST',
      data: JSON.stringify({
        action: 'deposit',
        currency: id,
        network: network,
        re_generation: reGeneration,
        jwt: jwt,
        auth_token: auth_token
      }),
      contentType: 'application/json',
      success: function(response) {
        if (response.result === 'success') {
          let depositAddress = response.depositResponse.address;
          if( depositAddress ){
            $('#address_txt').html( depositAddress );
            const qrCodeUrl = BASE_URL + 'extAPIs/qrCode.php?address=' + encodeURIComponent(depositAddress);
            $('#qrCodeContainer').html('<img src="' + qrCodeUrl + '" alt="QR Code">');
            enableWithSpinner('btnNewGen', 'Generate New Address');
          } else {
            enableWithSpinner('btnNewGen', 'Generate New Address');
            showToast('Please select a wallet address.');
            console.log('Please select a wallet address.');
          }
        } else {
          enableWithSpinner('btnNewGen', 'Generate New Address');
          showToast(response.error.errorMessage);
          console.log(response.error.errorMessage);
        }
      },
      error: function(error) {
        enableWithSpinner('btnNewGen', 'Generate New Address');
        console.log('An error occurred:', error);
      }
    });
  }

  // Copy address event handler
  function addressCopy() {
    const addressText = $('#address_txt').html();
    navigator.clipboard.writeText(addressText).then(function() {
      showToast("Address copied to clipboard!");
    }).catch(function(error) {
      console.error('Failed to copy text: ', error);
      showToast("Failed to copy address. Please try again.");
    });
  }

  // Get currency prices via API
  function cryptoPrice() {
    const jwt = localStorage.getItem('jwt');
    const auth_token = localStorage.getItem('auth_token');

    $.ajax({
      url: API_URL + 'ultimoApi.php',
      type: 'POST',
      data: JSON.stringify({
        action: 'cryptoPrice',
        jwt: jwt,
        auth_token: auth_token
      }),
      contentType: 'application/json',
      success: function(response) {
        if (response.result === 'success') {
          // Get the BTC price
          response.cryptocurrencies.forEach(price => {
            if( price.pair.slice(0, -3) === 'BTC' ){
              BTC_BUY_PRICE = removeCommaFromNumber(price.buy_price.toString()) * 1;
            }
          });
        } else {
          console.log(response.error.errorMessage);
        }
      },
      error: function(error) {
        console.log('An error occurred:', error);
      }
    });
  }

  // Do calculate
  function calculateBtc(btcToUsd){
    const btcAmount = removeCommaFromNumber($('#btc').val());
    const usdAmount = removeCommaFromNumber($('#usd').val());
    if( btcToUsd )
      $('#usd').val( formatNumberWithCommas((btcAmount * BTC_BUY_PRICE).toFixed(DECIMAL_POINTS['USD'])));
    else
      $('#btc').val( formatNumberWithCommas((usdAmount / BTC_BUY_PRICE).toFixed(DECIMAL_POINTS['BTC'])));
  }
</script>
<?php include 'includes/footer.php'; ?>
