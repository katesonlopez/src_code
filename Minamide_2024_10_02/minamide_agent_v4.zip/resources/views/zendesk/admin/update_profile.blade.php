@extends('layouts.app')

@section('content')
  <div class="container d-flex justify-content-center align-items-center flex-column" style="min-height: 50vh;">
    @if (session('success'))
      <div class="alert alert-success w-50">
        {{ session('success') }}
      </div>
    @endif
    @if (session('error'))
      <div class="alert alert-danger w-50">
        {{ session('error') }}
      </div>
    @endif
    <h1>Update Profile</h1>
    <form action="{{ route('zendesk.admin.update') }}" method="POST" class="w-50">
      @csrf
      <div class="mb-3">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" class="form-control form-control-sm rounded" placeholder="Email" required value="{{ old('email', $adminProfileData['email'] ?? '') }}">
        @error('email')
        <div class="text-danger">{{ $message }}</div>
        @enderror
      </div>
      <div class="mb-3">
        <label for="card_number">Card number:</label>
        <input type="text" id="card_number" name="card_number" class="form-control form-control-sm rounded" placeholder="Card Number" value="{{ old('card_number', $adminProfileData['card_number'] ?? '') }}">
      </div>
      <div class="mb-3">
        <label for="account_number">Account number:</label>
        <input type="text" id="account_number" name="account_number" class="form-control form-control-sm rounded" placeholder="Account Number" value="{{ old('account_number', $adminProfileData['account_number'] ?? '') }}">
      </div>
      <button type="submit" class="btn btn-primary btn-sm btn-block rounded-pill">Update Profile</button>
    </form>
  </div>
@endsection
