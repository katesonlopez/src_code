<?php
header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
  function getallheaders()
  {
    if (!is_array($_SERVER)) {
      return array();
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
      if (substr($name, 0, 5) == 'HTTP_') {
        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
      }
    }
    return $headers;
  }
}

function _log($email, $line) {
  // Determine the log file path based on the operating system
  if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    // Windows
    if ($email == "") {
      $logFilePath = 'C:' . DIRECTORY_SEPARATOR . '_deposit.log';
    } else {
      $logFilePath = 'C:' . DIRECTORY_SEPARATOR . $email . '_deposit.log';
    }
  } else {
    // Non-Windows (e.g., Unix/Linux)
    if ($email == "") {
      $logFilePath = '/var/www/api.ultimopay.io/v4/deposit/log/deposit.log';
    } else {
      $logFilePath = '/var/www/api.ultimopay.io/v4/deposit/log/' . $email . '.log';
    }
  }

  // Open the log file for appending (or create it if it doesn't exist)
  $fh2 = fopen($logFilePath, 'a');

  if ($fh2) {
    $fLine = date('[Ymd H:i:s] ') . $line . "\n";

    // Write the log line to the file
    fwrite($fh2, $fLine);

    // Close the log file
    fclose($fh2);
  }
}



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_once '../include/dbconfig.php';
  $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
  if (mysqli_connect_errno() != 0) {
    header('Content-Type: application/json');
    http_response_code(500);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
    echo json_encode($ret_rs);
    die();
  } else {
    _log("", "ket noi thanh cong");
    mysqli_query($dbhandle, "set names utf8;");
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
  $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
  $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
  $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
  $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret4 = 'climbpot api access key';
  $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
  $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
  $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
  $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
  $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
  $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
  //$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
  $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
  $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
  $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
  $apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
  $found = 0;
  $coin = 'USDT';
  $sandbox = 0;
  $partner = '';
  // update 20230424 busd,usdc k.o.
  $allowed_deposit_currency_arr = array('USDT', "BTC", "BUSD", "USDC");
  $allowed_deposit_usdt_network_arr = array('ETHEREUM_ERC20', 'TRON_TRC20', 'BNB_SMART_CHAIN_BEP20');
  $req_api_key = "";
  $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

  foreach (getallheaders() as $name => $value) {
    if ($name == 'Authorization') {
      $req_api_key = trim($value);
      $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
      $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
      if (mysqli_num_rows($partner_rs) > 0) {
        while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
          $cur_api_key = "Bearer " . $row_partner['api_key'];
          if ($req_api_key == $cur_api_key) {
            $req_partner['partner'] = trim($row_partner['partner']);
            $req_partner['api_key'] = trim($row_partner['api_key']);
            $req_partner['website'] = trim($row_partner['website']);
            $selected_api_key = $req_api_key;
            break;
          }
        }
      } else {
        _log("", "not found in db");
      }
    }
  }
  @mysqli_close($dbhandle);

  function isValidPassword($password) {
    if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
      return FALSE;
    return TRUE;
  }

  if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!($data)) {

      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          _log("", 'Reached the maximum stack depth');
          break;
        case JSON_ERROR_STATE_MISMATCH:
          _log("", 'Incorrect discharges or mismatch mode');
          break;
        case JSON_ERROR_CTRL_CHAR:
          _log("", 'Incorrect control character');
          break;
        case JSON_ERROR_SYNTAX:
          _log("", 'Syntax error or JSON invalid');
          break;
        case JSON_ERROR_UTF8:
          _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
          break;
        default:
          _log("", 'Unknown error');
          break;
      }

      _log("", 'A non-empty request body is required.');
      header('Content-Type: application/json');
      http_response_code(400);
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
      echo json_encode($ret_rs);
      die();
    } else {
      unset($errors);
      $errors = array();

      //email
      if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
        $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
        $errors[] = $error_obj;
      }

      //auth_token
      if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
        $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
        $errors[] = $error_obj;
      }

      //currency
      if ((!isset($data['currency'])) || (empty($data['currency']))) {
        $error_obj = array('errorCode' => 4, 'errorMessage' => 'currency parameter is required.');
        $errors[] = $error_obj;
      } else {
        if (!in_array(strtoupper($data['currency']), $allowed_deposit_currency_arr)) {
          $error_obj = array('errorCode' => 5, 'errorMessage' => 'unsupported currency');
          $errors[] = $error_obj;
        }
      }

      //network (only applied for USDT)
      if (strtoupper($data['currency']) == 'USDT') {
        if ((!isset($data['network'])) || (empty($data['network']))) {
          $error_obj = array('errorCode' => 6, 'errorMessage' => 'network parameter is required for USDT deposit.');
          $errors[] = $error_obj;
        } else {
          if (!in_array(strtoupper($data['network']), $allowed_deposit_usdt_network_arr)) {
            $error_obj = array('errorCode' => 7, 'errorMessage' => 'unsupported USDT blockchain network.');
            $errors[] = $error_obj;
          }
        }
      }

      if (count($errors) == 0) {

        //proceed to shift api
        require_once '../include/common.php';

        ////////////////////////////////////////////////////

        //receive POST params
        $reg_email_address = trim($data['email_address']);
        $private_key = trim($data['auth_token']);
        $currency = strtoupper(trim($data['currency']));
        $network = strtoupper(trim($data['network']));
        $re_generate = isset($data['re_generation']) && trim($data['re_generation']) !== '' ? trim($data['re_generation']) * 1 : 0;

        _log($reg_email_address, "get deposit wallet address started...");

        $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
        if (mysqli_connect_errno() == 0) {
          mysqli_query($dbhandle, "set names utf8;");
          $allow_access_api = 0;
          $merchant = '';
          $target_wallet_address = '';
          $cur_db_wallet_address = '';
          $cur_added_dt = '';
          $get_deposit_address_success = 0;
          $my_db_private_key = '';
          $my_db_auth_token = '';
          $my_db_wallet_auth_token = '';
          $my_db_sigin_dt = '';
          $my_db_token_refresh_dt = '';
          $my_db_shift_user_id = '';

          $sql_cnt = "SELECT * FROM cryptocash_shift_wallet WHERE shift_login_email = '$reg_email_address'";
          _log($reg_email_address, "sql_cnt: $sql_cnt");
          $rs_cnt = mysqli_query($dbhandle, $sql_cnt);
          $sql_check_signin = "select a.*, b.shift_account_currency, b.address, b.address_usdt_tron, b.address_usdt_binance, b.network, b.balance, b.added_dt, b.added_dt_tron, b.added_dt_binance from cryptocash_merchant_user_signin a, cryptocash_shift_wallet b where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_login_email";
          if (mysqli_num_rows($rs_cnt) > 6){
            $sql_check_signin = "select a.*, b.shift_account_currency, b.address, b.address_usdt_tron, b.address_usdt_binance, b.network, b.balance, b.added_dt, b.added_dt_tron, b.added_dt_binance from cryptocash_merchant_user_signin a, cryptocash_shift_wallet b where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_login_email AND (b.shift_user_id IS NULL OR TRIM(b.shift_user_id)='')";
          }
          _log($reg_email_address, "sql_check_signin: $sql_check_signin");
          $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
          if (mysqli_num_rows($rs_check_signin) >= 1) { //allow access API
            while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
              $my_db_auth_token = trim($row_signin['auth_token']);
              $my_db_sigin_dt = $row_signin['signin_dt'];
              $my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
              $my_db_private_key = trim($row_signin['private_key']);
              $cur_shift_currency = trim($row_signin['shift_account_currency']);
              $cur_private_key = trim($row_signin['private_key']);
              if ($cur_shift_currency == $currency) {
                $allow_access_api = 1;
                if ($cur_shift_currency == 'USDT') {
                  if ($network=='ETHEREUM_ERC20') {
                    $cur_db_wallet_address = trim($row_signin['address']);
                    $cur_added_dt = trim($row_signin['added_dt']);
                  } else if ($network=='TRON_TRC20') {
                    $cur_db_wallet_address = trim($row_signin['address_usdt_tron']);
                    $cur_added_dt = trim($row_signin['added_dt_tron']);
                  } else if ($network=='BNB_SMART_CHAIN_BEP20') {
                    $cur_db_wallet_address = trim($row_signin['address_usdt_binance']);
                    $cur_added_dt = trim($row_signin['added_dt_binance']);
                  }
                } else {
                  $cur_db_wallet_address = trim($row_signin['address']);
                  $cur_added_dt = trim($row_signin['added_dt']);
                }
              }
            }
          }

          if ($allow_access_api == 1) {
            if ($private_key != $cur_private_key) {
              @mysqli_close($dbhandle);
              header('Content-Type: application/json');
              http_response_code(500);
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 9, 'errorMessage' => 'Unauthorized.');
              echo json_encode($ret_rs);
              die();
            } else {
              ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
              _log($reg_email_address, "cur_db_wallet_address:, ". json_encode($cur_db_wallet_address));
              if ($cur_db_wallet_address == '' || $re_generate == 1 ) {
                _log($reg_email_address, "cur_db_wallet_address == '' is true");
                /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                //always try to get deposit wallet address by SHIFT API
                $deposit_status_call_retry_cnt = 0;
                $get_wallet_start_tm = time();
                $deposit_post_data = array();
                $deposit_post_data['product'] = $currency;
                /*if ($currency == 'USDT') {
                  if ($network=='ETHEREUM_ERC20') {
                    $deposit_post_data['network'] = "Ethereum";
                  } else if ($network=='TRON_TRC20') {
                    $deposit_post_data['network'] = "Tron";
                  } else if ($network=='BNB_SMART_CHAIN_BEP20') {
                    $deposit_post_data['network'] = "binance";
                  }
                } else if($currency == 'USDC'){
                  if ($network=='ETHEREUM_ERC20') {
                    $deposit_post_data['network'] = "Ethereum";
                  } else if ($network=='POLYGON_MATIC') {
                    $deposit_post_data['network'] = "Polygon";
                  }
                } else if ($currency == 'BTC') {
                  $deposit_post_data['network'] = "Bitcoin";
                } else if ($currency == 'BUSD') {
                  $deposit_post_data['network'] = "Bitcoin";
                }*/
				$payment_route_id = 'default';
				if ($currency == 'USDT') {
					if ($network=='ETHEREUM_ERC20') {
						$deposit_post_data['network'] = "Ethereum";
						$payment_route_id = 'ce872a17-9e52-4c7a-93e9-e7472954f175';
					} else if ($network=='TRON_TRC20') {
						$deposit_post_data['network'] = "Tron";
						$payment_route_id = '03b14832-5fa6-4a30-8382-2f8dcf9400cd';
					} else if ($network=='BNB_SMART_CHAIN_BEP20') {
						$deposit_post_data['network'] = "binance";
						$payment_route_id = '1f39fbf5-af8f-48ec-aa5d-787ebdf9420b';
					}
				} else if($currency == 'USDC'){
					if ($network=='ETHEREUM_ERC20') {
						$deposit_post_data['network'] = "Ethereum";
						$payment_route_id = 'a5e8a7f9-efbb-46ad-9714-e90b26c2c847';
					} else if ($network=='POLYGON_MATIC') {
						$deposit_post_data['network'] = "Polygon";
						$payment_route_id = 'e6e8d8c0-0e82-4f7e-9e16-2a059dda4287';
					} else {
						$payment_route_id = 'a5e8a7f9-efbb-46ad-9714-e90b26c2c847';	
					}
				} else if ($currency == 'BTC') {
					$deposit_post_data['network'] = "Bitcoin";
					$payment_route_id = '2244cf78-10a1-450b-bba4-6a509a2e4037';
				} else if ($currency == 'BUSD') {
					$deposit_post_data['network'] = "Bitcoin";
				} else if ($currency == 'SOL'){
					$deposit_post_data['network'] = "Solana";
					$payment_route_id = '6bb5d634-93e8-4644-9147-56890f6f0f6e';	
					
				}

                $refno = common_uuid();
                //$generate_wallet_address_query = sprintf('{"query":"query ($network: String, $currency_id: String!, $reference: String) {\\n  deposit_address_crypto(network: $network, currency_id: $currency_id, reference: $reference) {\\n    deposit_address_crypto_id\\n    currency_id\\n    address\\n    address_tag_type\\n    address_tag_value\\n    network\\n    created_at\\n    updated_at\\n  }\\n}","variables":{"network":"%s","currency_id":"%s","reference":"%s"}}', $deposit_post_data['network'], $currency, $refno);
				$generate_wallet_address_query = sprintf('{"query":"query ($currency_id: String!, $reference: String, $payment_route_id: String!) { deposit_address_crypto (currency_id: $currency_id, reference: $reference, payment_route_id: $payment_route_id) { deposit_address_crypto_id, currency_id, address, address_tag_type, address_tag_value, network, created_at, updated_at } }","variables":{"currency_id":"%s","payment_route_id":"%s","reference":"%s"}}', $currency, $payment_route_id, $refno);
				_log($reg_email_address, "deposit_post_data[network] = " . $deposit_post_data['network'] . ", payment_route_id = " . $payment_route_id);
                $authorization_client_value = "Bearer " . $my_db_auth_token;
                /////////////////////////////////////////////////////////////
                $deposit_post_data['exchange'] = "PLUSQO";
                $deposit_res = api_call('/wallet/deposit/create', 0, $generate_wallet_address_query, $deposit_post_data, $authorization_client_value);
                _log($reg_email_address, "/wallet/deposit/create generate_wallet_address_query: ".json_encode($generate_wallet_address_query));
                _log($reg_email_address, "/wallet/deposit/create deposit_post_data: ".json_encode($deposit_post_data));
                _log($reg_email_address, "/wallet/deposit/create authorization_client_value: ".json_encode($authorization_client_value));
                _log($reg_email_address, "/wallet/deposit/create" . json_encode($deposit_res));

                if (($deposit_res['http_code'] == "200") || ($deposit_res['http_code'] == "200 OK")) {
                  _log($reg_email_address, "du ma vao day");
                  $doituongloi = json_encode($deposit_res);
                  _log($reg_email_address, $doituongloi);

                  if (!empty($deposit_res['result']['errors'])) {
                    _log($reg_email_address, "con cac gi vay ??!");
                    if (!empty($deposit_res['result']['errors'][0]['message'])) {
                      _log($reg_email_address, $deposit_res['result']['errors'][0]['message']);
                    }
                    @mysqli_close($dbhandle);
                    header('Content-Type: application/json');
                    http_response_code(500);
                    $ret_rs['result'] = 'failed';
                    $ret_rs['error'] = array('errorCode' => 10, 'errorMessage' => 'unknown error occured. contact administrator for help 1.');
                    echo json_encode($ret_rs);
                    die();
                  } else {
                    _log($reg_email_address, "du ma vao tiep ne !");
                    if (!empty($deposit_res['result']['data']['deposit_address_crypto'])) {
                      if(isset($deposit_res['result']['data']['deposit_address_crypto']['address']) && !empty($deposit_res['result']['data']['deposit_address_crypto']['address'])) {
                        $target_wallet_address = $deposit_res['result']['data']['deposit_address_crypto']['address'];
                        $target_wallet_network = $deposit_res['result']['data']['deposit_address_crypto']['network'];
						///////////////////////////////////////
						/*if ($deposit_post_data['product'] == 'BTC') {
                            _log($reg_email_address, "BTC address " . $target_wallet_address);
                            $shift_wallet_added_dt = date('Y-m-d H:i:s');
                            $sql_update_shift_wallet = "update cryptocash_shift_wallet set address='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='BTC' LIMIT 1";
                          } else if ($deposit_post_data['product'] == 'USDT') {
                            _log($reg_email_address, "USDT address (" . $deposit_post_data['network'] . "): " . $target_wallet_address);
                            $shift_wallet_added_dt = date('Y-m-d H:i:s');
                            if ($deposit_post_data['network'] == "Ethereum") {
                              $sql_update_shift_wallet = "update cryptocash_shift_wallet set address='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDT' LIMIT 1";
                            } else if ($deposit_post_data['network'] == "Tron") {
                              $sql_update_shift_wallet = "update cryptocash_shift_wallet set address_usdt_tron='$target_wallet_address', added_dt_tron='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDT' LIMIT 1";
                            } else if ($deposit_post_data['network'] == "binance") {
                              $sql_update_shift_wallet = "update cryptocash_shift_wallet set address_usdt_binance='$target_wallet_address', added_dt_binance='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDT' LIMIT 1";
                            }
                            // begin add 20230326 busd,usdc k.o.
                          } else if ($deposit_post_data['product'] == 'BUSD') {
                            _log($reg_email_address, "BUSD address: " . $target_wallet_address);
                            $shift_wallet_added_dt = date('Y-m-d H:i:s');
                            $sql_update_shift_wallet = "update cryptocash_shift_wallet set address='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='BUSD' LIMIT 1";
                          } else if ($deposit_post_data['product'] == 'USDC') {
                            _log($reg_email_address, "USDC address: " . $target_wallet_address);
                            $shift_wallet_added_dt = date('Y-m-d H:i:s');
                            if ($deposit_post_data['network'] == "Ethereum") {
                              $sql_update_shift_wallet = "update cryptocash_shift_wallet set address='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDC' LIMIT 1";
                            } else if ($deposit_post_data['network'] == "Polygon") {
                              $sql_update_shift_wallet = "update cryptocash_shift_wallet set address_usdc_polygon='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDC' LIMIT 1";
                            }
                            _log($reg_email_address,__LINE__." ".$sql_update_shift_wallet);
                            // end add 20230326 busd,usdc k.o.
                          }
                          if (trim($target_wallet_address) != '') {
                            if (mysqli_query($dbhandle, $sql_update_shift_wallet)) {
                              _log($reg_email_address, "update address to wallet table successful");
                            } else {
                              _log($reg_email_address, "update address to wallet table FAILED");
                              _log($reg_email_address, $sql_update_shift_wallet);
                            }
                          }
                          $get_deposit_address_success = 1;
						*/
						//////////////////////////////////////////////
						
						
                        // Check double address, if new address exist for other user on database, or not
                        $addressQuery = "SELECT
                                                                  *
                                                                FROM
                                                                  `cryptocash_shift_wallet`
                                                                WHERE TRIM(`address`) = TRIM('$target_wallet_address')
                                                                  OR TRIM(`address_usdt_tron`) = TRIM('$target_wallet_address')
                                                                  OR TRIM(`address_usdt_binance`) = TRIM('$target_wallet_address')
                                                                  OR TRIM(`address_usdc_polygon`) = TRIM('$target_wallet_address')";
                        $rs_check_address = mysqli_query($dbhandle, $addressQuery);
                        if (mysqli_num_rows($rs_check_address) > 0) {
                          $row_address = mysqli_fetch_array($rs_check_address, MYSQLI_ASSOC);
                          $other_username = trim($row_address['shift_login_email']);
                          $same_address_field = '';
                          $same_address = '';
                          if( $target_wallet_address == trim($row_address['address'])) {
                            $same_address_field = 'address';
                            $same_address =  trim($row_address['address']);
                          }
                          else if( $target_wallet_address == trim($row_address['address_usdt_tron'])) {
                            $same_address_field = 'address_usdt_tron';
                            $same_address = trim($row_address['address_usdt_tron']);
                          }
                          else if( $target_wallet_address == trim($row_address['address_usdt_binance'])) {
                            $same_address_field = 'address_usdt_binance';
                            $same_address = trim($row_address['address_usdt_binance']);
                          }
                          else if( $target_wallet_address == trim($row_address['address_usdc_polygon'])) {
                            $same_address_field = 'address_usdc_polygon';
                            $same_address = trim($row_address['address_usdc_polygon']);
                          }
                          _log($reg_email_address, "the same $network address: $same_address is exist already for user: $other_username for field: $same_address_field.");
                          @mysqli_close($dbhandle);
                          header('Content-Type: application/json');
                          http_response_code(500);
                          $ret_rs['result'] = 'failed';
                          $ret_rs['error'] = array('errorCode' => 11, 'errorMessage' => "the same $network address: $same_address is exist already for user: $other_username for field: $same_address_field.");
                          echo json_encode($ret_rs);
                          die();
                        }
                        else{
                          if ($deposit_post_data['product'] == 'BTC') {
                            _log($reg_email_address, "BTC address " . $target_wallet_address);
                            $shift_wallet_added_dt = date('Y-m-d H:i:s');
                            $sql_update_shift_wallet = "update cryptocash_shift_wallet set address='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='BTC' LIMIT 1";
                          } else if ($deposit_post_data['product'] == 'USDT') {
                            _log($reg_email_address, "USDT address (" . $deposit_post_data['network'] . "): " . $target_wallet_address);
                            $shift_wallet_added_dt = date('Y-m-d H:i:s');
                            if ($deposit_post_data['network'] == "Ethereum") {
                              $sql_update_shift_wallet = "update cryptocash_shift_wallet set address='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDT' LIMIT 1";
                            } else if ($deposit_post_data['network'] == "Tron") {
                              $sql_update_shift_wallet = "update cryptocash_shift_wallet set address_usdt_tron='$target_wallet_address', added_dt_tron='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDT' LIMIT 1";
                            } else if ($deposit_post_data['network'] == "binance") {
                              $sql_update_shift_wallet = "update cryptocash_shift_wallet set address_usdt_binance='$target_wallet_address', added_dt_binance='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDT' LIMIT 1";
                            }
                            // begin add 20230326 busd,usdc k.o.
                          } else if ($deposit_post_data['product'] == 'BUSD') {
                            _log($reg_email_address, "BUSD address: " . $target_wallet_address);
                            $shift_wallet_added_dt = date('Y-m-d H:i:s');
                            $sql_update_shift_wallet = "update cryptocash_shift_wallet set address='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='BUSD' LIMIT 1";
                          } else if ($deposit_post_data['product'] == 'USDC') {
                            _log($reg_email_address, "USDC address: " . $target_wallet_address);
                            $shift_wallet_added_dt = date('Y-m-d H:i:s');
                            if ($deposit_post_data['network'] == "Ethereum") {
                              $sql_update_shift_wallet = "update cryptocash_shift_wallet set address='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDC' LIMIT 1";
                            } else if ($deposit_post_data['network'] == "Polygon") {
                              $sql_update_shift_wallet = "update cryptocash_shift_wallet set address_usdc_polygon='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDC' LIMIT 1";
                            }
                            _log($reg_email_address,__LINE__." ".$sql_update_shift_wallet);
                            // end add 20230326 busd,usdc k.o.
                          }
                          if (trim($target_wallet_address) != '') {
                            if (mysqli_query($dbhandle, $sql_update_shift_wallet)) {
                              _log($reg_email_address, "update address to wallet table successful");
                            } else {
                              _log($reg_email_address, "update address to wallet table FAILED");
                              _log($reg_email_address, $sql_update_shift_wallet);
                            }
                          }
                          $get_deposit_address_success = 1;
                        }
                      } else {
                        _log($reg_email_address, 'unknown error occured. contact administrator for help 2.');
                        @mysqli_close($dbhandle);
                        header('Content-Type: application/json');
                        http_response_code(500);
                        $ret_rs['result'] = 'failed';
                        $ret_rs['error'] = array('errorCode' => 10, 'errorMessage' => 'unknown error occured. contact administrator for help 3.');
                        echo json_encode($ret_rs);
                        die();
                      }
                    } else {
                      _log($reg_email_address, 'unknown error occured. contact administrator for help 4.');
                      @mysqli_close($dbhandle);
                      header('Content-Type: application/json');
                      http_response_code(500);
                      $ret_rs['result'] = 'failed';
                      $ret_rs['error'] = array('errorCode' => 10, 'errorMessage' => 'unknown error occured. contact administrator for help 5.');
                      echo json_encode($ret_rs);
                      die();
                    }
                  }
                } else {
                  $error_message = 'Unauthorized';
                  $res_code = 200;
                  $error_code = 9;
                  if (($deposit_res['http_code'] == "401") || ($deposit_res['http_code'] == "401 Unauthorized")) {
                    _log($reg_email_address, "/wallet/deposit/create error " . $deposit_res['http_code']);
                    $res_code = 401;
                  } else {
                    if (($deposit_res['http_code'] == "500") || ($deposit_res['http_code'] == "500 Internal Server Error") || ($deposit_res['http_code'] == "503 Service Unavailable")) {
                      if ($deposit_res['http_code'] == "503 Service Unavailable") {
                        $error_code = 10;
                        $error_message = 'system is under maintenance.';
                        $res_code = 503;
                      }
                      if (($deposit_res['http_code'] == "500") || ($deposit_res['http_code'] == "500 Internal Server Error")) {
                        $res_code = 401;
                      }
                      _log($reg_email_address, "/wallet/deposit/create error " . $deposit_res['http_code']);
                    } else {
                      _log($reg_email_address, "/wallet/deposit/create error unknown error code");
                      $error_code = 10;
                      $error_message = 'system is under maintenance.';
                      $res_code = 500;
                    }
                  }
                  @mysqli_close($dbhandle);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
                  header('Content-Type: application/json');
                  if ($res_code != 200) {
                    http_response_code($res_code);
                  }
                  echo json_encode($ret_rs);
                  die();
                }
              } else {
                _log($reg_email_address, "cur_db_wallet_address == '' is false");
                $target_wallet_address = $cur_db_wallet_address;
                $get_deposit_address_success = 1;
              }
            }
          } else {
            @mysqli_close($dbhandle);
            header('Content-Type: application/json');
            http_response_code(500);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 8, 'errorMessage' => 'you must sign in to use this API.');
            echo json_encode($ret_rs);
            die();
          }
        } else {
          _log($reg_email_address, "could not connect db !");
          //@mysqli_close($dbhandle);
          $ret_rs['result'] = 'failed';
          $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'error occurred. please contact administrator for help.');
          header('Content-Type: application/json');
          echo json_encode($ret_rs);
          die();
        }

        if ($get_deposit_address_success == 1) {
          @mysqli_close($dbhandle);
          $ret_rs['result'] = 'success';
          $ret_rs['email_address'] = $reg_email_address;
          if ($currency == 'USDT' || $currency == 'USDC') {
            $ret_rs['depositResponse'] = array('currency' => $currency, 'network' => $network, 'address' => $target_wallet_address);
          } else {
            $ret_rs['depositResponse'] = array('currency' => $currency, 'network' => '', 'address' => $target_wallet_address);
          }

          header('Content-Type: application/json');
          echo json_encode($ret_rs);
          die();
        }
      } else {
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = $errors[0];
        _log("", $ret_rs['error']['errorMessage']);
        header('Content-Type: application/json');
        echo json_encode($ret_rs);
        die();
      }
    }
  } else {
    header('HTTP/1.0 403 Forbidden');
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
  http_response_code(405);
  die();
}
