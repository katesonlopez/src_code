# api.kaiserpayment.com

JDB payment gateway integration like as Payment.Ultimopay.Io

```yaml
node.js: 16.17.1

php: 7.2.34
composer: 2.7.9
```

```bash
$ npm install

$ composer install --ignore-platform-req=ext-http

$ php artisan serve
```

After update API Key, use artisan command as follows:

### php artisan config:cache

### php artisan tail
