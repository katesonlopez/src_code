<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;

class XApiServer_V4 extends Model
{
  /**
   * @var string
   */
  public function __construct()
  {
    // Call the parent constructor
    parent::__construct();
  }

  /**=============      base api       ===============================================**/
  public static function baseApiCall($uri, $emailAddress, $authToken, $params = null): array
  {
    try{

      // request data that is going to be sent as POST to API
      $data = array(
        'email_address' => trim($emailAddress),
        'auth_token' => trim($authToken)
      );
      if( $params != null ){
        foreach ($params as $key => $value) {
          $data[$key] = $value;
        }
      }

      // encoding the request data as JSON which will be sent in POST
      $encodedData = json_encode($data);

      // initiate curl with the url to send request
      $curl = curl_init(config('purchaseCheckToolSetting.serverUrl').$uri);

      // return CURL response
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

      // Send request data using POST method
      curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

      // Data content-type is sent as JSON
      curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Content-Type:application/json',
        'Authorization:Bearer '.config('purchaseCheckToolSetting.apiKey')
      ));

      curl_setopt($curl, CURLOPT_POST, true);

      // Curl POST the JSON data to send the request
      curl_setopt($curl, CURLOPT_POSTFIELDS, $encodedData);

      // execute the curl POST request and send data
      $response = curl_exec($curl);
      curl_close($curl);

      Log::info($response);

      $response = (array)json_decode($response);
    }
    catch(\Throwable $th){
      $response = array('result'=>'failed');
    }
    return $response;
  }
}
