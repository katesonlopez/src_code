<?php
header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
	//global $fh;
	if ($email == "") {
		$fh2 = fopen(dirname(__FILE__) . "/log/check_2fa_code.log" , 'a');
	} else {
		$fh2 = fopen(dirname(__FILE__) . "/log/" . $email . ".log" , 'a');
	}		
	$fline = date('[Ymd H:i:s] ') . $line."\n";
	fwrite($fh2, $fline);
	fclose($fh2);
	//echo date('[Ymd H:i:s] ').$line."\n";
	//@ob_flush(); 
	//flush();
}
	
	
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		_log("", "ket noi thanh cong");
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$partner = "";
	$allowed_deposit_currency_arr = array('USDT');
	$allowed_deposit_usdt_network_arr = array('ETHEREUM_ERC20', 'TRON_TRC20', 'BNB_SMART_CHAIN_BEP20');
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			/*
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_freelancer) {
				$found = 7;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_bos) {
				$found = 8;
				$coin = 'USDT';
				$partner = "BOS";
				break;
			}
			*/
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						break;
					}
					
				}
			} else {
				_log("", "not found in db");
			}
		}
	}
	@mysqli_close($dbhandle);
	

	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}


	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	//_log("bat dau xu ly...");
	//if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==7)) {
	//if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6) || ($found==7) || ($found==8)) {
	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {


		
		
		//$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);
		
		//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
		//echo "payment_id: " . $payment_id . "<br/>";
		$json = file_get_contents('php://input');
		$data = json_decode($json, true);
		
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					//$failed_rs['error'] = 'Reached the maximum stack depth';
					_log("", 'Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					_log("", 'Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					//$failed_rs['error'] = 'Incorrect control character';
					_log("", 'Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					//$failed_rs['error'] = 'Syntax error or JSON invalid';
					_log("", 'Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					//$failed_rs['error'] = 'Unknown error';
					_log("", 'Unknown error');
					break;
			}
			
			//throw new Exception($error);
			//_log($failed_rs['error']);
			_log("", 'A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			}
			
			//auth_token
			if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
				$error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
				$errors[] = $error_obj;
			}
			
			//2FA code
			if ((!isset($data['two_fa_code'])) || (empty($data['two_fa_code']))) {
				$error_obj = array('errorCode' => 4, 'errorMessage' => 'two_fa_code parameter is required.');
				$errors[] = $error_obj;
			}

			
			if (count($errors) == 0) {
				
				//$errors_sub = array();
				
				
				//proceed to shift api
				require_once '../include/common.php';
				require_once '../classes/PHPGangsta/GoogleAuthenticator.php';
				
				////////////////////////////////////////////////////
				
				//$allowed_currency_arr = array('USDT');
				
				//receive POST params
				$reg_email_address = trim($data['email_address']);
				$private_key = trim($data['auth_token']);				
				$two_fa_code = trim($data['two_fa_code']);
				$password = trim($data['password']);
				$type = intval($data['type']);
				_log($reg_email_address, "set 2fa started..., $reg_email_address, $private_key, $two_fa_code, $password, $type");
				
				
				$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
				if (mysqli_connect_errno() == 0) {
					
					mysqli_query($dbhandle, "set names utf8;");
					$allow_access_api = 0;
					$merchant = '';
					////$merchant = ($found==6)?'LUCKY8':'';
					//if ($found == 7) { //only allow access to this API from freelancer
					//	$merchant = 'UltimoCasino';
					//}
					
					$cur_private_key = '';
					$cur_wallet_auth_token = '';
					$authorization_client_value = '';
					$cur_deposit_wallet_address = '';
					$cur_added_dt = '';
					$exec_withdraw_success = 0;
					$final_withdraw_txid = '';
					
					$two_fa_email = null;
					$two_fa_secret_key = null;
					$two_fa_status = null;
					$two_fa_update_dt = null;					
					
					$sql_check_signin = "select a.*, b.shift_account_currency, b.address, b.address_usdt_tron, b.address_usdt_binance, b.network, b.balance, b.added_dt, b.added_dt_tron, b.added_dt_binance from cryptocash_merchant_user_signin a, cryptocash_shift_wallet b where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_login_email";
					$rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
					if (mysqli_num_rows($rs_check_signin) >= 1) { //allow access API
						
						while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
							$cur_shift_currency = trim($row_signin['shift_account_currency']);
							$cur_wallet_auth_token = trim($row_signin['wallet_auth_token']);
							$authorization_client_value = 'Bearer ' . $cur_wallet_auth_token;
							$cur_private_key = trim($row_signin['private_key']);
							$allow_access_api = 1;
							
						}
					}
					
					if ($allow_access_api == 1) {
						if ($private_key != $cur_private_key) {
							@mysqli_close($dbhandle);
							header('Content-Type: application/json');
							http_response_code(500);
							$ret_rs['result'] = 'failed';
							$ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'Unauthorized.');
							echo json_encode($ret_rs);
							die();
						} else {
							
							//check 2FA
              $partnerName = $req_partner['partner'];
							$sql_check_twofa = "SELECT * FROM cryptocash_users_2fa WHERE created_from='$partnerName' and email = '$reg_email_address' LIMIT 1";
              _log($reg_email_address, $sql_check_twofa);
							$rs_check_twofa = mysqli_query($dbhandle, $sql_check_twofa);
							if (mysqli_num_rows($rs_check_twofa) <= 0) {
								
								
								@mysqli_close($dbhandle);
								header('Content-Type: application/json');
								http_response_code(500);
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => '2FA secret key not found for this account.'.$partnerName);
								echo json_encode($ret_rs);
								die();
								
							} else {
								while ($row_check_twofa = mysqli_fetch_array($rs_check_twofa, MYSQLI_ASSOC)) {
									$two_fa_email = trim($row_check_twofa['email']);
									$two_fa_secret_key = trim($row_check_twofa['secret_key']);
                  _log($reg_email_address, '$two_fa_secret_key: '.$two_fa_secret_key);
									$two_fa_status = intval($row_check_twofa['status']);
									$two_fa_update_dt = intval($row_check_twofa['update_dt']);
									_log($two_fa_email, $two_fa_email . " / " . $two_fa_secret_key . " / " . $two_fa_status . " / " . $two_fa_update_dt);
								}
								
								$ga = new PHPGangsta_GoogleAuthenticator();
								$twofa_passed = $ga->verifyCode($two_fa_secret_key, trim($two_fa_code), 1);    // 2 = 2*30sec clock tolerance
								if ($twofa_passed) {
									@mysqli_close($dbhandle);
									header('Content-Type: application/json');												
									$ret_rs['result'] = 'success';
									$ret_rs['email_address'] = $reg_email_address;
									$ret_rs['2FA_code_is_valid'] = true;
									echo json_encode($ret_rs);
									die();
									
								} else {
									@mysqli_close($dbhandle);
									header('Content-Type: application/json');												
									$ret_rs['result'] = 'success';
									$ret_rs['email_address'] = $reg_email_address;
									$ret_rs['2FA_code_is_valid'] = false;
									echo json_encode($ret_rs);
									die();
								}
								
								
							}
							
						}
					} else {
						@mysqli_close($dbhandle);
						header('Content-Type: application/json');
						http_response_code(500);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'you must sign in to use this API.');
						echo json_encode($ret_rs);
						die();
					}
					
					
					
					
					
				} else {
					_log($reg_email_address, "could not connect db !");
					//@mysqli_close($dbhandle);
					$ret_rs['result'] = 'failed';
					$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'system is under maintenance.');
					header('Content-Type: application/json');
					echo json_encode($ret_rs);
					die();
				}
				
				
				/*
				if ($exec_withdraw_success == 1) {
					@mysqli_close($dbhandle);				
					$ret_rs['result'] = 'success';
					$ret_rs['email_address'] = $reg_email_address;
					if ($currency == 'USDT') {
						$ret_rs['withdrawResponse'] = array('currency' => $currency, 'network' => $network, 'address' => $withdraw_wallet_address, 'txid' => $final_withdraw_txid );
					} else {
						$ret_rs['withdrawResponse'] = array('currency' => $currency, 'address' => $withdraw_wallet_address, 'txid' => $final_withdraw_txid);
					}
										
					header('Content-Type: application/json');
					echo json_encode($ret_rs);
					die();
				}
				*/
				
				
			} else {
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors[0];
				_log("", $ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
				
			
		}

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>