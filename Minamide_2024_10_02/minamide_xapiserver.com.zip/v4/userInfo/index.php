<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line)
{
    // Determine the log file path based on the operating system
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // Windows
        if ($email == "") {
            $logFilePath = 'C:' . DIRECTORY_SEPARATOR . '_userInfo.log';
        } else {
            $logFilePath = 'C:' . DIRECTORY_SEPARATOR . $email . '_userInfo.log';
        }
    } else {
        // Non-Windows (e.g., Unix/Linux)
        if ($email == "") {
            $logFilePath = dirname(__FILE__) . '/log/userInfo.log';
        } else {
            $logFilePath = dirname(__FILE__) . '/log/' . $email . '.log';
        }
    }

    // Create the directory if it doesn't exist
    $logDirectory = dirname($logFilePath);
    if (!is_dir($logDirectory)) {
        mkdir($logDirectory, 0755, true);
    }

    // Create the log file if it doesn't exist
    if (!file_exists($logFilePath)) {
        touch($logFilePath);
    }

    // Open the log file for appending
    $fh2 = fopen($logFilePath, 'a');

    if ($fh2) {
        $fLine = date('[Ymd H:i:s] ') . $line . "\n";

        // Write the log line to the file
        fwrite($fh2, $fLine);

        // Close the log file
        fclose($fh2);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	_log("", "bat dau xu ly...");
	require_once '../include/paths.php';
    require_once '../include/dbconfig.php';
    $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (mysqli_connect_errno() != 0) {
        header('Content-Type: application/json');
        http_response_code(500);
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
        echo json_encode($ret_rs);
        die();
    } else {
		_log("", "ket noi db thanh cong");
        mysqli_query($dbhandle, "set names utf8;");
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
    $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
    $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
    $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
    $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
    $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
    $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
    $clientSecret4 = 'climbpot api access key';
    $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
    $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
    $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
    $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
    $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
    $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
    $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
    $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
    $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
    $apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
    $found = 0;
    $coin = 'USDT';
    $sandbox = 0;
    $partner = "";
    $allowed_deposit_currency_arr = array('USDT');
    $req_api_key = "";
    $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

    foreach (getallheaders() as $name => $value) {
        if ($name == 'Authorization') {
            $req_api_key = trim($value);
			_log("", "req_api_key = " . $req_api_key);
            $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
            $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
            if (mysqli_num_rows($partner_rs) > 0) {
                while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
                    $cur_api_key = "Bearer " . $row_partner['api_key'];
                    if ($req_api_key == $cur_api_key) {
                        $req_partner['partner'] = trim($row_partner['partner']);
                        $req_partner['api_key'] = trim($row_partner['api_key']);
                        $req_partner['website'] = trim($row_partner['website']);
                        $selected_api_key = $req_api_key;
						_log("", $req_partner['partner'] . " / " . $req_partner['api_key'] . " / " . $req_partner['website']);
                        break;
                    }
                }
            } else {
                _log("", "not found in db");
            }
        }
    }
    @mysqli_close($dbhandle);


    function isValidPassword($password) {
        if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
            return FALSE;
        return TRUE;
    }

    if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);

        if (!($data)) {
            switch (json_last_error()) {
                case JSON_ERROR_DEPTH:
                    _log("", 'Reached the maximum stack depth');
                    break;
                case JSON_ERROR_STATE_MISMATCH:
                    _log("", 'Incorrect discharges or mismatch mode');
                    break;
                case JSON_ERROR_CTRL_CHAR:
                    _log("", 'Incorrect control character');
                    break;
                case JSON_ERROR_SYNTAX:
                    _log("", 'Syntax error or JSON invalid');
                    break;
                case JSON_ERROR_UTF8:
                    _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
                    break;
                default:
                    _log("", 'Unknown error');
                    break;
            }

            _log("", 'A non-empty request body is required.');
            header('Content-Type: application/json');
            http_response_code(400);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
            echo json_encode($ret_rs);
            die();
        } else {
            unset($errors);
            $errors = array();

            //email
            if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
                $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
                $errors[] = $error_obj;
            }

            //auth_token
            if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
                $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
                $errors[] = $error_obj;
            }

            if (count($errors) == 0) {
                $errors_sub = array();

                //proceed to shift api
                require_once '../include/common.php';
                require_once('../classes/PostAffiliatePro/PapApi.class.php');

                ////////////////////////////////////////////////////

                $allowed_shift_currency_arr = array('USDT', 'BTC', 'USD');
                //receive POST params
                $reg_email_address = trim($data['email_address']);
                $private_key = trim($data['auth_token']);
                $user_wallet_arr = array();

                _log($reg_email_address, "get user info started...");

                $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
                if (mysqli_connect_errno() == 0) {
                    mysqli_query($dbhandle, "set names utf8;");
                    $allow_access_api = 0;
                    $merchant = '';
                    $my_db_private_key = '';
                    $my_db_auth_token = '';
                    $my_db_sigin_dt = '';
                    $my_db_token_refresh_dt = '';
                    $my_db_shift_user_sub_id = '';
                    $sql_check_signin = "select a.*, b.shift_user_sub_id from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_email_address";
                    $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
                    if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
                        $allow_access_api = 1;
                        while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
                            $my_db_auth_token = trim($row_signin['auth_token']);
                            $my_db_sigin_dt = $row_signin['signin_dt'];
                            $my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
                            $my_db_private_key = trim($row_signin['private_key']);
                            $my_db_shift_user_sub_id = $row_signin['shift_user_sub_id'];
                        }
                    }

                    if ($allow_access_api == 1) {
                        if ($private_key != $my_db_private_key) {
                            @mysqli_close($dbhandle);
                            header('Content-Type: application/json');
                            http_response_code(500);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'Unauthorized.');
                            echo json_encode($ret_rs);
                            die();
                        } else {
                            _log($reg_email_address, "vao toi day rui");
                            //////////////////////////////////////////////////////////////////////////////////////////
                            $sql_user_info = "SELECT * from (SELECT a.email as shift_email, a.given_name, a.sur_name, a.middle_name, a.country as shift_country, a.add_dt as shift_add_dt, a.shift_update_dt, a.admin_update_dt, a.kyc_upload_dt, a.admin_action, a.admin_process_kyc_dt, a.admin_process_card_activate_dt, a.admin_process_card_load_dt, a.affiliation, a.created_from as created_from_one, b.*, c.debit_card_id, c.acc_no, c.debit_card_num, c.debit_card_name, c.status as card_status, c.has_paid_fee, c.payment_method, c.amount_fee_fiat, c.amount_fee_crypto, c.has_sent_document_postal, c.activation_deny_message, c.card_issuance_deny_message, c.secondary_address, c.secondary_country, c.secondary_district, c.secondary_province, c.secondary_postal_code, c.card_provider, c.selfie_with_card_file, c.send_data_step_one, c.send_data_step_two, c.card_active_local_approved, c.card_selfie_uploaded, d.kyc_status, d.card_activation_status, d.payment_status, d.kyc_file_url, d.card_activation_file_url, d.payment_dt FROM cryptocash_users_profile a LEFT JOIN cryptocash_jdb_profile b ON ((a.email = b.email_address) AND (a.created_from = b.created_from)) LEFT JOIN cryptocash_jdb_debit_card c ON ((b.profile_id = c.profile_id) AND (b.created_from = c.created_from)) LEFT JOIN cryptocash_user_status d ON ((a.email = d.email_address) AND (a.created_from = d.created_from)) ORDER BY a.shift_update_dt DESC) AS dataset WHERE dataset.shift_email='$reg_email_address' AND dataset.created_from_one='" . $req_partner['partner'] . "' ORDER BY dataset.shift_update_dt DESC LIMIT 1";
                            _log($reg_email_address, $sql_user_info);
                            $rs_user_info = mysqli_query($dbhandle, $sql_user_info);
                            $cur_user_info = array();
                            $my_profile_id = '';
                            $has_paid_fee = '';
                            $my_debit_card_id = '';
                            $has_sent_document_postal = '';
                            $my_card_status = '';
                            $kyc_pdf_file_created = '';
                            $card_selfie_uploaded = '';
                            $selfie_with_card_file = '';
                            $send_data_step_one = '';
                            $card_active_local_approved = '';
                            $send_data_step_two = '';
                            $shift_country = '';
                            $shift_email = '';
                            $kyc_status = '';
                            $card_activation_status = '';
                            $kyc_file_url = '';
                            $card_activation_file_url = '';
                            while ($row_user_info = mysqli_fetch_array($rs_user_info, MYSQLI_ASSOC)) {

                                $cur_user_info['email_address'] = (is_null($row_user_info['email_address']))?'':$row_user_info['email_address'];
                                $shift_email = (is_null($row_user_info['shift_email']))?'':$row_user_info['shift_email'];
                                $cur_user_info['given_name'] = (is_null($row_user_info['given_name']))?'':$row_user_info['given_name'];
                                $cur_user_info['middle_name'] = (is_null($row_user_info['middle_name']))?'':$row_user_info['middle_name'];
                                $cur_user_info['sur_name'] = (is_null($row_user_info['sur_name']))?'':$row_user_info['sur_name'];
                                $cur_user_info['signup_datetime'] = (is_null($row_user_info['shift_add_dt']))?'':$row_user_info['shift_add_dt'];

                                if ($cur_user_info['signup_datetime'] != '') {
                                    $shift_add_tm = strtotime($cur_user_info['signup_datetime']) - 32400; //change to UTC
                                    $cur_user_info['signup_datetime'] = date('Y/m/d H:i:s', $shift_add_tm);

                                }

                                $cur_user_info['last_update_datetime'] = (is_null($row_user_info['shift_update_dt']))?'':$row_user_info['shift_update_dt'];
                                if ($cur_user_info['last_update_datetime'] != '') {
                                    $shift_update_tm = strtotime($cur_user_info['last_update_datetime']) - 32400; //change to UTC
                                    $cur_user_info['last_update_datetime'] = date('Y/m/d H:i:s', $shift_update_tm);

                                }

                                $cur_user_info['submit_kyc_document_datetime'] = (is_null($row_user_info['kyc_upload_dt']))?'':$row_user_info['kyc_upload_dt'];
                                if ($cur_user_info['submit_kyc_document_datetime'] != '') {
                                    $kyc_upload_dt_tm = strtotime($cur_user_info['submit_kyc_document_datetime']) - 32400; //change to UTC
                                    $cur_user_info['submit_kyc_document_datetime'] = date('Y/m/d H:i:s', $kyc_upload_dt_tm);

                                }
                                $cur_user_info['card_was_issued_datetime'] = (is_null($row_user_info['admin_process_kyc_dt']))?'':$row_user_info['admin_process_kyc_dt'];
                                if ($cur_user_info['card_was_issued_datetime'] != '') {
                                    $admin_process_kyc_tm = strtotime($cur_user_info['card_was_issued_datetime']) - 32400; //change to UTC
                                    $cur_user_info['card_was_issued_datetime'] = date('Y/m/d H:i:s', $admin_process_kyc_tm);

                                }
                                $cur_user_info['card_was_activated_datetime'] = (is_null($row_user_info['admin_process_card_activate_dt']))?'':$row_user_info['admin_process_card_activate_dt'];
                                if ($cur_user_info['card_was_activated_datetime'] != '') {
                                    $admin_process_card_activate_tm = strtotime($cur_user_info['card_was_activated_datetime']) - 32400; //change to UTC
                                    $cur_user_info['card_was_activated_datetime'] = date('Y/m/d H:i:s', $admin_process_card_activate_tm);
                                }

                                $shift_country = (is_null($row_user_info['shift_country']))?'':$row_user_info['shift_country'];
                                $cur_user_info['affiliation'] = (is_null($row_user_info['affiliation']))?'':$row_user_info['affiliation'];
                                $my_profile_id = (is_null($row_user_info['profile_id']))?'':$row_user_info['profile_id'];
                                $cur_user_info['title'] = (is_null($row_user_info['gender']))?'':$row_user_info['gender'];
                                if (intval($cur_user_info['title'])==1) {
                                    $cur_user_info['title'] = "Mr.";
                                } else if (intval($cur_user_info['title'])==2) {
                                    $cur_user_info['title'] = "Ms.";
                                }
                                $cur_user_info['name'] = (is_null($row_user_info['name_romaji']))?'':$row_user_info['name_romaji'];
                                $cur_user_info['card_emboss_name'] = (is_null($row_user_info['name_on_card']))?'':$row_user_info['name_on_card'];
                                $cur_user_info['marriage_status'] = (is_null($row_user_info['marriage_status']))?'':$row_user_info['marriage_status'];
                                if (intval($cur_user_info['marriage_status'])==1) {
                                    $cur_user_info['marriage_status'] = "Single";
                                } else if (intval($cur_user_info['marriage_status'])==2) {
                                    $cur_user_info['marriage_status'] = "Married";
                                }
                                $cur_user_info['occupation'] =  (is_null($row_user_info['occupation']))?'':$row_user_info['occupation'];
                                $cur_user_info['country'] = (is_null($row_user_info['country']))?'':$row_user_info['country'];
                                $cur_user_info['nationality'] = (is_null($row_user_info['nationality']))?'':$row_user_info['nationality'];
                                $cur_user_info['date_of_birth'] = (is_null($row_user_info['date_of_birth']))?'':$row_user_info['date_of_birth'];
                                if ($cur_user_info['date_of_birth'] != '') {
                                    $cur_user_info['date_of_birth'] = str_replace("-","/",$cur_user_info['date_of_birth']);
                                }
                                $cur_user_info['place_of_birth'] = (is_null($row_user_info['place_of_birth']))?'':$row_user_info['place_of_birth'];
                                $cur_user_info['id_card_number'] = (is_null($row_user_info['id_card_number']))?'':$row_user_info['id_card_number'];
                                $cur_user_info['id_card_issued_date'] = (is_null($row_user_info['id_card_issued_dt']))?'':$row_user_info['id_card_issued_dt'];
                                if ($cur_user_info['id_card_issued_date'] != '') {
                                    $cur_user_info['id_card_issued_date'] = str_replace("-","/",$cur_user_info['id_card_issued_date']);
                                }
                                $cur_user_info['id_card_expired_date'] =(is_null($row_user_info['id_card_expired_dt']))?'':$row_user_info['id_card_expired_dt'];
                                if ($cur_user_info['id_card_expired_date'] != '') {
                                    $cur_user_info['id_card_expired_date'] = str_replace("-","/",$cur_user_info['id_card_expired_date']);
                                }
                                $cur_user_info['id_card_issuer'] = (is_null($row_user_info['id_card_issuer']))?'':$row_user_info['id_card_issuer'];
                                $cur_user_info['id_card_type'] = (is_null($row_user_info['id_card_type']))?'':$row_user_info['id_card_type'];
                                if ($cur_user_info['id_card_type'] == "passport") {
                                    $cur_user_info['id_card_type'] = "Passport";
                                } else if ($cur_user_info['id_card_type'] == "driving_license") {
                                    $cur_user_info['id_card_type'] = "ID card";
                                }
                                $cur_user_info['address'] = (is_null($row_user_info['residence_address']))?'':$row_user_info['residence_address'];
                                $cur_user_info['district'] = (is_null($row_user_info['district']))?'':$row_user_info['district'];
                                $cur_user_info['province'] = (is_null($row_user_info['province']))?'':$row_user_info['province'];
                                $cur_user_info['postal_code'] = (is_null($row_user_info['postal_code']))?'':$row_user_info['postal_code'];
                                $cur_user_info['cellphone_country_code'] = (is_null($row_user_info['cellphone_country_code']))?'':$row_user_info['cellphone_country_code'];
                                if ( strpos($cur_user_info['cellphone_country_code'], "_") !== false ) {
                                    $cellphone_country_code_arr = explode("_", $cur_user_info['cellphone_country_code']);
                                    if ($cellphone_country_code_arr[1] == "ca") {
                                        $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
                                    } else if ($cellphone_country_code_arr[1] == "44") {
                                        $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0] . " 44";
                                    } else if ($cellphone_country_code_arr[1] == "34") {
                                        $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0] . " 34";
                                    } else if ($cellphone_country_code_arr[1] == "97") {
                                        $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0] . " 97";
                                    } else if ($cellphone_country_code_arr[1] == "ca") {
                                        $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
                                    } else if ($cellphone_country_code_arr[1] == "kaz") {
                                        $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
                                    } else if ($cellphone_country_code_arr[1] == "swa") {
                                        $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
                                    } else if ($cellphone_country_code_arr[1] == "1") {
                                        $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
                                    }
                                }
                                $cur_user_info['cellphone_number'] = (is_null($row_user_info['cellphone_number']))?'':$row_user_info['cellphone_number'];
                                $cur_user_info['profile_added_date'] = (is_null($row_user_info['added_dt']))?'':$row_user_info['added_dt'];
                                if ($cur_user_info['profile_added_date'] != '') {
                                    $profile_added_tm = strtotime($cur_user_info['profile_added_date']) - 32400; //change to UTC
                                    $cur_user_info['profile_added_date'] = date('Y/m/d H:i:s', $profile_added_tm);
                                }
                                $cur_user_info['profile_updated_date'] = (is_null($row_user_info['update_dt']))?'':$row_user_info['update_dt'];
                                if ($cur_user_info['profile_updated_date'] != '') {
                                    $profile_updated_tm = strtotime($cur_user_info['profile_updated_date']) - 32400; //change to UTC
                                    $cur_user_info['profile_updated_date'] = date('Y/m/d H:i:s', $profile_updated_tm);
                                }
                                $cur_user_info['profile_status'] = (is_null($row_user_info['status']))?'':$row_user_info['status'];
                                $cur_user_info['kyc_deny_message'] = (is_null($row_user_info['application_deny_message']))?'':$row_user_info['application_deny_message'];
                                $cur_user_info['kyc_deny_message'] = addslashes($cur_user_info['kyc_deny_message']);
                                $my_debit_card_id = (is_null($row_user_info['debit_card_id']))?'':$row_user_info['debit_card_id'];
                                $cur_user_info['bank_account_number'] = (is_null($row_user_info['acc_no']))?'':$row_user_info['acc_no'];
                                $cur_user_info['card_number'] =  (is_null($row_user_info['debit_card_num']))?'':$row_user_info['debit_card_num'];
                                $my_card_status =  (is_null($row_user_info['card_status']))?'':$row_user_info['card_status'];
                                $has_paid_fee =  (is_null($row_user_info['has_paid_fee']))?'':$row_user_info['has_paid_fee'];
                                $cur_user_info['payment_method'] = (is_null($row_user_info['payment_method']))?'':strtoupper($row_user_info['payment_method']);
                                $cur_user_info['amount_fee_fiat'] = (is_null($row_user_info['amount_fee_fiat']))?'':$row_user_info['amount_fee_fiat'];
                                $cur_user_info['amount_fee_crypto'] = (is_null($row_user_info['amount_fee_crypto']))?'':$row_user_info['amount_fee_crypto'];
                                $has_sent_document_postal = (is_null($row_user_info['has_sent_document_postal']))?'':$row_user_info['has_sent_document_postal'];
                                $cur_user_info['card_activation_deny_message'] = (is_null($row_user_info['activation_deny_message']))?'':$row_user_info['activation_deny_message'];
                                $cur_user_info['card_issuance_deny_message'] = (is_null($row_user_info['card_issuance_deny_message']))?'':$row_user_info['card_issuance_deny_message'];

                                if (($row_user_info['secondary_address'] != "") && ($row_user_info['secondary_district'] != "") && ($row_user_info['secondary_province'] != "") && ($row_user_info['secondary_country'] != "")) {
                                    $cur_user_info['secondary_address'] = array('address' => $row_user_info['secondary_address'], 'district' => $row_user_info['secondary_district'], 'province' => $row_user_info['secondary_province'], 'postal_code' => $row_user_info['secondary_postal_code'], 'country' => $row_user_info['secondary_country']);
                                } else {
                                    $cur_user_info['secondary_address'] = "";
                                }

                                $cur_user_info['card_provider'] = (is_null($row_user_info['card_provider']))?'':$row_user_info['card_provider'];
                                if ($cur_user_info['card_provider'] == "visa") {
                                    $cur_user_info['card_provider'] = "VISA";
                                } else if ($cur_user_info['card_provider'] == "unionpay") {
                                    $cur_user_info['card_provider'] = "UNIONPAY";
                                }
                                $selfie_with_card_file = (is_null($row_user_info['selfie_with_card_file']))?'':$row_user_info['selfie_with_card_file'];
                                $send_data_step_one = (is_null($row_user_info['send_data_step_one']))?'':$row_user_info['send_data_step_one'];
                                $send_data_step_two = (is_null($row_user_info['send_data_step_two']))?'':$row_user_info['send_data_step_two'];
                                $card_active_local_approved = (is_null($row_user_info['card_active_local_approved']))?'':$row_user_info['card_active_local_approved'];

                                $cur_user_info['kyc_file_url'] = '';
                                $kyc_pdf_file_created = (is_null($row_user_info['kyc_pdf_file_created']))?'':intval($row_user_info['kyc_pdf_file_created']);
                                if ($kyc_pdf_file_created == 1) {
                                    $application_form_final_pdfex = ULTIMOPAY_WEB_ROOT . '/jdb/data/upload/application_final_signed_' . $my_profile_id . '.pdf';
                                    $cur_user_info['kyc_file_url'] = ULTIMOPAY_DASHBOARD_URL . 'jdb/data/upload/application_final_signed_' . $my_profile_id . '.pdf?t=' . time();
                                }
                                $cur_user_info['kyc_status'] = 'not yet';
                                if (intval($has_paid_fee) == 1) {
                                    $cur_user_info['payment_status'] = 'done';
                                } else {
                                    $cur_user_info['payment_status'] = 'not yet';
                                }
                                $card_selfie_uploaded = (is_null($row_user_info['card_selfie_uploaded']))?'':intval($row_user_info['card_selfie_uploaded']);
                                $cur_user_info['card_status'] = 'not yet';
                                $cur_user_info['card_activation_status'] = 'not yet';
                                $cur_user_info['group'] = (is_null($row_user_info['created_from_one']))?'':$row_user_info['created_from_one'];
                                
                                $kyc_status = $row_user_info['kyc_status'];
                                $card_activation_status = $row_user_info['card_activation_status'];
                                $kyc_file_url = $row_user_info['kyc_file_url'];
                                $card_activation_file_url = $row_user_info['card_activation_file_url'];
                                //////////////////////////////////////////////////////////////////////////
                                if ($my_profile_id != '') {
                                    if (intval($my_card_status) == 1) {
                                        $cur_user_info['kyc_status'] = 'approved';
                                        $cur_user_info['card_activation_status'] = 'approved';
                                        $cur_user_info['card_status'] = 'issued';
                                    } else {
                                        if (intval($cur_user_info['profile_status']) <= 0) {
                                            if ($kyc_status == 9) {														
                                                $cur_user_info['kyc_status'] = 'declined';
                                            } else {														
                                                if ($kyc_pdf_file_created == 1
                                                || $kyc_file_url) {
                                                    $cur_user_info['kyc_status'] = 'pending';
                                                }
                                            }
                                        } else {
                                            $cur_user_info['kyc_status'] = 'approved';
                                            if ($selfie_with_card_file != ''
                                            || $card_activation_file_url) {
                                                if ($card_activation_status == 9) {
                                                    $cur_user_info['card_activation_status'] = 'declined';
                                                } else {
                                                    if (intval($card_active_local_approved) == 0) { //card active requests
                                                        $cur_user_info['card_activation_status'] = 'pending';
                                                    } else {
                                                        $cur_user_info['card_activation_status'] = 'approved';
                                                    }		
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    _log($reg_email_address, "chua dang ky phat hanh the");
                                    $cur_user_info['email_address'] = $shift_email;
                                    $cur_user_info['country'] = $shift_country;
                                    $cur_user_info['kyc_status'] = 'not yet';
                                    $cur_user_info['card_status'] = 'not yet';
                                    $cur_user_info['card_activation_status'] = 'not yet';
                                }
                                //////////////////////////////////////////////////////////////////////////
                            }

                            //get charges data
                            if (!empty($my_debit_card_id)) {
                                $total_charge_completed = 0;
                                $total_charge_uncompleted = 0;
                                $card_loads = array();
                                $sql_charges = "SELECT * from `cryptocash_jdb_card_charges` WHERE `cryptocash_jdb_card_charges`.`email`='$reg_email_address' AND `cryptocash_jdb_card_charges`.`debit_card_id`=" . $my_debit_card_id . " ORDER BY `cryptocash_jdb_card_charges`.`created_dt` DESC";
                                _log($reg_email_address, $sql_charges);
                                $rs_charges = mysqli_query($dbhandle, $sql_charges);
                                $charges_cnt = mysqli_num_rows($rs_charges);
                                if ($charges_cnt > 0) {

                                    while ($row_charge = mysqli_fetch_array($rs_charges, MYSQLI_ASSOC)) {
                                        unset($charge_item);
                                        $charge_item = array();
                                        $charge_item['datetime'] = $row_charge['created_dt'];
                                        $charge_item['datetime'] = date('Y/m/d H:i:s', strtotime($charge_item['datetime']) - 32400);
                                        $charge_item['account_number'] = $row_charge['jdb_account_num'];
                                        $charge_item['card_number'] = $cur_user_info['card_number'];
                                        $charge_item['amount'] = $row_charge['amount'];
                                        $charge_item['type'] = (trim($row_charge['load_type']) == '')?'load':$row_charge['load_type'];
                                        if (intval($row_charge['status']) == 1) {
                                            $charge_item['status'] = 'completed';
                                        } else if (intval($row_charge['status']) == 2) {
                                            $charge_item['status'] = 'pending';
                                        }
                                        if (trim($charge_item['card_load_deny_message']) !='') {
                                            $charge_item['status'] = 'declined';
                                            $charge_item['message'] = trim($charge_item['card_load_deny_message']);
                                        }
                                        $card_loads[] = $charge_item;
                                    }
                                }
                                $cur_user_info['card_loads'] = $card_loads;
                            } else {
                                $cur_user_info['card_loads'] = array();
                            }

                            //PAP procedure
                            function PapLogin($_pap_url, $_username, $_password, $_type){
                                try {
                                    if ($_type == "merchant") {
                                        $_merchant_session = new Pap_Api_Session($_pap_url);
                                        if(!$_merchant_session->login($_username, $_password)) {
                                            _log("", "Merchant Cannot login: ".$_merchant_session->getMessage());
                                            return null;
                                        }
                                        return $_merchant_session;
                                    } else if ($_type == "affiliate") {
                                        $_aff_session = new Pap_Api_Session($_pap_url);
                                        if(!$_aff_session->login($_username,$_password, Pap_Api_Session::AFFILIATE)) {
                                            _log("", "Affiliate (" . $_username . ") Cannot login: ".$_aff_session->getMessage());
                                            return null;
                                        }
                                        return $_aff_session;
                                    }
                                } catch (Exception $e){
                                    return null;
                                }
                            }

                            function PapUserCheck($_username, $_merchant_session) {
                                if( $_merchant_session == null )
                                    return null;
                                $affiliate_user = array('userid' => '', 'refid' => '', 'error' => '');
                                $pap_user_check_request = new Pap_Api_AffiliatesGrid($_merchant_session);
                                //Filtering affiliate with username
                                $pap_user_check_request->addFilter('username', Gpf_Data_Filter::EQUALS, $_username);

                                // sets limit to 30 rows, offset to 0 (first row starts)
                                $pap_user_check_request->setLimit(0, 30);

                                // sets columns, use it only if you want retrieve other as default columns
                                $pap_user_check_request->addParam('columns', new Gpf_Rpc_Array(array(array('id'), array('refid'), array('userid'),
                                    array('username'), array('firstname'), array('lastname'), array('rstatus'), array('parentuserid'),
                                    array('dateinserted'), array('salesCount'), array('clicksRaw'), array('clicksUnique'))));

                                // send request
                                try {
                                    $pap_user_check_request->sendNow();
                                    // request was successful, get the grid result
                                    $grid = $pap_user_check_request->getGrid();

                                    // get recordset from the grid
                                    $pap_user_check_recordset = $grid->getRecordset();

                                    if (!empty($pap_user_check_recordset)) {
                                        foreach($pap_user_check_recordset as $rec) {
                                            if ((trim($rec->get('userid')) != '')  && (trim($rec->get('refid')) != '')){
                                                $affiliate_user['userid'] = $rec->get('userid');
                                                $affiliate_user['refid'] = $rec->get('refid');
                                                break;
                                            }
                                        }
                                    }
                                } catch(Exception $e) {
                                    $affiliate_user['error'] = $e->getMessage();
                                    return $affiliate_user;
                                }

                                return $affiliate_user;
                            }
                            $raw_pap_merchant_login_obj = PapLogin(PAP_URL, MERCHANT_USERNAME, MERCHANT_PASSWORD, "merchant");

                            $pap_affiliate_obj = PapUserCheck($shift_email, $raw_pap_merchant_login_obj);
                            $cur_user_info['pap_affiliate_refid'] = ($pap_affiliate_obj['refid'] != '')?$pap_affiliate_obj['refid']:'';

                            @mysqli_close($dbhandle);
                            $ret_rs['result'] = 'success';
                            $ret_rs['userInfoResponse'] = $cur_user_info;
                            header('Content-Type: application/json');
                            echo json_encode($ret_rs);
                            die();
                            //////////////////////////////////////////////////////////////////////////////////////////
                        }
                    } else {
                        @mysqli_close($dbhandle);
                        header('Content-Type: application/json');
                        http_response_code(500);
                        $ret_rs['result'] = 'failed';
                        $ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'you must sign in to use this API.');
                        echo json_encode($ret_rs);
                        die();
                    }
                } else {
                    _log($reg_email_address, "could not connect db !");
                }
                @mysqli_close($dbhandle);
                $ret_rs['result'] = 'success';
                $ret_rs['email_address'] = $reg_email_address;
                $ret_rs['wallet'] = $user_wallet_arr;
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
            } else {
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = $errors[0];
                _log("", $ret_rs['error']['errorMessage']);
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
            }
        }
    } else {
        header('HTTP/1.0 403 Forbidden');
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
    http_response_code(405);
    die();
}
