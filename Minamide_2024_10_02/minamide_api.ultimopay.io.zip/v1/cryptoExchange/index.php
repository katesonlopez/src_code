<?php

//header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
//header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
		
	//global $fh;
	if ($email == "") {
		$fh2 = fopen("/var/www/api.ultimopay.io/v1/cryptoExchange/log/crypto_exchange.log" , 'a');
	} else {
		$fh2 = fopen("/var/www/api.ultimopay.io/v1/cryptoExchange/log/" . $email . ".log" , 'a');
	}		
	$fline = date('[Ymd H:i:s] ') . $line."\n";
	fwrite($fh2, $fline);
	fclose($fh2);
	//echo date('[Ymd H:i:s] ').$line."\n";
	//@ob_flush(); 
	//flush();
	
}
	
	
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		_log("", "ket noi thanh cong");
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$partner = "";
	$crypto_pair_arr = array('USDTUSD', 'BTCUSD', 'BUSDUSD', 'USDCUSD');
	$exchange_type_arr = array('buy', 'sell');
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			/*
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_freelancer) {
				$found = 7;
				$coin = 'USDT';
				break;			
			} else if ($value == $apikey_bos) {
				$found = 8;
				$coin = 'USDT';
				$partner = "BOS";
				break;
			}
			*/
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
					
				}
			} else {
				_log("", "not found in db");
			}
		}
	}
	@mysqli_close($dbhandle);


	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}
	
	function uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	
	function decimal_notation($float) {
		$parts = explode('E', $float);

		if(count($parts) === 2){
			$exp = abs(end($parts)) + strlen($parts[0]);
			$decimal = number_format($float, $exp);
			return rtrim($decimal, '.0');
		}
		else{
			return $float;
		}
	}


	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	//_log("bat dau xu ly...");
	//if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6) || ($found==7) || ($found==8)) {
	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {
		
		
		//$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);
		
		//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
		//echo "payment_id: " . $payment_id . "<br/>";
		$json = file_get_contents('php://input');
		$data = json_decode($json, true);
		
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					//$failed_rs['error'] = 'Reached the maximum stack depth';
					_log("", 'Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					_log("", 'Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					//$failed_rs['error'] = 'Incorrect control character';
					_log("", 'Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					//$failed_rs['error'] = 'Syntax error or JSON invalid';
					_log("", 'Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					//$failed_rs['error'] = 'Unknown error';
					_log("", 'Unknown error');
					break;
			}
			
			//throw new Exception($error);
			//_log($failed_rs['error']);
			_log("", 'A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			}
			
			
			//auth_token
			if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
				$error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
				$errors[] = $error_obj;
			}
			
			//type
			if ((!isset($data['type'])) || (empty($data['type']))) {
				$error_obj = array('errorCode' => 4, 'errorMessage' => 'type parameter is required.');
				$errors[] = $error_obj;
			} else {
				if (!in_array(strtolower($data['type']), $exchange_type_arr)) {
					$error_obj = array('errorCode' => 5, 'errorMessage' => "unsupported type. Only 'buy' or 'sell' are allowed.");
					$errors[] = $error_obj;
				}
			}
			
			//pair
			if ((!isset($data['pair'])) || (empty($data['pair']))) {
				$error_obj = array('errorCode' => 6, 'errorMessage' => 'pair parameter is required.');
				$errors[] = $error_obj;
			} else {
				if (!in_array(strtoupper($data['pair']), $crypto_pair_arr)) {
					$error_obj = array('errorCode' => 7, 'errorMessage' => 'unsupported pair.');
					$errors[] = $error_obj;
				}
			}
				
				
			
						
			if (count($errors) == 0) {
				
				$errors_sub = array();
				
				
				//proceed to shift api
				require_once '../include/common.php';
				//require_once '../include/dbconfig.php';
				
				////////////////////////////////////////////////////
				
				//$allowed_currency_arr = array('USDT');
				$allowed_shift_currency_arr = array('USDT', 'BTC', 'BUSD', 'USDC', 'USD');
				//receive POST params
				$reg_email_address = trim($data['email_address']);
				//$auth_token = trim($data['auth_token']);
				$private_key = trim($data['auth_token']);
				$type = trim(strtolower($data['type']));
				$pair = trim(strtoupper($data['pair']));
				$amount = trim($data['amount']);
				$buyable_balance_before_order = 0;
				$sellable_balance_before_order = 0;
				$currency = '';
				$pair2 = '';
				if ($pair == "USDTUSD") {
					$currency = 'USDT';
					$pair2 = $pair;
				} else if  ($pair == "BUSDUSD") {
					$currency = 'BUSD';
					$pair2 = "BUSDUSDT";
				} else if  ($pair == "USDCUSD") {
					$currency = 'USDC';
					$pair2 = $pair;
				}
				
				//$currency = strtoupper(trim($data['currency']));
				//$crypto_price_arr = array();
								
				_log($reg_email_address, "crypto exchange started...");
				
				//$post_data = array();
				//$post_data['exchange'] = "PLUSQO";
				//$post_data['refreshToken'] = $auth_refresh_token;
								
				//$refresh_token_res = api_call('/authentication/user_authentication/refreshAccessToken', 0, '', $post_data, '');
				//if ($refresh_token_res['result']['result'] == 'success') {
					
					//$signin_user_data = array();
					
					$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
					if (mysqli_connect_errno() == 0) {
						mysqli_query($dbhandle, "set names utf8;");
						$allow_access_api = 0;
						
						$my_db_private_key = '';
						$my_db_auth_token = '';
						$my_db_wallet_auth_token = '';
						$my_db_sigin_dt = '';
						$my_db_token_refresh_dt = '';
						$my_db_shift_user_id = '';
						$nonce = millitime();						
						$usd_balance_before_order = 0;
						$usd_balance_after_order = 0;
						$sql_check_signin = "select a.*, b.shift_user_id from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_email_address";
						//_log($sql_check_signin);
						$rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
						if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
							$allow_access_api = 1;
							while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
								$my_db_auth_token = trim($row_signin['auth_token']);
								$my_db_wallet_auth_token = trim($row_signin['wallet_auth_token']);
								$my_db_sigin_dt = $row_signin['signin_dt'];
								$my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
								$my_db_private_key = trim($row_signin['private_key']);
								$my_db_shift_user_id = $row_signin['shift_user_id'];
								
							}
						}
						$authorization_value = "Bearer " . $my_db_auth_token;
						//@mysqli_close($dbhandle);
						
						if ($allow_access_api == 1) {
							
							if ($private_key != $my_db_private_key) {
								@mysqli_close($dbhandle);
								header('Content-Type: application/json');
								http_response_code(500);
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'Unauthorized.');
								echo json_encode($ret_rs);
								die();
							} else {
								/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
								//try getting wallet USD wallet balance before execution of order...
								////////////////////////////////////////////////////////////////////////////
								$nonce = $nonce + 1;
								$tmp_dto_arr = array();
								$accounts_res = api_call('/api/v1/accounts', $nonce, '', $tmp_dto_arr, $authorization_value);
								if (($accounts_res['http_code'] == "200") || ($accounts_res['http_code'] == "200 OK")) {
									if (is_array($accounts_res['result'])) {
										/////////////////////////////////////////////////////////
										$accounts_arr = $accounts_res['result'];
										if (count($accounts_arr) > 0) {
											_log($reg_email_address, "/api/v1/accounts ok vao roi");
											//$shift_wallet_arr = array();
											for ($coin_cnt=0; $coin_cnt<count($accounts_arr); $coin_cnt++) {
												$cur_coin_stat = $accounts_arr[$coin_cnt];
												
												if ( (!is_null($cur_coin_stat['id'])) && (!is_null($cur_coin_stat['currency_id'])) ) {
													
													if ($cur_coin_stat['currency_id'] == 'USD') {
														$usd_balance_before_order = format_coin(number_format($cur_coin_stat['balance'], 10, '.', ','));
														$buyable_balance_before_order = $cur_coin_stat['balance'];
													} else if ($cur_coin_stat['currency_id'] == $currency) {
														$sellable_balance_before_order = $cur_coin_stat['balance'];
													}
													
													
												}
												
											}
											
											
										} else {
																	
										}
																			
										/////////////////////////////////////////////////////////
									} else {
										
									}
								} else {
									
								}
								_log($reg_email_address, "usd_balance_before_order = " . $usd_balance_before_order);
								sleep(1);
								
								
								// begin add 20230424 busd,usdc k.o.
								if ($currency == 'BUSD' || $currency == 'USDT' || $currency == 'USDC') {
									
									$nonce = $nonce + 1;
									$order_dto_arr = array();
									unset($statistics_res);
									$statistics_res = api_call('/api/v1/securities/statistics', $nonce, "", $order_dto_arr, $authorization_value);
									if ($statistics_res['result'] != '') {
										if ($statistics_res['result']['error'] != 'invalid_token') {
											_log($reg_email_address, "(first time)::token is still valid");
											if (is_array($statistics_res['result'])) {
												$statistics_arr = $statistics_res['result'];
												if (count($statistics_arr) > 0) {
													for ($pair_cnt=0; $pair_cnt<count($statistics_arr); $pair_cnt++) {
														$cur_pair_stat = $statistics_arr[$pair_cnt];
														if (strtoupper($cur_pair_stat['security_id']) == $pair2) {
															_log($reg_email_address, "(first time)::security_id : " . $cur_pair_stat['security_id']);
															if (isset($cur_pair_stat['ask'])) {
																$securities_sell_price = $cur_pair_stat['ask'];		
															}
															
															if (isset($cur_pair_stat['bid'])) {
																$securities_buy_price = $cur_pair_stat['bid'];
																
															}
															
															break;
														}
													}
												} else {
													_log($reg_email_address, "api call /api/v1/securities/statistics ERROR: array is EMPTY");
													
												}
											} else {
												
												_log($reg_email_address, "api call /api/v1/securities/statistics ERROR: is not array");
											}
										}
									}

									$sql_get_shift_wallets = "select * from cryptocash_shift_wallet where shift_login_email='$reg_email_address'";
									$rs_get_shift_wallets = mysqli_query($dbhandle, $sql_get_shift_wallets);
									while ($row_get_shift_wallet = mysqli_fetch_array($rs_get_shift_wallets, MYSQLI_ASSOC)) {
										if ($row_get_shift_wallet['shift_account_currency'] == 'USD') {
											$shift_user_id = $row_get_shift_wallet['shift_user_id'];
											$shift_usd_account_id = $row_get_shift_wallet['shift_account_id'];
										} else if ($row_get_shift_wallet['shift_account_currency'] == $currency) {
											$shift_account_id = $row_get_shift_wallet['shift_account_id'];
										}
									}

									////////////////////////////////////////////////////
									$amount_flag = 0;
									if ($type=="sell") {
										$feePercent = 0.97;
										$amount_usd = floor($amount * $securities_buy_price * $feePercent * 100) / 100;
										_log($reg_email_address, "sellable_balance_before_order = " . $sellable_balance_before_order . "amount = " . $amount);
										if ($sellable_balance_before_order >= $amount) {
											$amount_flag = 1;
										}
									} else if ($type=="buy") {
										$feePercent = 1.03;
										$amount_usd = ceil((string)($amount * $securities_sell_price * $feePercent * 100)) / 100;
										_log($reg_email_address, "buyable_balance_before_order = " . $buyable_balance_before_order . "amount_usd = " . $amount_usd);
										if ($buyable_balance_before_order >= $amount_usd) {
											$amount_flag = 1;
										}
									}

									if ($amount_flag == 1) {
										$dec_configurator_key = '';
										_log($reg_email_address, "::try call get_configurator_key api...");										
										$plusqo_configurator_info_res = get_configurator_key($reg_email_address, $my_db_auth_token, 'plusqo_configurator_key_salt', 'plusqo_configurator_ec_key');									
										if (($plusqo_configurator_info_res['http_code'] == "200") || ($plusqo_configurator_info_res['http_code'] == "200 OK")) {
											_log($reg_email_address, "::call get_configurator_key api success.");
											//_log($reg_email_address, "::target_key_value = " . $plusqo_configurator_info_res['result']['target_key_value']);
											if (!empty($plusqo_configurator_info_res['result']['target_key_value'])) {
												$dec_configurator_key = trim($plusqo_configurator_info_res['result']['target_key_value']);
												_log($reg_email_address, "::get dec_configurator_key success");
											}
											
										} else {
											_log($reg_email_address, "::call decrypt api failed.");
										}
										if ($dec_configurator_key == '') {											
											_log($reg_email_address, "::failed logging by Configurator Account (get dec_configurator_key failed)!");
											@mysqli_close($dbhandle);
											header('Content-Type: application/json');
											http_response_code(500);
											$ret_rs['result'] = 'failed';
											$ret_rs['error'] = array('errorCode' => 11, 'errorMessage' => 'error occurred. please contact administrator for help.');
											echo json_encode($ret_rs);
											die();
										}
										
										_log($reg_email_address, "try logging in by Configurator Account...");
										$configurator_access_token = '';
										///////////////////////////////////////////////////////////////////////////////////////////////
										//try login as configorator
										$configurator_login_post_data = array();
										// Update 2023.07.21 by h.m
										// $configurator_login_post_data['username'] = "PlusqoAdmin2";
										// $configurator_login_post_data['password'] = "fY2ADeHDFkpVq%J18gaq";
										$configurator_login_post_data['username'] = "PlusqoAdmin@server.com";
										// Update 2023.10.06 by h.m
										// $configurator_login_post_data['password'] = "aaJKaMMxHYC84Z5xgUtRfTmKVyBspgFZ";
										$configurator_login_post_data['password'] = $dec_configurator_key;
										$configurator_login_post_data['exchange'] = "CONFIGURATOR_PLUSQO";

										$configurator_login_res = shift_configurator_api_call('/api/configurator_authentication/configuratorToken', 0, '', $configurator_login_post_data, '');
										if ($configurator_login_res['result']['result'] == 'success') {
											$configurator_access_token = trim($configurator_login_res['result']['configurator_access_token']);
											$configurator_auth_value = "Bearer " . $configurator_access_token;
											if ($configurator_access_token != '') {
												_log($reg_email_address, "Configurator Account logged in successful. Try execute balancecorrection...");
												//execute balance correction here, first is deduction from user wallet balance				
												$nonce = $nonce + 1;
												$balance_correction_dto_ex = array();
												$balance_correction_dto_ex['userId'] = $shift_user_id;
												$balance_correction_dto_ex['accountId'] = $shift_account_id;
												$balance_correction_dto_ex['currency'] = $currency;
												$calculated_amount = format_fiat(number_format($amount, 10, '.', ','), 2);
												if ($type=="sell") {
													$balance_correction_dto_ex['amount'] = "-" . $calculated_amount;
													$balance_correction_dto_ex['comment'] = 'Sell ' . $calculated_amount . ' ' . $currency;
												} else if ($type=="buy") {
													$balance_correction_dto_ex['amount'] = "+" . $calculated_amount;
													$balance_correction_dto_ex['comment'] = 'Buy ' . $calculated_amount . ' ' . $currency;
												}
												_log($reg_email_address, $balance_correction_dto_ex['accountId'] . " / " . $balance_correction_dto_ex['currency'] . " / " . $calculated_amount . " / " . $balance_correction_dto_ex['amount']);
												$balance_correction_dto_ex['type'] = 5;
												$balance_correction_res = shift_configurator_api_call('balancecorrection', $nonce, '', $balance_correction_dto_ex, $configurator_auth_value);
												if (($balance_correction_res['http_code'] == "200") || ($balance_correction_res['http_code'] == "200 OK")) {
													_log($reg_email_address, "executed balancecorrection(1) successful. Try execute balancecorrection(2)...");
													//execute balance correction here, next is adding to company wallet balance
													$nonce = $nonce + 1;
													$balance_correction_dto_ex2 = array();
													$balance_correction_dto_ex2['userId'] = $shift_user_id;
													$balance_correction_dto_ex2['accountId'] = $shift_usd_account_id;
													$balance_correction_dto_ex2['currency'] = "USD";
													if ($type=="sell") {
														$calculated_amount_usd = format_fiat(number_format($amount_usd, 10, '.', ','), 2);
														$balance_correction_dto_ex2['amount'] = "+" . $calculated_amount_usd;
														$balance_correction_dto_ex2['comment'] = 'Sell ' . $calculated_amount . ' ' . $currency;
													} else if ($type=="buy") {
														$calculated_amount_usd = format_fiat(number_format($amount_usd, 10, '.', ','), 2);
														$balance_correction_dto_ex2['amount'] = "-" . $calculated_amount_usd;
														$balance_correction_dto_ex2['comment'] = 'Buy ' . $calculated_amount . ' ' . $currency;
													}
													_log($reg_email_address, $balance_correction_dto_ex2['accountId'] . " / " . $balance_correction_dto_ex2['currency'] . " / " . $calculated_amount_usd . " / " . $balance_correction_dto_ex2['amount']);
													$balance_correction_dto_ex2['type'] = 5;
													$balance_correction_res2 = shift_configurator_api_call('balancecorrection', $nonce, '', $balance_correction_dto_ex2, $configurator_auth_value);
													if (($balance_correction_res['http_code'] == "200") || ($balance_correction_res['http_code'] == "200 OK")) {
														_log($reg_email_address, "executed balancecorrection(2) successful.");

														$tx_history_date = date('Y/m/d H:i:s');

														$sql_add_tx_history = "INSERT INTO cryptocash_exchange_history (id, email_address, currency, type, amount, usd_amount, status, date, tx_id, created_from) VALUES (null, '$reg_email_address', '$currency', '$type', '$calculated_amount','$calculated_amount_usd', 'completely_filled', '$tx_history_date', '', '" . $req_partner['partner'] . "')";
														if (mysqli_query($dbhandle, $sql_add_tx_history)) {
															$exchange_res = array('email_address' => $reg_email_address, 'id' => '');
															$exchange_res_details = array();

															$exchange_res_details['type'] = $type;
															$exchange_res_details['pair'] = $pair;
															$exchange_res_details['currency'] = $currency;
															$exchange_res_details['amount'] = $amount;
															$exchange_res_details['status'] = "success";
															if ($type=="sell") {
																$exchange_res_details['received_amount'] = abs($calculated_amount_usd);
															} else if ($type=="buy") {
																$exchange_res_details['paid_amount'] = abs($calculated_amount_usd);
															}
															$tx_history_date_utc = strtotime($tx_history_date) - 32400; //change to UTC
															$exchange_res_details['created_dt'] = date('Y/m/d H:i:s', $tx_history_date_utc);

															$exchange_res['details'] = $exchange_res_details;
															_log($reg_email_address, "ra toi day roi !");
															////////////////////////////////////////////////////////
															
															@mysqli_close($dbhandle);
															$ret_rs['result'] = 'success';
															$ret_rs['exchange_response'] = $exchange_res;
															header('Content-Type: application/json');
															echo json_encode($ret_rs);
															die();
														} else {
															_log($reg_email_address, $sql_update_debit_card);
														}
													} else {
														_log($reg_email_address, "balancecorrection execution(2) failed");
													}
												} else {
													_log($reg_email_address, "balancecorrection execution(1) failed");
												}
											}
										} else {
											_log($reg_email_address, "failed logging by Configurator Account!");
											_log($reg_email_address, $configurator_login_res['error']);
										}
									} else {
										_log($reg_email_address, "You do not have enought amount");
									}
								} else {
								// end add 20230424 busd,usdc k.o.
								
									_log($reg_email_address, $pair . " / " . $type. " / " . $amount);
									//$nonce = millitime();								
									//$authorization_value = "Bearer " . $my_db_auth_token;
									unset($buy_order_dto_ex);
									$buy_order_dto_ex = array();
									$client_order_id = uuid();
									$buy_order_dto_ex['client_order_id'] = $client_order_id;
									$buy_order_dto_ex['security_id'] = $pair; 
									$buy_order_dto_ex['type'] = "market";
									$buy_order_dto_ex['side'] = $type;
									$buy_order_dto_ex['quantity'] = "" . $amount;
									//$buy_order_dto_ex['time_in_force'] = "day";
									$buy_order_dto_ex['time_in_force'] = "ioc";
									$buy_order_dto_ex['price'] = "0.00";
									//$buy_order_dto_ex['expire_time'] = "0";
									$buy_order_dto_ex['submission_time'] = "0";
									$buy_order_dto_ex['destination'] = "SHIFTFX";
									$buy_order_dto_ex['text'] = $client_order_id;
									$buy_order_dto_properties_arr_ex = array();
									$buy_order_dto_ex['properties'] = $buy_order_dto_properties_arr_ex;
									unset($order_res);	
									$nonce = $nonce + 1;			
									$order_res = api_call('/api/v1/orders/', $nonce, $pair, $buy_order_dto_ex, $authorization_value);
									if (($order_res['http_code'] == "200") || ($order_res['http_code'] == "200 OK")) {
										
										////////////////////////////////////////////////////////////////////////////////////////////////////									
										if (!empty($order_res['result']['client_order_id'])) { //SUCCESS
										
										
											$res_client_order_id = $order_res['result']['client_order_id'];
											$res_order_id = strtoupper(trim($order_res['result']['id']));
											$res_order_price = $order_res['result']['price'];
											$res_order_status = $order_res['result']['status'];
											$res_order_quantity = $order_res['result']['quantity'];
											$res_order_side = $order_res['result']['side'];
										
											//$exchange_res = array('email_address' => $reg_email_address, 'id' => $res_order_id, 'status' => $res_order_status, 'type' => $res_order_side, 'pair' => $pair, 'amount' => $amount);
											$exchange_res = array('email_address' => $reg_email_address, 'id' => $res_order_id);
											$exchange_res_details = array();
											
											$used_currency = "";
											if ($pair=='BTCUSD') {
												$used_currency = "BTC";
											} else if ($pair=='USDTUSD') {
												$used_currency = "USDT";
											} else if ($pair=='USDCUSD') {
												$used_currency = "USDC";
											}
																				
											////////////////////////////////////////////////////////
											sleep(5);
											$tx_history_ret_arr = array();
											_log($reg_email_address, "try getting exchange history...");
											$date_from_tm = millitime() - 600000;
											$query_string = "/?flter_date_from=" . $date_from_tm . "&sort_direction=desc";
											$tx_history_post_data = array();
											$tx_history_res = api_call('/trade/orders/closed', 0, $query_string, $tx_history_post_data, $authorization_value);
											if (is_array($tx_history_res['result']['items'])) {
												if (count($tx_history_res['result']['items']) > 0) {
													_log($reg_email_address , "::/trade/orders/closed: ok vao roi");		
													_log($reg_email_address , ":: total exchange cnt = " . count($tx_history_res['result']['items']));								
													for ($tx_cnt=0; $tx_cnt<count($tx_history_res['result']['items']); $tx_cnt++) {	
														$cur_tx = $tx_history_res['result']['items'][$tx_cnt];
														_log($reg_email_address, $cur_tx['type'] . " / " . $cur_tx['id'] . " / " . $cur_tx['status']);
														if ($res_order_id == strtoupper($cur_tx['id'])) {
															$exchange_res_details['type'] = strtolower($cur_tx['side']);
															$exchange_res_details['pair'] = strtoupper($cur_tx['instrument_id']);
															
															//if (($cur_tx['type'] == 'market') && ($cur_tx['instrument_id'] == 'BTCUSD')) {
															if ($cur_tx['type'] == 'market') {
																
																unset($tx_item);
																$tx_item = array();
																$tx_item['created_dt'] = date('Y/m/d H:i:s', ($cur_tx['open_time'] / 1000) - 32400);
																$found_instrument = 0;
																$coin_type = "";
																if ($cur_tx['instrument_id'] == 'BTCUSD') {
																	$tx_item['currency'] = 'BTC';
																	$found_instrument = 1;
																	$coin_type = "BTC";
																} else if ($cur_tx['instrument_id'] == 'USDTUSD') {
																	$tx_item['currency'] = 'USDT';
																	$found_instrument = 1;
																	$coin_type = "USDT";
																} else if ($cur_tx['instrument_id'] == 'USDCUSD') {
																	$tx_item['currency'] = 'USDC';
																	$found_instrument = 1;
																	$coin_type = "USDC";
																}
																
																
																if ($found_instrument == 1) {
																	$exchange_res_details['currency'] = $tx_item['currency'];
																	$exchange_res_details['amount'] = $amount;
																	//////////////////////////////////////////////////////
																	$buy_total_usd_paid = 0;
																	$buy_total_usd_beforetax_paid = 0;
																	$buy_total_usd_aftertax_paid = 0;
																	
																	
																	$net_receive_usd_amount = 0;
																	$gross_receive_usd_amount = 0;
																	$shift_trading_commission_amount = 0;
																	if (($cur_tx['status'] == 'completely_filled') || ($cur_tx['status'] == 'partially_filled')) {
																		_log($reg_email_address, "status = " . $cur_tx['status']);
																		$exchange_res_details['status'] = "completed";
																		//////////////////////////////////////////////////////////////
																		if ((is_array($cur_tx['transactions'])) && (count($cur_tx['transactions']) > 0)){									
																		//if (!empty($cur_tx['transactions'])) {
																			_log($reg_email_address, "right here !!!");
																			//_log("transactions total = " . count($cur_tx['transactions']));
																			//iterate transactions of this order
																			// update 20230424 transactionHistory k.o start
																			$cur_tx_execution_amount = 0;
																			$cur_tx_commission_amount = 0;
																			foreach ($cur_tx['transactions'] as $order_tx_k => $order_tx_v) {
																				// _log("cur_tx[transactions][" . $order_tx_k . "] = " . $order_tx_v);
																				$cur_tx_type = '';
																				$cur_tx_currency = '';
																				$cur_tx_conversion_currency = '';
																				$cur_tx_amount = 0;
																				foreach ($order_tx_v as $order_tx_k2 => $order_tx_v2) {
																					// _log("order_tx_v[" . $order_tx_k2 . "] = " . $order_tx_v2);
																					if (trim($order_tx_k2) == 'type') {
																						$cur_tx_type = trim($order_tx_v2);
																					}
																					if (trim($order_tx_k2) == 'conversion_currency') {
																						$cur_tx_conversion_currency = trim(strtoupper($order_tx_v2));
																					}
																					if (trim($order_tx_k2) == 'currency') {
																						$cur_tx_currency = trim(strtoupper($order_tx_v2));
																					}
																					if (trim($order_tx_k2) == 'amount') {
																						$cur_tx_amount = $order_tx_v2;
																					}
																				}
																				if (($cur_tx_type == 'Execution') && ($cur_tx_currency == 'USD') && ($cur_tx_conversion_currency == 'USD')) {
																					$cur_tx_execution_amount += $cur_tx_amount;
																					$gross_receive_usd_amount = $cur_tx_execution_amount;
																					$buy_total_usd_beforetax_paid = abs($cur_tx_execution_amount);
																				}										
																				if (($cur_tx_type == 'TradingCommission') && ($cur_tx_currency == 'USD') && ($cur_tx_conversion_currency == 'USD')) {
																					$cur_tx_commission_amount += $cur_tx_amount;
																					$shift_trading_commission_amount = abs($cur_tx_commission_amount);
																				}
																			}
																			// update 20230424 transactionHistory k.o end
																			
																			/////////////////////////////////////////////////////
																			if ($cur_tx['side'] == 'sell') {
																				if ($gross_receive_usd_amount > 0) {
																					$net_receive_usd_amount = $gross_receive_usd_amount - $shift_trading_commission_amount;
																				}
																				_log($reg_email_address, "SELL:: " . $net_receive_usd_amount . " / " . $gross_receive_usd_amount . " / " . $shift_trading_commission_amount);
																			} else if ($cur_tx['side'] == 'buy'){
																				if ($buy_total_usd_beforetax_paid > 0) {
																					$buy_total_usd_aftertax_paid = $buy_total_usd_beforetax_paid + $shift_trading_commission_amount;
																				}
																				_log($reg_email_address, "BUY:: " . $buy_total_usd_beforetax_paid . " / " . $buy_total_usd_aftertax_paid . " / " . $shift_trading_commission_amount);
																			}
																			
																			$buy_total_usd_aftertax_paid = format_fiat(number_format($buy_total_usd_aftertax_paid, 10, '.', ','), 2);
																			
																			$net_receive_usd_amount = format_fiat(number_format($net_receive_usd_amount, 10, '.', ','), 2);
																			$gross_receive_usd_amount = format_fiat(number_format($gross_receive_usd_amount, 10, '.', ','), 2);
																			_log($reg_email_address, $net_receive_usd_amount . " / " . $gross_receive_usd_amount);
																			//$shift_trading_commission_amount = format_fiat(number_format($shift_trading_commission_amount, 10, '.', ','), 2);
																			if ($cur_tx['side'] == 'sell') {
																				
																				$tx_item['side'] = 'sell';
																				$tx_item['content'] = 'Sell ' . decimal_notation($cur_tx['quantity']) . ' ' . $coin_type .'<br/>(Received ' . $net_receive_usd_amount . ' USD)';
																				$exchange_res_details['received_amount'] = $net_receive_usd_amount;
																			} else if ($cur_tx['side'] == 'buy'){
																				$tx_item['side'] = 'Buy';
																				$tx_item['content'] = 'Buy ' . decimal_notation($cur_tx['quantity']) . ' ' . $coin_type . '<br/>(Paid ' . $buy_total_usd_aftertax_paid . ' USD)';	
																				$exchange_res_details['paid_amount'] = $buy_total_usd_aftertax_paid;																	
																			}
																			$tx_item['status'] = "<span style=\"font-weight: 900\">COMPLETED</span>";
																			/////////////////////////////////////////////////////
																			
																		} else {
																			sleep(1);
																			_log($reg_email_address, "have to call additional api");
																			//try getting wallet post balance from another api...
																			////////////////////////////////////////////////////////////////////////////
																			$nonce = $nonce + 1;
																			$accounts_res2 = api_call('/api/v1/accounts', $nonce, '', $tmp_dto_arr, $authorization_value);
																			if (($accounts_res2['http_code'] == "200") || ($accounts_res2['http_code'] == "200 OK")) {
																				if (is_array($accounts_res2['result'])) {
																					/////////////////////////////////////////////////////////
																					$accounts_arr2 = $accounts_res2['result'];
																					if (count($accounts_arr2) > 0) {
																						_log($reg_email_address, "/api/v1/accounts ok vao roi");
																						//$shift_wallet_arr = array();
																						for ($coin_cnt2=0; $coin_cnt2<count($accounts_arr2); $coin_cnt2++) {
																							$cur_coin_stat2 = $accounts_arr2[$coin_cnt2];
																							
																							if ( (!is_null($cur_coin_stat2['id'])) && (!is_null($cur_coin_stat2['currency_id'])) ) {
																								
																								if ($cur_coin_stat2['currency_id'] == 'USD') {
																									$usd_balance_after_order = format_coin(number_format($cur_coin_stat2['balance'], 10, '.', ','));
																									break;
																								}
																								
																							}
																							
																						}
																						
																						
																					} else {
																												
																					}
																					
																					/////////////////////////////////////////////////////////
																				} else {
																					
																				}
																				_log($reg_email_address, "usd_balance_after_order = " . $usd_balance_after_order);
																				if ($type=="sell") {
																					$exchange_res_details['received_amount'] = abs($usd_balance_after_order - $usd_balance_before_order);
																				} else if ($type=="buy") {
																					$exchange_res_details['paid_amount'] = abs($usd_balance_before_order - $usd_balance_after_order);
																				}
																			} else {
																				
																			} 
																			////////////////////////////////////////////////////////////////////////////
																		}
																		
																		
																		//////////////////////////////////////////////////////////////
																	} else {
																		
																		if ($cur_tx['status'] == 'rejected') {
																			$exchange_res_details['status'] = "failed";
																			if ($cur_tx['side'] == 'sell') {
																				$tx_item['side'] = 'sell';
																				$tx_item['content'] = 'Sell ' . decimal_notation($cur_tx['quantity']) . ' ' . $coin_type . '<br/>(Received ' . $net_receive_usd_amount . ' USD)';		
																			} else if ($cur_tx['side'] == 'buy'){
																				$tx_item['side'] = 'buy';
																				$tx_item['content'] = 'Buy ' . decimal_notation($cur_tx['quantity']) . ' ' . $coin_type . '<br/>(Paid ' . $buy_total_usd_aftertax_paid . ' USD)';	
																			}
																			$tx_item['status'] = "<span style=\"padding: 3px 3px; background-color: red; color: #fff; font-weight: 900; \">FAILED</span>";
																		}
																	}
																	$tx_history_ret_arr[] = $tx_item;
																	$exchange_res_details['created_dt'] = $tx_item['created_dt'];
																	//////////////////////////////////////////////////////
																} else {
																	//////////////////////////////////////////////////////
																	
																	//////////////////////////////////////////////////////
																}
																
																
																
															}
															break;
														}
													}
												} else {
													_log($reg_email_address, "::/trade/orders/closed ERROR: is EMPTY");
												}
												
											} else {
												_log($reg_email_address, "::/trade/orders/closed ERROR: is not array");
											}
											
											$exchange_res['details'] = $exchange_res_details;
											_log($reg_email_address, "ra toi day roi !");
											////////////////////////////////////////////////////////
											
											@mysqli_close($dbhandle);
											$ret_rs['result'] = 'success';
											//$ret_rs['email_address'] = $reg_email_address;
											$ret_rs['exchange_response'] = $exchange_res;					
											header('Content-Type: application/json');
											echo json_encode($ret_rs);
											die();
														
										} else {
											_log($reg_email_address, "::/api/v1/orders/ FAILED : " . $order_res['result']['message']);
											if (strstr($order_res['result']['message'],"Cannot use margin")) {
												//$data['msg'] = 'proc_ng2';
												//$data['msg_ex'] = "Insufficiency BTC Balance to execute this selling order";
												@mysqli_close($dbhandle);
												header('Content-Type: application/json');
												http_response_code(500);
												$ret_rs['result'] = 'failed';
												$ret_rs['error'] = array('errorCode' => 8, 'errorMessage' => 'Insufficiency balance to execute this order.');
												echo json_encode($ret_rs);
												die();
											} else {
												//$data['msg'] = 'proc_ng2';
												//$data['msg_ex'] = "Unknown error occured. Please contact administrator for help";
												@mysqli_close($dbhandle);
												header('Content-Type: application/json');
												http_response_code(500);
												$ret_rs['result'] = 'failed';
												$ret_rs['error'] = array('errorCode' => 9, 'errorMessage' => 'Error occurred. Please contact administrator for help.');
												echo json_encode($ret_rs);
												die();
											}
										} 
										
										////////////////////////////////////////////////////////////////////////////////////////////////////
									} else {
										_log($reg_email_address, "ERROR : " . $order_res['result']['status_code'] . " / " . $order_res['result']['message']);
										
										if (($order_res['http_code'] == "400") || ($order_res['http_code'] == "400 Bad Request")) {
											if (!empty($order_res['result']['message'])) { 
												@mysqli_close($dbhandle);
												header('Content-Type: application/json');
												http_response_code(500);
												$ret_rs['result'] = 'failed';
												$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Error occurred. Perhaps you provided invalid value for amount, or you do not have enough balance to place this order.');
												echo json_encode($ret_rs);
												die();
											}
										}
										
									}
								}
								
								//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							}
							
							
							
						} else {
							@mysqli_close($dbhandle);
							header('Content-Type: application/json');
							http_response_code(500);
							$ret_rs['result'] = 'failed';
							$ret_rs['error'] = array('errorCode' => 10, 'errorMessage' => 'you must sign in to use this API.');
							echo json_encode($ret_rs);
							die();
						}
						
						
					} else {			
						//_log($reg_email_address, "could not connect db !");
						@mysqli_close($dbhandle);
						header('Content-Type: application/json');
						http_response_code(500);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'system is under maintenance.');
						echo json_encode($ret_rs);
						die();
						
					}
					
					/*
					//header('Content-Type: application/json');
					//echo json_encode($ret_rs);
					//die();
					@mysqli_close($dbhandle);
					$ret_rs['result'] = 'success';
					//$ret_rs['email_address'] = $reg_email_address;
					$ret_rs['cryptocurrencies'] = $crypto_price_arr;					
					header('Content-Type: application/json');
					echo json_encode($ret_rs);
					die();
					*/
					
					
					
				//} else {
				//	_log($reg_email_address . " : " . $refresh_token_res['result']['message']);
				//	$ret_rs['result'] = 'failed';
				//	$ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'failed to refresh auth_token');
				//	header('Content-Type: application/json');
				//	echo json_encode($ret_rs);
				//	die();
				//}
				
				
			} else {
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors[0];
				_log("", $ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
				
			
		}

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>