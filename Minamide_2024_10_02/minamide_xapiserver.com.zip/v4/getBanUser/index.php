<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding("UTF-8");
date_default_timezone_set('Asia/Tokyo');

if (!function_exists('getallheaders'))  {
  function getallheaders()
  {
    if (!is_array($_SERVER)) {
      return array();
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
      if (substr($name, 0, 5) == 'HTTP_') {
        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
      }
    }
    return $headers;
  }
}
function _log($email, $line): void
{
  $logFilePath = (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') ?
    'C:' . DIRECTORY_SEPARATOR . ($email ? $email : '_getBanUser') . '.log' :
    dirname(__FILE__) . '/log/' . ($email ? $email : 'getBanUser') . '.log';

  $logDirectory = dirname($logFilePath);
  if (!is_dir($logDirectory)) {
    mkdir($logDirectory, 0755, true);
  }

  if (!file_exists($logFilePath)) {
    touch($logFilePath);
  }

  $fh2 = fopen($logFilePath, 'a');
  if ($fh2) {
    $fLine = date('[Ymd H:i:s] ') . $line . "\n";
    fwrite($fh2, $fLine);
    fclose($fh2);
  }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_once '../include/dbconfig.php';
  $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
  if (mysqli_connect_errno() != 0) {
    http_response_code(500);
    echo json_encode(['result' => 'failed', 'error' => ['errorCode' => 999, 'errorMessage' => 'System is under maintenance.']]);
    die();
  }
  mysqli_query($dbhandle, "set names utf8;");
  $req_api_key = '';
  $req_partner = ['partner' => '', 'api_key' => '', 'website' => ''];

  foreach (getallheaders() as $name => $value) {
    if ($name == 'Authorization') {
      $req_api_key = trim($value);
      $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
      $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
      if (mysqli_num_rows($partner_rs) > 0) {
        while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
          if ($req_api_key == "Bearer " . $row_partner['api_key']) {
            $req_partner = [
              'partner' => trim($row_partner['partner']),
              'api_key' => trim($row_partner['api_key']),
              'website' => trim($row_partner['website'])
            ];
            break;
          }
        }
      } else {
        _log("", "not found in db");
      }
    }
  }
  mysqli_close($dbhandle);

  if ($req_partner['partner'] && $req_partner['api_key'] && $req_partner['website']) {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!$data) {
      $errors = [
        JSON_ERROR_DEPTH => 'Reached the maximum stack depth',
        JSON_ERROR_STATE_MISMATCH => 'Incorrect discharges or mismatch mode',
        JSON_ERROR_CTRL_CHAR => 'Incorrect control character',
        JSON_ERROR_SYNTAX => 'Syntax error or JSON invalid',
        JSON_ERROR_UTF8 => 'Invalid UTF-8 characters, possibly invalid encoding'
      ];
      _log("", $errors[json_last_error()] ?? 'Unknown error');
      _log("", 'A non-empty request body is required.');
      http_response_code(400);
      echo json_encode(['result' => 'failed', 'error' => ['errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.']]);
      die();
    }

    $errors = array();
    if (empty($data['email_address'])) {
      $errors[] = ['errorCode' => 2, 'errorMessage' => 'email_address parameter is required.'];
    }
    if (empty($data['auth_token'])) {
      $errors[] = ['errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.'];
    }

    if (count($errors) == 0) {
      require_once '../include/common.php';
      $reg_email_address = trim($data['email_address']);
      $private_key = trim($data['auth_token']);

      _log($reg_email_address, "get ban user started...");
      $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
      if (mysqli_connect_errno() == 0) {
        mysqli_query($dbhandle, "set names utf8;");
        $sql_check_signin = "SELECT a.*, b.shift_user_sub_id 
                                     FROM cryptocash_merchant_user_signin a 
                                     JOIN cryptocash_shift_user_ids b 
                                     ON a.email_address = b.shift_email_address 
                                     WHERE a.email_address = '$reg_email_address' 
                                     AND a.merchant='" . $req_partner['partner'] . "'";
        $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
        if (mysqli_num_rows($rs_check_signin) == 1) {
          $row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC);

          if ($private_key == trim($row_signin['private_key'])) {
            $result['result'] = 'success';
            $query = "SELECT * FROM `cryptocash_ban_user` WHERE email='$reg_email_address'";
            $rs_ban_user = mysqli_query($dbhandle, $query);
            if (mysqli_num_rows($rs_ban_user) == 1) {
              $ban_user = mysqli_fetch_array($rs_ban_user, MYSQLI_ASSOC);
              $result['ban_user'] = $ban_user;
            }
            else{
              $result['ban_user'] = [];
			  _log($reg_email_address, "toi khong bi ban !");
            }
            echo json_encode($result);
            mysqli_close($dbhandle);
            die();
          } else {
            mysqli_close($dbhandle);
            http_response_code(500);
            echo json_encode(['result' => 'failed', 'error' => ['errorCode' => 6, 'errorMessage' => 'Unauthorized.']]);
            die();
          }
        } else {
          mysqli_close($dbhandle);
          http_response_code(500);
          echo json_encode(['result' => 'failed', 'error' => ['errorCode' => 4, 'errorMessage' => 'You must sign in to use this API.']]);
          die();
        }
      } else {
        _log($reg_email_address, "could not connect db !");
        echo json_encode(['result' => 'failed', 'error' => ['errorCode' => 5, 'errorMessage' => 'You must sign in to use this API.']]);
        die();
      }
    } else {
      echo json_encode(['result' => 'failed', 'error' => $errors[0]]);
      _log("", $errors[0]['errorMessage']);
      die();
    }
  } else {
    header('HTTP/1.0 403 Forbidden');
  }
} else {
  http_response_code(405);
  die();
}
