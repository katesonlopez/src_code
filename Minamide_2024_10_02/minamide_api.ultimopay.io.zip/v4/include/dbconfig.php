<?php
define("DB_HOST", 'localhost');
define("DB_USERNAME", 'root');
define("DB_PASSWORD", '');
define("DB_NAME", 'ultimopay.io');

//define("DB_HOST", '65.109.73.120');
//define("DB_USERNAME", 'ultimopay_api_user002');
//define("DB_PASSWORD", 'dRTbs927fgXXINQHYX5t5U53Caya4m');
//define("DB_NAME", 'ultimopay.io');

define("DB_HOST_XEXON", '95.216.23.251');
define("DB_USERNAME_XEXON", 'xexon001');
define("DB_PASSWORD_XEXON", 'tRLG8LPrKUtQAkdT');
define("DB_NAME_XEXON", 'cryptocash.com');
?>
