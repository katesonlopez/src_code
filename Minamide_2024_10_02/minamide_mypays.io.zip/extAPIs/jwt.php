<?php
require '../vendor/autoload.php';
require_once '../includes/config.php';
use \Firebase\JWT\JWT;
use \Firebase\JWT\Key;

function generateJwt( $emailAddress ): string
{
  $secretKey = JWT_SECRET;
  $issuedAt = time();
  $expirationTime = $issuedAt + 3600;
  $payload = array(
    'iat' => $issuedAt,
    'exp' => $expirationTime,
    'data' => array(
      'email_address' => $emailAddress
    )
  );

  return JWT::encode($payload, $secretKey, 'HS256');
}

function verifyJwt( $jwt ): array
{
  $result = array('error'=>null, 'emailAddress'=>null);

  try {
    $decoded = JWT::decode($jwt, new Key(JWT_SECRET, 'HS256'));
    $decoded_array = (array) $decoded;
    $result['emailAddress'] = $decoded_array['data']->email_address;
  } catch (\Firebase\JWT\ExpiredException $e) {
    $result['error'] = "Error: JWT has expired: ". $e->getMessage();
  } catch (\Exception $e) {
    $result['error'] = "Error: decoding JWT: " . $e->getMessage();
  }

  return $result;
}