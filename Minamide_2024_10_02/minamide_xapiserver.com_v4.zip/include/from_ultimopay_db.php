<?php


/**
 * Get user id from email address
 **@throws Exception
 */
function _ultimopay_db_get_user_id( $dbHandle, $username )
{

    $user_id = null;
    try {
        $sql_check_shift_id = "SELECT * FROM cryptocash_shift_user_ids WHERE shift_email_address='$username'";
        $rs_check_shift_id = mysqli_query($dbHandle, $sql_check_shift_id);
        $shift_user_cnt = mysqli_num_rows($rs_check_shift_id);
        if( $shift_user_cnt > 0 ){
            $user_id_rec = mysqli_fetch_assoc($rs_check_shift_id);
            $user_id = $user_id_rec['shift_user_sub_id'];
        }
    }
    catch ( Exception $e ){
    }

    return $user_id;
}

