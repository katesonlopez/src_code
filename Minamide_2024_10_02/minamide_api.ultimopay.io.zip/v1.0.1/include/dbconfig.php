<?php
define("DB_HOST", '95.216.23.251');
define("DB_USERNAME", 'ultimopay003');
define("DB_PASSWORD", 'c6XNCs72Bsd39w4T');
define("DB_NAME", 'ultimopay.io');
?>
