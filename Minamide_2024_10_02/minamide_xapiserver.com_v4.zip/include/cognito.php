<?php
/**
    First, run composer

 *          composer require paragonie/sodium_compat
 *          composer require aws/aws-sdk-php
 *          composer require nesbot/carbon
 *          composer require phpseclib/phpseclib

 *
 **/
/**
Get id of client from https://plusqo-uat.cryptosrvc.com/exchange by using graphQl
 **/

require_once 'server_env.php';
require_once '../vendor/autoload.php';
require_once 'AwsCognitoIdentitySRP.php';
require_once 'graphQL_api.php';



/**
 * SignIn API
 **@throws Exception
 */
function _cognito_signIn( $username, $password ): array
{

    $result = array( 'result'=>'failed', 'message'=>'', 'data'=>null );
    try {
        // 1. Get client id
        $client_id = null;
        $pool_id = null;
        $clientInfo = getClientId();
        //echo json_encode($clientInfo);
        if ($clientInfo['result'] !== 'success')
            return $clientInfo;

        if (isset($clientInfo['data']['data']['sso_settings']['trader'])) {
            $traderData = $clientInfo['data']['data']['sso_settings']['trader'];

            $client_id = $traderData['client_id'];
            $pool_id = $traderData['pool_id'];
        }

        // 2. Generate SRP-A code from user's password.
        $awsCognito = new AwsCognitoIdentitySRP('test', $client_id, $pool_id);
        $srpACode = $awsCognito->largeA()->toHex();

        // 3. Do user SRP authentication
        $userSrpAuth = doUserSrpAuth($client_id, $username, $srpACode);
        if ($userSrpAuth['result'] != 'success')
            return $userSrpAuth;

        //echo json_encode($userSrpAuth);

        // 4. Do verify password
        // 4.1 calculate ChallengeResponses
        $challengeResponses = calculateChallengeResponses($password, $userSrpAuth['data'], $awsCognito);
        if ($challengeResponses['result'] != 'success')
            return $challengeResponses;
        //echo json_encode($challengeResponses);

        // 4.2 Do verify password
        $result = doVerifyPassword($client_id, $challengeResponses['data']);
        $result['data']['user_id'] = $challengeResponses['data']['USERNAME'];
        //echo json_encode($result);
    }
    catch ( Exception $e ){
        $result['message'] = $e->getMessage();
    }

    return $result;
}

/**
 * Get User Info API
 **@throws Exception
 */
function _cognito_getUserInfo($authToken): array
{
    $result = array('result' => 'failed', 'message' => '', 'data' => null);

    try {
        // Initialize stream context for HTTP request
        $options = [
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/x-amz-json-1.1' . "\r\n" .
                            'X-Amz-Target: AWSCognitoIdentityProviderService.GetUser',
                'content' => json_encode([
                    'AccessToken' => $authToken
                ]),
                'ignore_errors' => true,
            ],
        ];

        // Set the URL
        $url = COGNITO_URL;

        // Create a stream context
        $context = stream_context_create($options);

        // Perform the HTTP request and capture the response
        $response = @file_get_contents($url, false, $context); // Use @ to suppress warnings

        preg_match('/^HTTP\/\d\.\d\s+(\d+)\s+(.*)$/', $http_response_header[0], $matches);
        $httpCode = (int) $matches[1];
        $result['http_code'] = $httpCode;

        if (strpos($httpCode, '200') !== false) {
            $responseObj = json_decode($response, true);
            if (!isset($responseObj['Username'])) {
                $result['http_code'] = 400;
                if(isset($responseObj['__type']))
                    $result['message'] = $responseObj['__type'];
                if(isset($responseObj['Output']['__type']))
                    $result['message'] = $responseObj['Output']['__type'];
                $result['data'] = $responseObj;
            } else {
                $result['result'] = 'success';
                $result['data'] = $responseObj;
            }
        } else {
            if(isset($responseObj['__type']))
                $result['message'] = $responseObj['__type'];
            if(isset($responseObj['Output']['__type']))
                $result['message'] = $responseObj['Output']['__type'];
            $result['data'] = json_decode($response, true);
        }
    } catch (Exception $e) {
        $result['http_code'] = 500;
        $result['message'] = 'exception: ' . $e->getMessage();
        $result['data'] = $e;
    }

    return $result;
}


/**
    Do USER_SRP_AUTH via Cognito's API
 **/
function doUserSrpAuth( $clientId, $username, $srp_A ): array
{

    $result = array( 'result'=>'failed', 'message'=>'', 'data'=>null );

    // Define the request body as an array
    $request_body = array(
        "AuthFlow" => "USER_SRP_AUTH",
        "ClientId" => $clientId,
        "AuthParameters" => array(
            "USERNAME" => $username,
            "SRP_A" => $srp_A
        ),
        "ClientMetadata" => (object)array()
    );

    // Convert the request body to JSON
    $request_json = json_encode($request_body);

    // Initialize cURL session
    $ch = curl_init( COGNITO_URL );

    // Set cURL options
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $request_json);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'X-Amz-Target: AWSCognitoIdentityProviderService.InitiateAuth',
        'Content-Type: application/x-amz-json-1.1'
    ));

    // Execute the cURL session
    $response = curl_exec($ch);

    // Check for cURL errors
    if (curl_errno($ch)) {
        $result['message'] = 'Error: ' . curl_error($ch);
        return $result;
    }

    // Close the cURL session
    curl_close($ch);

    // Decode the JSON response
    $responseData = json_decode($response, true);
    $result['result'] = 'success';
    $result['data'] = $responseData;

    return $result;
}

/**
 * Do PASSWORD_VERIFIER via Cognito's API
 **@throws Exception
 */
function calculateChallengeResponses($password, $data, AwsCognitoIdentitySRP $awsCognitoIdentitySRP ): array
{

    $result = array( 'result'=>'failed', 'message'=>'', 'data'=>null );
    $awsResult = new Aws\Result($data);
    try{
        $result['data'] = $awsCognitoIdentitySRP->processChallenge($awsResult, $password);
        $result['result'] = 'success';
    }
    catch (Exception $e){
        $result['message'] = $e->getMessage();
    }

    return $result;
}

/**

 **/
function doVerifyPassword($clientId, $challengeResponses): array
{
    $result = array( 'result'=>'failed', 'message'=>'', 'data'=>null );

    // Define the request body as an array
    $request_body = array(
        "ChallengeName" => "PASSWORD_VERIFIER",
        "ClientId" => $clientId,
        "ChallengeResponses" => $challengeResponses,
        "ClientMetadata" => (object)array()
    );

    // Convert the request body to JSON
    $request_json = json_encode($request_body);

    // Initialize cURL session
    $ch = curl_init( COGNITO_URL );

    // Set cURL options
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $request_json);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'X-Amz-Target: AWSCognitoIdentityProviderService.RespondToAuthChallenge',
        'Content-Type: application/x-amz-json-1.1'
    ));

    // Execute the cURL session
    $response = curl_exec($ch);

    // Check for cURL errors
    if (curl_errno($ch)) {
        $result['message'] = 'Error: ' . curl_error($ch);
        return $result;
    }

    // Close the cURL session
    curl_close($ch);

    // Decode the JSON response
    $responseData = json_decode($response, true);

    if( !isset($responseData['AuthenticationResult'])){
        $result['message'] = $responseData['message'];
    }
    else{
        $result['result'] = 'success';
        $result['data'] = $responseData;
    }

    return $result;
}

/**
 * get Admin Auth Token API
 **@throws Exception
 */
function _cognito_getAdminAuthToken(): array
{

    $result = array( 'result'=>'failed', 'message'=>'', 'data'=>null );
    try {
        // 1. prepare client id and pool id
        $client_id = COGNITO_ADMIN_CLIENT_ID;
        $pool_id = COGNITO_ADMIN_POOL_ID;
        $username = COGNITO_ADMIN_USERNAME;
        $password = COGNITO_ADMIN_PASSWORD;

        // 2. Generate SRP-A code from user's password.
        $awsCognito = new AwsCognitoIdentitySRP('test', $client_id, $pool_id);
        $srpACode = $awsCognito->largeA()->toHex();

        // 3. Do user SRP authentication
        $userSrpAuth = doUserSrpAuth($client_id, $username, $srpACode);
        if ($userSrpAuth['result'] != 'success')
            return $userSrpAuth;

        //echo json_encode($userSrpAuth);

        // 4. Do verify password
        // 4.1 calculate ChallengeResponses
        $challengeResponses = calculateChallengeResponses($password, $userSrpAuth['data'], $awsCognito);
        if ($challengeResponses['result'] != 'success')
            return $challengeResponses;
        //echo json_encode($challengeResponses);

        // 4.2 Do verify password
        $signInResult = doVerifyPassword($client_id, $challengeResponses['data']);
        //echo json_encode($signInResult);
        $result['data'] = $signInResult['data']['AuthenticationResult']['AccessToken'];
    }
    catch ( Exception $e ){
        $result['message'] = $e->getMessage();
    }

    return $result;
}
