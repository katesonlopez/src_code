<?php

const COGNITO_URL = 'https://cognito-idp.us-east-1.amazonaws.com/';

/**
GRAPHQL_URL can be one of:
 *      https://vakotrade-demo.cryptosrvc.com/graphql/
 *      https://vakotrade.cryptosrvc-dev.com/graphql/
 *      https://vakotrade-plusqo-uat.cryptosrvc.com/graphql/
 **/
const GRAPHQL_URL = 'https://vakotrade-plusqo.cryptosrvc.com/graphql/';
const COGNITO_ADMIN_CLIENT_ID = 'm7l0q5iogv03n6fk26ad58no9';
const COGNITO_ADMIN_POOL_ID = 'us-east-1_y7iaOx557';
//const COGNITO_ADMIN_USERNAME = 'minamide@optlynx.com';
//const COGNITO_ADMIN_PASSWORD = 'N;2k.oE-Cm60rc7Op59v&=0)TA_7R$rZ';
const COGNITO_ADMIN_USERNAME = 'quy@optlynx.com';
const COGNITO_ADMIN_PASSWORD = 'ExHJL&y4Qw2S#xj6VX6Bd$Soh';