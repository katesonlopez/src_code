# payment.ultimopay.io.prod

```yaml
node.js: 16.17.1
php: 7.2.34
```

```bash
$ npm i
$ composer install

$ php artisan serve

$ php artisan key:generate
$ cp .env.local .env
$ php artisan config:clear
```
