<?php

namespace App\includes\JDB_PROD\api;

class ThreeDSProc
{
  public function getChallengeHtml($acsURL, $rawCreq, $threeDSSessionData ){

    // Form data
    $postData = [
      'creq' => $rawCreq,
      'threeDSSessionData' => $threeDSSessionData,
    ];

    // Initialize cURL session
    $ch = curl_init($acsURL);

    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the response as a string
    curl_setopt($ch, CURLOPT_POST, true); // Use POST method
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData)); // Send form data

    // Execute the cURL request
    $response = curl_exec($ch);

    // Check for errors
    if(curl_errno($ch)) {
      $result = 'cURL error: ' . curl_error($ch);
    } else {
      // Output the HTML content of the new page
      $result = $response;
    }

    // Close the cURL session
    curl_close($ch);

    return $result;
  }
}
