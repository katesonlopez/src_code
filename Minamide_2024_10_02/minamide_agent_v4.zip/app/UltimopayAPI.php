<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class UltimopayAPI extends Model
{
  /**=============      base api       ===============================================**/
  public static function baseApiCall($url, $params = null): array
  {
    try{

      // request data that is going to be sent as POST to API
      $data = array(
        'email_address' => trim(session()->get("email")),
        'auth_token' => trim(session()->get("auth_token"))
      );

      if( $params != null ){
        foreach ($params as $key => $value) {
          $data[$key] = $value;
        }
      }
      // encoding the request data as JSON which will be sent in POST
      $encodedData = json_encode($data);

      // initiate curl with the url to send request
      $curl = curl_init($url);

      // return CURL response
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

      // Send request data using POST method
      curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

      // Data content-type is sent as JSON
      curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Content-Type:application/json',
        'Authorization:Bearer '.env("API_KEY")
      ));
      curl_setopt($curl, CURLOPT_POST, true);

      // Curl POST the JSON data to send the request
      curl_setopt($curl, CURLOPT_POSTFIELDS, $encodedData);

      // execute the curl POST request and send data
      $response = curl_exec($curl);
      curl_close($curl);

      $response = (array)json_decode($response);
    }
    catch(\Throwable $th){
      $response = array('result'=>'failed');
    }
    return $response;
  }


  /**=============      signIn       ===============================================**/
  public static function signIn( $email, $password )
  {
    try
    {
      $response = Http::withHeaders([
        'Content-Type' => 'application/json',
        'Authorization' => "Bearer ".env('API_KEY')
      ])->post("https://xapiserver.com/v4/signin/",  [
        'email_address' => $email,
        'password' => $password,
      ]);
      if( $response["result"] === "success"){
        session()->put('auth_token', $response['signinResponse']['auth_token']);
        session()->put("email", $email);
      }
    }
    catch (\Throwable $th) {
      $response = array('result'=>'failed');
    }
    return $response;
  }

  public static function signInForAjax( $email, $password ): array
  {
    try
    {
      $params = array('password' => $password);
      $response = self::baseApiCall("https://xapiserver.com/v4/signin/", $params);
      if( $response["result"] === "success"){
        session()->put('auth_token', $response['signinResponse']->auth_token);
        session()->put("email", $email);
      }
    }
    catch (\Throwable $th) {
      $response = array('result'=>'failed');
    }
    return $response;
  }

  /**=============      wallet Balance       ===============================================**/
  public static function walletBalance()
  {
    if( !auth()->check())
      return redirect()->route('login');

    try
    {
      $response = Http::withHeaders([
        'Content-Type' => 'application/json',
        'Authorization' => trim('Bearer ' . env("API_KEY")),
      ])->post("https://xapiserver.com/v4/walletBalance/",  [
        'email_address' => trim(session()->get("email")),
        'auth_token' => trim(session()->get("auth_token"))
      ]);
    }
    catch (\Throwable $th) {
      $response = array('result'=>'failed');
    }
    return $response;
  }

  public static function walletBalanceForAjax(): array
  {
    if( !auth()->check())
      return array('result'=>'require_login');

    try
    {
      $response = self::baseApiCall("https://xapiserver.com/v4/walletBalance/");
    }
    catch (\Throwable $th) {
      $response = array('result'=>'failed');
    }
    return $response;
  }

  /**=============      old Balance Correction       =========================================**/
  public static function balanceCorrection($email_address, $amount, $currency, $comment)
  {
    if( !auth()->check())
      return redirect()->route('login');

    try
    {
      $response = Http::withHeaders([
        'Content-Type' => 'application/json',
        'Authorization' => trim('Bearer ' . env("API_KEY")),
      ])->post("https://xapiserver.com/v4/balanceCorrection/",  [
        'email_address' => $email_address,
        'amount' => $amount,
        'currency' => $currency,
        'comment' => $comment,
        'auth_token' => trim(session()->get("auth_token")),
        'version' => 'sec.2.0.0.1'
      ]);
    }
    catch (\Throwable $th) {
      $response = array('result'=>'failed');
    }
    return $response;
  }

  public static function balanceCorrectionForAjax( $params ): array
  {
    if( !auth()->check())
      return array('result'=>'require_login');

    try
    {
      $response = self::baseApiCall("https://xapiserver.com/v4/balanceCorrection/", $params);
    }
    catch (\Throwable $th) {
      $response = array('result'=>'failed');
    }
    return $response;
  }

  /**=============      new Balance Correction       =========================================**/
  public static function balanceCorrection2(
    $email_address,
    $amount,
    $target_address,
    $target_account_currency,
    $target_user_id,
    $target_account_id,
    $comment)
  {
    if( !auth()->check())
      return redirect()->route('login');

    try
    {
      $response = Http::withHeaders([
        'Content-Type' => 'application/json',
        'Authorization' => trim('Bearer ' . env("API_KEY")),
      ])->post("https://xapiserver.com/v4/balanceCorrection2/",  [
        'email_address' => $email_address,
        'auth_token' => trim(session()->get("auth_token")),
        'amount' => $amount,
        'target_address' => $target_address,
        'target_account_currency' => $target_account_currency,
        'target_user_id' => $target_user_id,
        'target_account_id' => $target_account_id,
        'comment' => $comment,
        'version' => 'sec.2.0.0.1'
      ]);
    }
    catch (\Throwable $th) {
      $response = array('result'=>'failed');
    }
    return $response;
  }

  public static function balanceCorrection2ForAjax( $params ): array
  {
    if( !auth()->check())
      return array('result'=>'require_login');

    try
    {
      $response = self::baseApiCall("https://xapiserver.com/v4/balanceCorrection2/", $params);
    }
    catch (\Throwable $th) {
      $response = array('result'=>'failed');
    }
    return $response;
  }

  /**=============      search User's Wallet       =========================================**/
  public static function searchUserWallet($email_address, $user_list)
  {
    if( !auth()->check())
      return redirect()->route('login');

    try
    {
      $response = Http::withHeaders([
        'Content-Type' => 'application/json',
        'Authorization' => trim('Bearer ' . env("API_KEY")),
      ])->post("https://xapiserver.com/v4/searchUserWallet/",  [
        'email_address' => $email_address,
        'auth_token' => trim(session()->get("auth_token")),
        'user_list' => $user_list
      ]);
    }
    catch (\Throwable $th) {
      $response = array('result'=>'failed');
    }
    return $response;
  }

  public static function searchUserWalletForAjax( $params ): array
  {
    if( !auth()->check())
      return array('result'=>'require_login');

    try
    {
      $response = self::baseApiCall("https://xapiserver.com/v4/searchUserWallet/", $params);
    }
    catch (\Throwable $th) {
      $response = array('result'=>'failed');
    }
    return $response;
  }

  public static function getAuthToken()
  {
    $response = array('result'=>'failed');
    $retries = 3;
    while($response['result'] != 'success' && $retries > 0 ){
      Log::info("getAuthToken Request:     >>>>>>>>>>>>>>>>>>>>>>");
      Log::info("           Content-Type:application/json");
      Log::info("           Authorization:".'Bearer ' . env("API_KEY"));
      Log::info("           email_address:".session()->get("email"));
      Log::info("           merchant:".session()->get("merchant"));

      try
      {
        $api_key = 'Bearer ' . env("API_KEY");
        $response = Http::withHeaders([
          'Content-Type' => 'application/json',
          'Authorization' => $api_key,
        ])->post("https://xapiserver.com/v4/getAuthToken/",  [
          'email_address' => trim(session()->get("email")),
          'merchant' => trim(session()->get("merchant"))
        ]);
        Log::info("           response:".$response);
        if ($response["result"] === "success") {
          session()->put('auth_token', $response['authResponse']['auth_token']);
          session()->put('user_id', $response['authResponse']['user_id']);
          session()->put('accounts', $response['authResponse']['accounts']);
        }
      }
      catch (\Throwable $th) {
        Log::info("!!!!!!!!!!!!! getAuthToken working EXCEPTION:     >>>>>>>>>>>>>>>>>>>>>>".$th);
        $response = array('result'=>'failed');
      }
      $retries--;
    }
    return $response;
  }

  public static function getUserInfo()
  {
    $response = array('result'=>'failed');
    $retries = 3;
    while($response['result'] != 'success' && $retries > 0 ) {
      Log::info("getUserInfo Request:     >>>>>>>>>>>>>>>>>>>>>>");
      Log::info("           Content-Type:application/json");
      Log::info("           Authorization:".'Bearer ' . env("API_KEY"));
      Log::info("           email_address:".session()->get("email"));
      Log::info("           auth_token:".session()->get("auth_token"));

      try
      {
        $response = Http::withHeaders([
          'Content-Type' => 'application/json',
          'Authorization' => 'Bearer '.env("API_KEY")
        ])->post("https://xapiserver.com/v4/userInfo/",  [
          'email_address' => session()->get("email"),
          'auth_token' => session()->get("auth_token")
        ]);
        Log::info("           response:".$response);
      }
      catch (\Throwable $th) {
        Log::info("!!!!!!!!!!!!! getUserInfo working EXCEPTION:     >>>>>>>>>>>>>>>>>>>>>>".$th);
        $response = array('result'=>'failed');
      }
      $retries--;
    }
    return $response;
  }
}

