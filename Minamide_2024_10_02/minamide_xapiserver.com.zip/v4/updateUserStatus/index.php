<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
  function getallheaders()
  {
    if (!is_array($_SERVER)) {
      return array();
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
      if (substr($name, 0, 5) == 'HTTP_') {
        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
      }
    }
    return $headers;
  }
}

function _log($email, $line) {
  if ($email == "") {
    $fh2 = fopen(dirname(__FILE__) . "/log/update_user_status.log" , 'a');
  } else {
    $fh2 = fopen(dirname(__FILE__) . "/log/" . $email . ".log" , 'a');
  }
  $fline = date('[Ymd H:i:s] ') . $line."\n";
  fwrite($fh2, $fline);
  fclose($fh2);
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../classes/PHPMailer/src/Exception.php';
require '../classes/PHPMailer/src/PHPMailer.php';
require '../classes/PHPMailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_once '../include/dbconfig.php';
  $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
  if (mysqli_connect_errno() != 0) {
    header('Content-Type: application/json');
    http_response_code(500);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
    echo json_encode($ret_rs);
    die();
  } else {
    _log("", "ket noi thanh cong");
    mysqli_query($dbhandle, "set names utf8;");
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
  $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
  $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
  $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
  $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret4 = 'climbpot api access key';
  $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
  $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
  $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
  $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
  $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
  $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
  //$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
  $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
  $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
  $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
  $apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
  $found = 0;
  $coin = 'USDT';
  $sandbox = 0;
  $partner = "";
  $allowed_deposit_currency_arr = array('USDT');
  $req_api_key = "";
  $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

  foreach (getallheaders() as $name => $value) {
    if ($name == 'Authorization') {
      $req_api_key = trim($value);
      $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
      $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
      if (mysqli_num_rows($partner_rs) > 0) {
        while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
          $cur_api_key = "Bearer " . $row_partner['api_key'];
          if ($req_api_key == $cur_api_key) {
            $req_partner['partner'] = trim($row_partner['partner']);
            $req_partner['api_key'] = trim($row_partner['api_key']);
            $req_partner['website'] = trim($row_partner['website']);
            $selected_api_key = $req_api_key;
            break;
          }
        }
      } else {
        _log("", "not found in db");
      }
    }
  }

  function generateRandomString($length, $bitmask) {
    $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $lowercase = 'abcdefghijklmnopqrstuvwxyz';
    $numbers = '0123456789';
    $characters = '';
    $characters .= $uppercase . $lowercase . $numbers;
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
      $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
  }

  function validateDate($date, $format = 'Y-m-d H:i:s'){
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
  }

  function isValidPassword($password) {
    if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
      return FALSE;
    return TRUE;
  }

  if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    if (!($data)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          _log("", 'Reached the maximum stack depth');
          break;
        case JSON_ERROR_STATE_MISMATCH:
          _log("", 'Incorrect discharges or mismatch mode');
          break;
        case JSON_ERROR_CTRL_CHAR:
          _log("", 'Incorrect control character');
          break;
        case JSON_ERROR_SYNTAX:
          _log("", 'Syntax error or JSON invalid');
          break;
        case JSON_ERROR_UTF8:
          _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
          break;
        default:
          _log("", 'Unknown error');
          break;
      }

      _log("", 'A non-empty request body is required.');
      header('Content-Type: application/json');
      http_response_code(400);
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
      echo json_encode($ret_rs);
      die();
    } else {
      unset($errors);
      $errors = array();

      //email_address
      if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
        $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
        $errors[] = $error_obj;
      } else {
        $email_address = mysqli_real_escape_string($dbhandle, trim($data['email_address']));
      }

      //auth_token
      if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
        $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
        $errors[] = $error_obj;
      } else {
        $private_key = mysqli_real_escape_string($dbhandle, trim($data['auth_token']));
      }

      if ((isset($data['status']['kyc_status'])) && (!empty($data['status']['kyc_status']))) {
        $kyc_status = mysqli_real_escape_string($dbhandle, trim($data['status']['kyc_status']));
      } else if ($data['status']['kyc_status'] === 0 || $data['status']['kyc_status'] === "0"){
        $kyc_status = "0";
      }

      if ((isset($data['status']['card_activation_status'])) && (!empty($data['status']['card_activation_status']))) {
        $card_activation_status = mysqli_real_escape_string($dbhandle, trim($data['status']['card_activation_status']));
      } else if ($data['status']['card_activation_status'] === 0 || $data['status']['card_activation_status'] === "0"){
        $card_activation_status = "0";
      }

      if ((isset($data['status']['card_status'])) && (!empty($data['status']['card_status']))) {
        $card_status = mysqli_real_escape_string($dbhandle, trim($data['status']['card_status']));
      } else if ($data['status']['card_status'] === 0 || $data['status']['card_status'] === "0"){
        $card_status = "0";
      }

      if ((isset($data['status']['payment_status'])) && (!empty($data['status']['payment_status']))) {
        $payment_status = mysqli_real_escape_string($dbhandle, trim($data['status']['payment_status']));
      } else if ($data['status']['payment_status'] === 0 || $data['status']['payment_status'] === "0"){
        $payment_status = "0";
      }

      if ((isset($data['status']['kyc_file_url'])) && (!empty($data['status']['kyc_file_url']))) {
        $kyc_file_url = mysqli_real_escape_string($dbhandle, trim($data['status']['kyc_file_url']));
      }

      if ((isset($data['status']['card_activation_file_url'])) && (!empty($data['status']['card_activation_file_url']))) {
        $card_activation_file_url = mysqli_real_escape_string($dbhandle, trim($data['status']['card_activation_file_url']));
      }

      if ((isset($data['status']['kyc_upload_date'])) && (!empty($data['status']['kyc_upload_date']))) {
        $kyc_upload_dt = date('Y-m-d H:i:s');
      }

      if ((isset($data['status']['kyc_admin_date'])) && (!empty($data['status']['kyc_admin_date']))) {
        $kyc_admin_dt = date('Y-m-d H:i:s');
      }

      if ((isset($data['status']['card_activation_upload_date'])) && (!empty($data['status']['card_activation_upload_date']))) {
        $card_activation_upload_dt = date('Y-m-d H:i:s');
      }

      if ((isset($data['status']['card_activation_admin_date'])) && (!empty($data['status']['card_activation_admin_date']))) {
        $card_activation_admin_dt = date('Y-m-d H:i:s');
      }

      if ((isset($data['status']['card_issue_date'])) && (!empty($data['status']['card_issue_date']))) {
        $card_issue_dt = date('Y-m-d H:i:s');
      }

      if ((isset($data['status']['payment_date'])) && (!empty($data['status']['payment_date']))) {
        $payment_dt = date('Y-m-d H:i:s');
      }

      _log($email_address, "update status dataseted...");
      if (count($errors) == 0) {
        $errors_sub = array();
        require_once '../include/common.php';
        _log($email_address, "update status started...");
        $allow_access_api = 0;
        $my_db_private_key = '';
        $sql_check_signin = "select a.*, b.shift_user_id, b.shift_client_user_id  from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b where a.email_address = '$email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_email_address";
        $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
        if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
          $allow_access_api = 1;
          while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
            $my_db_private_key = trim($row_signin['private_key']);
          }
        }

        if ($allow_access_api == 1) {
          if ($private_key != $my_db_private_key) {
            _log($email_address, "update status failed...private_key != my_db_private_key");
            @mysqli_close($dbhandle);
            header('Content-Type: application/json');
            http_response_code(500);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'Unauthorized.');
            echo json_encode($ret_rs);
            die();
          } else {
            _log($email_address, "private_key ok");

            // Check member card status.
            $memberCardStatus = 0;
            $sql_check_user_member_card_status = "SELECT * FROM cryptocash_jdb_debit_card WHERE email_address = '$email_address' AND created_from='" . $req_partner['partner'] . "'";
            _log($email_address, "check member_card sql: $sql_check_user_member_card_status");
            $rs_check_user_member_card_status = mysqli_query($dbhandle, $sql_check_user_member_card_status);
            if (mysqli_num_rows($rs_check_user_member_card_status) > 0) {
              while ($row_member_card_status = mysqli_fetch_array($rs_check_user_member_card_status, MYSQLI_ASSOC)) {
                $memberCardStatus = (int)trim($row_member_card_status['member_card']);
              }
            }

            // Check user status
            $old_kyc_status = 0;
            $old_card_activation_status = 0;
            $old_card_status = 0;
            $old_payment_status = 0;

            $sql_check_user_status = "SELECT * FROM cryptocash_user_status WHERE email_address = '$email_address' AND created_from='" . $req_partner['partner'] . "'";
            $rs_check_user_status = mysqli_query($dbhandle, $sql_check_user_status);
            if (mysqli_num_rows($rs_check_user_status) > 0) {
              while ($row_user_status = mysqli_fetch_array($rs_check_user_status, MYSQLI_ASSOC)) {
                $old_kyc_status = trim($row_user_status['kyc_status']);
                $old_card_activation_status = trim($row_user_status['card_activation_status']);
                $old_card_status = trim($row_user_status['card_status']);
                $old_payment_status = trim($row_user_status['payment_status']);
                $old_kyc_file_url = trim($row_user_status['kyc_file_url']);
                $old_card_activation_file_url = trim($row_user_status['card_activation_file_url']);
                $old_kyc_upload_dt = $row_user_status['kyc_upload_dt'];
                $old_kyc_admin_dt = $row_user_status['kyc_admin_dt'];
                $old_card_activation_upload_dt = $row_user_status['card_activation_upload_dt'];
                $old_card_activation_admin_dt = $row_user_status['card_activation_admin_dt'];
                $old_card_issue_dt = $row_user_status['card_issue_dt'];
                $old_payment_dt = $row_user_status['payment_dt'];
              }
              _log($email_address, "try update status...");
              $set_flag = 0;
              _log($email_address, " old_kyc_status ...".$old_kyc_status);
              _log($email_address, " set_kyc_status ...".isset($kyc_status));
              if(isset($kyc_status)){
                $set_kyc_status = ", `kyc_status` = '$kyc_status'";
                $set_flag = 1;
              } else {
                $set_kyc_status ="";
                $kyc_status = $old_kyc_status;
              }
              _log($email_address, " set_kyc_status ...".$set_kyc_status);
              if(isset($card_activation_status)){
                $set_card_activation_status = ", `card_activation_status` = '$card_activation_status'";
                $set_flag = 1;
              } else {
                $set_card_activation_status ="";
                $card_activation_status = $old_card_activation_status;
              }
              if(isset($card_status)){
                $set_card_status = ", `card_status` = '$card_status'";
                $set_flag = 1;
              } else {
                $set_card_status ="";
                $card_status = $old_card_status;
              }
              if(isset($payment_status)){
                $set_payment_status = ", `payment_status` = '$payment_status'";
                $set_flag = 1;
              } else {
                $set_payment_status ="";
                $payment_status = $old_payment_status;
              }
              if(isset($kyc_file_url)){
                $set_kyc_file_url = ", `kyc_file_url` = '$kyc_file_url'";
                $set_flag = 1;
              } else {
                $set_kyc_file_url ="";
                $kyc_file_url = $old_kyc_file_url;
              }
              if(isset($card_activation_file_url)){
                $set_card_activation_file_url = ", `card_activation_file_url` = '$card_activation_file_url'";
                $set_flag = 1;
              } else {
                $set_card_activation_file_url ="";
                $card_activation_file_url = $old_card_activation_file_url;
              }
              if(isset($kyc_upload_dt)){
                $set_kyc_upload_dt = ", `kyc_upload_dt` = '$kyc_upload_dt'";
                $set_flag = 1;
              } else {
                $set_kyc_upload_dt ="";
                $kyc_upload_dt = $old_kyc_upload_dt;
              }
              if(isset($kyc_admin_dt)){
                $set_kyc_admin_dt = ", `kyc_admin_dt` = '$kyc_admin_dt'";
                $set_flag = 1;
              } else {
                $set_kyc_admin_dt ="";
                $kyc_admin_dt = $old_kyc_admin_dt;
              }
              if(isset($card_activation_upload_dt)){
                $set_card_activation_upload_dt = ", `card_activation_upload_dt` = '$card_activation_upload_dt'";
                $set_flag = 1;
              } else {
                $set_card_activation_upload_dt ="";
                $card_activation_upload_dt = $old_card_activation_upload_dt;
              }
              if(isset($card_activation_admin_dt)){
                $set_card_activation_admin_dt = ", `card_activation_admin_dt` = '$card_activation_admin_dt'";
                $set_flag = 1;
              } else {
                $set_card_activation_admin_dt ="";
                $card_activation_admin_dt = $old_card_activation_admin_dt;
              }
              if(isset($card_issue_dt)){
                $set_card_issue_dt = ", `card_issue_dt` = '$card_issue_dt'";
                $set_flag = 1;
              } else {
                $set_card_issue_dt ="";
                $card_issue_dt = $old_card_issue_dt;
              }
              if(isset($payment_dt)){
                $set_payment_dt = ", `payment_dt` = '$payment_dt'";
                $set_flag = 1;
              } else {
                $set_payment_dt ="";
                $payment_dt = $old_payment_dt;
              }

              _log($email_address, "set_flag ".$set_flag);

              // Check this use is normal card user or member card one.
              $cardType = 0;// means new user that did not try to issue any card

              try{
                // Retrieve $member_card value or set default if omitted
                $member_card = isset($data['member_card']) ? $data['member_card'] : null;

                if ($memberCardStatus != 0) {
                  if ($member_card === null) {
                    if($set_flag == 1){
                      // This does not make sense
                      throw new Exception('Invalid request: The member_card should not be omitted because you are in member card processing.');
                    }
                  }
                  $cardType = 2;
                } else {
                  if ($member_card == 1) {
                    if ($old_kyc_status != 0 || $old_card_activation_status != 0 || $old_card_status != 0 || $old_payment_status != 0) {
                      // This does not make sense
                      throw new Exception('Invalid request: The member_card can not be 1 because you are in normal card processing.');
                    }
                    $cardType = 2;
                  } elseif ($member_card === null || $member_card == 0) {
                    if ($old_kyc_status != 0 || $old_card_activation_status != 0 || $old_card_status != 0 || $old_payment_status != 0) {
                      $cardType = 1;
                    } else {
                      $cardType = 0;
                    }
                  } else {
                    // Handle any unexpected values for $member_card
                    throw new Exception('Invalid request: Unexpected value for member_card.');
                  }
                }
              }
              catch(\Exception $e){
                _log($email_address, "update failed :: invalid card type. memberCardStatus: $memberCardStatus, member_card: $member_card, error: $e");
                @mysqli_close($dbhandle);
                header('Content-Type: application/json');
                http_response_code(500);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 18, 'errorMessage' => "invalid card type. memberCardStatus: $memberCardStatus, member_card: $member_card, error: $e");
                echo json_encode($ret_rs);
                die();
              }

              if ($set_flag == 1) {
                $sql_update_user_status = "UPDATE `cryptocash_user_status` SET `email_address` = '$email_address'".
                  $set_kyc_status.
                  $set_card_activation_status.
                  $set_card_status.
                  $set_payment_status.
                  $set_kyc_file_url.
                  $set_card_activation_file_url.
                  $set_kyc_upload_dt.
                  $set_kyc_admin_dt.
                  $set_card_activation_upload_dt.
                  $set_card_activation_admin_dt.
                  $set_card_issue_dt.
                  $set_payment_dt.
                  " WHERE `email_address` = '$email_address' AND created_from='" . $req_partner['partner'] . "'";
                _log($email_address, "sql_update_user_status ::  ".$sql_update_user_status);
                if (!mysqli_query($dbhandle, $sql_update_user_status)) {
                  _log($email_address, "update failed :: " . $sql_update_user_status);
                  @mysqli_close($dbhandle);
                  header('Content-Type: application/json');
                  http_response_code(500);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'error occurred. please contact administrator for help.');
                  echo json_encode($ret_rs);
                  die();
                }

                if( $cardType == 2 ){
                  $sql_update_member_card_status = "UPDATE `cryptocash_jdb_debit_card` 
                        SET `member_card` = 1 
                        WHERE `email_address` = '$email_address' 
                          AND created_from='" . $req_partner['partner'] . "'";
                  _log($email_address, "sql_update_member_card_status ::  ".$sql_update_member_card_status);
                  if (!mysqli_query($dbhandle, $sql_update_member_card_status)) {
                    _log($email_address, "update failed :: " . $sql_update_member_card_status);
                    @mysqli_close($dbhandle);
                    header('Content-Type: application/json');
                    http_response_code(500);
                    $ret_rs['result'] = 'failed';
                    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'error occurred. please contact administrator for help. 2');
                    echo json_encode($ret_rs);
                    die();
                  }
                }

                // send kyc mail
                if($set_kyc_status != "" && $kyc_status == 1){
                  $sql = "SELECT name_romaji FROM cryptocash_jdb_profile WHERE email_address='{$email_address}' AND created_from='{$req_partner['partner']}'";
                  $result = mysqli_query($dbhandle, $sql);
                  $row = mysqli_fetch_assoc($result);
                  _log($email_address,'name_romaji :: '.$row['name_romaji']);
                  send_kyc_mail($email_address,$row['name_romaji'],$req_partner['partner']);
                }
                @mysqli_close($dbhandle);
              }

              if (!is_null($kyc_upload_dt)) {
                $kyc_upload_dt = date('Y/m/d H:i:s', strtotime($kyc_upload_dt));
              }
              if (!is_null($kyc_admin_dt)) {
                $kyc_admin_dt = date('Y/m/d H:i:s', strtotime($kyc_admin_dt));
              }
              if (!is_null($card_activation_upload_dt)) {
                $card_activation_upload_dt = date('Y/m/d H:i:s', strtotime($card_activation_upload_dt));
              }
              if (!is_null($card_activation_admin_dt)) {
                $card_activation_admin_dt = date('Y/m/d H:i:s', strtotime($card_activation_admin_dt));
              }
              if (!is_null($card_issue_dt)) {
                $card_issue_dt = date('Y/m/d H:i:s', strtotime($card_issue_dt));
              }
              if (!is_null($payment_dt)) {
                $payment_dt = date('Y/m/d H:i:s', strtotime($payment_dt));
              }

              header('Content-Type: application/json');
              $ret_rs['result'] = 'success';
              $ret_status_arr = array();
              $ret_status_arr['email_address'] = $email_address;
              $ret_status_arr['kyc_status'] = (int)$kyc_status;
              $ret_status_arr['card_activation_status'] = (int)$card_activation_status;
              $ret_status_arr['card_status'] = (int)$card_status;
              $ret_status_arr['payment_status'] = (int)$payment_status;
              $ret_status_arr['kyc_file_url'] = $kyc_file_url;
              $ret_status_arr['card_activation_file_url'] = $card_activation_file_url;
              $ret_status_arr['kyc_upload_date'] = $kyc_upload_dt;
              $ret_status_arr['kyc_admin_date'] = $kyc_admin_dt;
              $ret_status_arr['card_activation_upload_date'] = $card_activation_upload_dt;
              $ret_status_arr['card_activation_admin_date'] = $card_activation_admin_dt;
              $ret_status_arr['card_issue_date'] = $card_issue_dt;
              $ret_status_arr['payment_date'] = $payment_dt;
              $ret_status_arr['member_card_status'] = (int)$memberCardStatus;
              $ret_status_arr['card_type'] = (int)$cardType;
              $ret_rs['updateStatusResponse'] = $ret_status_arr;
              _log($email_address, "update success :: ".json_encode($ret_rs));
              echo json_encode($ret_rs);
              die();
            }
          }
        } else {
          _log($email_address, "update failed :: you must sign in to use this API.");
          @mysqli_close($dbhandle);
          header('Content-Type: application/json');
          http_response_code(500);
          $ret_rs['result'] = 'failed';
          $ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'you must sign in to use this API.');
          echo json_encode($ret_rs);
          die();
        }
      } else {
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = $errors;
        _log($email_address, "update failed :: ".$errors);
        header('Content-Type: application/json');
        echo json_encode($ret_rs);
        die();
      }
    }
  } else {
    header('HTTP/1.0 403 Forbidden');
  }
} else {
  http_response_code(405);
  die();
}

function send_kyc_mail($email_address,$profile_name,$creted_from){
  $domain = 'ultimopay.io';

  // send mail
  $mail = new PHPMailer(true);
  try {
    //Server settings
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'mail.privateemail.com';                // Set the SMTP server to send through
    $mail->Mailer   = 'smtp';
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'info@controladmin.xyz';                // SMTP username
    $mail->Password   = 'qK2YiPXe';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    //Recipients
    $mail->setFrom('info@controladmin.xyz', 'KYC-control');
    $mail->addBCC('verification@'.$domain);
    $mail->addAddress('cs2014bonz@gmail.com');
    $mail->addReplyTo('info@controladmin.xyz', 'KYC-control');

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $confirm_body  = "<!DOCTYPE html";
    $confirm_body  .= "    PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">";
    $confirm_body  .= "<html xmlns:v=\"urn:schemas-microsoft-com:vml\">";
    $confirm_body  .= "<head></head>";
    $confirm_body  .= "<body class=\"respond\" leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" marginheight=\"0\">";
    $confirm_body  .= "<p>We have received a request for KYC.</p>";
    $confirm_body  .= "<p>Please respond to the request.</p>";
    $confirm_body  .= "<p>USER: " . $profile_name . "</p>";
    $confirm_body  .= "</body>";
    $confirm_body  .= "</html>";
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    _log($email_address, $confirm_body);
    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = "A REQUEST FOR KYC";
    $mail->Body    = $confirm_body;
    if(!$mail->Send())
    {
      _log($email_address, $mail->ErrorInfo);
    }
    else
    {
      _log($email_address, "has been sent");
    }

  } catch (Exception $e) {
    _log($email_address,"could not be sent. Mailer Error: {$mail->ErrorInfo}");
  }
}
?>