<?php
include_once( '../include/common.php');
include_once('../classes/PostAffiliatePro/PapApi.class.php');

$POST_AFFILIATE_PRO_SERVER_URL = "https://ultimopay.postaffiliatepro.com/scripts/server.php";
$POST_AFFILIATE_PRO_LOGIN_EMAIL = "technologiescrypto2022@gmail.com";
$POST_AFFILIATE_PRO_LOGIN_PWD = "DU1g4B4M";

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getAllHeaders'))  {
    function getAllHeaders(): array
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(
                    ' ', '-', ucwords(
                    strtolower(
                        str_replace(
                            '_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
    $fh2 = null;
    try {
        if ($email == "") {
            if( file_exists("/var/www/api.ultimopay.io/v1/getAffiliateReport/log/afffiliate_report.log")){
                $fh2 = fopen("/var/www/api.ultimopay.io/v1/getAffiliateReport/log/afffiliate_report.log", 'a');
            }
        } else {
            if( file_exists("/var/www/api.ultimopay.io/v1/getAffiliateReport/log/" . $email . ".log")){
                $fh2 = fopen("/var/www/api.ultimopay.io/v1/getAffiliateReport/log/" . $email . ".log", 'a');
            }
        }
        $fLine = date('[Ymd H:i:s] ') . $line . "\n";
        if ($fh2) {
            fwrite($fh2, $fLine);
            fclose($fh2);
        }
    }
    catch (Exception $e){

    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../include/dbconfig.php';
    $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (mysqli_connect_errno() != 0) {
        header('Content-Type: application/json');
        http_response_code(500);
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
        echo json_encode($ret_rs);
        die();
    } else {
        _log("", "ket noi thanh cong");
        mysqli_query($dbhandle, "set names utf8;");
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
    $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
    $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
    $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
    $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
    $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
    $clientSecret4 = 'climbpot api access key';
    $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
    $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
    $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
    $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
    $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
    $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
    $apikey5 = 'ApiKey ' . base64_encode(':'/*$clientSecret5*/);
    $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
    $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
    $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
    $apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
    $found = 0;
    $coin = 'USDT';
    $sandbox = 0;
    $partner = "";
    $allowed_deposit_currency_arr = array('USDT');
    $req_api_key = "";
    $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

    foreach (getAllHeaders() as $name => $value) {
        if ($name == 'Authorization') {
            $req_api_key = trim($value);
            $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
            $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
            if (mysqli_num_rows($partner_rs) > 0) {
                while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
                    $cur_api_key = "Bearer " . $row_partner['api_key'];
                    if ($req_api_key == $cur_api_key) {
                        $req_partner['partner'] = trim($row_partner['partner']);
                        $req_partner['api_key'] = trim($row_partner['api_key']);
                        $req_partner['website'] = trim($row_partner['website']);
                        $selected_api_key = $req_api_key;
                        break;
                    }
                }
            } else {
                _log("", "not found in db");
            }
        }
    }

    function isValidPassword($password): bool
    {
        if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
            return FALSE;
        return TRUE;
    }

    if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

        $json = file_get_contents('php://input');
        $strJSON = preg_replace('/\: *([0-9]+\.?[0-9e+\-]*)/', ':"\\1"', $json);
        $data = json_decode($strJSON, true );
        if (!($data)) {

            switch (json_last_error()) {
                case JSON_ERROR_DEPTH:
                    //$failed_rs['error'] = 'Reached the maximum stack depth';
                    _log("", 'Reached the maximum stack depth');
                    break;
                case JSON_ERROR_STATE_MISMATCH:
                    //$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
                    _log("", 'Incorrect discharges or mismatch mode');
                    break;
                case JSON_ERROR_CTRL_CHAR:
                    //$failed_rs['error'] = 'Incorrect control character';
                    _log("", 'Incorrect control character');
                    break;
                case JSON_ERROR_SYNTAX:
                    //$failed_rs['error'] = 'Syntax error or JSON invalid';
                    _log("", 'Syntax error or JSON invalid');
                    break;
                case JSON_ERROR_UTF8:
                    //$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
                    _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
                    break;
                default:
                    //$failed_rs['error'] = 'Unknown error';
                    _log("", 'Unknown error');
                    break;
            }

            _log("", 'A non-empty request body is required.');
            header('Content-Type: application/json');
            http_response_code(400);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
            echo json_encode($ret_rs);
            die();

        } else {
            unset($errors);
            $errors = array();

            //email
            if (empty($data['email_address'])) {
                $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
                $errors[] = $error_obj;
            }

            //auth_token
            if (empty($data['auth_token'])) {
                $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
                $errors[] = $error_obj;
            }

            //auth_token
            if (empty($data['affiliate_name'])) {
                $error_obj = array('errorCode' => 4, 'errorMessage' => 'affiliate_name parameter is required.');
                $errors[] = $error_obj;
            }

            if (count($errors) == 0) {

                $errors_sub = array();

                //proceed to shift api
                require_once '../include/common.php';
                ////////////////////////////////////////////////////
                //receive POST params
                $reg_email_address = trim($data['email_address']);
                $private_key = trim($data['auth_token']);
                $affiliate_name = trim($data['affiliate_name']);

                _log($reg_email_address, "getting started affiliate report data...");

                $allow_access_api = 0;
                $my_db_private_key = '';
                $sql_check_signin = "select a.*, b.*, c.debit_card_id, c.acc_no, c.debit_card_num 
                                        from cryptocash_merchant_user_signin a, cryptocash_shift_wallet b, cryptocash_jdb_debit_card c 
                                        where a.email_address = '".$reg_email_address."' 
                                          AND a.merchant='" . $req_partner['partner'] . "' 
                                          AND a.email_address = b.shift_login_email";
                _log($reg_email_address, $sql_check_signin);
                $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
                if (mysqli_num_rows($rs_check_signin) > 0) { //allow access API
                    $allow_access_api = 1;
                    while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
                        $my_db_private_key = trim($row_signin['private_key']);
                    }
                }

                if ($allow_access_api == 1) {

                    if ($private_key != $my_db_private_key) {
                        returnFailed($dbhandle, 6, 'Unauthorized.');
                    }
                    else {
                        // auto update api.class.php
                        if (isUpdateNeeded()) {
                            $updateError = updatePapApiFile();
                            if( strlen($updateError) != 0 ){
                                returnFailed( $dbhandle, 7, $updateError);
                            }
                        }

                        // log the post affiliate pro in.
                        try {
                            $raw_pap_merchant_login_obj = PapLogin(
                                $POST_AFFILIATE_PRO_SERVER_URL,
                                $POST_AFFILIATE_PRO_LOGIN_EMAIL,
                                $POST_AFFILIATE_PRO_LOGIN_PWD,
                                "merchant");
                            if (empty($raw_pap_merchant_login_obj))
                                returnFailed( $dbhandle, 8, 'Post Affiliate Pro login failed.');
                        }
                        catch (Exception $e) {
                            if (empty($raw_pap_merchant_login_obj))
                                returnFailed( $dbhandle, 8, 'Post Affiliate Pro login failed.');
                        }

                        $result = [];
                        $trans_req = new \Pap_Api_TransactionsGrid($raw_pap_merchant_login_obj);
                        $trans_req->addFilter('username', \Gpf_Data_Filter::EQUALS, $affiliate_name);

                        // list here all columns which you want to read from grid
                        try {
                            $trans_req->addParam('columns', new \Gpf_Rpc_Array(array(
                                array('id'),
                                array('transid'),
                                array('campaignid'),
                                array('orderid'),
                                array('productid'),
                                array('dateinserted'),
                                array('rstatus'),
                                array('payoutstatus'),
                                array('commission'),
                                array('userid'),
                                array('totalcost'),
                                array('firstname'),
                                array('lastname'),
                                array('username'))));
                        }
                        catch (Gpf_Exception $e) {
                            returnFailed( $dbhandle, 9, 'Get column information failed.');
                        }

                        $trans_req->setSorting('dateinserted');
                        $commission_arr = array();
                        $maxRecords = 0;
                        try {
                            do{
                                $trans_req->setLimit($maxRecords, 100);
                                $trans_req->sendNow();
                                $grid = $trans_req->getGrid();
                                $recordset = $grid->getRecordset();
                                $maxRecords += $recordset->getSize();
                                $totalRecords = $grid->getTotalCount();

                                // get Date, orderID, TotalCost, Commission, ProductID, Status, PaidStatus, Affiliater
                                foreach ($recordset as $rec) {
                                    $commission_item = array();
                                    $commission_item['Date'] = $rec->contains('dateinserted') ? $rec->get('dateinserted') : '';
                                    $commission_item['OrderID'] = $rec->contains('orderid') ? $rec->get('orderid') : '';
                                    $commission_item['TotalCost'] = $rec->contains('totalcost') ? $rec->get('totalcost') : '';
                                    $commission_item['Commission'] = $rec->contains('commission') ? $rec->get('commission') : '';
                                    $commission_item['ProductID'] = $rec->contains('productid') ? $rec->get('productid') : '';
                                    $commission_item['Affiliater'] = ($rec->contains('username') && $rec->contains('firstname') && $rec->contains('lastname')) ? ($rec->get('username').', '.$rec->get('firstname').' '.$rec->get('lastname')) : '';
                                    $cur_commission = floatval($rec->contains('commission') ? $rec->get('commission') : 0);
                                    $rstatus = $rec->contains('commission') ? $rec->get('rstatus') : '';
                                    $payoutstatus = $rec->contains('payoutstatus') ? $rec->get('payoutstatus') : '';
                                    if (strtoupper($rstatus) == 'P') {
                                        $commission_item['Status'] = 'PENDING';
                                        $commission_item['PaidStatus'] = 'none';
                                    } else if (strtoupper($rstatus) == 'A') {
                                        $commission_item['Status'] = 'APPROVED';
                                        if (strtoupper($payoutstatus) == 'U') {
                                            $commission_item['PaidStatus'] = 'UNPAID';
                                        } else {
                                            $commission_item['PaidStatus'] = 'PAID';
                                        }
                                    } else {
                                        $commission_item['Status'] = 'DECLINE';
                                        $commission_item['PaidStatus'] = 'none';
                                    }

                                    $commission_arr[] = $commission_item;
                                }
                            }
                            while($maxRecords != $totalRecords);

                            // response success
                            header('Content-Type: application/json');
                            $ret_rs['result'] = 'success';
                            $ret_rs['email_address'] = $reg_email_address;
                            $ret_rs['apiResponse'] = $commission_arr;
                            echo json_encode($ret_rs);
                            die();
                        }
                        catch (Exception $e) {
                            returnFailed( $dbhandle, 10, 'Fetch rows to get affiliate report data failed.');//$e->getMessage();
                        }
                    }
                }
                else {
                    returnFailed($dbhandle, 5, 'you must sign in to use this API.');
                }
            }
            else {
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = $errors[0];
                _log("", $ret_rs['error']['errorMessage']);
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
            }
        }
    }
    else {
        header('HTTP/1.0 403 Forbidden');
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
    http_response_code(405);
    die();
}

function returnFailed($dbHandle, $errorCode, $errorMsg){
    @mysqli_close($dbHandle);
    header('Content-Type: application/json');
    http_response_code(500);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => $errorCode, 'errorMessage' => $errorMsg);
    echo json_encode($ret_rs);
    die();
}


/**==============================  start Auto update for PapApi.class.php  ==============================*/
function getPapUrl(): string
{
    return "https://cryptowire.postaffiliatepro.com/";
}

//name of api file (with path if it is not in the same directory as this script)
function getApiFilename(): string
{
    return __DIR__ . '/../classes/PostAffiliatePro/PapApi.class.php';
}

function getVersionFromPap()
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, getPapUrl() . 'api/version.php');
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $error = curl_error($ch);

    curl_close($ch);
    if (strlen($error)) {
        echo 'Curl error: ' . $error . '; ' . getPapUrl() . 'api/version.php';
        die();
    }
    preg_match('(<versionNumber>*.*<\/versionNumber>)', $response, $matches);
    preg_match('(\d.*<)', $matches[0], $matches);
    if (count($matches) > 0)
        return substr($matches[0], 0, -1);
    else
        return null;
}

function getVersionFromLocalFile()
{
    $apiClassPath = getApiFilename();
    $fileHandler = @fopen($apiClassPath, 'r');

    while (($buffer = @fgets($fileHandler)) !== false) {
        if (preg_match('(PAP version:.*,)', $buffer, $matches)) {
            fclose($fileHandler);
            return substr($matches[0], 13, -1);
        }
    }
    return null;
}

function updatePapApiFile(): string
{
    $retWithError = '';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, getPapUrl() . 'api/download.php');
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $papApiSourcecode = curl_exec($ch);
    $error = curl_error($ch);

    curl_close($ch);
    if (strlen($error)) {
        //echo 'Curl error: ' . $error . '; ' . getPapUrl() . 'api/version.php';
        $retWithError = 'New PapApi.class.php version download failed.';
    }
    else{
        file_put_contents(getApiFilename(), $papApiSourcecode);
    }

    return $retWithError;
}

function isUpdateNeeded(): bool
{
    $oldVersion = getVersionFromLocalFile();
    $curVersion = getVersionFromPap();
    return is_null($curVersion) || $oldVersion != $curVersion;
}
/**==============================  end Auto update for PapApi.class.php  ==============================*/




/**==============================              base api helpers          ==============================
 * @throws Exception
 */
function PapLogin($pap_url, $_username, $_password, $_type)
{
    try {
        if ($_type == "merchant") {
            $_merchant_session = new Pap_Api_Session($pap_url);
            if(!$_merchant_session->login($_username, $_password)) {
                return null;
            }
            return $_merchant_session;
        }
        else if ($_type == "affiliate") {
            $_aff_session = new Pap_Api_Session($pap_url);
            if(!$_aff_session->login($_username,$_password, Gpf_Api_Session::AFFILIATE)) {
                return null;
            }
            return $_aff_session;
        }
    }
    catch (Exception $e){
        return null;
    }
    return null;
}
/**==============================           base api helpers        ==============================*/

