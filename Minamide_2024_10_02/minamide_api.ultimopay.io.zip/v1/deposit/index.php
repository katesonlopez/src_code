<?php
header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
	
	//global $fh;
	if ($email == "") {
		$fh2 = fopen("/var/www/api.ultimopay.io/v1/deposit/log/deposit.log" , 'a');
	} else {
		$fh2 = fopen("/var/www/api.ultimopay.io/v1/deposit/log/" . $email . ".log" , 'a');
	}		
	$fline = date('[Ymd H:i:s] ') . $line."\n";
	fwrite($fh2, $fline);
	fclose($fh2);
	//echo date('[Ymd H:i:s] ').$line."\n";
	//@ob_flush(); 
	//flush();
	
}
	
	
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		_log("", "ket noi thanh cong");
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$partner = '';
	$allowed_deposit_currency_arr = array('USDT', "BTC");
	$allowed_deposit_usdt_network_arr = array('ETHEREUM_ERC20', 'TRON_TRC20', 'BNB_SMART_CHAIN_BEP20');
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	
	foreach (getAllHeaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			/*
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_freelancer) {
				$found = 7;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_bos) {
				$found = 8;
				$coin = 'USDT';
				$partner = "BOS";
				break;
			}
			*/
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
					
				}
			} else {
				_log("", "not found in db");
			}
		}
	}
	@mysqli_close($dbhandle);



	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}


	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	//_log("bat dau xu ly...");
	//if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6) || ($found==7) || ($found==8)) {
	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

		
		
		//$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);
		
		//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
		//echo "payment_id: " . $payment_id . "<br/>";
		$json = file_get_contents('php://input');
		$data = json_decode($json, true);
		
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					//$failed_rs['error'] = 'Reached the maximum stack depth';
					_log("", 'Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					_log("", 'Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					//$failed_rs['error'] = 'Incorrect control character';
					_log("", 'Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					//$failed_rs['error'] = 'Syntax error or JSON invalid';
					_log("", 'Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					//$failed_rs['error'] = 'Unknown error';
					_log("", 'Unknown error');
					break;
			}
			
			//throw new Exception($error);
			//_log($failed_rs['error']);
			_log("", 'A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			}
			
			//auth_token
			if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
				$error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
				$errors[] = $error_obj;
			}
			
			//currency
			if ((!isset($data['currency'])) || (empty($data['currency']))) {
				$error_obj = array('errorCode' => 4, 'errorMessage' => 'currency parameter is required.');
				$errors[] = $error_obj;
			} else {
				if (!in_array(strtoupper($data['currency']), $allowed_deposit_currency_arr)) {
					$error_obj = array('errorCode' => 5, 'errorMessage' => 'unsupported currency');
					$errors[] = $error_obj;
				}
			}
			
			//network (only applied for USDT)
			if (strtoupper($data['currency']) == 'USDT') {
				if ((!isset($data['network'])) || (empty($data['network']))) {
					$error_obj = array('errorCode' => 6, 'errorMessage' => 'network parameter is required for USDT deposit.');
					$errors[] = $error_obj;
				} else {
					if (!in_array(strtoupper($data['network']), $allowed_deposit_usdt_network_arr)) {
						$error_obj = array('errorCode' => 7, 'errorMessage' => 'unsupported USDT blockchain network.');
						$errors[] = $error_obj;
					}
				}
			}
			
			
			if (count($errors) == 0) {
			
				//proceed to shift api
				require_once '../include/common.php';
				//require_once '../include/dbconfig.php';
				
				////////////////////////////////////////////////////
				
				//$allowed_currency_arr = array('USDT');
				
				//receive POST params
				$reg_email_address = trim($data['email_address']);
				$private_key = trim($data['auth_token']);
				$currency = strtoupper(trim($data['currency']));
				$network = strtoupper(trim($data['network']));
				//$user_wallet_arr = array();
				//$wallet_info = array('currency' => '', 'address' => '');
				
				_log($reg_email_address, "get deposit wallet address started...");
				
					
				$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
				if (mysqli_connect_errno() == 0) {
					mysqli_query($dbhandle, "set names utf8;");
					$allow_access_api = 0;
					$merchant = '';
					////$merchant = ($found==6)?'LUCKY8':'';
					//if (($found == 6) || ($found == 7)) {
					//	$merchant = 'UltimoCasino';
					//}
					$cur_private_key = '';
					$cur_wallet_auth_token = '';
					$target_wallet_address = '';
					$cur_db_wallet_address = '';
					$cur_added_dt = '';
					$get_deposit_address_success = 0;
					
					$sql_check_signin = "select a.*, b.shift_account_currency, b.address, b.address_usdt_tron, b.address_usdt_binance, b.network, b.balance, b.added_dt, b.added_dt_tron, b.added_dt_binance from cryptocash_merchant_user_signin a, cryptocash_shift_wallet b where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_login_email";
					$rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
					if (mysqli_num_rows($rs_check_signin) >= 1) { //allow access API
						
						while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
							$cur_shift_currency = trim($row_signin['shift_account_currency']);
							$cur_wallet_auth_token = trim($row_signin['wallet_auth_token']);
							$cur_private_key = trim($row_signin['private_key']);
							if ($cur_shift_currency == $currency) {
								$allow_access_api = 1;
								if ($cur_shift_currency == 'USDT') {
									if ($network=='ETHEREUM_ERC20') {
										$cur_db_wallet_address = trim($row_signin['address']);
										$cur_added_dt = trim($row_signin['added_dt']);
									} else if ($network=='TRON_TRC20') {
										$cur_db_wallet_address = trim($row_signin['address_usdt_tron']);
										$cur_added_dt = trim($row_signin['added_dt_tron']);
									} else if ($network=='BNB_SMART_CHAIN_BEP20') {
										$cur_db_wallet_address = trim($row_signin['address_usdt_binance']);
										$cur_added_dt = trim($row_signin['added_dt_binance']);
									}
								} else {
									$cur_db_wallet_address = trim($row_signin['address']);
									$cur_added_dt = trim($row_signin['added_dt']);
								}
							}
						}
					}
					//@mysqli_close($dbhandle);
					
					if ($allow_access_api == 1) {
						
						if ($private_key != $cur_private_key) {
							@mysqli_close($dbhandle);
							header('Content-Type: application/json');
							http_response_code(500);
							$ret_rs['result'] = 'failed';
							$ret_rs['error'] = array('errorCode' => 9, 'errorMessage' => 'Unauthorized.');
							echo json_encode($ret_rs);
							die();
						} else {
							
							////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							//if ($force_use_api == 1) {
							if ($cur_db_wallet_address == '') {
								/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
								//always try to get deposit wallet address by SHIFT API
								//$nonce = millitime();
								//$nonce = $nonce + 1;
								//$tmp_dto_arr = array();
								$deposit_status_call_retry_cnt = 0;
								$get_wallet_start_tm = time();
								$deposit_post_data = array();
								$deposit_post_data['product'] = $currency;
								if ($currency == 'USDT') {
									if ($network=='ETHEREUM_ERC20') {
										$deposit_post_data['network'] = "Ethereum";
									} else if ($network=='TRON_TRC20') {
										$deposit_post_data['network'] = "Tron";
									} else if ($network=='BNB_SMART_CHAIN_BEP20') {
										$deposit_post_data['network'] = "Binance";
									}
								}							
								
								$authorization_client_value = "Bearer " . $cur_wallet_auth_token;
								/////////////////////////////////////////////////////////////
								$deposit_post_data['exchange'] = "PLUSQO";		
								$deposit_res = api_call('/wallet/deposit/create', 0, '', $deposit_post_data, $authorization_client_value);
								if (($deposit_res['http_code'] == "200") || ($deposit_res['http_code'] == "200 OK")) {
									///////////////////////////////////////////////////////////////////
									//if ($deposit_res['result'] != '') {
										if(isset($deposit_res['result']['txid']) && !empty($deposit_res['result']['txid'])) {
											$deposit_txid = $deposit_res['result']['txid'];
											$deposit_state_hash = $deposit_res['result']['state_hash'];
											_log($reg_email_address, $deposit_post_data['product'] . " / " . $deposit_txid . " / ". $deposit_state_hash);
											
											while ($deposit_status_call_retry_cnt < 2) {
												
												sleep(3);
												unset($req_data);
												$req_data = array();
												$req_data['txid'] = $deposit_txid;
												$req_data['state_hash'] = $deposit_state_hash;
												$req_data['timeout'] = "10000";
												$deposit_status_res = api_call('/wallet/transaction/status', 0,  $req_data, '', $authorization_client_value);
												//$login_res = api_call('/authentication/user_authentication/exchangeToken', 0, '', $post_data);
												if (($deposit_status_res['http_code'] == "200") || ($deposit_status_res['http_code'] == "200 OK")) {
													/////////////////////////////////////////////////////////////////
													//if ($deposit_status_res['result'] != '') {
														if(isset($deposit_status_res['result']['address']) && !empty($deposit_status_res['result']['address'])) {
															$target_wallet_address = $deposit_status_res['result']['address'];
															if ($deposit_post_data['product'] == 'BTC') {
																_log($reg_email_address, "BTC address (time " . $deposit_status_call_retry_cnt . "): " . $target_wallet_address);
																$shift_wallet_added_dt = date('Y-m-d H:i:s');
																$sql_update_signin = "update cryptocash_shift_wallet set address='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='BTC' LIMIT 1";															
															} else if ($deposit_post_data['product'] == 'USDT') {
																_log($reg_email_address, "USDT address (" . $deposit_post_data['network'] . ") (time " . $deposit_status_call_retry_cnt . "): " . $target_wallet_address);
																$shift_wallet_added_dt = date('Y-m-d H:i:s');
																if ($deposit_post_data['network'] == "Ethereum") {
																	$sql_update_signin = "update cryptocash_shift_wallet set address='$target_wallet_address', added_dt='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDT' LIMIT 1";
																} else if ($deposit_post_data['network'] == "Tron") {
																	$sql_update_signin = "update cryptocash_shift_wallet set address_usdt_tron='$target_wallet_address', added_dt_tron='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDT' LIMIT 1";
																} else if ($deposit_post_data['network'] == "Binance") {
																	$sql_update_signin = "update cryptocash_shift_wallet set address_usdt_binance='$target_wallet_address', added_dt_binance='$shift_wallet_added_dt' where shift_login_email = '$reg_email_address' AND shift_account_currency='USDT' LIMIT 1";
																}
															}
															$deposit_status_call_retry_cnt = 2;
															if (trim($target_wallet_address) != '') {
																if (mysqli_query($dbhandle, $sql_update_signin)) {
																	_log($reg_email_address, "update address to wallet table successful");
																} else {
																	_log($reg_email_address, "update address to wallet table FAILED");
																}
															}
															$get_deposit_address_success = 1;
															
															
															break;
															/*
															if ((!empty($coin_address)) && (trim($coin_address) != '')) {
																
																$target_wallet_address = $coin_address;
																break;
																//$wallet_info['currency'] = $deposit_post_data['product'];
																//$wallet_info['address'] = $coin_address;
																//if ($deposit_post_data['product'] == 'USDT') {
																//	$wallet_info['network'] = $network;													
																//}															
															}*/
															
															
														} else {
															
															
															_log($reg_email_address, "/wallet/transaction/status call error (cannot get address) time " . $deposit_status_call_retry_cnt);
															foreach($deposit_status_res['result'] as $key => $value) {
																_log($reg_email_address, $key . " = " . $value);
															}
															$deposit_status_call_retry_cnt++;
															if ($deposit_status_call_retry_cnt >= 2) {
																@mysqli_close($dbhandle);
																header('Content-Type: application/json');
																http_response_code(500);
																$ret_rs['result'] = 'failed';
																$ret_rs['error'] = array('errorCode' => 9, 'errorMessage' => 'system is under maintenance.');
																echo json_encode($ret_rs);
																die();
															}
															
															
														}
													//}
													/////////////////////////////////////////////////////////////////
												} else {
													$error_message = 'Unauthorized';
													$res_code = 200;
													$error_code = 9;
													if (($deposit_status_res['http_code'] == "401") || ($deposit_status_res['http_code'] == "401 Unauthorized")) {
														_log($reg_email_address, "/wallet/transaction/status error (time " . $deposit_status_call_retry_cnt . ") : " . $deposit_status_res['http_code']);
														$res_code = 401;
													} else {
														if (($deposit_status_res['http_code'] == "500") || ($deposit_status_res['http_code'] == "500 Internal Server Error") || ($deposit_status_res['http_code'] == "503 Service Unavailable")) {
															
															if ($deposit_status_res['http_code'] == "503 Service Unavailable") {
																$error_code = 10;
																$error_message = 'system is under maintenance.';
																$res_code = 503;
															}
															if (($deposit_status_res['http_code'] == "500") || ($deposit_status_res['http_code'] == "500 Internal Server Error")) {	
																$res_code = 401;
															}
															
															_log($reg_email_address, "/wallet/transaction/status error (time " . $deposit_status_call_retry_cnt . ") :" . $deposit_status_res['http_code']);
														} else {
															_log($reg_email_address, "/wallet/transaction/status error unknown error code (time " . $deposit_status_call_retry_cnt . ")");
															$error_code = 10;
															$error_message = 'system is under maintenance.';
															$res_code = 500;
														}
													}
													$deposit_status_call_retry_cnt++;
													if ($deposit_status_call_retry_cnt >= 2) {
														@mysqli_close($dbhandle);
														$ret_rs['result'] = 'failed';
														$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
														header('Content-Type: application/json');
														if ($res_code != 200) {
															http_response_code($res_code);
														}
														echo json_encode($ret_rs);
														die();
													}
													
												}
											}
											
											
										} else {
											_log($reg_email_address, "/wallet/deposit/create call error (cannot get txid)");
											foreach($deposit_res['result'] as $key => $value) {
												_log($reg_email_address, $key . " = " . $value);
											}
											@mysqli_close($dbhandle);
											header('Content-Type: application/json');
											http_response_code(500);
											$ret_rs['result'] = 'failed';
											$ret_rs['error'] = array('errorCode' => 10, 'errorMessage' => 'system is under maintenance.');
											//$ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'unknown error occured. contact administrator for help.');
											echo json_encode($ret_rs);
											die();
											//foreach($deposit_res2['result'] as $key => $value) {
											//	_log($key . " = " . $value);
											//}
										}
									//} else {
										
									//}
									///////////////////////////////////////////////////////////////////
								} else {
									$error_message = 'Unauthorized';
									$res_code = 200;
									$error_code = 9;
									if (($deposit_res['http_code'] == "401") || ($deposit_res['http_code'] == "401 Unauthorized")) {
										_log($reg_email_address, "/wallet/deposit/create error " . $deposit_res['http_code']);
										$res_code = 401;
									} else {
										if (($deposit_res['http_code'] == "500") || ($deposit_res['http_code'] == "500 Internal Server Error") || ($deposit_res['http_code'] == "503 Service Unavailable")) {
											
											if ($deposit_res['http_code'] == "503 Service Unavailable") {
												$error_code = 10;
												$error_message = 'system is under maintenance.';
												$res_code = 503;
											}
											if (($deposit_res['http_code'] == "500") || ($deposit_res['http_code'] == "500 Internal Server Error")) {	
												$res_code = 401;
											}
											
											_log($reg_email_address, "/wallet/deposit/create error " . $deposit_res['http_code']);
										} else {
											_log($reg_email_address, "/wallet/deposit/create error unknown error code");
											$error_code = 10;
											$error_message = 'system is under maintenance.';
											$res_code = 500;
										}
									}
									@mysqli_close($dbhandle);
									$ret_rs['result'] = 'failed';
									$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
									header('Content-Type: application/json');
									if ($res_code != 200) {
										http_response_code($res_code);
									}
									echo json_encode($ret_rs);
									die();
								}
								
								
								/////////////////////////////////////////////////////////////
								/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							} else {
								$target_wallet_address = $cur_db_wallet_address;
								$get_deposit_address_success = 1;
							}
						
							////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						}
						
						
						
						
					} else {
						@mysqli_close($dbhandle);
						header('Content-Type: application/json');
						http_response_code(500);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 8, 'errorMessage' => 'you must sign in to use this API.');
						echo json_encode($ret_rs);
						die();
					}
					
					
				} else {			
					_log($reg_email_address, "could not connect db !");
					//@mysqli_close($dbhandle);
					$ret_rs['result'] = 'failed';
					$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'error occurred. please contact administrator for help.');
					header('Content-Type: application/json');
					echo json_encode($ret_rs);
					die();
				}
				
				
				//header('Content-Type: application/json');
				//echo json_encode($ret_rs);
				//die();
				if ($get_deposit_address_success == 1) {
					@mysqli_close($dbhandle);				
					$ret_rs['result'] = 'success';
					$ret_rs['email_address'] = $reg_email_address;
					if ($currency == 'USDT') {
						$ret_rs['depositResponse'] = array('currency' => $currency, 'network' => $network, 'address' => $target_wallet_address);
					} else {
						$ret_rs['depositResponse'] = array('currency' => $currency, 'address' => $target_wallet_address);
					}
										
					header('Content-Type: application/json');
					echo json_encode($ret_rs);
					die();
				}
				
				
				
			} else {
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors[0];
				_log("", $ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
				
			
		}

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>