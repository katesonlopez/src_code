<?php
/*extract($_GET);

// Start the session
session_start();

if( isset($_SESSION['auth']) && $_SESSION['auth'])
  header("Location: admin_dashboard.php");*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>API Delivery Server</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
      /* Custom CSS to center align the form */
      body, html {
          height: 100%;
      }
      .flex-center {
          align-items: center;
          display: flex;
          justify-content: center;
      }
      .container{
          height: 100%;
      }
      .vertical-center {
          min-height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
      }

      .form-container {
          max-width: 400px;
          width: 100%;
          margin: auto;
      }
      .subtitle {
          font-size: 30px;
      }
      /* Media query for smaller screens */
      @media (max-width: 576px) {
          .ascii-art {
              font-size: 8px; /* Adjust the font size as per your requirement */
          }
      }
  </style>
</head>
<body>
<div class="container">
  <div class="row justify-content-center vertical-center">
    <div class="col-md-12 flex-center">
      <div class="">
        <div class="m-b-md">
                    <pre class="ascii-art">

                 _   _____       _ _                         _____
     /\         (_) |  __ \     | (_)                       / ____|
    /  \   _ __  _  | |  | | ___| |___   _____ _ __ _   _  | (___   ___ _ ____   _____ _ __
   / /\ \ | '_ \| | | |  | |/ _ \ | \ \ / / _ \ '__| | | |  \___ \ / _ \ '__\ \ / / _ \ '__|
  / ____ \| |_) | | | |__| |  __/ | |\ V /  __/ |  | |_| |  ____) |  __/ |   \ V /  __/ |
 /_/    \_\ .__/|_| |_____/ \___|_|_| \_/ \___|_|   \__, | |_____/ \___|_|    \_/ \___|_|
          | |                                        __/ |
          |_|                                       |___/

                    </pre>
        </div>
        <div class="m-b-lg subtitle">Minamide API Delivery Server for Next.js Partner Sites<sup class="m-b-sm">@2024</sup></div>
        <div class="card form-container mt-4">
          <div class="card-body">
            <div class="alert alert-danger" id="alert" <?php echo !isset($error) || $error == null ? 'style="display: none;"' : ''; ?>>
              <?php echo isset($error) && $error != null ? $error : ''; ?>
            </div>
            <form action="admin_process.php" method="post">
              <input type="hidden" id="cmd" name="cmd" value="login">
              <div class="form-group">
                <label for="username">Admin email address</label>
                <input type="text" class="form-control" id="username" name="username" required>
              </div>
              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
              </div>
              <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
