<?php
/**
"data": {
"msg": "proc_ok",
"msg_ex": "",
"page": "",
"top_name_display": "",
"application_form_1_screenshot_url": "",
"application_form_1_screenshot_page_1_url": "http:\/\/localhost\/minamide\/ApiUltimopayIo\/v4\/jdb\/data\/download\/application_form_1_screenshot_2dbc9313cde73231f4dea94a10d08754_0.png?time=1725361674",
"application_form_1_screenshot_page_2_url": "http:\/\/localhost\/minamide\/ApiUltimopayIo\/v4\/jdb\/data\/download\/application_form_1_screenshot_2dbc9313cde73231f4dea94a10d08754_1.png?time=1725361674",
"application_form_2_screenshot_page_1_url": "http:\/\/localhost\/minamide\/ApiUltimopayIo\/v4\/jdb\/data\/download\/application_form_2_screenshot_2dbc9313cde73231f4dea94a10d08754_0.png?time=1725361687",
"application_form_2_screenshot_page_2_url": "http:\/\/localhost\/minamide\/ApiUltimopayIo\/v4\/jdb\/data\/download\/application_form_2_screenshot_2dbc9313cde73231f4dea94a10d08754_1.png?time=1725361687",
"application_form_2_screenshot_page_3_url": "http:\/\/localhost\/minamide\/ApiUltimopayIo\/v4\/jdb\/data\/download\/application_form_2_screenshot_2dbc9313cde73231f4dea94a10d08754_2.png?time=1725361687",
"application_form_2_screenshot_page_4_url": "http:\/\/localhost\/minamide\/ApiUltimopayIo\/v4\/jdb\/data\/download\/application_form_2_screenshot_2dbc9313cde73231f4dea94a10d08754_3.png?time=1725361687",
"unique_pid": "2dbc9313cde73231f4dea94a10d08754"
},
 **/
if(isset($data))
  extract($data);
include dirname(__FILE__) . '/../common.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Debit Card Application</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/signature_pad@4.0.0/dist/signature_pad.umd.min.js"></script>

  <!--<link href="../vendor/bootstrap.min.css" rel="stylesheet">
  <script src="../vendor/popper.min.js"></script>
  <script src="../vendor/bootstrap.min.js"></script>
  <script src="../vendor/jquery-3.6.0.min.js"></script>
  <script src="../vendor/signature_pad.umd.min.js"></script>-->
  <style>
      body {
          overflow-x: hidden;
      }
      .doc-border{
          border: 1px solid lightgray;
      }
      .doc-area{
          height: 400px;
          overflow-y: auto;
      }
      .cursor-hand {
          cursor: pointer;
      }
  </style>
</head>
<body>
<div class="container mt-5">
  <input type="hidden" id="base_url" value="<?php echo SITE_PATH; ?>">
  <input type="hidden" id="apiKey" value="<?php echo $apiKey; ?>">
  <input type="hidden" id="auth_token" value="<?php echo $auth_token; ?>">
  <input type="hidden" id="email_address" value="<?php echo $profileData['email_address']; ?>">
  <input type="hidden" id="document_type" value="<?php echo $profileData['profile']['id_card_type']; ?>">
  <input type="hidden" id="passport_open" value="<?php echo $profileData['image']['passport_open_file']; ?>">
  <input type="hidden" id="passport_selfie" value="<?php echo $profileData['image']['passport_selfie_file']; ?>">
  <input type="hidden" id="id_card_front" value="<?php echo $profileData['image']['id_card_front_file']; ?>">
  <input type="hidden" id="id_card_back" value="<?php echo $profileData['image']['id_card_back_file']; ?>">
  <input type="hidden" id="id_card_selfie" value="<?php echo $profileData['image']['id_card_selfie_file']; ?>">

  <h2 class="text-center mb-4">Debit Card Application: Profile Confirmation & Digital Signature</h2>

  <div class="row">
    <!-- App Form 1 -->
    <div class="col-md-6 col-sm-12 mb-3">
      <div class="card">
        <div class="card-header">
          Application Form 1
        </div>
        <div class="card-body doc-area">
          <div class="row">
            <div class="col-md-12">
              <a class="cursor-hand" data-bs-toggle="modal" data-bs-target="#zoomModalForm1" onClick="">
                <div class="doc-border">
                  <img class="w-100 form-1-img-1" src="<?php echo $pdfData['application_form_1_screenshot_page_1_url']; ?>" alt="form1 page 1"/>
                </div>
              </a>
            </div>
            <div class="col-md-12 mt-3">
              <a class="cursor-hand" data-bs-toggle="modal" data-bs-target="#zoomModalForm1" onClick="">
                <div class="doc-border">
                  <img class="w-100 form-1-img-2" src="<?php echo $pdfData['application_form_1_screenshot_page_2_url']; ?>" alt="form1 page 2"/>
                </div>
              </a>
            </div>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-between align-items-center">
          <button id="form1SignBtn" data-bs-toggle="modal" data-bs-target="#signaturePad" class="btn btn-outline-dark">
            <span class="spinner-text">&#9312; Sign this application form</span>
          </button>
          <div class="alert-danger text-danger">
            <span class="form-1-signature-alert" style="display: none;">PLEASE PROVIDE A FORM 1 SIGNATURE.</span>
          </div>
        </div>
      </div>
    </div>

    <!-- App Form 2 -->
    <div class="col-md-6 col-sm-12">
      <div class="card">
        <div class="card-header">
          Application Form 2
        </div>
        <div class="card-body doc-area app-form2">
          <div class="row">
            <div class="col-md-12">
              <a class="cursor-hand" data-bs-toggle="modal" data-bs-target="#zoomModalForm2" onClick="">
                <div class="doc-border">
                  <img class="w-100 form-2-img-1" src="<?php echo $pdfData['application_form_2_screenshot_page_1_url']; ?>" alt="form2 page 1"/>
                </div>
              </a>
            </div>
            <div class="col-md-12 mt-3">
              <a class="cursor-hand" data-bs-toggle="modal" data-bs-target="#zoomModalForm2" onClick="">
                <div class="doc-border">
                  <img class="w-100 form-2-img-2" src="<?php echo $pdfData['application_form_2_screenshot_page_2_url']; ?>" alt="form2 page 2"/>
                </div>
              </a>
            </div>
            <div class="col-md-12 mt-3">
              <a class="cursor-hand" data-bs-toggle="modal" data-bs-target="#zoomModalForm2" onClick="">
                <div class="doc-border">
                  <img class="w-100 form-2-img-3" src="<?php echo $pdfData['application_form_2_screenshot_page_3_url']; ?>" alt="form2 page 3"/>
                </div>
              </a>
            </div>
            <div class="col-md-12 mt-3">
              <a class="cursor-hand" data-bs-toggle="modal" data-bs-target="#zoomModalForm2" onClick="">
                <div class="doc-border">
                  <img class="w-100 form-2-img-4" src="<?php echo $pdfData['application_form_2_screenshot_page_4_url']; ?>" alt="form2 page 4"/>
                </div>
              </a>
            </div>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-between align-items-center">
          <div class="alert-danger text-danger">
            <span class="form-2-signature-alert" style="display: none;">PLEASE PROVIDE A FORM 2 SIGNATURE.</span>
          </div>
          <button id="form2SignBtn" data-bs-toggle="modal" data-bs-target="#signaturePad" class="btn btn-outline-dark">
            <span class="spinner-text">&#9313; Sign this application form</span>
          </button>
        </div>
      </div>
    </div>

    <!-- Submit document -->
    <div class="col-md-12 col-sm-12 mb-3 mt-3 mt-md-0">
      <div class="d-flex justify-content-end">
        <button id="finalSubmitBtn" class="btn btn-outline-dark">
          <span class="spinner-anim spinner-border spinner-border-sm text-dark" role="status" style="display: none"></span>
          <span class="spinner-text">&#9314; Submit Application Document</span>
        </button>
      </div>
    </div>
  </div>

  <!-- Zoom Modal 1 -->
  <div class="modal fade" id="zoomModalForm1" tabindex="-1" aria-labelledby="wideModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-scrollable modal-xl">
      <div class="modal-content">
        <div class="modal-header bg-light">
          <h5 class="modal-title" id="wideModalLabel">Application Form 1 (Application for Opening Account)</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <div class="doc-border">
                <img class="w-100 form-1-img-1" src="<?php echo $pdfData['application_form_1_screenshot_page_1_url']; ?>" alt="form1 page 1"/>
              </div>
            </div>
            <div class="col-md-12 mt-3">
              <div class="doc-border">
                <img class="w-100 form-1-img-2" src="<?php echo $pdfData['application_form_1_screenshot_page_2_url']; ?>" alt="form1 page 2"/>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-dark" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Zoom Modal 2-->
  <div class="modal fade" id="zoomModalForm2" tabindex="-1" aria-labelledby="wideModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-scrollable modal-xl">
      <div class="modal-content">
        <div class="modal-header bg-light">
          <h5 class="modal-title" id="wideModalLabel">Application Form 2 (Application for International Card Use Agreement)</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <div class="doc-border">
                <img class="w-100 form-2-img-1" src="<?php echo $pdfData['application_form_2_screenshot_page_1_url']; ?>" alt="form2 page 1"/>
              </div>
            </div>
            <div class="col-md-12 mt-3">
              <div class="doc-border">
                <img class="w-100 form-2-img-2" src="<?php echo $pdfData['application_form_2_screenshot_page_2_url']; ?>" alt="form2 page 2"/>
              </div>
            </div>
            <div class="col-md-12 mt-3">
              <div class="doc-border">
                <img class="w-100 form-2-img-3" src="<?php echo $pdfData['application_form_2_screenshot_page_3_url']; ?>" alt="form2 page 3"/>
              </div>
            </div>
            <div class="col-md-12 mt-3">
              <div class="doc-border">
                <img class="w-100 form-2-img-4" src="<?php echo $pdfData['application_form_2_screenshot_page_4_url']; ?>" alt="form2 page 4"/>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-dark" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Signature Pad 1 for form1 -->
  <div class="modal fade" id="signaturePad" tabindex="-1" aria-labelledby="wideModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-scrollable modal-xl">
      <div class="modal-content">
        <div class="modal-header bg-light">
          <h5 class="modal-title" id="signaturePadLabel"></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <canvas id="signature-pad" style="background-color: white; width: 100%; height: 300px;"></canvas>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <div class="alert-danger text-danger">
            <span class="signature-alert" style="display: none;">PLEASE PROVIDE A SIGNATURE FIRST.</span>
          </div>
          <div>
            <button id="clearSignature" type="button" class="btn btn-outline-dark me-2">
              <span class="spinner-text">Clear</span>
            </button>
            <button id="submitSignature" type="button" class="btn btn-outline-dark">
              <span class="spinner-anim spinner-border spinner-border-sm text-dark" role="status" style="display: none"></span>
              <span class="spinner-text">Submit signature</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  let SIGNATURE_PAD_ID = 1;
  let form1SignatureDataUrl = null;
  let form2SignatureDataUrl = null;
  let signaturePad;
  let BASE_URL = '';

  $(document).ready(function() {
    BASE_URL = $('#base_url').val();

    $('.app-form2').scrollTop(200);

    initializeSignaturePad();

    $('#form1SignBtn').click(function (){
      openSignaturePad(1);
    });

    $('#form2SignBtn').click(function (){
      openSignaturePad(2);
    });

    $('#clearSignature').click(function (){
      clearSignaturePad();
    });

    $('#submitSignature').click(function(){
      submitSignature();
    });

    $('#finalSubmitBtn').click(function (){
      finalSubmitDocument();
    });
  });

  function finalSubmitDocument(){
    if(!form1SignatureDataUrl) {
      $('.form-1-signature-alert').show();
    }
    else if(!form2SignatureDataUrl) {
      $('.form-2-signature-alert').show();
    }
    else{
      SpinBtnCtrl('finalSubmitBtn', true);

      let requestData = {
        document_type: 1,
        kyc_doc_upload: 'yes',
        email_address: $('#email_address').val()
      };

      if ($('#document_type').val() === 'driving_license') {
        requestData.document_type = 2;
        requestData.id_card_front = $('#id_card_front').val();
        requestData.id_card_back = $('#id_card_back').val();
        requestData.id_card_selfie = $('#id_card_selfie').val();
      } else {
        requestData.passport_open = $('#passport_open').val();
        requestData.passport_selfie = $('#passport_selfie').val();
      }

      // Determine which images need to be fetched
      const imagePromises = [];
      if (requestData.passport_open) {
        imagePromises.push(getImageBlob(requestData.passport_open));
      }
      if (requestData.passport_selfie) {
        imagePromises.push(getImageBlob(requestData.passport_selfie));
      }
      if (requestData.id_card_front) {
        imagePromises.push(getImageBlob(requestData.id_card_front));
      }
      if (requestData.id_card_back) {
        imagePromises.push(getImageBlob(requestData.id_card_back));
      }
      if (requestData.id_card_selfie) {
        imagePromises.push(getImageBlob(requestData.id_card_selfie));
      }

      // Fetch image data
      $.when.apply($, imagePromises).done(function(...images) {
        let formData = new FormData();
        formData.append('document_type', requestData.document_type);
        formData.append('kyc_doc_upload', requestData.kyc_doc_upload);
        formData.append('email_address', requestData.email_address);

        // Append the images to FormData
        if (requestData.document_type === 1) {
          const passportOpenExtension = getFileExtension(images[0][0].type);
          const passportSelfieExtension = getFileExtension(images[1][0].type);
          formData.append('passport_open', images[0][0], 'passport_open.' + passportOpenExtension);
          formData.append('passport_selfie', images[1][0], 'passport_selfie.' + passportSelfieExtension);
        } else {
          const idCardFrontExtension = getFileExtension(images[0][0].type);
          const idCardBackExtension = getFileExtension(images[1][0].type);
          const idCardSelfieExtension = getFileExtension(images[2][0].type);
          formData.append('id_card_front', images[0][0], 'id_card_front.' + idCardFrontExtension);
          formData.append('id_card_back', images[1][0], 'id_card_back.' + idCardBackExtension);
          formData.append('id_card_selfie', images[2][0], 'id_card_selfie.' + idCardSelfieExtension);
        }

        // Send the AJAX request using jQuery
        $.ajax({
          url: BASE_URL + '/IssueCard/upload_doc.php',
          method: 'POST',
          processData: false,
          contentType: false,
          data: formData,
          success: function(response) {
            SpinBtnCtrl('finalSubmitBtn', false);
            let data = JSON.parse(response);
            if( data.status * 1 === 1 ){
              updateKycStatus(data);
            }
          },
          error: function(/*jqXHR, textStatus, errorThrown*/) {
            SpinBtnCtrl('finalSubmitBtn', false);
          }
        });
      });
    }
  }

  // Function to convert image URL to Blob
  function getImageBlob(imageUrl) {
    return $.ajax({
      url: imageUrl,
      type: 'GET',
      xhrFields: {
        responseType: 'blob'
      }
    });
  }

  // Function to get the file extension from MIME type
  function getFileExtension(mimeType) {
    return mimeType.split('/')[1]; // Get the part after "image/", like "jpeg", "png", etc.
  }

  // Submit user status
  function updateKycStatus(kycData){
    $.ajax({
      url: BASE_URL + "/updateUserStatus/",
      type: "POST",
      headers: {
        "Authorization": "Bearer " + $('#apiKey').val(),
        "Content-Type": "application/json"
      },
      data: JSON.stringify({
        auth_token: $('#auth_token').val(),
        email_address: $('#email_address').val(),
        status:{
          kyc_status: "1",
          card_activation_status: "0",
          card_status: "0",
          payment_status: "0",
          kyc_file_url: kycData.application_form_final_url,
          kyc_upload_date: (new Date()).toString()
        }
      }),
      success: function(response) {
        //const data = JSON.parse( response );
        console.log(response.result);
        if( response.result === 'success' )
          window.location.href = BASE_URL + '/IssueCard/templates/template_card_issue_pending.php';
        else
          alert(response);
      },
      error: function(xhr, status, error) {
        console.error("Error:", status, error);
        alert(error);
      }
    });
  }

  function submitSignature(){
    if (signaturePad.isEmpty()) {
      $('.signature-alert').show();
    } else {
      $('.signature-alert').hide();

      let dataURL = signaturePad.toDataURL(); // Get the base64-encoded image data
      if(SIGNATURE_PAD_ID === 1) {
        form1SignatureDataUrl = dataURL;
        $('.form-1-signature-alert').hide();
      }
      else {
        form2SignatureDataUrl = dataURL;
        $('.form-2-signature-alert').hide();
      }

      SpinBtnCtrl('submitSignature', true);

      // Prepare the data object
      const requestData = {
        mydata: dataURL,
        profile: 'unique',
        whichForm: SIGNATURE_PAD_ID,
        email_address: $('#email_address').val(),
        direction: 'landscape'
      };

      // Send the AJAX request using jQuery
      $.ajax({
        url: BASE_URL + '/IssueCard/upload_signature.php',
        method: 'POST',
        contentType: 'application/x-www-form-urlencoded',
        data: $.param(requestData),
        success: function(response) {
          SpinBtnCtrl('submitSignature', false);

          let data = null;
          try {
            data = JSON.parse(response);
          }
          catch (e){
            alert(response);
            return;
          }
          if( data.msg === 'proc_ng') {
            alert(response);
          }
          else{
            $('.btn-close').trigger('click');
            if( data.whichForm === 1 ){
              $('.form-1-img-1').attr('src', data.form1_page1_screenshot);
              $('.form-1-img-2').attr('src', data.form1_page2_screenshot);
            }
            else{
              $('.form-2-img-1').attr('src', data.form2_page1_screenshot);
              $('.form-2-img-4').attr('src', data.form2_page4_screenshot);
            }
          }
        },
        error: function(/*jqXHR, textStatus, errorThrown*/) {
          SpinBtnCtrl('submitSignature', false);
        }
      });
    }
  }

  function clearSignaturePad(){
    if(signaturePad)
      signaturePad.clear();

    if(SIGNATURE_PAD_ID === 1) {
      form1SignatureDataUrl = null;
      $('.form-1-signature-alert').show();
    }
    else {
      form2SignatureDataUrl = null;
      $('.form-2-signature-alert').show();
    }
  }

  function SpinBtnCtrl(btnID, showSpin) {
    let $button = $('#' + btnID); // Use jQuery to select the button
    let $spinner = $button.find('.spinner-anim'); // Use jQuery to find the spinner within the button

    if (showSpin) {
      $spinner.css('display', 'inline-block'); // Set display to inline-block
      $button.prop('disabled', true); // Disable the button
    } else {
      $spinner.css('display', 'none'); // Hide the spinner
      $button.prop('disabled', false); // Enable the button
    }
  }

  function openSignaturePad(padNum){
    if(signaturePad)
      signaturePad.clear();

    $('.signature-alert').hide();

    SIGNATURE_PAD_ID = padNum;
    if(padNum === 1){
      $('#signaturePadLabel').text('Sign for Application Form 1 (Application for Opening Account)');
    }
    else{
      $('#signaturePadLabel').text('Sign for Application Form 2 (Application for International Card Use Agreement)');
    }
  }

  function initializeSignaturePad(){
    // Initialize the Signature Pad
    let canvas = document.getElementById('signature-pad');

    // Function to resize the canvas
    function resizeCanvas() {
      // Get the actual width and height from CSS
      let ratio = Math.max(window.devicePixelRatio || 1, 1);
      canvas.width = canvas.offsetWidth * ratio;
      canvas.height = canvas.offsetHeight * ratio;
      canvas.getContext('2d').scale(ratio, ratio); // Scale the context to handle high DPI displays
    }

    // Event listener to handle canvas resize on modal show
    $('#signaturePad').on('shown.bs.modal', function () {
      resizeCanvas(); // Resize canvas when the modal is shown
      signaturePad = new SignaturePad(canvas, {
        backgroundColor: 'rgb(255, 255, 255)', // Set white background for the canvas
      });
    });
  }
</script>

</body>
</html>
