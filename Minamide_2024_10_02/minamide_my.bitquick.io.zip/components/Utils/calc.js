export function truncateFloat(number, decimalPlaces) {
    // Convert the number to a string and split it at the decimal point
    let parts = number.toString().split(".");

    // If there is no decimal part, add an empty string to parts[1]
    if (parts.length === 1) {
        parts.push("");
    }

    // Slice the decimal part to the specified number of decimal places
    // and pad with zeros if necessary
    parts[1] = (parts[1] + "0".repeat(decimalPlaces)).slice(0, decimalPlaces);

    // Join the integer and decimal parts back together
    return parts.join(".");
}

export function parseStringToFloat(str) {
    // Remove commas from the string
    var strWithoutCommas = str.toString().replace(/,/g, '');
    // Parse the string as a float
    return parseFloat(strWithoutCommas);
}

export function toUsNumber( number ){
    const [integerPart, decimalPart] = number.toString().split('.');
    const formattedIntegerPart = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return decimalPart ? `${formattedIntegerPart}.${decimalPart}` : formattedIntegerPart;
}

export function noneZeroFormatNumber(num, decimalPlaces) {
    // Convert the number to a string with specified decimal places
    let formatted = num.toString();

    // Remove trailing zeros from the decimal part
    formatted = formatted.replace(new RegExp('(\\.\\d*?[1-9])0{0,' + (formatted.length - formatted.indexOf('.') - 1 - decimalPlaces) + '}$'), "$1");
    // Convert the formatted string back to a number
    return Number(formatted);
}

export function maskEmail(email) {
    const [localPart, domain] = email.split('@');

    const maskString = (str) => {
        if (str.length <= 4) return str;
        return str.slice(0, 2) + '*'.repeat(str.length - 4) + str.slice(-2);
    };

    const maskedLocalPart = maskString(localPart);
    const [domainName, domainExt] = domain.split('.');
    const maskedDomainName = maskString(domainName);

    return `${maskedLocalPart}@${maskedDomainName}.${domainExt}`;
}

export function roundNumber(num, decimalPlaces) {
    // Convert the number to a string to manipulate its digits
    let numStr = num.toString();

    // Find the position of the decimal point
    let decimalPosition = numStr.indexOf('.');

    // If the decimal point is not found, return the number as it is
    if (decimalPosition === -1) {
        return num;
    }

    // Initialize a variable to keep track of the number of digits after the decimal point
    let digitsAfterDecimal = numStr.length - decimalPosition - 1;
    let addOper = Math.pow(10, (-1)*digitsAfterDecimal);

    // If there are already fewer or equal digits after the decimal point than required, return the number as it is
    if (digitsAfterDecimal <= decimalPlaces) {
        return parseFloat(num.toFixed(decimalPlaces));
    }

    // Initialize a counter for the number of digits to remove
    let removeCount = digitsAfterDecimal - decimalPlaces;

    // Start removing digits from the (decimalPlaces + 1)th decimal place onward
    while (removeCount > 0) {
        // Increase addOper
        addOper *= 10;

        // Find the index of the last digit before rounding
        let lastIndex = decimalPosition + decimalPlaces + removeCount;

        // Get the digit at the last index
        let lastDigit = parseInt(numStr[lastIndex]);

        // If the last digit is 5 or greater, round up by incrementing the preceding digit
        if (lastDigit >= 5) {
            num = parseFloat(num) + addOper;
        }

        // Remove the last digit and decrement the remove count
        numStr = num.toString().substring(0, lastIndex);
        removeCount--;
    }

    // Convert the modified string back to a float and return
    return parseFloat(numStr);
}

export function roundUp(num, decimalPlaces) {
    const factor = Math.pow(10, decimalPlaces);
    return Math.ceil(num * factor) / factor;
}

/**
 * Returns the number of decimal places in a floating-point number.
 *
 * @param {number} value - The floating-point number.
 * @returns {number} The number of decimal places.
 */
export function getDecimalPlaceLength(value) {
    // Convert the number to a string
    const valueString = value.toString();

    // Find the position of the decimal point
    const decimalIndex = valueString.indexOf('.');

    // If there is no decimal point, the number of decimal places is 0
    if (decimalIndex === -1) {
        return 0;
    }

    // Calculate the length of the decimal part
    return valueString.length - decimalIndex - 1;
}