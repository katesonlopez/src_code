import React, { useEffect } from 'react';

const OneTimeNotification = ({ showModal, closeModal }) => {
  useEffect(() => {
    if (showModal) {
      document.getElementById('boostrapModalLunch').click();
    }
  }, [showModal]);

  return (
    <div className="d-flex justify-content-center align-items-center">
      <button
        type="button"
        className="btn btn-primary"
        data-bs-toggle="modal"
        data-bs-target="#notificationModal"
        id="boostrapModalLunch"
        hidden={true}
      >
        Launch demo modal
      </button>

      <div
        className="modal fade"
        id="notificationModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
        data-bs-backdrop="static"
      >
        <div className="modal-dialog"
             style={{ zIndex: 1001 }}>
          <div className="modal-content">
            <div className="modal-header bg-info text-white">
              <h5 className="modal-title" id="exampleModalLabel">
                Important Notices:
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body p-4">
              <h4 className=" fw-bold mb-2 center text-center">
                An Ethereum hard fork is scheduled <br/>(March 13, 11:00 - 17:00 UTC)
              </h4>
              <p className="mb-1">
                Due to the implementation of a hard fork in the Ethereum network on
                <span className="fw-bold" style={{ fontSize: '1.2em' }}>
                  &nbsp;Wednesday March 13, at 13:55 UTC,
                </span>
              </p>
              <p className="mb-4">
                please do not deposit ETH network tokens during this time.
              </p>
              <p className="mb-4">
                There is a risk that they may not be properly received due to network instability, and we cannot compensate for such cases.
              </p>
              <p className="mb-4">
                Therefore, please refrain from depositing the following tokens during the following time period.
              </p>
              <p style={{ marginLeft: '30px' }}>
                From : March 13th (Wednesday) 11:00 (UTC)<br/>
              </p>
              <p style={{ marginLeft: '30px' }}>
                To     :  March 13th (Wednesday) 17:00 (UTC)<br/>
              </p>
              <p style={{ marginLeft: '30px' }}>
                Coin :  USDT (ERC20), USDC (ERC20)<br/>
              </p>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-info text-white"
                data-bs-dismiss="modal"
              >
                I understand
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OneTimeNotification;
