import Link from 'next/link'
import {useState, useEffect} from "react";
import Main from './layout/Main'
import {useRouter} from 'next/router';
import {useForm} from 'react-hook-form';
import {yupResolver} from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import {userService, alertService} from '/services';
import Swal from 'sweetalert2';
import cookie from "js-cookie";
import Waiting from "../components/Waiting";

export default function VerifySignup() {
  const router = useRouter();
  const [user, setUserData] = useState(null);
  const [sendState, setSendState] = useState(false);
  const [isSigning, setIsSigning] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    const y = localStorage.getItem('verification-token')

    if (!y) {
      router.push('/register')
    } else {
      const userser = JSON.parse(y)
      const now = new Date().getTime()
      if (now > userser.expiration) {
        localStorage.removeItem('verification-token')
        router.push('/register')
      }
      const user = JSON.parse(userser.res.config.data)
      setUserData(user);
    }


  }, [router])
  const validationSchema = Yup.object().shape({

    verification_code: Yup.string()
      .required('Code is required')
      .notOneOf(['http', 'script'], 'Invalid input')
      .matches(/^(?![<>]).*$/, 'Invalid input'),
  });
  const formOptions = {
    resolver: yupResolver(validationSchema), defaultValues: {
      verification_code: '',
      email_address: user ? (user.email_address) : ('fdfdf'),
    }
  };

  // get functions to build form with useForm() hook
  const {register, setValue, handleSubmit, formState, setError} = useForm(formOptions);
  const {errors} = formState;
  const handleButtonClick = () => {
    setValue('email_address', user ? (user.email_address) : ('fdfdf'));
  };

  const handleResendClick = () => {
    setSendState(true)
    userService.runApi('resendSignupCode/', user).then((d) => {

      Swal.fire({
        title: "Success",
        text: "We have successfully resent your verification code to your email address",
        icon: "success"
      }).then(function (result) {
        setSendState(false)

      })
    })
  };

  async function onSubmit(user) {
    return userService.runApi('confirmSignUp/', user)
      .then((res) => {
        if (res.data.result === 'success') {
          Swal.fire({
            title: "Success",
            text: "Congratulation! Your account has been created successfully. Now you can login in your account.",
            icon: "success"
          }).then(function (result) {
            const userString = localStorage.getItem('beforeSignIn');
            if (userString) {
              setIsSigning(true);
              // Do sign in automatically
              const user = JSON.parse(userString);
              user.expires_second = process.env.NEXT_PUBLIC_SESSION_EXPIRE_TIME;
              user.kloginTime = Date().toLocaleString();

              userService
                .runApi("signin/", user)
                .then((res) => {
                  if (res.data.result === "success") {
                    userService.runApi("changeUserSystemGroup/", user).then((i) => {
                      localStorage.setItem("user", JSON.stringify({res}));
                      localStorage.setItem("loginTime", user.kloginTime);
                      localStorage.setItem("expires_second", user.expires_second);
                      localStorage.setItem("lastAccessTime", user.kloginTime);
                      localStorage.setItem("full_expires_second", res.data.signinResponse.expires_in ?? 3600);
                      cookie.set('user', JSON.stringify({res}), {path: '/'});

                      router.push({
                        pathname: "user/dashboard",
                      });
                    });
                  } else if (res.data.result === "failed") {
                    setIsSigning(false);
                    // Redirect to sign in page
                    router.push({
                      pathname: '/',
                      query: {success: true},
                    });
                  }
                })
                .catch(alertService.error);
            } else {
              setIsSigning(false);
              // Redirect to sign in page
              router.push({
                pathname: '/',
                query: {success: true},
              });
            }
          })
        } else if (res.data.result === "failed") {
          setError('verification_code', {message: res.data.error.errorMessage});
        }
      })
      .catch(alertService.error);
  }

  return (
    <Main page="SIGN IN">
      <section className="height-con height-con-2">
        <div className="container">
          <div className="crow">
            <div className="col-sm-10 m-auto col-frm">
              <div className="main-frm" style={{top: '65px', position: 'relative', fontSize: '12px', padding: '0px'}}>
                <h1 className="p-4">COMPLETE SIGN-UP</h1>
                <div className={`${isMobile ? "" : "pse-5-1"} p-4`}>
                  {isSigning === false ? (
                    <form className="row p-2 sign-up-fm" onSubmit={handleSubmit(onSubmit)}>
                      <div className="mb-4 ps-0">
                        <p>
                          <p style={{wordBreak: 'break-all', lineHeight: '1.5'}}>
                            Please enter the verification code we have sent to <b
                            className="text-white"> {user ? (user.email_address) : ''}</b> (we
                            have sent from <b className="text-white">no-reply@mailverificate.com</b> ) to complete your
                            sign up:
                          </p>
                        </p>
                      </div>
                      <div className="col-md-12 mb-4 p-0">
                        <label htmlFor="inputPassword4" className="form-label">
                          Verification Code
                        </label>
                        <input
                          type="text"
                          name="verification_code"
                          {...register('verification_code')}
                          className={`form-control ${errors.verification_code ? 'is-invalid' : ''}`}
                          id="inputEmail4"
                          placeholder="Enter Verification Code"
                          autoFocus
                        />
                        <input
                          type="hidden"
                          name="email_address"
                          {...register('email_address')}
                          value={user ? (user.email_address) : ('fdfdf')}
                        />
                        <div className="invalid-feedback">{errors.verification_code?.message}</div>
                        <div className='mt-3'>
                          Can't get the verification code ?
                          <button
                            className='btn text-white font-16 font-800 text-decoration-underline' type='button'
                            disabled={sendState} onClick={handleResendClick}
                            style={{ fontWeight: '800', fontSize: '13px'}}>
                            {sendState && <span className="spinner-border spinner-border-sm mr-1"></span>}
                            Resend Verification Code
                          </button>
                        </div>
                      </div>
                      <div className="col-md-12 mb-4 p-0">
                        <p>ATTENTION:</p>
                        <p>
                          For Gmail, please also check the Promotion Tabs, as well as
                          the spam folder if you cannot find the email in your INBOX.
                        </p>
                      </div>
                      <div className="mb-4 text-center ps-0 pe-0">
                        <button disabled={formState.isSubmitting} className="button primary size-xl-wider cstm-submit p-0"
                                onClick={handleButtonClick}>
                          {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                          <font>CONFIRM</font>{" "}
                        </button>
                      </div>
                      <div className="mb-2 text-left ps-0 text-white font-800 font-16 text-decoration-underline">
                        <Link href="/" className="">
                          Back to sign in
                        </Link>
                      </div>
                    </form>
                  ) : (
                    <Waiting className="mt-5 mb-5" message={'Signing...'}/>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="sign-bg">
          <div className="bg-img">
            {/*<img src="/assets/img/bg.png" width="100%" style={{opacity: 0.7}} alt="background"/>*/}
          </div>
        </div>
      </section>
    </Main>
  )
}
