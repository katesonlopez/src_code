import React, {useCallback, useMemo, useState} from 'react';
import {useTable, useSortBy, useGlobalFilter, usePagination} from 'react-table';

function DataTableMobileDashboard({data, col, isLoading, reportType}) {
  const [filterInput, setFilterInput] = useState('');
  const columns = useMemo(() => col, [col]);


  const handleButtonClick = (event, item) => {
    // 1. Hide all <tr> elements that have class name 'address'.
    const addressRows = document.querySelectorAll('.address');
    addressRows.forEach(row => row.classList.add('d-none'));

    // 2. Show the <tr> element that has the class name same as item.payment_id value.
    const targetRow = document.querySelector(`.address${item.payment_id}`);
    if (targetRow) {
      targetRow.classList.remove('d-none');
    }
  }

  const tableData = useMemo(() => toMobileData(data, reportType, handleButtonClick), [data, reportType]);

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,
    state,
    setGlobalFilter,
    gotoPage,
    nextPage,
    previousPage,
    canNextPage,
    canPreviousPage,
    pageOptions,
    pageCount,
    setPageSize,
  } = useTable(
    {
      columns,
      data: tableData,
      initialState: {pageIndex: 0, pageSize: 10},
    },
    useGlobalFilter,
    useSortBy,
    usePagination
  );

  const {globalFilter, pageIndex, pageSize} = state;

  const handleFilterChange = (e) => {
    const value = e.target.value || '';
    setGlobalFilter(value);
    setFilterInput(value);
  };

  function toMobileData(tableData, reportType, handleButtonClick) {
    return tableData.map((item, index) => {
      const amount = typeof item.amount === 'number' || typeof item.amount === 'string' ? item.amount : '';
      let data = null;

      if (reportType === 1) {
        data = (
          <table>
            <tbody>
            <tr>
              <td className="border-0 font-11" style={{minWidth: '124px'}}>
                {item.currency}
                <br/>
                {item.updated_date}
              </td>
              <td className="border-0 font-11">
                {item.amount}
                <br/>
                {item.status}
              </td>
              <td className="border-0 font-11 float-end">
                <button className="button ghost size-xl-narrow" onClick={(event) => handleButtonClick(event, item, index)}>
                  <i className="bi bi-chevron-right"></i>
                </button>
              </td>
            </tr>
            <tr className={`address d-none address${item.payment_id}`}>
              <td colSpan="3" className="border-0">
                {item.type === 'deposit' && item.crypto_transaction_id.length > 0 && (
                  <div className="mt-2">
                    <div>TXID</div>
                    <div className="flex justify-content-between">
                      <div className="text-break">{item.crypto_transaction_id}</div>
                      <button className="button ghost size-smaller"
                              onClick={(event) => {
                                event.preventDefault();
                                const { crypto_transaction_id: txId, currency, crypto_network } = item;
                                let url = ``;
                                if( currency === 'USDT' && crypto_network === 'erc20')
                                  url = `https://etherscan.io/tx/${txId}`;
                                if( currency === 'USDT' && crypto_network === 'tron')
                                  url = `https://tronscan.org/#/transaction/${txId}`;
                                if( currency === 'USDC')
                                  url = `https://etherscan.io/tx/${txId}`;
                                if (currency === 'BTC')
                                  url = `https://www.blockchain.com/explorer/search?search=${txId}`;
                                if (currency === 'BCH')
                                  url = `https://explorer.btc.com/bch/transaction/${txId}`;
                                if (currency === 'SOL')
                                  url = `https://solscan.io/tx/${txId}`;
                                if (currency === 'ETH')
                                  url = `https://etherscan.io/tx/${txId}`;
                                if (currency === 'XRP')
                                  url = `https://xrpscan.com/tx/${txId}`;
                                if (currency === 'LTC')
                                  url = `https://litecoinblockexplorer.net/tx/${txId}`;
                                window.open(url, '_blank');
                              }}>
                        <i className="bi bi-box-arrow-up-right"></i>
                      </button>
                    </div>
                  </div>
                )}
              </td>
            </tr>
            </tbody>
          </table>
        );
      } else if (reportType === 2) {
        data = (
          <table>
            <tbody>
            <tr>
              <td className="border-0 font-11" style={{minWidth: '124px'}}>
                {item.currency}
                <br/>
                {item.created_date}
              </td>
              <td className="border-0 font-11">
                {item.amount}
                <br/>
                {item.status}
              </td>
              <td className="border-0 font-11 float-end">
                <button className="button ghost size-xl-narrow" onClick={(event) => handleButtonClick(event, item, index)}>
                  <i className="bi bi-chevron-right"></i>
                </button>
              </td>
            </tr>
            <tr className={`address d-none address${item.payment_id}`}>
              <td colSpan="3" className="border-0">
                <label>Address</label><br/>
                <label>{item.address}</label>
                {item.type === 'withdrawal' && item.crypto_transaction_id.length > 0 && (
                  <div className="mt-2">
                    <div>TXID</div>
                    <div className="flex justify-content-between">
                      <div className="text-break">{item.crypto_transaction_id}</div>
                      <button className="button ghost size-smaller"
                              onClick={(event) => {
                                event.preventDefault();
                                const { crypto_transaction_id: txId, currency, crypto_network } = item;
                                let url = ``;
                                if( currency === 'USDT' && crypto_network === 'erc20')
                                  url = `https://etherscan.io/tx/${txId}`;
                                if( currency === 'USDT' && crypto_network === 'tron')
                                  url = `https://tronscan.org/#/transaction/${txId}`;
                                if( currency === 'USDC')
                                  url = `https://etherscan.io/tx/${txId}`;
                                if (currency === 'BTC')
                                  url = `https://www.blockchain.com/explorer/search?search=${txId}`;
                                if (currency === 'BCH')
                                  url = `https://explorer.btc.com/bch/transaction/${txId}`;
                                if (currency === 'SOL')
                                  url = `https://solscan.io/tx/${txId}`;
                                if (currency === 'ETH')
                                  url = `https://etherscan.io/tx/${txId}`;
                                if (currency === 'XRP')
                                  url = `https://xrpscan.com/tx/${txId}`;
                                if (currency === 'LTC')
                                  url = `https://litecoinblockexplorer.net/tx/${txId}`;
                                window.open(url, '_blank');
                              }}>
                        <i className="bi bi-box-arrow-up-right"></i>
                      </button>
                    </div>
                  </div>
                )}
              </td>
            </tr>
            </tbody>
          </table>
        );
      } else if (reportType === 3) {
        data = (
          <table>
            <tbody>
            <tr>
              <td className="border-0 font-11" style={{minWidth: '124px'}}>
                {item.currency}
                <br/>
                {item.created_date}
              </td>
              <td className="border-0 font-11">{item.amountMobile}</td>
            </tr>
            </tbody>
          </table>
        );
      } else if (reportType === 4) {
        data = (
          <table>
            <tbody>
            <tr>
              <td className="border-0 font-11" style={{minWidth: '120px', width: '120px'}}>
                {item.datetime}
              </td>
              <td className="border-0 font-11 text-start" style={{minWidth: '60px', width: '60px'}}>
                {item.instant}
              </td>
              <td className="border-0 font-11" style={{width: '100px'}}>
                {item.amount}
              </td>
              <td className="border-0 font-11 text-end">{item.status}</td>
            </tr>
            </tbody>
          </table>
        );
      } else if (reportType === 5) {
        data = (
          <table>
            <tbody>
            <tr>
              <td className="border-0 font-11" style={{minWidth: '160px', width: '160px', wordBreak: 'break-all'}}>
                {item.description}
                <br/>
                {item.datetime}
              </td>
              <td className="border-0 font-11 text-start">
                Out(USD)
                <br/>
                In(USD)
                <br/>
                Balance(USD)
              </td>
              <td className="border-0 font-11 text-end">
                {item.money_out}
                <br/>
                {item.money_in}
                <br/>
                {item.post_balance}
              </td>
            </tr>
            </tbody>
          </table>
        );
      }
      return {Data: data};
    });
  }

  return (
    <>
      {isLoading ? (
        <div className="d-flex w-100 h-100 justify-content-center">
          <div className="datatable-loading">Data Loading...</div>
        </div>
      ) : (
        <table {...getTableProps()} className="mytable2">
          {/*<thead>
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th>{column.render('Header')}</th>
              ))}
            </tr>
          ))}
          </thead>*/}
          <tbody {...getTableBodyProps()}>
          {page.map((row, rowIndex) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()} key={rowIndex}>
                {row.cells.map((cell, cellIndex) => (
                  <td {...cell.getCellProps()} key={cellIndex}>
                    {cell.value}
                  </td>
                ))}
              </tr>
            );
          })}
          </tbody>
        </table>
      )}

      <div align="center" className="mt-2">
        <div className="pagination" style={{display: 'block'}}>
          <button className="none-border-btn" onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
            {'<<'}
          </button>
          {' '}
          <button className="none-border-btn" onClick={() => previousPage()} disabled={!canPreviousPage}>
            {'<'}
          </button>
          {' '}
          <button className="none-border-btn" onClick={() => nextPage()} disabled={!canNextPage}>
            {'>'}
          </button>
          {' '}
          <button className="none-border-btn" onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
            {'>>'}
          </button>
          {' '}
        </div>
        <div className="mt-0">
          Page{' '}
          <strong>
            {pageIndex + 1} of {pageOptions.length}
          </strong>{' '}
        </div>
      </div>
    </>
  );
}

export default DataTableMobileDashboard;
