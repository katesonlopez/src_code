import Link from 'next/link'
import { useRouter } from 'next/router';

function AllComplete({ user, form2 , userdata , form1 , onNextClick, isMobile, memberCard}) {
  useRouter();
  return (
    <>
      <div className="col-md-7 mx-auto mt-5">
        <div className="card mx-auto" >
          <div className="card-body">
            <h3 className="card-title text-center mb-4 text-white font-800">You Have Already Issued a Card</h3>
            <p className="card-text text-center">Your card has been activated and is ready to use.</p>
            <div className="d-flex justify-content-center mt-3">
              <Link href={`/user/my-card`} className="button primary w-100 me-2">My Card</Link>
              <Link href={`/user/card/load`} className="button primary outline w-100">Load</Link>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export { AllComplete };
