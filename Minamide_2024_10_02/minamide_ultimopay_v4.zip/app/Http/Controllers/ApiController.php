<?php

namespace App\Http\Controllers;

use App\Report;
use Illuminate\Http\Request;

class ApiController extends Controller
{
  public function getReportData(Request $request){
    $emails = $request->input('emails');
    $reports = Report::whereIn('email', $emails)
      ->where('status', 'complete')
      ->get();

    // Return the data as a JSON response
    return response()->json($reports);
  }
}
