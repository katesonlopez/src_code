<?php global $baseUrl;
include 'includes/header.php';

$requestUri = $_SERVER['REQUEST_URI'];
$queryParams = parse_url($requestUri, PHP_URL_QUERY);

if (strpos($requestUri, '/payment-confirmation') !== false) {
  header('Location: '.getBaseUrl().'pay_with_card_callback.php'.'?cmd=payment-confirmation&'.$queryParams);
}
if (strpos($requestUri, '/payment-failed') !== false) {
  header('Location: '.getBaseUrl().'pay_with_card_callback.php'.'?cmd=payment-failed&'.$queryParams);
}
if (strpos($requestUri, '/payment-cancellation') !== false) {
  header('Location: '.getBaseUrl().'pay_with_card_callback.php'.'?cmd=payment-cancellation&'.$queryParams);
}
if (strpos($requestUri, '/payment-backend') !== false) {
  header('Location: '.getBaseUrl().'pay_with_card_callback.php'.'?cmd=payment-backend&'.$queryParams);
}
?>
<!-- Container start -->
<div class="main-content container d-flex justify-content-center align-items-center">
  <div class="col-md-6 col-lg-4">
    <h1 class="text-center mb-4">SignIn</h1>
    <form id="loginForm" novalidate>
      <div class="form-group">
        <label for="email">Email address</label>
        <input type="email" class="form-control" id="email" name="email" required>
        <div class="invalid-feedback">
          Email address required.
        </div>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
        <div class="invalid-feedback">
          Password required.
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block mt-4" id="signInButton">
        <span class="spinner-anim spinner-border spinner-border-sm text-white" role="status" style="display: none"></span>
        <span class="spinner-text">Sign In</span>
      </button>
    </form>
  </div>
</div>
<!-- Container end -->

<script>
  $(document).ready(function() {

    $('.username').hide();

    $('#loginForm').on('submit', function(event) {
      event.preventDefault();

      // Validation
      const form = $(this);
      if (this.checkValidity() === false) {
        event.stopPropagation();
        form.addClass('was-validated');
        return;
      }

      // Perform AJAX submission
      disableWithSpinner('signInButton', 'Sign in...');
      let email = $('#email').val();
      let password = $('#password').val();
      $.ajax({
        url: API_URL + 'ultimoApi.php',
        type: 'POST',
        data: JSON.stringify({ action: 'signin', email_address: email, password: password }),
        contentType: 'application/json',
        success: function(response) {
          if (response.result === 'success') {
            localStorage.setItem('user', JSON.stringify(response.signinResponse));
            localStorage.setItem('jwt', response.signinResponse.jwt);
            localStorage.setItem('auth_token', response.signinResponse.auth_token);
            window.location.href = BASE_URL + 'dashboard.php';
            enableWithSpinner('signInButton', 'Sign In');
          } else {
            console.log('An error occurred:', response.error.errorMessage);
            showToast(response.error.errorMessage);
            enableWithSpinner('signInButton', 'Sign In');
          }
        },
        error: function(error) {
          console.log('An error occurred:', error);
          enableWithSpinner('signInButton', 'Sign In');
        }
      });
    });
  });
</script>
<?php include 'includes/footer.php'; ?>
