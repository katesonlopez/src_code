import {useRouter} from 'next/router';
import {useEffect, useState} from "react";
import {useForm} from 'react-hook-form';
import {yupResolver} from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import {userService} from '/services';
import Swal from "sweetalert2";
import 'react-toastify/dist/ReactToastify.css';
import styles from '../public/assets/css/cardLoad.module.css';
import {roundNumber, roundUp, truncateFloat} from "./Utils/calc";


function CardLoad({wallet, user, pendingTotal, allwallet, userInfo}) {

  const standardLoadType = 1;
  const router = useRouter();
  const usdBalance = truncateFloat(allwallet[2].balance, 2);
  const [inputValue, setInputValue] = useState(0);
  const [loadType, setLoadType] = useState(standardLoadType);
  const [load_processing_fee_fixed, setLoadProcessingFeeFixed] = useState(0.25);
  const [load_instant_fee_rate, setLoadInstantFeeRate] = useState(1);
  const [loadFee, setLoadFee] = useState(load_instant_fee_rate);
  const [availableAmount, setAvailableAmount] = useState(
    truncateFloat(Math.max(0, usdBalance - load_processing_fee_fixed) / (1 + load_instant_fee_rate / 100), 2));
  const minimum = 0;

  useEffect(() => {
    fetchMasterSetting();
  }, []);

  function fetchMasterSetting() {
    userService.runApi("getMasterSetting/", { 'partner': 'BITQUICK' })
      .then((response) => {
        const settings = response.data.response;
        const instantFeeRate = parseFloat(settings.find(s => s.type === 'load_instant_fee_rate').value);
        const processingFeeFixed = parseFloat(settings.find(s => s.type === 'load_processing_fee_fixed').value);

        setLoadInstantFeeRate(instantFeeRate);
        setLoadProcessingFeeFixed(processingFeeFixed);
        setLoadFee(instantFeeRate);
        updateAvailableAmount(standardLoadType, usdBalance, instantFeeRate, processingFeeFixed);
      })
      .catch((error) => {
        console.error('Error fetching master settings:', error);
      });
  }

  function updateAvailableAmount(loadType, usdBalance, instantFeeRate, processingFeeFixed) {
    if (loadType === standardLoadType) {
      setAvailableAmount(truncateFloat(Math.max(0, (usdBalance - processingFeeFixed) / (1 + instantFeeRate / 100)), 2));
    } else {
      setAvailableAmount(truncateFloat(Math.max(0, (usdBalance - processingFeeFixed)), 2));
    }
  }

  const handleInputChange = (event) => {
    let newValue = event.target.value;
    newValue = newValue.replace(/[^0-9.]/g, '');
    const parts = newValue.split('.');
    if (parts.length > 1) {
      newValue = `${parts[0]}.${parts[1].slice(0, 2)}`;
    }

    setInputValue(parseFloat(newValue));

    // Update availableAmount based on selected load type
    updateAvailableAmount(loadType, usdBalance, load_instant_fee_rate, load_processing_fee_fixed);
  }

  useEffect(() => {
    console.log('availableAmount, inputValue', availableAmount, inputValue);
    if (availableAmount >= minimum) {
      if (availableAmount < inputValue) {
        setError('amount', {message: `You don't have enough USD to Load`})
      } else {
        setError('amount', '');
      }
    } else {
      setError('amount', {message: `Please enter load amount`});
    }
  }, [availableAmount, inputValue, minimum, loadType]);

  // Event handler for the Radio Change
  const handleRadioChange = (e) => {
    const selectedValue = e.target.value * 1;
    setLoadType(selectedValue);

    updateAvailableAmount(selectedValue, usdBalance, load_instant_fee_rate, load_processing_fee_fixed);
  };

  const handleKeyDown = (event) => {
    if (event.key === '-' || event.key === '+') {
      event.preventDefault(); // prevent '-' or '+' from being entered
    }
  }
  const validationSchema = Yup.object().shape({
    amount: Yup.number()
      .typeError('Amount must be a number')
      .required('Amount is required')
      .min(0, 'Amount must be greater than zero'),
  });
  const formOptions = {
    resolver: yupResolver(validationSchema), defaultValues: {
      email_address: user.email_address,
      auth_token: user.auth_token,
      bank_account_number: userInfo.bank_account_number,
      card_number: userInfo.card_number,
      amount: inputValue,
      instant: loadType,
      fee: loadFee,
    },
  };

  // get functions to build form with useForm() hook
  const {register, handleSubmit, formState, setError} = useForm(formOptions);
  const {errors} = formState;

  function onSubmit(formData) {

    if (inputValue > 0) {
      formData.fee = loadType === standardLoadType ? load_instant_fee_rate : 0;
      formData.instant = loadType;
      formData.processing_fee = load_processing_fee_fixed;
    }

    let feeAmount = load_processing_fee_fixed;
    let loadTypeDesc = 'Delayed Load';
    if (loadType === standardLoadType) {
      feeAmount = load_processing_fee_fixed + roundUp(inputValue * (load_instant_fee_rate / 100), 2);
      loadTypeDesc = 'Standard Load';
    }
    let description = `<span style="font-size: 14px; font-weight: normal">Do you want to make a <span>${loadTypeDesc}</span> 
               <span style="font-weight: bold; color:white;">${inputValue} USD</span> to your debit card?<br/>
               <span>${loadTypeDesc} fee: <span style="font-weight: bold; color:white;">${feeAmount.toFixed(2)} USD </span></span></span>`;

    if (inputValue > 0) {
      // Check validation for balance
      if (inputValue > availableAmount) {
        Swal.fire({
          title: 'Insufficient balance',
          html: `Your balance ${availableAmount} USD is insufficient <br/>to load ${inputValue} USD.`,
          icon: "warning",
        }).then(function () {
        });
        return;
      }

      return Swal.fire({
        title: 'Load Card',
        html: description,
        icon: "question",
        showCancelButton: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
      }).then((result) => {
        if (result.isConfirmed) {

          userService.showLoader(true);

          return userService.runApi('loadCard/', formData)
            .then((res) => {
              if (res.data.result === "success") {
                userService.showLoader(false);
                Swal.fire({
                  title: "Success",
                  text: "The loading process was successful. Please wait a moment until the processing is complete (Up to "+ (loadType === standardLoadType? '24' : '72') +" hours maximum)",
                  icon: "success",
                }).then(function () {
                  userService.showLoader(false);
                  router.reload();
                });
              } else if (res.data.result === "failed") {
                userService.showLoader(false);
                Swal.fire({
                  title: "Error",
                  text: res.data.error.errorMessage,
                  icon: "error",
                }).then(function (result) {

                });
              }
            })
            .catch((res) => {
              userService.showLoader(false);
              Swal.fire({
                title: "Error",
                text: res.response.data.error.errorMessage,
                icon: "error",
              }).then(function (result) {

              });
            });
        }
      })
    } else {
      setError('amount', {message: `Amount must be greater than 0`});
    }
  }

  return (
    <>
      <div className="container-fluid px-4">
        <div className="row pe-4 ps-5 pt-4 pb-4">
          <div className="col-sm-11 mt-1">
            <label className="">
              You are going to load money from your USD WALLET to your {memberCard === 0 ? "Debit" : "Member"} Card.{` (Load fee: ${load_processing_fee_fixed} $)`}
            </label>
            <br/>
            <label className="">
              Also , currently your pending load amount is <span className="pending-amount">{pendingTotal}</span> USD
            </label>
          </div>
          <div className="col-sm-12 mt-2">
            <form onSubmit={handleSubmit(onSubmit)}>
              <h4 className="mt-3">
                <b>Amount USD</b>
              </h4>
              <div className="mb-4">
                <input onKeyDown={handleKeyDown}
                       name="amount" step="0.01"
                       {...register('amount')} className={`form-control ${errors.amount ? 'is-invalid' : ''}`}
                       type="number"
                       value={inputValue}
                       onChange={handleInputChange}
                       placeholder={`Enter USD Amount`}
                       pattern="\d*\.?\d{0,2}"
                />
                <div className="invalid-feedback">{errors.amount?.message}</div>
                <div className="">Available amount
                  : {availableAmount} USD
                </div>
              </div>

              <h4 className="mt-0">
                <b>Select Load Type</b>
              </h4>

              <div className={`mb-4 ${styles.inputContainer}`}>
                <div className={styles.radioContainer}>
                  <label className={styles.formLabel}>
                    <input
                      type="radio"
                      name="instant"
                      value="1"
                      checked={loadType === 1}
                      onChange={handleRadioChange}
                    />
                    <span className={styles.formSpan}>Standard</span>
                  </label>
                  <span className={styles.textBelow}>* Loads within 24 hours</span>
                  <span className={styles.textBelow}>* {load_instant_fee_rate}% additional load fee</span>
                </div>
                <div className={styles.radioContainer}>
                  <label className={styles.formLabel}>
                    <input
                      type="radio"
                      name="instant"
                      value="0"
                      checked={loadType === 0}
                      onChange={handleRadioChange}
                    />
                    <span className={styles.formSpan}>Delayed</span>
                  </label>
                  <span className={styles.textBelow}>* Loads within 72 hours</span>
                  <span className={styles.textBelow}>* 0% additional load fee</span>
                </div>
              </div>

              <input
                type="hidden"
                name="fee"
                step="0.000001"
                {...register('fee')}
                value={loadFee}
              />
              <button type="submit" className="size-xl button primary mt-3 col-sm-3"
                      disabled={!!(formState.isSubmitting || errors.amount?.message)}
              >
                LOAD {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  )
}

export default CardLoad;
