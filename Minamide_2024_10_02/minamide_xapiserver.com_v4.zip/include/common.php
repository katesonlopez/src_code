<?php
define("MERCHANT_USERNAME", "Technologiescrypto2022@gmail.com"); //ultimo pap
define("MERCHANT_PASSWORD", "DU1g4B4M"); //ultimo pap
define("PAP_URL", "http://ultimopay.postaffiliatepro.com/scripts/server.php"); //ultimo pap
define("MERCHANT_USERNAME_XEXON", "contact@xexon.io"); //xexon pap
define("MERCHANT_PASSWORD_XEXON", "EGsY9Omo"); //xexon pap
define("PAP_URL_XEXON", "http://xexon.postaffiliatepro.com/scripts/server.php"); //xexon pap
define("DEFAULT_CAMPAIGN_ID", "faf0ba4c");
define("COMMISSION_TYPE_ID", "880wngo3");
define("ULTIMOCASINO_SHIFT_MASTER_USER_ID", "6116C4BB-81CE-4A51-AD67-951170C0673D");
define("ULTIMOCASINO_SHIFT_MASTER_USDT_ACCOUNT_ID", "62C90697-CB00-4C8F-BEB8-E10E0C5F553E");
define("ULTIMOCASINO_MASTER_EMAIL", "ultimocasino.master@gmail.com");
define("ULTIMOCASINO_MASTER_PASSWORD", "a7sDPz5u#6iL75b49!6n");
define("SHIFT_CONFIGURATOR_USERNAME", "PlusqoAdmin@server.com");
define("SHIFT_CONFIGURATOR_PASSWORD", "aaaaaa");
define("SHIFT_ADMIN_V2_USERNAME01", "kakizaki@optlynx.com");
define("SHIFT_ADMIN_V2_PASSWORD01", "1234567891aA#");
define("SHIFT_TIER_ZERO_GROUP_ID", "41E7FF0E-ABF0-4C6D-A48C-53520C522382");
define("SHIFT_LUCKY8_GROUP_ID", "2FA105F5-EC31-472A-BF58-92E621475752");
//define("SHIFT_ULTIMO_GROUP_ID", "5846043D-1BD2-48E6-944B-39DF32D8DBC5");
define("SHIFT_ULTIMO_GROUP_ID", "e5b7d0cf-e1e8-46ff-a3a0-e3a75987c0e9");
//define("PLUSQO_FEE_RECEIVER_USER_ID", "04E03E00-4A43-4C6C-B020-935E5F30B729"); //ultimo-card@ymail.ne.jp
//define("PLUSQO_FEE_RECEIVER_USER_ID", "c49657c4-f1e9-4f37-8eb7-a958435752bd"); //ririmi924@choco.la
define("PLUSQO_FEE_RECEIVER_USER_ID", "db06012e-3f65-4316-8b11-4aaaeeb25257"); //v4.ultimocard@gmail.com
define("PLUSQO_FEE_RECEIVER_USD_ACCOUNT_ID", "0246C676-107B-4FA3-9C0E-F08E8424E1EC"); //ultimo-card@ymail.ne.jp
define("PLUSQO_FEE_RECEIVER_BTC_ACCOUNT_ID", "E76E77CE-B8EF-4916-AA55-7989FD5744D5"); //ultimo-card@ymail.ne.jp
define("PLUSQO_FEE_RECEIVER_USDT_ACCOUNT_ID", "F2749898-2A51-4EFE-BDDB-5F2F12767F12"); //ultimo-card@ymail.ne.jp
// begin add 20230424 busd,usdc k.o.
define("PLUSQO_FEE_RECEIVER_BUSD_ACCOUNT_ID", "29257E5B-AC46-43F2-81E2-99E7527B112F"); //ultimo-card@ymail.ne.jp
define("PLUSQO_FEE_RECEIVER_USDC_ACCOUNT_ID", "B8282FFF-101A-4041-ADA2-A07F2FDF1860"); //ultimo-card@ymail.ne.jp
// end add 20230424 busd,usdc k.o.


//API V.4 configuration vars
define("BACKOFFICE_ADMIN_USERNAME", "quy@optlynx.com");
define("BACKOFFICE_ADMIN_PWD", "ExHJL&y4Qw2S#xj6VX6Bd$Soh"); //production
//define("BACKOFFICE_ADMIN_PWD", "M)4v&wuZuPsTZru#"); //test
define("AWS_COGNITO_AUTH_FLOW", "USER_PASSWORD_AUTH");
define("AWS_COGNITO_AUTH_FLOW_REFRESH", "REFRESH_TOKEN_AUTH");
/*
//dev environment
$api_host = 'https://cognito-idp.us-east-1.amazonaws.com';
$api_graphql_host = 'https://vakotrade.cryptosrvc-dev.com/graphql'; //dev
$aws_cognito_app_client_id = '3mqqalpv6hbf9fig7pljdk2s23'; //dev
$aws_cognito_pool_id = 'us-east-1_3Iq1Cisn1'; //dev

//demo environment
$api_host = 'https://cognito-idp.us-east-1.amazonaws.com';
$api_graphql_host = 'https://vakotrade-demo.cryptosrvc.com/graphql'; //demo
$aws_cognito_app_client_id = '3mqqalpv6hbf9fig7pljdk2s23'; //demo
$aws_cognito_pool_id = 'us-east-1_3Iq1Cisn1'; //demo
*/
//plusqo-uat environment
$api_host = 'https://cognito-idp.us-east-1.amazonaws.com';
/*
$api_graphql_host = 'https://vakotrade-plusqo-uat.cryptosrvc.com/graphql'; //plusqo-uat
$aws_cognito_app_client_id = '7o4j0hil5i6adpk6lrsrh44l8r'; //plusqo-uat
$aws_cognito_backoffice_client_id = '2v948ieso6kvk4m5l8attchhv2'; //plusqo-uat
$aws_cognito_pool_id = 'us-east-1_f0Bj5wJPM'; //plusqo-uat
*/
$api_graphql_host = 'https://vakotrade-plusqo.cryptosrvc.com/graphql'; //plusqo-production
$aws_cognito_app_client_id = '6b7na264auoki8v9tfrg1be91n'; //plusqo-production
$aws_cognito_backoffice_client_id = 'm7l0q5iogv03n6fk26ad58no9'; //plusqo-production
$aws_cognito_pool_id = 'us-east-1_GMO7BtFJV'; //plusqo-production

/*
//API V.4 configuration vars (plusqo sandbox)
$api_host = 'https://cognito-idp.us-east-1.amazonaws.com';
//$api_graphql_host = 'https://vakotrade-plusqo-uat.cryptosrvc.com/graphql'; //plusqo sandbox graphQL
$api_graphql_host = 'https://vakotrade.cryptosrvc-dev.com/graphql'; //demo graphQL
$aws_cognito_app_client_id = '3mqqalpv6hbf9fig7pljdk2s23'; //demo
//$aws_cognito_app_client_id = '7o4j0hil5i6adpk6lrsrh44l8r'; //sandbox
$aws_cognito_pool_id = 'us-east-1_3Iq1Cisn1'; //demo
*/

//$api_host = 'https://api.cryptosrvc.com';
$api_host2 = 'https://api.plusqo.io';
$simplex_sandbox_url = 'https://sandbox.test-simplexcc.com';
$simplex_production_url = 'https://backend-wallet-api.simplexcc.com';
//$api_host2 = 'https://trade.plusqo.shiftmarketsdev.com';
$security_id = 'XBITBTC';
$ipgeolocation_api_key = "6be02f683f5342ff8320ca9d4dea20dc";
////$simplex_prod_api_key = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwYXJ0bmVyIjoicGx1c3FvIiwiaXAiOlsiODguOTkuOTcuMTM1Il0sInNhbmRib3giOmZhbHNlfQ.SXPgnQ5Xl5ozZWPyTgnx_dfjDLJ-Qn9wylWegSuJUms";
$simplex_sandbox_api_key = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwYXJ0bmVyIjoieGJ1eSIsImlwIjpbIjEuMi4zLjQiXSwic2FuZGJveCI6dHJ1ZX0.kbTzzb1fvDNwTEaQgzS2VyBuU6Sc9j1kl4KlbQxfjgA";
$simplex_prod_api_key = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwYXJ0bmVyIjoieGJ1eSIsImlwIjpbIjk0LjEzMC43MS40NSJdLCJzYW5kYm94IjpmYWxzZX0.74WAs7zBQ0xSk2vq83oHYbjfHF8HAlNI0xeJK9F5gd8";
function write_log($line) {
  //global $fh;
  $fh3 = fopen(dirname(dirname(__FILE__)) . "/log/giaima.log" , 'a');
  $fline = date('[Ymd H:i:s] ') . $line."\n";
  fwrite($fh3, $fline);
  fclose($fh3);
}


function format_coin($in_amount) {

  $in_amount_temp = "" . $in_amount;
  $dotpos = strpos($in_amount_temp,".",0);
  if ( $dotpos !== false ) {
    $p1 = substr($in_amount_temp,0, $dotpos);
    $p2 = substr($in_amount_temp,$dotpos + 1);
    $p2_len = strlen($p2);
    if ($p2_len > 8) {
      $p2_final =	substr($p2, 0, 8);
    } else {
      $p2_final = $p2;
    }
    $amount_final = $p1 . "." . $p2_final;
  } else {
    $amount_final = $in_amount_temp;
  }
  return $amount_final;
}

function format_fiat($in_amount, $float_point) {

  $in_amount_temp = "" . $in_amount;
  $dotpos = strpos($in_amount_temp,".",0);
  if ( $dotpos !== false ) {
    $p1 = substr($in_amount_temp,0, $dotpos);
    $p2 = substr($in_amount_temp,$dotpos + 1);
    $p2_len = strlen($p2);
    if ($p2_len > $float_point) {
      $p2_final =	substr($p2, 0, $float_point);
    } else {
      $p2_final = $p2;
    }
    $amount_final = $p1 . "." . $p2_final;
  } else {
    $amount_final = $in_amount_temp;
  }
  return $amount_final;
}

function common_uuid()
{
  return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
    mt_rand(0, 0xffff), mt_rand(0, 0xffff),
    mt_rand(0, 0xffff),
    mt_rand(0, 0x0fff) | 0x4000,
    mt_rand(0, 0x3fff) | 0x8000,
    mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
  );
}

function millitime() {
  $microtime = microtime();
  $comps = explode(' ', $microtime);

  // Note: Using a string here to prevent loss of precision
  // in case of "overflow" (PHP converts it to a double)
  return sprintf('%d%03d', $comps[1], $comps[0] * 1000);
}

function exchangeratesapi_call($base_currency) {
  $rates_rs = array ('error' => '', 'result' => '', 'http_code' => 0);
  $req_url = "https://api.exchangeratesapi.io/latest?base=" . $base_currency;
  $curl = curl_init();

  curl_setopt_array($curl, array(
    CURLOPT_URL => $req_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
  ));

  $rates = curl_exec($curl);
  $rates_rs['http_code']  = curl_getinfo($curl, CURLINFO_HTTP_CODE);

  if ($rates === false) { //CURL call failed
    //throw new Exception('Could not get reply: ' . curl_error($ch));
    $rates_rs['error'] = 'could not get reply with error : ' . curl_error($simplex_ch);
    //return $rs;
  } else {
    //$rates_rs['result'] = $simplex_result;

    $rates_decode = json_decode($rates, true );
    if (!($rates_decode)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          $rates_rs['error'] = 'Reached the maximum stack depth';
          break;
        case JSON_ERROR_STATE_MISMATCH:
          $rates_rs['error'] = 'Incorrect discharges or mismatch mode';
          break;
        case JSON_ERROR_CTRL_CHAR:
          $rates_rs['error'] = 'Incorrect control character';
          break;
        case JSON_ERROR_SYNTAX:
          $rates_rs['error'] = 'Syntax error or JSON invalid';
          break;
        case JSON_ERROR_UTF8:
          $rates_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
          break;
        default:
          $rates_rs['error'] = 'Unknown error';
      }

      //throw new Exception($error);

    } else {

      $rates_rs['result'] = $rates_decode;
    }

  }

  curl_close($curl);
  return $rates_rs;


}

function ipgeolocation_api_call($ipgeolocation_api_name, $ipgeolocation_post_data) {
  global $simplex_sandbox_url;
  global $simplex_production_url;

  $simplex_rs = array ('error' => '', 'result' => '', 'http_code' => 0);

  $simplex_ch = curl_init();

  if ($simplex_api_name == '/wallet/merchant/v2/quote') {
    if ($api_mode == "sandbox") {
      $simplex_api_url = $simplex_sandbox_url . '/wallet/merchant/v2/quote';
    } else if ($api_mode == "production") {
      $simplex_api_url = $simplex_production_url . '/wallet/merchant/v2/quote';
    }
    $simplex_post_data = json_encode( $simplex_post_data );
    curl_setopt($simplex_ch, CURLOPT_URL, $simplex_api_url);
    curl_setopt($simplex_ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($simplex_ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($simplex_ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: $simplex_authorization_value"));
    curl_setopt($simplex_ch, CURLOPT_POSTFIELDS, $simplex_post_data);
    curl_setopt($simplex_ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($simplex_ch, CURLOPT_FOLLOWLOCATION, true);
  }

  $simplex_result = curl_exec($simplex_ch);
  //print curl_error($ch);
  //$responseInfo = curl_getinfo($ch);
  //$rs['http_code'] = $responseInfo["http_code"];
  $rs['http_code']  = curl_getinfo($simplex_ch, CURLINFO_HTTP_CODE);
  //_log($api_name . ": http_code = " . $rs['http_code'], $file_handle);

  //if ($rs['http_code'] == 401) {
  //	$rs['result'] = '';
  //	$rs['error'] = 'invalid_token';
  //} else {
  if ($simplex_result === false) { //CURL call failed
    //throw new Exception('Could not get reply: ' . curl_error($ch));
    $simplex_rs['error'] = 'could not get reply with error : ' . curl_error($simplex_ch);
    //return $rs;
  } else {
    //$simplex_rs['result'] = $simplex_result;

    $simplex_result_decode = json_decode($simplex_result, true );
    if (!($simplex_result_decode)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          $simplex_rs['error'] = 'Reached the maximum stack depth';
          break;
        case JSON_ERROR_STATE_MISMATCH:
          $simplex_rs['error'] = 'Incorrect discharges or mismatch mode';
          break;
        case JSON_ERROR_CTRL_CHAR:
          $simplex_rs['error'] = 'Incorrect control character';
          break;
        case JSON_ERROR_SYNTAX:
          $simplex_rs['error'] = 'Syntax error or JSON invalid';
          break;
        case JSON_ERROR_UTF8:
          $simplex_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
          break;
        default:
          $simplex_rs['error'] = 'Unknown error';
      }

      //throw new Exception($error);

    } else {

      $simplex_rs['result'] = $simplex_result_decode;
    }

  }

  //}

  curl_close($simplex_ch);
  return $simplex_rs;
}

function simplex_api_call($simplex_api_name, $simplex_post_data, $simplex_authorization_value, $api_mode) {
  global $simplex_sandbox_url;
  global $simplex_production_url;

  $simplex_rs = array ('error' => '', 'result' => '', 'http_code' => 0);

  $simplex_ch = curl_init();

  if ($simplex_api_name == '/wallet/merchant/v2/quote') {
    if ($api_mode == "sandbox") {
      $simplex_api_url = $simplex_sandbox_url . '/wallet/merchant/v2/quote';
    } else if ($api_mode == "production") {
      $simplex_api_url = $simplex_production_url . '/wallet/merchant/v2/quote';
    }
    $simplex_post_data = json_encode( $simplex_post_data );
    curl_setopt($simplex_ch, CURLOPT_URL, $simplex_api_url);
    curl_setopt($simplex_ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($simplex_ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($simplex_ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: $simplex_authorization_value"));
    curl_setopt($simplex_ch, CURLOPT_POSTFIELDS, $simplex_post_data);
    curl_setopt($simplex_ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($simplex_ch, CURLOPT_FOLLOWLOCATION, true);

  }

  $simplex_result = curl_exec($simplex_ch);
  //print curl_error($ch);
  //$responseInfo = curl_getinfo($ch);
  //$rs['http_code'] = $responseInfo["http_code"];
  $rs['http_code']  = curl_getinfo($simplex_ch, CURLINFO_HTTP_CODE);
  //_log($api_name . ": http_code = " . $rs['http_code'], $file_handle);

  //if ($rs['http_code'] == 401) {
  //	$rs['result'] = '';
  //	$rs['error'] = 'invalid_token';
  //} else {
  if ($simplex_result === false) { //CURL call failed
    //throw new Exception('Could not get reply: ' . curl_error($ch));
    $simplex_rs['error'] = 'could not get reply with error : ' . curl_error($simplex_ch);
    //return $rs;
  } else {
    //$simplex_rs['result'] = $simplex_result;
    $simplex_rs['raw'] = $simplex_result;
    $simplex_result_decode = json_decode($simplex_result, true );
    if (!($simplex_result_decode)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          $simplex_rs['error'] = 'Reached the maximum stack depth';
          break;
        case JSON_ERROR_STATE_MISMATCH:
          $simplex_rs['error'] = 'Incorrect discharges or mismatch mode';
          break;
        case JSON_ERROR_CTRL_CHAR:
          $simplex_rs['error'] = 'Incorrect control character';
          break;
        case JSON_ERROR_SYNTAX:
          $simplex_rs['error'] = 'Syntax error or JSON invalid';
          break;
        case JSON_ERROR_UTF8:
          $simplex_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
          break;
        default:
          $simplex_rs['error'] = 'Unknown error';
      }

      //throw new Exception($error);

    } else {

      $simplex_rs['result'] = $simplex_result_decode;
    }

  }

  //}

  curl_close($simplex_ch);
  return $simplex_rs;
}

function simplex_payment_request($simplex_api_name, $simplex_post_data, $simplex_authorization_value, $api_mode, $username) {
  global $simplex_sandbox_url;
  global $simplex_production_url;

  $simplex_rs = array ('error' => '', 'result' => '', 'http_code' => 0);

  $simplex_ch = curl_init();


  if ($api_mode == "sandbox") {
    $simplex_api_url = $simplex_sandbox_url . '/wallet/merchant/v2/payments/partner/data';
  } else if ($api_mode == "production") {
    $simplex_api_url = $simplex_production_url . '/wallet/merchant/v2/payments/partner/data';
  }

  $authorization_string = "Authorization: " . $simplex_authorization_value;

  $simplex_post_data['payment_details']['payment_details']['quote_id'] = $quote_id2;
  $simplex_post_data['account_details']['payment_details']['payment_id'] = $payment_id2;
  $simplex_post_data['account_details']['payment_details']['order_id'] = $order_id2;
  $simplex_post_data['account_details']['payment_details']['fiat_total_amount']['currency'] = $fiat_total_currency2;
  $simplex_post_data['account_details']['payment_details']['fiat_total_amount']['amount'] = floatval($fiat_total_amount_amount2);
  $simplex_post_data['account_details']['payment_details']['requested_digital_amount']['currency'] = $requested_digital_amount_currency2;
  $simplex_post_data['account_details']['payment_details']['requested_digital_amount']['amount'] = floatval($requested_digital_amount_amount2);
  $simplex_post_data['account_details']['payment_details']['destination_wallet']['currency'] = $requested_digital_amount_currency2;
  $simplex_post_data['account_details']['payment_details']['destination_wallet']['address'] = $destination_wallet_address2;
  $simplex_post_data['account_details']['payment_details']['destination_wallet']['tag'] = "";
  $simplex_post_data['account_details']['payment_details']['original_http_ref_url'] = $original_http_ref_url2;

  $header_cookie_value = "Cookie: " . $username;
  $raw_data = "{\"account_details\":{\"signup_login\":{\"ip\":\"";
  $raw_data = $raw_data . $simplex_post_data['account_details']['signup_login']['ip'];
  $raw_data = $raw_data . "\",\"accept_language\":\"";
  $raw_data = $raw_data . $simplex_post_data['account_details']['signup_login']['accept_language'];
  $raw_data = $raw_data . "\",\"http_accept_language\":\"";
  $raw_data = $raw_data . $simplex_post_data['account_details']['signup_login']['http_accept_language'];
  $raw_data = $raw_data . "\",\"user_agent\":\"";
  $raw_data = $raw_data . $simplex_post_data['account_details']['signup_login']['user_agent'];
  $raw_data = $raw_data . "\",\"timestamp\":\"";
  $raw_data = $raw_data . $simplex_post_data['account_details']['signup_login']['timestamp'];
  $raw_data = $raw_data . "\"},\"app_provider_id\":\"xbuy\",\"app_version_id\":\"1.0.0\",\"app_end_user_id\":\"";
  $raw_data = $raw_data . $simplex_post_data['account_details']['app_end_user_id'];
  $raw_data = $raw_data . "\"},\"transaction_details\":{\"payment_details\":{\"quote_id\":\"";
  $raw_data = $raw_data . $simplex_post_data['transaction_details']['payment_details']['quote_id'];
  $raw_data = $raw_data . "\",\"payment_id\":\"";
  $raw_data = $raw_data . $simplex_post_data['transaction_details']['payment_details']['payment_id'];
  $raw_data = $raw_data . "\",\"order_id\":\"";
  $raw_data = $raw_data . $simplex_post_data['transaction_details']['payment_details']['order_id'];
  $raw_data = $raw_data . "\",\"fiat_total_amount\":{\"currency\":\"";
  $raw_data = $raw_data . $simplex_post_data['transaction_details']['payment_details']['fiat_total_amount']['currency'];
  $raw_data = $raw_data . "\",\"amount\":";
  $raw_data = $raw_data . floatval($simplex_post_data['transaction_details']['payment_details']['fiat_total_amount']['amount']);
  $raw_data = $raw_data . "},\"requested_digital_amount\":{\"currency\":\"" . $simplex_post_data['transaction_details']['payment_details']['requested_digital_amount']['currency'] . "\",\"amount\":";
  $raw_data = $raw_data . floatval($simplex_post_data['transaction_details']['payment_details']['requested_digital_amount']['amount']);
  $raw_data = $raw_data . "},\"destination_wallet\":{\"currency\":\"" . $simplex_post_data['transaction_details']['payment_details']['destination_wallet']['currency'] . "\",\"address\":\"";
  $raw_data = $raw_data . $simplex_post_data['transaction_details']['payment_details']['destination_wallet']['address'];
  $raw_data = $raw_data . "\",\"tag\":\"\"},\"original_http_ref_url\":\"";
  $raw_data = $raw_data . $simplex_post_data['transaction_details']['payment_details']['original_http_ref_url'];
  $raw_data = $raw_data . "\"}}}";

  $fh = @fopen("/var/www/xbuy.io/log/transaction2.log" , 'a');
  $fline = date('[Ymd H:i:s] ') . $raw_data."\n";
  fwrite($fh, $fline);
  fclose($fh);

  curl_setopt_array($simplex_ch, array(
    CURLOPT_URL => $simplex_api_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $raw_data,
    CURLOPT_HTTPHEADER => array(
      $authorization_string,
      "Content-Type: application/json",
      "Content-Type: text/plain",
      $header_cookie_value
    ),
  ));





  $simplex_result = curl_exec($simplex_ch);
  //print curl_error($ch);
  //$responseInfo = curl_getinfo($ch);
  //$rs['http_code'] = $responseInfo["http_code"];
  $rs['http_code']  = curl_getinfo($simplex_ch, CURLINFO_HTTP_CODE);
  //_log($api_name . ": http_code = " . $rs['http_code']);

  //if ($rs['http_code'] == 401) {
  //	$rs['result'] = '';
  //	$rs['error'] = 'invalid_token';
  //} else {
  if ($simplex_result === false) { //CURL call failed
    //throw new Exception('Could not get reply: ' . curl_error($ch));
    $simplex_rs['error'] = 'could not get reply with error : ' . curl_error($simplex_ch);
    //return $rs;
  } else {
    //$simplex_rs['result'] = $simplex_result;
    $simplex_rs['raw'] = $simplex_result;
    $simplex_result_decode = json_decode($simplex_result, true );
    if (!($simplex_result_decode)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          $simplex_rs['error'] = 'Reached the maximum stack depth';
          break;
        case JSON_ERROR_STATE_MISMATCH:
          $simplex_rs['error'] = 'Incorrect discharges or mismatch mode';
          break;
        case JSON_ERROR_CTRL_CHAR:
          $simplex_rs['error'] = 'Incorrect control character';
          break;
        case JSON_ERROR_SYNTAX:
          $simplex_rs['error'] = 'Syntax error or JSON invalid';
          break;
        case JSON_ERROR_UTF8:
          $simplex_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
          break;
        default:
          $simplex_rs['error'] = 'Unknown error';
      }

      //throw new Exception($error);

    } else {

      $simplex_rs['result'] = $simplex_result_decode;
    }

  }

  //}

  curl_close($simplex_ch);
  return $simplex_rs;
}

function shift_configurator_api_call($api_name, $nonce, $query_string, $post_data, $authorization_value) {

  global $api_host;
  global $api_host2;

  $rs = array ('error' => '', 'result' => '', 'http_code' => 0);
  $ch = curl_init();

  if ($api_name == 'balancecorrection') {

    $api_url = "https://config.plusqo.shiftmarketsdev.com/api/users/" . $post_data['userId'] . "/accounts/" . $post_data['accountId'] . "/balancecorrection";

    $postdata = json_encode( $post_data );
    curl_setopt($ch, CURLOPT_URL, $api_url);
    //curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: $authorization_value"));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  } else if ($api_name == '/api/configurator_authentication/configuratorToken') {
    $api_url = "https://authentication.cryptosrvc.com/api/configurator_authentication/configuratorToken";
    $postdata = json_encode( $post_data );

    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    //curl_setopt($ch, CURLOPT_HTTPHEADER, array('authorization: Basic d2ViOg==','Content-Type: application/x-www-form-urlencoded'));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
  }

  $result = curl_exec($ch);
  $rs['http_code']  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  if ($result === false) { //CURL call failed
    //throw new Exception('Could not get reply: ' . curl_error($ch));
    $rs['error'] = 'could not get reply with error : ' . curl_error($ch);
    //return $rs;
  } else {
    $result_decode = json_decode($result, true );
    if (!($result_decode)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          $rs['error'] = 'Reached the maximum stack depth';
          break;
        case JSON_ERROR_STATE_MISMATCH:
          $rs['error'] = 'Incorrect discharges or mismatch mode';
          break;
        case JSON_ERROR_CTRL_CHAR:
          $rs['error'] = 'Incorrect control character';
          break;
        case JSON_ERROR_SYNTAX:
          $rs['error'] = 'Syntax error or JSON invalid';
          break;
        case JSON_ERROR_UTF8:
          $rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
          break;
        default:
          $rs['error'] = 'Unknown error';
      }

      //throw new Exception($error);

    } else {

      $rs['result'] = $result_decode;
    }
  }

  curl_close($ch);
  return $rs;
}

function shift_admin_v2_api_call($api_name, $nonce, $query_string, $post_data, $authorization_value) {


  $rs = array ('error' => '', 'result' => '', 'http_code' => 0);
  $ch = curl_init();

  if ($api_name == 'login') {

    $api_url = "https://admin-api.cryptosrvc.com/v2/authentication/back_office_authentication/login/";

    $postdata = json_encode( $post_data );
    curl_setopt($ch, CURLOPT_URL, $api_url);
    //curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_TIMEOUT, 45);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  } else if ($api_name == 'changeUserGroup') {
    $api_url = "https://admin-api.cryptosrvc.com/v2/authentication/exchange_user_admin/changeUserGroup/";
    $postdata = json_encode( $post_data );

    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    //curl_setopt($ch, CURLOPT_HTTPHEADER, array('authorization: Basic d2ViOg==','Content-Type: application/x-www-form-urlencoded'));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: $authorization_value"));
    curl_setopt($ch, CURLOPT_TIMEOUT, 45);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
  } else if ($api_name == 'getUserGroup') {
    $api_url = "https://admin-api.cryptosrvc.com/v2/authentication/exchange_user_admin/getUserGroup/";
    $postdata = json_encode( $post_data );

    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    //curl_setopt($ch, CURLOPT_HTTPHEADER, array('authorization: Basic d2ViOg==','Content-Type: application/x-www-form-urlencoded'));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: $authorization_value"));
    curl_setopt($ch, CURLOPT_TIMEOUT, 45);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
  }

  $result = curl_exec($ch);
  $rs['http_code']  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  if ($result === false) { //CURL call failed
    //throw new Exception('Could not get reply: ' . curl_error($ch));
    $rs['error'] = 'could not get reply with error : ' . curl_error($ch);
    //return $rs;
  } else {
    $result_decode = json_decode($result, true );
    if (!($result_decode)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          $rs['error'] = 'Reached the maximum stack depth';
          break;
        case JSON_ERROR_STATE_MISMATCH:
          $rs['error'] = 'Incorrect discharges or mismatch mode';
          break;
        case JSON_ERROR_CTRL_CHAR:
          $rs['error'] = 'Incorrect control character';
          break;
        case JSON_ERROR_SYNTAX:
          $rs['error'] = 'Syntax error or JSON invalid';
          break;
        case JSON_ERROR_UTF8:
          $rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
          break;
        default:
          $rs['error'] = 'Unknown error';
      }

      //throw new Exception($error);

    } else {

      $rs['result'] = $result_decode;
    }
  }

  curl_close($ch);
  return $rs;
}


function api_call($api_name, $nonce, $query_string, $post_data, $authorization_value) {

  global $api_host;
  global $api_host2;
  global $api_graphql_host;


  $rs = array ('error' => '', 'result' => '', 'http_code' => 0);

  //$mt = explode(' ', microtime());
  //$NONCE = $mt[1] . substr($mt[0], 2, 6);
  //$authorization_value = "Bearer " . trim($_SESSION['exchange_access_token']);


  //$req_data = http_build_query($data);
  //$req_data = http_build_query($data, '', '&');

  $ch = curl_init();


  if ($api_name == '/authentication/user_authentication/resendSignUpCode') {
    //$api_url = $api_host . "/authentication/user_authentication/resendSignUpCode";
    $postdata = json_encode( $post_data );
    curl_setopt($ch, CURLOPT_URL, $api_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/x-amz-json-1.1',
      'X-Amz-Target: AWSCognitoIdentityProviderService.ResendConfirmationCode'
    ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);


  } else if ($api_name == '/authentication/user_authentication/startForgotPassword') {
    //$api_url = $api_host . "/authentication/user_authentication/startForgotPassword";
    $postdata = json_encode( $post_data );
    curl_setopt($ch, CURLOPT_URL, $api_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/x-amz-json-1.1',
      'X-Amz-Target: AWSCognitoIdentityProviderService.ForgotPassword'
    ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);

  } else if ($api_name == '/authentication/user_authentication/completeForgotPassword') {
    //$api_url = $api_host . "/authentication/user_authentication/completeForgotPassword";
    $postdata = json_encode( $post_data );
    curl_setopt($ch, CURLOPT_URL, $api_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/x-amz-json-1.1',
      'X-Amz-Target: AWSCognitoIdentityProviderService.ConfirmForgotPassword'
    ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);

  } else if ($api_name == '/authentication/user_authentication/signUp') {
    //$api_url = $api_host . "/authentication/user_authentication/signUp";
    $postdata = json_encode( $post_data );
    curl_setopt($ch, CURLOPT_URL, $api_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.89 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/x-amz-json-1.1',
      'X-Amz-Target: AWSCognitoIdentityProviderService.SignUp'
    ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);


  } else if ($api_name == '/authentication/user_authentication/confirmSignUp') {
    //$api_url = $api_host . "/authentication/user_authentication/confirmSignUp";
    $postdata = json_encode( $post_data );
    curl_setopt($ch, CURLOPT_URL, $api_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.89 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/x-amz-json-1.1',
      'X-Amz-Target: AWSCognitoIdentityProviderService.ConfirmSignUp'
    ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);

  } else if ($api_name == '/authentication/user_authentication/exchangeToken') {
    $api_url = $api_host . "/authentication/user_authentication/exchangeToken";
    $postdata = json_encode( $post_data );

    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    //curl_setopt($ch, CURLOPT_HTTPHEADER, array('authorization: Basic d2ViOg==','Content-Type: application/x-www-form-urlencoded'));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  } else if ($api_name == '/authentication/user_authentication/refreshAccessToken') {
    //$api_url = $api_host . "/authentication/user_authentication/exchangeToken";
    $postdata = json_encode( $post_data );

    curl_setopt($ch, CURLOPT_URL, $api_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    //curl_setopt($ch, CURLOPT_HTTPHEADER, array('authorization: Basic d2ViOg==','Content-Type: application/x-www-form-urlencoded'));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/x-amz-json-1.1',
      'X-Amz-Target: AWSCognitoIdentityProviderService.InitiateAuth'
    ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);

  } else if ($api_name == '/api/v1/orders/') {
    $api_url = $api_host2 . "/api/v1/orders/";
    $headers = array("Accept: application/json", "x-deltix-nonce: $nonce", "Authorization: $authorization_value");

    //$data['client_order_id'] = $NewOrderDto['client_order_id'];
    //$data['security_id'] = $NewOrderDto['security_id'];

    //$data['type'] = $NewOrderDto['type'];
    //$data['side'] = $NewOrderDto['side'];
    //$data['quantity'] = $NewOrderDto['quantity'];
    //$data['time_in_force'] = $NewOrderDto['time_in_force'];
    //$data['expire_time'] = $NewOrderDto['expire_time'];
    //$data['submission_time'] = $NewOrderDto['submission_time'];
    //$data['text'] = $NewOrderDto['text'];
    //$data['properties'] = $NewOrderDto['properties'];
    $postdata = json_encode( $post_data );
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "x-deltix-nonce: $nonce", "Authorization: $authorization_value"));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);


  } else if ($api_name == '/wallet/deposit/create') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  } else if ($api_name == '/api/v4/wallet/withdraw/create') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  } else if ($api_name == '/wallet/transaction/status') {
    $req_data = http_build_query($query_string, '', '&');
    $api_url = $api_host . "/wallet/transaction/status" . "?" . $req_data;
    $headers = array("Authorization: $authorization_value");
    curl_setopt($ch, CURLOPT_URL, $api_url);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  } else if ($api_name == '/api/v4/wallet/transaction/history') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  } else if ($api_name == '/api/v4/securities/statistics') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  }  else if ($api_name == '/api/v4/accounts') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);


  } else if ($api_name == '/api/v1/currencies/') {
    $api_url = $api_host2 . "/api/v1/currencies/";
    //_log("access : " . $api_url);
    $headers = array("x-deltix-nonce: $nonce", "Authorization: $authorization_value");
    curl_setopt($ch, CURLOPT_URL, $api_url);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  } else if ($api_name == '/api/v4/trade/orders/closed/') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  } else if ($api_name == 'getReport') {
    //$req_data = http_build_query($query_string, '', '&');
    $api_url = $api_host . "/trade/orders/closed";
    $headers = array("Authorization: $authorization_value");
    curl_setopt($ch, CURLOPT_URL, $api_url);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  }  else if ($api_name == '/api/v4/create_account_transaction') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  }  else if ($api_name == '/api/v4/update_user_fee_group') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  }  else if ($api_name == '/api/v4/update_user_limit_group') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  }  else if ($api_name == '/api/v4/create_order/') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);


  }  else if ($api_name == '/api/v4/auth_check_in') {
    curl_setopt($ch, CURLOPT_URL, $api_graphql_host);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      "Content-Type: application/json",
      "Authorization: $authorization_value"
    ));
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.34 Safari/537.36');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  }

  $result = curl_exec($ch);
  if ($api_name == '/authentication/user_authentication/confirmSignUp') {
    write_log(curl_error($ch));
    write_log(json_encode($result, JSON_PRETTY_PRINT));
  }

  //print curl_error($ch);
  //$responseInfo = curl_getinfo($ch);
  //$rs['http_code'] = $responseInfo["http_code"];
  $rs['http_code']  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  //_log($api_name . ": http_code = " . $rs['http_code'], $file_handle);

  //if ($rs['http_code'] == 401) {
  //	$rs['result'] = '';
  //	$rs['error'] = 'invalid_token';
  //} else {
  if ($result === false) { //CURL call failed
    //throw new Exception('Could not get reply: ' . curl_error($ch));
    $rs['error'] = 'could not get reply with error : ' . curl_error($ch);
    //return $rs;
  } else {
    $result_decode = json_decode($result, true );
    if (!($result_decode)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          $rs['error'] = 'Reached the maximum stack depth';
          break;
        case JSON_ERROR_STATE_MISMATCH:
          $rs['error'] = 'Incorrect discharges or mismatch mode';
          break;
        case JSON_ERROR_CTRL_CHAR:
          $rs['error'] = 'Incorrect control character';
          break;
        case JSON_ERROR_SYNTAX:
          $rs['error'] = 'Syntax error or JSON invalid';
          break;
        case JSON_ERROR_UTF8:
          $rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
          break;
        default:
          $rs['error'] = 'Unknown error';
      }

      //throw new Exception($error);

    } else {

      $rs['result'] = $result_decode;
    }
  }

  //}

  curl_close($ch);
  return $rs;
}


function get_access_token($username, $pwd) {


  $post_data = array();
  $post_data['username'] = trim($username);
  $post_data['password'] = $pwd;
  $post_data['exchange'] = "PLUSQO";
  $access_token_res = api_call('/authentication/user_authentication/exchangeToken', 0, '', $post_data, '');
  $rs = array ('exchange_access_token' => '', 'client_access_token' => '', 'msg' => '');

  if ($access_token_res['result'] != '') {
    if ($access_token_res['result']['result'] == 'success') {

      if (isset($access_token_res['result']['exchange_access_token'])) {
        $access_token = $access_token_res['result']['exchange_access_token'];
        $rs['exchange_access_token'] = $access_token;
      }
      if (isset($access_token_res['result']['client_access_token'])) {
        $client_access_token = $access_token_res['result']['client_access_token'];
        $rs['client_access_token'] = $client_access_token;
      }
      if (($rs['exchange_access_token'] != '') && ($rs['client_access_token'] != '')) {

        $rs['msg'] = 'get new token ok';
      } else {
        $rs['msg'] = 'get new token failed';
      }

    } else {

      if ( strpos(strtolower($access_token_res['result']['message']), "incorrect username or password") !== false ) {

        $data['msg'] = "Incorrect login email or password";

      } else if ( strpos(strtolower($access_token_res['result']['message']), "user does not exist") !== false ) {

        $data['msg'] = "User does not exist";

      } else if ( strpos(strtolower($access_token_res['result']['message']), "missing required parameter software_token_mfa_code") !== false ) {

        $data['msg'] = "need_2fa";

      } else if ( strpos(strtolower($access_token_res['result']['message']), "user is not confirmed") !== false ) {

        $data['msg'] = "user is not confirmed";

      }
    }
  } else {

    $rs['msg'] = 'get new token failed';
  }

  return $rs;

}


function check_token_expiration($authorization_value, $username, $pwd) {
  //global $config_access_token;
  //global $config_refresh_token;
  //global $config_expires_in;
  //global $config_last_token_time;
  //global $force_new_token_interval;
  //global $nonce; //use for ping_test_api
  //$rs = array ('error' => '', 'msg' => '');
  $rs = array ('exchange_access_token' => '', 'client_access_token' => '', 'msg' => '', 'msg_ex' => '' , 'error' => '');


  $_nonce = millitime();

  //_log("begin check_token_expiration()...", $file_handle);

  /////////////////////////////////////////////////////////////////////////////

  //because cannot believe in expires_in, so we ping api every time to check.
  //sleep(1); //for safe api call
  $_nonce = $_nonce + 1;
  unset($ping_api_res);
  $order_dto_arr = array();
  //_log("begin ping test...", $file_handle);
  $ping_api_res = api_call('/api/v1/currencies/', $_nonce,  '', $order_dto_arr, $authorization_value);
  //$login_res = api_call('/authentication/user_authentication/exchangeToken', 0, '', $post_data);
  if ($ping_api_res['result'] != '') {
    if ($ping_api_res['result']['error'] == 'invalid_token') {

      //// Unset all of the session variables.
      //unset($_SESSION['username']);
      //unset($_SESSION['pwd']);
      //unset($_SESSION['exchange_access_token']);
      //unset($_SESSION['client_access_token']);
      //// Finally, destroy the session.
      //session_destroy();

      //sleep(1); //need ??

      $get_access_token_res = get_access_token($username, $pwd);
      $rs['exchange_access_token'] = $get_access_token_res['exchange_access_token'];
      $rs['client_access_token'] = $get_access_token_res['client_access_token'];
      $rs['msg'] = $get_access_token_res['msg'];


    } else {
      //_log("check_token_expiration(): token is still valid !", $file_handle);
      $rs['msg'] = 'token is still valid';
    }
  } else { //CURL failed or json object failed (API Fatal Error)
    //ping failed, perhaps other api calls will be failed, too
    //in this case, should do nothing.
    /*
    //reset global vars
    $config_access_token = 'empty';
    $config_refresh_token = 'empty';
    $config_expires_in = 0;
    $config_last_token_time = 0;
    sleep(1); //need ??
    $get_access_token_res = get_access_token();
    if (($get_access_token_res==1) && ($config_access_token != 'empty') && ($config_refresh_token != 'empty')) {
      _log("check_token_expiration(): could get new token !");
    }
    */
    //_log("ping /api/v1/currencies/ FAILED : " . $ping_api_res['error'], $file_handle);

    //$rs['msg'] = "ping failed";
    //$rs['error'] = $ping_api_res['error'];

    sleep(2);
    $get_access_token_res = get_access_token($username, $pwd);
    if ($get_access_token_res['msg'] == 'get new token ok') {
      $rs['exchange_access_token'] = $get_access_token_res['exchange_access_token'];
      $rs['client_access_token'] = $get_access_token_res['client_access_token'];
      $rs['msg'] = $get_access_token_res['msg'];
      $rs['msg_ex'] = 'ping failed but retry ok';
    } else {
      $rs['msg'] = "ping failed";
      $rs['error'] = $ping_api_res['error'];
    }


  }




  /////////////////////////////////////////////////////////////////////////////

  return $rs;


}



function h($str){
  return nl2br(htmlspecialchars($str, ENT_QUOTES, 'UTF-8'), false);
}

function send_confirm_email($from, $to, $body, $subject)
{
  $send_confirm = false;
  $headersfrom='';
  $headersfrom .= 'MIME-Version: 1.0' . "\r\n";
  //$headersfrom .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
  $headersfrom .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
  $headersfrom .= 'From: ' . $from. "\r\n";
  //$headers .= 'From: PLUSQO<info@plusqo.io>' . "\r\n";
  $headersfrom .= "Reply-To:  " . $from . "\r\n";
  //mail($to,$subject,$body,$headersfrom);
  $send_confirm = mb_send_mail($to, $subject, $body, $headersfrom);
  return $send_confirm;
}

function getUserIpAddr(){
  if(!empty($_SERVER['CF_CONNECTING_IP'])){
    //ip pass from proxy
    $ip = $_SERVER['CF_CONNECTING_IP'];
  }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
    //ip from share internet
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
  }else{
    $ip = $_SERVER['REMOTE_ADDR'];
  }
  return $ip;
}


function generate_id( $length=10 )
{
  $random = NULL;
  $chars  = '1234567890';


  $index  = 1;
  while ( $index <= $length ) {
    $max        = strlen($chars)-1;
    $num        = rand(0, $max);
    $tmp        = substr($chars, $num, 1);
    $random        .= $tmp;
    ++$index;
  }

  return $random;
}

function get_configurator_key($_email, $_auth_token, $_target_key_salt, $_target_key_value) {

  $rs = array ('error' => '', 'result' => '', 'http_code' => 0);

  ////////////////////////////////////
  $curl = curl_init();

  $raw_postdata = array();
  $raw_postdata['email_address'] = $_email;
  $raw_postdata['auth_token'] = $_auth_token;
  $raw_postdata['target_key_salt'] = $_target_key_salt;
  $raw_postdata['target_key_value'] =  $_target_key_value;
  //$raw_postdata['target_key_salt'] = 'plusqo_configurator_key_salt';
  //$raw_postdata['target_key_value'] = 'plusqo_configurator_ec_key';
  $postdata = json_encode($raw_postdata);

  curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://secure-api.ultimopay.io/v1/getConfiguratorKey/',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => $postdata,
    CURLOPT_HTTPHEADER => array(
      'Content-Type: application/json'
    ),
  ));

  $response = curl_exec($curl);
  $rs['http_code']  = curl_getinfo($curl, CURLINFO_HTTP_CODE);
  if ($response === false) { //CURL call failed
    //throw new Exception('Could not get reply: ' . curl_error($ch));
    $rs['error'] = 'could not get reply with error : ' . curl_error($curl);
    //return $rs;
  } else {
    $result_decode = json_decode($response, true );
    if (!($result_decode)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          $rs['error'] = 'Reached the maximum stack depth';
          break;
        case JSON_ERROR_STATE_MISMATCH:
          $rs['error'] = 'Incorrect discharges or mismatch mode';
          break;
        case JSON_ERROR_CTRL_CHAR:
          $rs['error'] = 'Incorrect control character';
          break;
        case JSON_ERROR_SYNTAX:
          $rs['error'] = 'Syntax error or JSON invalid ne ban';
          break;
        case JSON_ERROR_UTF8:
          $rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
          break;
        default:
          $rs['error'] = 'Unknown error';
      }

      //throw new Exception($error);

    } else {

      $rs['result'] = $result_decode;
    }
  }

  curl_close($curl);
  return $rs;
  ////////////////////////////////////

}

?>