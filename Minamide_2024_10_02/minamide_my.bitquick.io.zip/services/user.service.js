import {BehaviorSubject} from 'rxjs';
import axios from '/lib/axios'
import React from 'react';
import ReactDOM from 'react-dom';
import LoadingOverlay from 'react-loading-overlay';
import * as Yup from 'yup';

let isLoading = false;
let container = null;
const userSubject = new BehaviorSubject(process.browser && (localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')) : null));

export const userService = {
  user: userSubject.asObservable(),
  verifyResetCode,
  walletBalance,
  register,
  forgot,
  set2FA,
  get2FASecretKey,
  runApi,
  getDatePhpFormat,
  getUserStatus,
  getCurrencyOrder,
  getWalletOrder,
  showLoader,
  PreventIncrement,
  CommonValidation,
  getCountries
};

function runApi(api, user) {
  const url = process.env.NEXT_PUBLIC_API_URL + '?uri=' + api;
  return axios.post(url, user);
}

function CommonValidation() {
  return Yup.string().test('not-one-of', 'Invalid input', value => {
    const invalidWords = ['http', 'script', 'https', 'javascript'];
    const regex = new RegExp(`\\b(?:${invalidWords.join('|')})\\b`, 'i');
    return !regex.test(value);
  })
    .matches(/^(?![<>]).*$/, 'Invalid input');
}

function getCurrencyOrder() {
  return ["USDT", "BTC", "USD", "USDC", "BUSD", "SOL", "BCH", "ETH", "LTC", "XRP"];
}

function getWalletOrder(){
  return {
    USDT: {
      key: 0,
      float: 6,
      title: 'Tether',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="%width%" height="%height%" viewBox="0 0 24 24"><path d="M 12 1 C 5.935 1 1 5.935 1 12 C 1 18.065 5.935 23 12 23 C 18.065 23 23 18.065 23 12 C 23 5.935 18.065 1 12 1 z M 12 3 C 16.963 3 21 7.038 21 12 C 21 16.963 16.963 21 12 21 C 7.038 21 3 16.963 3 12 C 3 7.038 7.038 3 12 3 z M 7 7 L 7 9 L 11 9 L 11 10.048828 C 8.7935403 10.157378 6 10.631324 6 12 C 6 13.368676 8.7935403 13.842622 11 13.951172 L 11 18 L 13 18 L 13 13.951172 C 15.20646 13.842622 18 13.368676 18 12 C 18 10.631324 15.20646 10.157378 13 10.048828 L 13 9 L 17 9 L 17 7 L 7 7 z M 11 11.027344 L 11 12 L 13 12 L 13 11.027344 C 15.42179 11.151768 16.880168 11.700988 17.003906 11.978516 C 16.863906 12.334516 15.021 13 12 13 C 8.978 13 7.1360937 12.335484 6.9960938 12.021484 C 7.1198324 11.706835 8.5777007 11.152269 11 11.027344 z"></path></svg>',
      data: {},
    },
    BTC: {
      key: 1,
      float: 8,
      title: 'Bitcoin',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" width="%width%" height="%height%" fill="currentColor" class="bi bi-currency-bitcoin" viewBox="0 0 16 16" > <path d="M5.5 13v1.25c0 .138.112.25.25.25h1a.25.25 0 0 0 .25-.25V13h.5v1.25c0 .138.112.25.25.25h1a.25.25 0 0 0 .25-.25V13h.084c1.992 0 3.416-1.033 3.416-2.82 0-1.502-1.007-2.323-2.186-2.44v-.088c.97-.242 1.683-.974 1.683-2.19C11.997 3.93 10.847 3 9.092 3H9V1.75a.25.25 0 0 0-.25-.25h-1a.25.25 0 0 0-.25.25V3h-.573V1.75a.25.25 0 0 0-.25-.25H5.75a.25.25 0 0 0-.25.25V3l-1.998.011a.25.25 0 0 0-.25.25v.989c0 .137.11.25.248.25l.755-.005a.75.75 0 0 1 .745.75v5.505a.75.75 0 0 1-.75.75l-.748.011a.25.25 0 0 0-.25.25v1c0 .138.112.25.25.25L5.5 13zm1.427-8.513h1.719c.906 0 1.438.498 1.438 1.312 0 .871-.575 1.362-1.877 1.362h-1.28V4.487zm0 4.051h1.84c1.137 0 1.756.58 1.756 1.524 0 .953-.626 1.45-2.158 1.45H6.927V8.539z" /> </svg>',
      data: {},
    },
    USDC: {
      key: 3,
      float: 6,
      title: 'USD Coin',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" width="%width%" height="%height%" fill="currentColor" class="bi bi-currency-bitcoin mx-2" viewBox="0 0 256.000000 256.000000"><g transform="translate(0.000000,256.000000) scale(0.100000,-0.100000)"><path d="M920 2271 c-211 -79 -389 -217 -509 -395 -389 -576 -136 -1355 517 -1590 l72 -26 0 98 0 97 -60 23 c-142 56 -296 184 -388 325 -262 402 -149 944 251 1205 42 28 104 61 137 74 l60 23 0 97 c0 54 -1 98 -2 98 -2 -1 -37 -14 -78 -29z"></path><path d="M1552 2204 l3 -95 58 -24 c244 -99 433 -314 509 -580 33 -116 33 -334 0 -450 -76 -266 -265 -481 -509 -580 l-58 -24 -3 -95 c-1 -53 0 -96 2 -96 3 0 42 13 87 30 645 235 895 1013 509 1585 -122 180 -300 319 -509 395 -45 17 -84 30 -87 30 -2 0 -3 -43 -2 -96z"></path><path d="M1188 1904 l-3 -87 -40 -12 c-93 -28 -179 -95 -219 -173 -46 -90 -41 -195 15 -272 54 -74 144 -117 321 -150 105 -20 168 -47 192 -82 45 -64 19 -156 -57 -198 -34 -20 -56 -24 -117 -24 -117 0 -185 47 -205 142 l-7 32 -95 0 -96 0 6 -54 c7 -70 36 -124 92 -174 43 -38 143 -82 187 -82 15 0 18 -12 20 -87 l3 -88 87 -3 87 -3 3 87 3 87 52 13 c76 20 123 46 170 96 81 89 105 220 57 316 -50 101 -159 163 -338 193 -133 23 -159 32 -191 71 -42 50 -28 134 28 171 63 41 179 41 237 -2 37 -27 70 -80 70 -112 l0 -29 91 0 92 0 -6 54 c-11 109 -94 215 -201 255 l-51 19 -3 91 -3 91 -89 0 -89 0 -3 -86z"></path></g></svg>',
      data: {},
    },
    SOL: {
      key: 4,
      float: 9,
      title: 'Solana',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" width="%width%" height="%height%" fill="currentColor" viewBox="0 0 24 24"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.08398 5.22265C7.17671 5.08355 7.33282 5 7.5 5H18.5C18.6844 5 18.8538 5.10149 18.9408 5.26407C19.0278 5.42665 19.0183 5.62392 18.916 5.77735L16.916 8.77735C16.8233 8.91645 16.6672 9 16.5 9H5.5C5.3156 9 5.14617 8.89851 5.05916 8.73593C4.97215 8.57335 4.98169 8.37608 5.08398 8.22265L7.08398 5.22265ZM7.76759 6L6.43426 8H16.2324L17.5657 6H7.76759Z"/><path fill-rule="evenodd" clip-rule="evenodd" d="M7.08398 15.2226C7.17671 15.0836 7.33282 15 7.5 15H18.5C18.6844 15 18.8538 15.1015 18.9408 15.2641C19.0278 15.4267 19.0183 15.6239 18.916 15.7774L16.916 18.7774C16.8233 18.9164 16.6672 19 16.5 19H5.5C5.3156 19 5.14617 18.8985 5.05916 18.7359C4.97215 18.5734 4.98169 18.3761 5.08398 18.2226L7.08398 15.2226ZM7.76759 16L6.43426 18H16.2324L17.5657 16H7.76759Z"/><path fill-rule="evenodd" clip-rule="evenodd" d="M7.08398 13.7774C7.17671 13.9164 7.33282 14 7.5 14H18.5C18.6844 14 18.8538 13.8985 18.9408 13.7359C19.0278 13.5733 19.0183 13.3761 18.916 13.2226L16.916 10.2226C16.8233 10.0836 16.6672 10 16.5 10H5.5C5.3156 10 5.14617 10.1015 5.05916 10.2641C4.97215 10.4267 4.98169 10.6239 5.08398 10.7774L7.08398 13.7774ZM7.76759 13L6.43426 11H16.2324L17.5657 13H7.76759Z"/></svg>',
      data: {},
    },
    BCH: {
      key: 5,
      float: 8,
      title: 'Bitcoin Cash',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" width="%width%" height="%height%" fill="currentColor" viewBox="0 0 32 32"><path d="M16 32C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16zm5.236-21.309c-.777-1.972-2.722-2.15-4.988-1.71l-.807-2.813-1.712.491.785 2.74c-.45.128-.907.269-1.362.41l-.79-2.758-1.712.49.806 2.813c-.369.114-.73.225-1.086.327l-.002-.008-2.362.676.525 1.829s1.257-.387 1.243-.357c.693-.2 1.035.139 1.2.467l.92 3.205c.047-.013.11-.03.184-.04l-.181.052 1.287 4.49c.032.227.003.612-.481.752.027.013-1.245.356-1.245.356l.246 2.143 2.229-.64c.414-.118.824-.228 1.226-.34l.816 2.845 1.71-.49-.806-2.815a65.74 65.74 0 001.371-.38l.803 2.803 1.712-.491-.813-2.84c2.831-.991 4.638-2.294 4.113-5.07-.422-2.234-1.725-2.912-3.472-2.836.848-.79 1.214-1.859.643-3.301zm-.651 6.77c.61 2.127-3.1 2.929-4.26 3.263l-1.08-3.77c1.16-.333 4.704-1.71 5.34.508zm-2.322-5.09c.554 1.935-2.547 2.58-3.513 2.857l-.98-3.419c.966-.277 3.914-1.455 4.493.562z" fill-rule="evenodd"/></svg>',
      data: {},
    },
    ETH: {
      key: 6,
      float: 9,
      title: 'Ethereum',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" width="%width%" height="%height%" fill="currentColor" viewBox="0 0 226.777 226.777"><g><polygon points="112.553,157 112.553,86.977 44.158,116.937"/><polygon points="112.553,82.163 112.553,-0.056 46.362,111.156"/><polygon points="116.962,-0.09 116.962,82.163 184.083,111.566"/><polygon points="116.962,86.977 116.962,157.002 185.405,116.957"/><polygon points="112.553,227.406 112.553,171.085 44.618,131.31"/><polygon points="116.962,227.406 184.897,131.31 116.962,171.085"/></g></svg>',
      data: {},
    },
    LTC: {
      key: 7,
      float: 8,
      title: 'Litecoin',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" width="%width%" height="%height%" fill="currentColor" viewBox="0 0 226.777 226.777"><polygon points="94.718,184.145 107.496,123.31 172.074,79.039 179.644,42.883 115.053,87.335 133.398,0 83.788,0 57.142,127.189 29.975,145.887 23.667,180.781 49.639,162.975 36.281,226.743 195.198,226.743 204.027,184.145"/></svg>',
      data: {},
    },
    XRP: {
      key: 8,
      float: 6,
      title: 'Ripple',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" width="%width%" height="%height%" fill="currentColor" viewBox="0 0 512 424"><defs></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1" d="M437,0h74L357,152.48c-55.77,55.19-146.19,55.19-202,0L.94,0H75L192,115.83a91.11,91.11,0,0,0,127.91,0Z"/><path class="cls-1" d="M74.05,424H0L155,270.58c55.77-55.19,146.19-55.19,202,0L512,424H438L320,307.23a91.11,91.11,0,0,0-127.91,0Z"/></g></g></svg>',
      data: {},
    }
  };
}

function getDatePhpFormat(currentDate) {
  return currentDate.getFullYear() + "/" +
    (currentDate.getMonth() + 1).toString().padStart(2, '0') + "/" +
    currentDate.getDate().toString().padStart(2, '0') + " " +
    currentDate.getHours().toString().padStart(2, '0') + ":" +
    currentDate.getMinutes().toString().padStart(2, '0') + ":" +
    currentDate.getSeconds().toString().padStart(2, '0');
}

function getUserStatus(userrr, type = 'both') {
  return new Promise((resolve, reject) => {
    runApi(`updateUserStatus/`, userrr).then((response) => {
      const resd = response?.data?.updateStatusResponse;
      if( !resd )
        return null;

      let status = 0;
      if (resd.kyc_status === 1) {
        status = 1;
      }
      if (resd.kyc_status === 2) {
        status = 2;
      }
      if (resd.kyc_status === 9) {
        status = 9;
      }
      if (resd.kyc_status === 2 && resd.payment_status === 2) {
        status = 3;
      }
      if (resd.kyc_status === 2 && resd.payment_status === 2 && resd.card_status === 2 && resd.card_activation_status === 2) {
        status = 4;
      }

      if (resd.kyc_status === 2 && resd.payment_status === 2 && resd.card_activation_status === 1) {
        status = 5;
      }
      if (resd.card_activation_status === 9) {
        status = 19;
      }
      //status = 2
      if (type === 'status') {
        resolve(status);
      } else {
        let data = {
          'status': status,
          'data': resd,
        }
        resolve(data);
      }
    }).catch((error) => {
      reject(error);
    });
  });
}

function showLoader(show) {
  isLoading = show;
  if (isLoading) {
    container = document.createElement('div');
    document.body.appendChild(container);
    ReactDOM.render(
      <LoadingOverlay
        active={true}
        spinner
        text='Loading...'
        styles={{ wrapper: { zIndex: 9999, position: "fixed" } }}
      />,
      container
    );
  } else if (container) {

    ReactDOM.unmountComponentAtNode(container);
    container.remove();
    container = null;
  }
}

export { showLoader };

function walletBalance(user) {
  const url = process.env.NEXT_PUBLIC_API_URL + '?uri=' + `walletBalance/`;
  return axios.post(url, user);
}

function getCountries() {
  const url = process.env.NEXT_PUBLIC_API_URL + '?uri=' + `getCountries/`;
  return axios.post(url, null);
}

function set2FA(user) {
  const url = process.env.NEXT_PUBLIC_API_URL + '?uri=' + `set2FA/`;
  return axios.post(url, user);
}

function get2FASecretKey(user) {
  const url = process.env.NEXT_PUBLIC_API_URL + '?uri=' + `get2FASecretKey/`;
  return axios.post(url, user);
}

function register(user) {
  const url = process.env.NEXT_PUBLIC_API_URL + '?uri=' + `signup/`;
  return axios.post(url, user);
}

function forgot(user) {
  let reqdata = {
    ...user,
    url: 'resetPassword/'
  }
  return fetch(`api/sendReq`, {method: 'POST', body: JSON.stringify(reqdata)})
    .then(response => response.json())
    .then(data => {
      return data; // Return the response data
    })
    .catch(error => {
      console.error('Error in forgot API:', error);
      throw error;
    });
}

function verifyResetCode(user) {
  const url = process.env.NEXT_PUBLIC_API_URL + '?uri=' + `completeResetPassword/`;
  return axios.post(url, user);
}

function PreventIncrement(event) {
  const charCode = event.key.charCodeAt(0);

  const value = event.target.value;
  if (
    (charCode < 48 || charCode > 57) &&
    (event.key !== "." || value.split(".").length > 1)
  ) {
    if (event.key !== "Backspace") {
      event.preventDefault();
    }
  }
}
