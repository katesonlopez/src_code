<?php

require_once("../include/graphQL_api.php");
require_once '../include/dbconfig.php';
require_once("../include/from_ultimopay_db.php");

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
  function getallheaders()
  {
    if (!is_array($_SERVER)) {
      return array();
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
      if (substr($name, 0, 5) == 'HTTP_') {
        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
      }
    }
    return $headers;
  }
}

function _log($email, $line) {
  if ($email == "") {
    $fh2 = fopen("/var/www/api.ultimopay.io/v4/walletBalance/log/walletBalance.log", 'a');
  } else {
    $fh2 = fopen("/var/www/api.ultimopay.io/v4/walletBalance/log/" . $email . ".log", 'a');
  }
  $fline = date('[Ymd H:i:s] ') . $line . "\n";
  fwrite($fh2, $fline);
  fclose($fh2);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
  if (mysqli_connect_errno() != 0) {
    header('Content-Type: application/json');
    http_response_code(500);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
    echo json_encode($ret_rs);
    die();
  } else {
    _log("", "ket noi thanh cong");
    mysqli_query($dbhandle, "set names utf8;");
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
  $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
  $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
  $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
  $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret4 = 'climbpot api access key';
  $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
  $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
  $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
  $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
  $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
  $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
  $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
  $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
  $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
  $apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
  $found = 0;
  $coin = 'USDT';
  $sandbox = 0;
  $partner = "";
  $allowed_deposit_currency_arr = array('USDT');
  $req_api_key = "";
  $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

  foreach (getallheaders() as $name => $value) {
    if ($name == 'Authorization') {
      $req_api_key = trim($value);
      $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
      $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
      if (mysqli_num_rows($partner_rs) > 0) {
        while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
          $cur_api_key = "Bearer " . $row_partner['api_key'];
          if ($req_api_key == $cur_api_key) {
            $req_partner['partner'] = trim($row_partner['partner']);
            $req_partner['api_key'] = trim($row_partner['api_key']);
            $req_partner['website'] = trim($row_partner['website']);
            $selected_api_key = $req_api_key;
            break;
          }
        }
      } else {
        _log("", "not found in db");
      }
    }
  }
  @mysqli_close($dbhandle);

  function isValidPassword($password) {
    if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
      return FALSE;
    return TRUE;
  }

  if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!($data)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          _log("", 'Reached the maximum stack depth');
          break;
        case JSON_ERROR_STATE_MISMATCH:
          _log("", 'Incorrect discharges or mismatch mode');
          break;
        case JSON_ERROR_CTRL_CHAR:
          _log("", 'Incorrect control character');
          break;
        case JSON_ERROR_SYNTAX:
          _log("", 'Syntax error or JSON invalid');
          break;
        case JSON_ERROR_UTF8:
          _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
          break;
        default:
          _log("", 'Unknown error');
          break;
      }

      _log("", 'A non-empty request body is required.');
      header('Content-Type: application/json');
      http_response_code(400);
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
      echo json_encode($ret_rs);
      die();
    } else {
      unset($errors);
      $errors = array();

      //email
      if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
        $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
        $errors[] = $error_obj;
      }

      //auth_token
      if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
        $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
        $errors[] = $error_obj;
      }

      if (count($errors) == 0) {
        $errors_sub = array();

        //proceed to shift api
        require_once '../include/common.php';

        ////////////////////////////////////////////////////

        $allowed_shift_currency_arr = array('USDT', 'BTC', 'BUSD', 'USDC', 'USD', 'SOL', 'BCH', 'ETH', 'LTC', 'XRP');
        //receive POST params
        $reg_email_address = trim($data['email_address']);
        $private_key = trim($data['auth_token']);
        $user_wallet_arr = array();

        _log($reg_email_address, "get wallet balance started...");

        $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
        if (mysqli_connect_errno() == 0) {
          mysqli_query($dbhandle, "set names utf8;");
          $allow_access_api = 0;
          $merchant = '';
          $my_db_private_key = '';
          $my_db_auth_token = '';
          $my_db_sigin_dt = '';
          $my_db_token_refresh_dt = '';
          $my_db_shift_user_sub_id = '';
          $sql_check_signin = "select a.*, b.shift_user_sub_id from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_email_address";
          $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
          if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
            $allow_access_api = 1;
            while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
              $my_db_auth_token = trim($row_signin['auth_token']);
              $my_db_sigin_dt = $row_signin['signin_dt'];
              $my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
              $my_db_private_key = trim($row_signin['private_key']);
            }
          }

          $my_db_shift_user_sub_id = _ultimopay_db_get_user_id($dbhandle, $reg_email_address);

          if ($allow_access_api == 1) {
            if ($private_key != $my_db_private_key) {
              @mysqli_close($dbhandle);
              header('Content-Type: application/json');
              http_response_code(500);
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'Unauthorized.');
              echo json_encode($ret_rs);
              die();
            } else {
              //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
              //check there is data of my shift wallet?
              $shift_wallet_cnt = 0;
              $sql_check_shift_wallet = "select * from cryptocash_shift_wallet where shift_login_email='$reg_email_address'";
              $rs_check_shift_wallet = mysqli_query($dbhandle, $sql_check_shift_wallet);
              $shift_wallet_cnt = mysqli_num_rows($rs_check_shift_wallet);

              $usdt_balance_final = number_format(0, 8, '.', '');
              $usdt_balance = number_format(0, 8, '.', '');

              $shift_wallet_arr = array();
              $tmp_dto_arr = array();
              $accounts_res = _shift_getAccountBalance( $my_db_auth_token );
              if (($accounts_res['http_code'] == "200") || ($accounts_res['http_code'] == "200 OK")) {
                if (is_array($accounts_res['data']['data']['alias_get_accounts_balances'])) {
                  /////////////////////////////////////////////////////////
                  $accounts_arr = $accounts_res['data']['data']['alias_get_accounts_balances'];
                  if (count($accounts_arr) > 0) {
                    _log($reg_email_address, "_shift_getAccountBalance: ok vao roi");
                    for ($coin_cnt=0; $coin_cnt<count($accounts_arr); $coin_cnt++) {
                      $cur_coin_stat = $accounts_arr[$coin_cnt];
                      unset($shift_wallet_obj);
                      $shift_wallet_obj = array('id' => '', 'currency_id' => '', 'balance' => 0);
                      if ( (!is_null($cur_coin_stat['total_balance'])) && (!is_null($cur_coin_stat['currency_id'])) ) {
                        _log($reg_email_address, $cur_coin_stat['currency_id'] . " / " . $cur_coin_stat['total_balance']);

                        $shift_wallet_obj['id'] = strtoupper($cur_coin_stat['currency_id']);
                        $shift_wallet_obj['currency_id'] = strtoupper($cur_coin_stat['currency_id']);
                        $shift_wallet_obj['balance'] = format_coin(number_format($cur_coin_stat['total_balance'], 10, '.', ','));

                        if (in_array($shift_wallet_obj['currency_id'], $allowed_shift_currency_arr)) {
                          $shift_wallet_arr[] = $shift_wallet_obj;
                          $allowed_wallet_obj = array();
                          $allowed_wallet_obj = array('currency' => $shift_wallet_obj['currency_id'], 'balance' => $shift_wallet_obj['balance']);
                          $user_wallet_arr[] = $allowed_wallet_obj;
                        }
                      }
                    }

                    if ((count($shift_wallet_arr) > 0) && ($my_db_shift_user_sub_id != '')) {
                      _log($reg_email_address, "vao toi day roi...");
                      $shift_wallet_added_dt = date('Y-m-d H:i:s');
                      for ($s=0; $s<count($shift_wallet_arr); $s++) {
                        $cur_wallet = $shift_wallet_arr[$s];
                        if (isset($cur_wallet['id'])) {

                          //check if this currency exists
                          $sql_check_coin = "SELECT * FROM cryptocash_shift_wallet WHERE shift_login_email='$reg_email_address' AND shift_user_sub_id='$my_db_shift_user_sub_id' AND shift_account_currency='" . $cur_wallet['currency_id'] . "'";
                          $rs_check_coin = mysqli_query($dbhandle, $sql_check_coin);
                          if (mysqli_num_rows($rs_check_coin) <= 0) {
                            $sql_save_shift_wallet = "INSERT INTO cryptocash_shift_wallet (shift_login_email, shift_user_sub_id, shift_account_currency, balance, added_dt) VALUES ('$reg_email_address', '$my_db_shift_user_sub_id', '" . $cur_wallet['currency_id'] . "', '" . $cur_wallet['balance'] . "', '$shift_wallet_added_dt')";
                            mysqli_query($dbhandle, $sql_save_shift_wallet);
                            if (mysqli_affected_rows($dbhandle) <= 0) {
                              _log($reg_email_address, "failed save to cryptocash_shift_wallet ! " . $cur_wallet['currency_id']);
                              @mysqli_close($dbhandle);
                              $ret_rs['result'] = 'failed';
                              $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occurred. please contact administrator for help #1.');
                              header('Content-Type: application/json');
                              http_response_code(500);
                              echo json_encode($ret_rs);
                              die();
                            }
                          }
                          else {
                            _log($reg_email_address, "vao update cho " . $cur_wallet['currency_id']);
                            $sql_update_shift_wallet = "UPDATE cryptocash_shift_wallet SET balance='" . $cur_wallet['balance'] . "' WHERE shift_login_email='$reg_email_address' AND shift_user_sub_id='$my_db_shift_user_sub_id' AND shift_account_currency='" . $cur_wallet['currency_id'] . "' LIMIT 1";
                            mysqli_query($dbhandle, $sql_update_shift_wallet);
                          }
                        }
                      }
                    }
                    else {
                      _log($reg_email_address, "error::shift_wallet_arr empty or shift_user_sub_id empty !!!");
                      @mysqli_close($dbhandle);
                      $ret_rs['result'] = 'failed';
                      $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occurred. please contact administrator for help #2.');
                      header('Content-Type: application/json');
                      http_response_code(500);
                      echo json_encode($ret_rs);
                      die();
                    }
                  }
                  else {
                    _log($reg_email_address, "/api/v1/accounts error array empty");
                    @mysqli_close($dbhandle);
                    $ret_rs['result'] = 'failed';
                    $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occurred. please contact administrator for help #3.');
                    header('Content-Type: application/json');
                    http_response_code(500);
                    echo json_encode($ret_rs);
                    die();
                  }
                  /////////////////////////////////////////////////////////
                } else {
                  _log($reg_email_address, "/api/v1/accounts error not array");
                  @mysqli_close($dbhandle);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occurred. please contact administrator for help #4.');
                  header('Content-Type: application/json');
                  http_response_code(500);
                  echo json_encode($ret_rs);
                  die();
                }
              }
              else {
                $error_message = $accounts_res['message'];
                $res_code = $accounts_res['http_code'];
                $error_code = 6;
                @mysqli_close($dbhandle);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
                header('Content-Type: application/json');
                if ($res_code != 200) {
                  http_response_code($res_code);
                }
                echo json_encode($ret_rs);
                die();
              }
              //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            }
          } else {
            @mysqli_close($dbhandle);
            header('Content-Type: application/json');
            http_response_code(500);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'you must sign in to use this API.');
            echo json_encode($ret_rs);
            die();
          }
        } else {
          _log($reg_email_address, "could not connect db !");
        }

        @mysqli_close($dbhandle);
        $ret_rs['result'] = 'success';
        $ret_rs['email_address'] = $reg_email_address;
        $ret_rs['wallet'] = $user_wallet_arr;
        header('Content-Type: application/json');
        echo json_encode($ret_rs);
        die();
      } else {
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = $errors[0];
        _log("", $ret_rs['error']['errorMessage']);
        header('Content-Type: application/json');
        echo json_encode($ret_rs);
        die();
      }
    }
  } else {
    header('HTTP/1.0 403 Forbidden');
  }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
  http_response_code(405);
  die();
}
