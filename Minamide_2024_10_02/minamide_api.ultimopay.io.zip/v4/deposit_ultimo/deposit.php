<?php
function get_wallet($currency) {
    global $authorization_value;
    global $authorization_client_value;
    global $fixed_username;
    $deposit_post_data = array();
    $deposit_post_data['product'] = $currency;
    $deposit_post_data['exchange'] = "PLUSQO";
    $deposit_res = api_call('/wallet/deposit/create', 0, '', $deposit_post_data, $authorization_client_value);
    if ($deposit_res['result'] != '') {
        if(isset($deposit_res['result']['txid']) && !empty($deposit_res['result']['txid'])) {
            $deposit_txid = $deposit_res['result']['txid'];
            $deposit_state_hash = $deposit_res['result']['state_hash'];
            _log($fixed_username, $currency . "::" . $deposit_txid . " / ". $deposit_state_hash);

            sleep(2);
            $req_data = array();
            $req_data['txid'] = $deposit_txid;
            $req_data['state_hash'] = $deposit_state_hash;
            $req_data['timeout'] = "10000";
            $deposit_res2 = api_call('/wallet/transaction/status', 0,  $req_data, '', $authorization_client_value);

            if ($deposit_res2['result'] != '') {
                if(isset($deposit_res2['result']['address']) && !empty($deposit_res2['result']['address'])) {
                    $currency_address = $deposit_res2['result']['address'];
                    if ($currency == "BTC") {
                        $_SESSION['ultimopay_btc_address'] = $currency_address;
                        _log($fixed_username, "BTC address : " . $currency_address);
                    } else if ($currency == "USDT") {
                        $_SESSION['ultimopay_usdt_address'] = $currency_address;
                        _log($fixed_username, "USDT address : " . $currency_address);
                    }

                } else {
                    _log($fixed_username, "::" . $_SESSION['ultimopay_username'] . "::/wallet/transaction/status FAILED : " . $deposit_res2['result']['message']);
                    foreach($deposit_res2['result'] as $key => $value) {
                        _log($fixed_username, $key . " = " . $value);
                    }
                }
            }
        } else {

            _log($fixed_username, "::/wallet/deposit/create FAILED : " . $deposit_res['result']['message']);
            foreach($deposit_res2['result'] as $key => $value) {
                _log($fixed_username, $key . " = " . $value);
            }
        }
    }
}

if ($currency == "BTC") {
    if ($_SESSION['ultimopay_btc_address'] == '') {
        _log($fixed_username, "tien hanh lay dia chi Bitcoin !");
        get_wallet($currency);
    } else {
        _log($fixed_username, "da co btc address roi !");
    }
} else if ($currency == "USDT") {
    if ($_SESSION['ultimopay_usdt_address'] == '') {
        _log($fixed_username, "tien hanh lay dia chi USDT !");
        get_wallet($currency);
    } else {
        _log($fixed_username, "da co USDT address roi !");
    }
}
?>

<style>
    .mytabs {
    }
    .mytabs input[type=radio] {
        display: none;
    }
    .mytabs label {
        transition: background 0.4s ease-in-out, height 0.2s linear;
        display: inline-block;
        cursor: pointer;
        color: #000;
        width: 20%;
        height: 2em;
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
        background: #FCFCFC;
        text-align: center;
        line-height: 2em;
        font-size: 0.8em !important;
        font-weight: 600 !important;
    }
    .mytabs label:last-of-type {
        border-bottom: none;
    }
    .mytabs label:hover {
        background: #079e07;
        color:#ffffff;
    }
    @media screen and (max-width: 1600px) {
        .mytabs label {
            width: 15% !important; }
    }
    @media screen and (max-width: 900px) {
        .mytabs label {
            width: 20% !important;
        }
    }
    @media screen and (max-width: 600px) {
        .mytabs label {
            width: 100% !important;
            display: block;
            border-bottom: 2px solid #C7C6C4;
            border-radius: 0;
        }
    }
    @media screen and (max-width: 600px) {
        .mytabs {
            margin: 0;
        }
    }

    #tab1:checked + label, #tab2:checked + label, #tab3:checked + label, #tab4:checked + label, #tab5:checked + label {
        background: #09cd09;
        color: #000; }

    .tab-content {
        position: absolute;
        top: -9999px;
        padding: 10px;
    }

    .tab-content-wrapper{
        background: transparent;
        border-top: #09cd09 1px solid;
        border-bottom-right-radius: 3px;
        border-bottom-left-radius: 3px;
        border-top-right-radius: 3px;
        /*margin-top: -8px !important;*/

    }
    @media screen and (max-width: 600px) {
        .tab-content-wrapper, .tab1-content-wrapper {
            border: none;
            border-radius: 0;
        }
    }

    #tab1:checked ~ .tab-content-wrapper #tab-content-1, #tab2:checked ~ .tab-content-wrapper #tab-content-2, #tab3:checked ~ .tab-content-wrapper #tab-content-3, #tab4:checked ~ .tab-content-wrapper #tab-content-4, #tab5:checked ~ .tab-content-wrapper #tab-content-5 {
        position: relative;
        top: 0px;
    }


    .bg-info2 {
        background-color: #F7A037 !important;
    }

    a.bg-info2:hover, a.bg-info2:focus,
    button.bg-info:hover,
    button.bg-info:focus {
        background-color: #d39e00  !important;
    }
    table.dataTable td {
        word-break: break-word;
    }
    table.dataTable td {
        font-size: 0.85em;
    }
    .dataTable > thead > tr > th[class*="sort"]::after{display: none}
    .dataTable > thead > tr > th[class*="sort"]::before{display: none}

    table.dataTable thead .sorting,
    table.dataTable thead .sorting_asc,
    table.dataTable thead .sorting_desc {
        background : none;
        padding-top: 2px !important;
        padding-bottom: 2px !important;
    }

    table.dataTable thead th {
        background: transparent !important;
        white-space: nowrap;
        padding-top: 2px !important;
        padding-bottom: 2px !important;
    }

    table.dataTable thead span.sort-icon {
        display: inline-block;
        padding-left: 10px !important;
        width: 16px;
        height: 16px;
    }

    table.dataTable thead .sorting span { background: url('http://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/images/sort_both.png') no-repeat center right; }
    table.dataTable thead .sorting_asc span { background: url('http://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/images/sort_asc.png') no-repeat center right; }
    table.dataTable thead .sorting_desc span { background: url('http://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/images/sort_desc.png') no-repeat center right; }

    table.dataTable thead .sorting_asc_disabled span { background: url('http://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/images/sort_asc_disabled.png') no-repeat center right; }
    table.dataTable thead .sorting_desc_disabled span { background: url('http://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/images/sort_desc_disabled.png') no-repeat center right; }

    table.dataTable thead {background-color:#CAC0B4; color: #000;}
    div.dataTables_filter input {
        border: 1px solid #fdaa1b !important;
        background-color: #282a30 !important;
        color: #fff !important;


    }

    .page-item.active .page-link {
        background-color: lightgrey !important;
        border: 1px solid white;
        outline: none !important;
    }
    .page-link {
        color: black !important;
    }

    /*
    * materrial loading bar
    */
    .mybar {
        position:absolute;
        padding-top: 10px;
        transform:translate(-50%,-50%);
        width:100%;
        height:4px;
        background:#acece6;
        overflow:hidden;
    }
    .mybar div:before {
        content:"";
        position:absolute;
        top:0px;
        left:0px;
        bottom:0px;
        background:#26a69a;
        animation:box-1 2100ms cubic-bezier(0.65,0.81,0.73,0.4) infinite;
    }
    .mybar div:after {
        content:"";
        position:absolute;
        top:0px;
        left:0px;
        bottom:0px;
        background:#26a69a;
        animation:box-2 2100ms cubic-bezier(0.16,0.84,0.44,1) infinite;
        animation-delay:1150ms;
    }
    @keyframes box-1 {
        0% {
            left:-35%;
            right:100%;
        }
        60%,100% {
            left:100%;
            right:-90%;
        }
    }
    @keyframes box-2 {
        0% {
            left:-200%;
            right:100%;
        }
        60%,100% {
            left:107%;
            right:-8%;
        }
    }



    /*
    * custom radio buttons
    */
    *, *:after, *:before {
        box-sizing: border-box;
    }

    .radio-label {
        display: flex !important;
        cursor: pointer !important;
        font-weight: 500 !important;
        position: relative !important;
        overflow: hidden !important;
        margin-bottom: 0.375em !important;
        width: 100%;

    }
    .radio-label input {
        position: absolute !important;
        left: -9999px !important;
    }
    .radio-label input:checked + span {
        background-color: #d6d6e5 !important;
        color: #000 !important;
    }
    .radio-label input:checked + span:before {
        box-shadow: inset 0 0 0 0.4375em #00005c !important;
    }
    .radio-label span {
        display: flex !important;
        align-items: center !important;
        padding: 0.375em 0.75em 0.375em 0.375em !important;
        border-radius: 99em !important;
        transition: 0.25s ease !important;

    }
    .radio-label span:hover {
        background-color: #d6d6e5 !important;
        color: #000 !important;
    }
    .radio-label span:before {
        display: flex !important;
        flex-shrink: 0 !important;
        content: "" !important;
        background-color: #fff !important;
        width: 1.5em !important;
        height: 1.5em !important;
        border-radius: 50% !important;
        margin-right: 0.375em !important;
        transition: 0.25s ease !important;
        box-shadow: inset 0 0 0 0.125em #00005c;
    }
    .id-container {

        width: 100%;
        /*display: flex;*/
        /*justify-content: center;*/
        /*align-items: center;*/
        /*padding: 20px;*/
    }


    /*
    * custom dropdown
    */
    @import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap");

    :root {
        --px-dropdown-color-border: rgb(0, 0, 0);
        --px-dropdown-color-border-active: rgb(12, 240, 9);
        --px-dropdown-color-bg: rgb(10, 15, 25);
        --px-dropdown-color-panelbg: rgb(255, 255, 255);
        --px-dropdown-color-panelfont: rgb(19, 26, 41);
        --px-dropdown-color-panelhover: rgb(235, 237, 243);

        --pxdemo-color-font: rgb(245, 247, 250);
        --pxdemo-color-bodybg: rgb(19, 26, 41);

        --px-dropdown-width: 100%;
        --px-dropdown-height: 46px;
        --px-dropdown-transition-duration: 300ms;
        --px-dropdown-iconsize: 18px;

        --pxdemo-fontfamily: "Inter", sans-serif;
        --pxdemo-fontsize: 1.0em;
        --pxdemo-fontweight-normal: 400;
        --pxdemo-fontweight-bold: 600;
        --pxdemo-lineheight: 1.5;
    }



    .px-app,
    .px-app *,
    .px-app *::before,
    .px-app *::after {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        outline: 0;
    }

    .px-dropdown {
        position: relative;
        width: var(--px-dropdown-width);
        height: var(--px-dropdown-height);
    }

    .px-dropdown-input {
        width: 100%;
        height: 100%;
        border: 1px solid;
        border-color: var(--px-dropdown-color-border);
        border-radius: 5px;
        background-color: var(--px-dropdown-color-bg);
        display: flex;
        flex-wrap: nowrap;
        align-items: center;
        justify-content: flex-start;
        cursor: pointer;
        transition: border-color var(--px-dropdown-transition-duration) ease;
    }
    .px-dropdown.active .px-dropdown-input {
        border-color: var(--px-dropdown-color-border-active);
    }

    .px-dropdown-input input {
        color: var(--pxdemo-color-font);
        font-size: 1.0rem;
        flex: 0 0 auto;
        width: 85%;
        height: 100%;
        padding: 0 1rem;
        border: none;
        background: transparent;
        cursor: pointer;
    }

    .px-dropdown-input i {
        font-size: var(--px-dropdown-iconsize);
        flex: 0 0 auto;
        width: 15%;
        text-align: right;
        padding-right: 10px;
    }

    .px-dropdown-panel {
        position: absolute;
        width: 100%;
        left: 0;
        top: calc(100% + 20px);
        border: 1px solid;
        border-color: var(--px-dropdown-color-border);
        border-radius: 5px;
        background-color: var(--px-dropdown-color-panelbg);
        overflow: hidden;
        opacity: 0;
        pointer-events: none;
        transition: top var(--px-dropdown-transition-duration) ease,
        opacity var(--px-dropdown-transition-duration) ease;
    }
    .px-dropdown.active .px-dropdown-panel {
        top: calc(100% + 4px);
        opacity: 1;
        pointer-events: auto;
    }

    .px-dropdown-panel p {
        color: var(--px-dropdown-color-panelfont);
        padding: 0.5rem 1rem;
        cursor: pointer;
        transition: background-color var(--px-dropdown-transition-duration) ease;
    }

    .px-dropdown-panel p:hover {
        background-color: var(--px-dropdown-color-panelhover);
    }



</style>
<!--Begin Dashboard Content -->

<div class="container-xxl flex-grow-1 container-p-y" style="height: auto; min-height: 600px !important; margin: 0px 0px !important; padding: 0px 0px !important">
    <div class="row"  style="margin: 0px 0px !important; padding: 0px 0px !important; margin-top: 20px !important">
        <!-- update 20230303 style change k.o -->
        <!-- <div class="col-12" style="margin: 0px 0px !important; padding: 0px 20px !important; margin-bottom: 0px !important; color: #fff !important">
            <div style="color: #fff !important; width: 100%; text-align: left;"> -->
        <div class="col-12" style="margin: 0px 0px !important; padding: 0px 20px !important; margin-bottom: 0px !important; color: var(--main-text-color)">
            <div style="color: var(--main-text-color); width: 100%; text-align: left;">
                <?php
                $currency_deposit_box_title = "Deposit";
                if ($currency=="BTC") {
                    $slug = "Bitcoin";
                    $slug2 = "Bitcoin";
                    $currency_deposit_box_title = $lang['global.deposit_page.box_title_btc'];
                    echo "<a href=\"" . WEBSITE_ROOT_URL . "dashboard/\" class=\"linkex4\">Dashboard</a>&nbsp;&nbsp|&nbsp;&nbsp;" . $lang['global.deposit_page.box_title_btc'];
                } else if ($currency=="USDT") {
                    $slug = "USDT";
                    $slug2 = "Tether(USDT)";
                    $currency_deposit_box_title = $lang['global.deposit_page.box_title_usdt'];
                    echo "<a href=\"" . WEBSITE_ROOT_URL . "dashboard/\" class=\"linkex4\">Dashboard</a>&nbsp;&nbsp|&nbsp;&nbsp;" . $lang['global.deposit_page.box_title_usdt'];
                }

                ?>



            </div>
        </div>
    </div>
    <!--begin box of balance -->
    <div class="row"  style="margin: 0px 0px !important; padding: 0px 20px !important;">
        <div class="col-12" style="margin: 0px 0px !important; padding: 0px 0px !important; margin-bottom: 0px !important;">
            <!--bitcoin begin -->
            <div class="card box-6" style="padding: 0px 0px !important; height: auto !important; margin: 0px 0px !important">

                <div class="card-body" style="padding: 1.075rem 1.075rem !important; width 100% !important">
                    <div class="container-fluid" style="margin 0px 0px !important; padding 0px 0px !important;">
                        <div class="row" style="margin 0px 0px !important; padding 0px 0px !important">
                            <div class="col-md-4" style="margin 0px 0px !important; padding 0px 0px !important;">
                                <!--begin hop icon -->
                                <div style="height: 100px;">
                                    <table class="myboxstyle">
                                        <tr>
                                            <td class="cryptoicon">
                                                <div style="width: 100%;height: 90px; padding-left: 0px" class="d-flex align-items-center justify-content-start gap-3">
                                                    <div class="avatar" style="width: 50px; height: 50px;">
                                                        <?php
                                                        if ($currency=="BTC") {
                                                            ?>
                                                            <!-- update 20230303 style change k.o -->
                                                            <!-- <span class="avatar-initial bg-label-primary rounded-circle" style=" background-color: #000 !important; border-radius: 50%; border: 3px solid #0a8b07; padding: 8px 8px !important" -->
                                                            <span class="avatar-initial bg-label-primary rounded-circle" style=" background-color: #333; border-radius: 50%; border: 3px solid #0a8b07; padding: 8px 8px !important"
                                                            ><img width="35" height="35" src="../assets/img/misc/btc-white.svg?<?php echo time();?>">
																	</span>
                                                            <?php
                                                        } else if ($currency=="USDT") {
                                                            ?>
                                                            <!-- update 20230303 style change k.o -->
                                                            <!-- <span class="avatar-initial bg-label-primary rounded-circle" style=" background-color: #000 !important; border-radius: 50%; border: 3px solid #0a8b07; padding: 8px 8px !important" -->
                                                            <span class="avatar-initial bg-label-primary rounded-circle" style=" background-color: #333; border-radius: 50%; border: 3px solid #0a8b07; padding: 8px 8px !important"
                                                            ><img width="35" height="35" src="../assets/img/misc/usdt-white.svg?<?php echo time();?>">
																	</span>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="info">
                                                <div style="width: 100%; margin-left: 0px; height: 90px" class="d-flex align-items-center gap-3">
                                                    <div style="width: 100%; text-align: left !important; height: 80px; word-break: break-all !important;">
                                                        <div style="width: 100%; word-break: break-all !important; padding-left: 10px; text-align: left">
                                                            <h5 class="card-title mb-0 me-2" style="line-height: 150% !important; color:#fff; font-size: 1.3em; text-align: left !important"><?php echo $slug2;?></h5>
                                                            <h5 class="card-title mb-0 me-2" style="word-break: break-all !important; line-height: 150% !important; color:#fff; font-size: 1.23em; text-align: left !important">
                                                                <?php if ($currency=="BTC") {echo $myData['btc_balance'];} else if ($currency=="USDT") {echo $myData['usdt_balance'];}?>
                                                            </h5>

                                                            <!--
                                                            <div style="margin-left: 0px; width: 100%; height: 22px; font-size: 0.9em; color: #fff;" class="d-flex align-items-center justify-content-start">
                                                                <div class="blink_me">Loading...</div>

                                                            </div>
                                                            -->

                                                            <div style="width: 100%; font-size: 1.2em; font-weight: 900; color: #b3b3b3; text-align: left !important"><?php echo $currency;?></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>

                                        </tr>

                                    </table>
                                </div>
                                <!--end hop icon -->
                            </div>
                            <div class="col-md-8" style="margin 0px 0px !important; padding 0px 0px !important; ">
                                <div class="container" style="width 100%; height: 100%; margin: 0px 0px  !important; padding: 0px 0px !important">
                                    <div class="row d-flex justify-content-center align-items-center" style="height: 100%; margin: 0px 0px  !important; padding: 0px 0px !important; ">
                                        <div class="col-12 col-xl-3 col-sm-3 col-md-6" style="margin: 0px 0px  !important; padding: 5px 0px !important">
                                            <div style="display: flex; width: 100%; align-items: center; justify-content: center;">
                                                <a class="btnCommon" href="<?php echo WEBSITE_ROOT_URL;?>dashboard/?m=<?php echo strtolower($currency);?>&act=deposit" id="btc_depositLink" style="width 100% !important; font-size: 0.9em !important"><?php echo $lang['global.dashboard.sidebar_wallet_deposit'];?></a>
                                            </div>
                                        </div>
                                        <div class="col-12 col-xl-3 col-sm-3 col-md-6" style="margin: 0px 0px  !important; padding: 5px 0px !important">
                                            <div style="display: flex; width: 100%; align-items: center; justify-content: center;">
                                                <a class="btnCommon" href="<?php echo WEBSITE_ROOT_URL;?>dashboard/?m=<?php echo strtolower($currency);?>&act=withdraw" id="btc_withdrawLink" style="width 100% !important; font-size: 0.9em !important"><?php echo $lang['global.dashboard.sidebar_wallet_withdraw'];?></a>
                                            </div>
                                        </div>

                                        <div class="col-12 col-xl-3 col-sm-3 col-md-6" style="margin: 0px 0px  !important; padding: 5px 0px !important">
                                            <div style="display: flex; width: 100%; align-items: center; justify-content: center;">
                                                <a class="btnCommon" href="<?php echo WEBSITE_ROOT_URL;?>dashboard/?m=<?php echo strtolower($currency);?>&act=buy" id="btc_buyLink" style="width 100% !important; font-size: 0.9em !important">Buy</a>
                                            </div>
                                        </div>

                                        <div class="col-12 col-xl-3 col-sm-3 col-md-6" style="margin: 0px 0px  !important; padding: 5px 0px !important">
                                            <div style="display: flex; width: 100%; align-items: center; justify-content: center;">
                                                <a class="btnCommon" href="<?php echo WEBSITE_ROOT_URL;?>dashboard/?m=<?php echo strtolower($currency);?>&act=sell" id="btc_sellLink" style="width 100% !important; font-size: 0.9em !important"><?php echo $lang['global.dashboard.sidebar_wallet_sell'];?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--
                    <div style="display: block; width: 100%; height: auto;">

                        <div class="d-flex justify-content-between">
                            <div class="container" style="height: 170px; width: 100%; margin: 0px 0px !important; padding: 0px 0px !important">
                                <div class="row">
                                    <div class="col-sm-12" style="margin-top: 10px; text-align: right !important">
                                        <div class="container-fluid" style="margin: 0px 0px  !important; padding: 0px 0px !important">
                                            <div class="row" style="margin: 0px 0px  !important; padding: 0px 0px !important">
                                                <div class="col-12" style="margin: 0px 0px  !important; padding: 5px 0px !important">
                                                    <div style="display: flex; width: 100%; align-items: center; justify-content: center; padding: 5px 3px">

                                                        <a href="/dashboard/?m=btc&act=deposit" class="btnCommon">Deposit</a>

                                                    </div>
                                                </div>
                                                <div class="col-12" style="margin: 0px 0px  !important; padding: 5px 0px !important">
                                                    <div style="display: flex; width: 100%; align-items: center; justify-content: center; padding: 5px 3px">

                                                        <a href="/dashboard/?m=btc&act=withdraw" class="btnCommon">Withdraw</a>

                                                    </div>
                                                </div>
                                                <div class="col-12" style="margin: 0px 0px  !important; padding: 5px 0px !important">
                                                    <div style="display: flex; width: 100%; align-items: center; justify-content: center; padding: 5px 3px">

                                                        <a href="/dashboard/?m=btc&act=buy" class="btnCommon">Buy</a>
                                                    </div>
                                                </div>
                                                <div class="col-12" style="margin: 0px 0px  !important; padding: 5px 0px !important">
                                                    <div style="display: flex; width: 100%; align-items: center; justify-content: center; padding: 5px 3px">

                                                        <a href="/dashboard/?m=btc&act=sell" class="btnCommon">Sell</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" style="height: 15px !important">
                                </div>

                            </div>
                        </div>

                    </div>
                    <div style="display: block; width: 100%; height: 40px; color: #b3b3b3; font-size: 1.3em; font-weight: 900;">
                    </div>
                    -->

                </div>

            </div>
            <!--bitcoin end-->
        </div>

    </div>
    <!--end box of balance -->
    <div class="row"  style="margin: 0px 0px !important; padding: 0px 20px !important; margin-top: 20px !important">

        <div class="col-12" style="margin: 0px 0px !important; padding: 0px 0px !important; margin-bottom: 0px !important;">
            <!--sign up panel begin -->
            <div id="profile-panel" class="login-box-content" style="margin-top: 0px; padding-left: 0px; padding-right: 0px; width: 100%; height: auto;  background-color: rgba(0, 0, 0, 0.45) !important; border: 1px solid #01243c">
                <!--begin content-->
                <div style="width; 100%">


                    <div style="display: block; padding: 3px 10px; width: 100%; text-align: center; color: #fff; font-size: 1.3em; font-weight: 900; border-bottom: 1px solid #000; margin-bottom: 5px; text-transform: uppercase; background-color: green">
                        <?php echo $currency_deposit_box_title;?>
                    </div>
                    <div class="container-xxl container-p-y" style="margin: 0px 0px !important; padding: 0px 0px !important;">
                        <!--
									<div class="row" style="padding: 10px 10px !important;">
										<div class="col-12">
											<div id="depositSuccessNotice" style="transition: all 0.5s ease-in-out; border-radius: 5px; margin-top: 10px; text-align: left; border: 2px solid #0CCF1A; background-color: #C3F8D5; padding: 8px 8px; color: #03670A; font-size: 1.0em; font-weight: 900;  width: 100%; display: none;">
												<span style="font-size: 1.2em; display: inline-block;"><i class="fas fa-check" style="color: #03670A"></i></span>&nbsp;<?php echo $lang['global.profile_page.profile_success_update'];?>
											</div>

											<div id="depositErrorNotice" style="transition: all 0.5s ease-in-out; border-radius: 5px; margin-top: 10px; text-align: left; border: 2px solid #FC0606; background-color: #FFD6D6; padding: 8px 8px; color: #FC0606; font-size: 1.0em; font-weight: 900;  width: 100%; display: none;">
												<span style="font-size: 1.2em; display: inline-block;"><i class="fas fa-times" style="color: #FC0606"></i></span>&nbsp;<?php echo $lang['global.profile_page.profile_failed_update'];?>
											</div>
										</div>
									</div>
									-->

                        <div class="row" style="margin: 0px 0px !important; padding: 0px 0px !important;">
                            <div class="col-md-12" style="margin: 0px 0px !important; padding: 0px 0px !important;">
                                <?php
                                if ($currency=="BTC") {
                                    ?>
                                    <form id="deposit-form" action="/" method="post">
                                        <div class="container-fluid" style="margin: 0px 0px !important; padding: 0px 0px !important">


                                            <div class="row" style="margin: 0px 0px !important; padding: 0px 0px !important">
                                                <div class="col-md-3" style="text-align: center !important; color: #fff !important"></div>
                                                <div class="col-md-6" style="color: #fff !important">
                                                    <br/>
                                                    <strong><?php echo $lang['global.deposit_page.deposit_btc'];?></strong><br/><br/>

                                                </div>
                                                <div class="col-md-3" style="text-align: center !important; color: #fff !important"></div>
                                            </div>
                                            <div class="row" style="margin: 0px 0px !important; padding: 0px 0px !important">
                                                <div class="col-md-3" style="text-align: center !important; color: #fff !important"></div>
                                                <div class="col-md-6" style="color: #F2240D !important; font-weight: 900 !important">
                                                    <div style="width :100%; text-decoration: underline">
                                                        <?php echo $lang['global.deposit_page.deposit_usdt_notice001'];?><br/>
                                                    </div>
                                                    <div style="width :100%;">
                                                        <?php echo $lang['global.deposit_page.deposit_usdt_notice002'];?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3" style="text-align: center !important; color: #fff !important"></div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="d-flex justify-content-center align-items-center">
                                                        <?php
                                                        $decided_crypto_address =  $_SESSION['ultimopay_btc_address'];

                                                        ?>
                                                        <img src="https://chart.googleapis.com/chart?chs=200x200&cht=qr&chl=<?php  echo $decided_crypto_address;?>"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <div style="width: 100%; padding: 0px 30px; margin-top: 10px !important;">
                                                        <div style="width: 100%; word-break:break-all;">
                                                            <button class="btnIcon" id="btnIconDeposit"><i class="far fa-copy"></i> copy</button><br>
                                                            <div class="purple-border">
                                                                <textarea class="banner_code" id="btc_address" rows="2" readonly><?php echo $decided_crypto_address;?></textarea>
                                                            </div>
                                                        </div>
                                                        <div style="width: 100%; height: 80px;">

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>
                                    </form>
                                    <?php
                                } else if ($currency=="USDT") {
                                    ?>
                                    <form id="deposit-form" action="/" method="post">
                                        <div class="container-fluid" style="margin: 0px 0px !important; padding: 0px 0px !important">

                                            <div class="row" style="margin: 0px 0px !important; padding: 0px 0px !important">
                                                <div class="col-md-1" style="text-align: center !important; color: #fff !important"></div>
                                                <div class="col-md-10" style="color: #fff !important; padding-top: 30px;">
                                                    <p>
                                                        UltimoPay supports 2 blockchain networks for USDT deposit: Ethereum(ERC20) and Tron(TRC20). Please carefully check that you have selected correspond network of your source address when making deposit to UltimoPay.
                                                    </p>
                                                    <label class="mb-1" for="btnSelNetwork">Network</label>
                                                    <div style="width: 100%; font-size: 0.9em !important">
                                                        <div class="px-app px-dropdown">
                                                            <input class="px-dropdown-value" id="mySelNetwork" type="hidden">
                                                            <div class="px-dropdown-input">
                                                                <input type="text" readonly value="--Select Network--">
                                                                <i class='bx bx-chevron-down'></i>
                                                            </div>
                                                            <div class="px-dropdown-panel">
                                                                <p data-value="Ethereum_ERC20">Ethereum(ERC20)</p>
                                                                <p data-value="Tron_TRC20">Tron(TRC20)</p>
                                                            </div>
                                                        </div>
                                                        <!--
                                                        <button type="button" id="btnSelNetwork" class="btn btn-secondary dropdown-toggle" style="box-shadow: none !important; border: 1px solid #0DF21E !important; background: transparent !important; width: 100% !important" data-bs-toggle="dropdown" aria-expanded="false">

                                                        <div style="display: inline-block; padding-right: 5px"></div><div style="display: inline-block; margin-left: 0px;">--Select network--</div>


                                                        </button>

                                                        <ul class="dropdown-menu" id="selBlockchainNetwork" style="width: 100% !important; background-color: #063304 !important">
                                                            <li>
                                                                <a class="dropdown-item" href="javascript:void(0);" id="ethereum_blockchain"><div style="display: inline-block; padding-right: 5px"></div><div style="display: inline-block; margin-left: 0px;">Ethereum(ERC20)</div></a>
                                                            </li>
                                                            <li>
                                                                <a class="dropdown-item" href="#0" id="tron_blockchain"><div style="display: inline-block; padding-right: 5px"></div><div style="display: inline-block; margin-left: 0px;">Tron(TRC20)</div></a>
                                                            </li>
                                                        </ul>
                                                        -->
                                                    </div>
                                                </div>
                                                <div class="col-md-1" style="text-align: center !important; color: #fff !important"></div>
                                            </div>
                                            <div style="width: 100%; text-align: center; display: none; clear: both; color: #fff !important; padding-top: 20px" id="address_loading_panel">
                                                <div class="d-flex justify-content-center align-items-center" style="width: 100%;">
                                                    <div class="sk-wave" style="background-color: transparent !important;">
                                                        <div class="sk-wave-rect" style="background-color: #11b719 !important;"></div>
                                                        <div class="sk-wave-rect" style="background-color: #11b719 !important;"></div>
                                                        <div class="sk-wave-rect" style="background-color: #11b719 !important;"></div>
                                                        <div class="sk-wave-rect" style="background-color: #11b719 !important;"></div>
                                                        <div class="sk-wave-rect" style="background-color: #11b719 !important;"></div>
                                                    </div>

                                                </div>
                                                <p align="center">loading USDT wallet address...</p>
                                            </div>
                                            <div style="width: 100%; text-align: center; clear: both; color: #fff !important; padding: 0px 30px">
                                                <div id="wallet_address_failed_panel" style="transition: all 0.5s ease-in-out; border-radius: 5px; margin-top: 10px; text-align: left; border: 2px solid #FC0606; background-color: #FFD6D6; padding: 8px 8px; color: #FC0606; font-size: 1.0em; font-weight: 900;  width: 100%; display: none;">
                                                </div>
                                            </div>
                                            <div class="row" style="margin: 0px 0px !important; padding: 0px 0px !important; display: none" id="usdt_address_panel">
                                                <div class="col-12">
                                                    <div class="container-fluid" style="margin: 0px 0px !important; padding: 0px 0px !important">
                                                        <!--begin ne -->
                                                        <div class="row" style="margin: 0px 0px !important; padding: 0px 0px !important;">
                                                            <div class="col-md-1" style="text-align: center !important; color: #fff !important"></div>
                                                            <div class="col-md-10" style="color: #fff !important" id="deposit_usdt_guide_text">
                                                                <br/><strong>Please deposit USDT (ERC-20) to the address below</strong><br/><br/>

                                                            </div>
                                                            <div class="col-md-1" style="text-align: center !important; color: #fff !important"></div>
                                                        </div>
                                                        <div class="row" style="margin: 0px 0px !important; padding: 0px 0px !important">
                                                            <div class="col-md-1" style="text-align: center !important; color: #fff !important"></div>
                                                            <div class="col-md-10" style="color: #F2240D !important; font-weight: 900 !important">
                                                                <div style="width :100%; text-decoration: underline">
                                                                    <?php echo $lang['global.deposit_page.deposit_usdt_notice001'];?><br/>
                                                                </div>
                                                                <div style="width :100%;">
                                                                    <?php echo $lang['global.deposit_page.deposit_usdt_notice002'];?>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-1" style="text-align: center !important; color: #fff !important"></div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="d-flex justify-content-center align-items-center">
                                                                    <?php
                                                                    $decided_crypto_address = $_SESSION['ultimopay_usdt_address'];

                                                                    ?>
                                                                    <img src="https://chart.googleapis.com/chart?chs=200x200&cht=qr&chl=<?php  echo $decided_crypto_address;?>" id="wallet_address_qr_code"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <div style="width: 100%; padding: 0px 30px; margin-top: 10px !important;">
                                                                    <div style="width: 100%; word-break:break-all;">
                                                                        <button class="btnIcon" id="btnIconDeposit"><i class="far fa-copy"></i> copy</button><br>
                                                                        <div class="purple-border" id="wallet_address_container">
                                                                            <textarea class="banner_code" id="btc_address" rows="2" readonly><?php echo $decided_crypto_address;?></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div style="width: 100%; height: 80px;">

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--end ne -->
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row" style="height: 120px; margin: 0px 0px !important; padding: 0px 0px !important;">

                                            </div>





                                        </div>
                                        <input type="hidden" id="previous_usdt_ethereum_address" value="<?php echo $_SESSION['ultimopay_usdt_address'];?>">
                                        <input type="hidden" id="previous_usdt_tron_address" value="<?php echo $_SESSION['ultimopay_usdt_tron_address'];?>">
                                    </form>
                                    <?php
                                }
                                ?>

                            </div>

                        </div>

                    </div>


                </div>
                <!--end content -->
            </div>
            <!-- end sign up panel -->
        </div>
    </div>

</div>
<div class="container-xxl flex-grow-1 container-p-y" style="margin: 0px 0px !important; padding: 0px 0px !important">
    <div class="row" style="height: 30px; margin: 0px 0px !important; padding: 0px 0px !important">

    </div>
</div>
<!--<div style="height: 700px; width: 100%"></div>-->
<!-- End Dasboard Content -->