// The api key of ultimo partner
let API_KEY = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6IjMiLCJuYW1lIjoiVUxUSU1PUEFZIiwiZG9tYWluIjoiREFTSEJPQVJELlVMVElNT1BBWS5JTyIsImZlZSI6IjYiLCJzZXJ2aWNlX3R5cGUiOiJQUk9EIiwiZXhwIjo0ODczNjc4MDk5fQ.7D2xXUbYuXrCDY1MGW31rx5XclyQJ1xT5PQXc6ZeQAQ';
function formatDateTime(dateTimeString) {
  // Check if the string is in ISO 8601 format or the other format
  let dateTime;
  if (dateTimeString.includes('T')) {
    // ISO 8601 format
    dateTime = new Date(dateTimeString);
  } else {
    // Other format
    dateTime = new Date(dateTimeString.replace(' ', 'T') + 'Z');
  }

  // Format the date and time separately
  const date = dateTime.toISOString().split('T')[0]; // '2024-06-09' or '2024-06-07'
  const time = dateTime.toTimeString().split(' ')[0]; // '06:46:41' or '08:33:20'

  // Construct the HTML output
  return `<span class="simple-date">${date}</span><br/><sub class="simple-time">${time}</sub>`;
}