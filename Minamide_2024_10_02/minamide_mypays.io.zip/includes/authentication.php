<?php
require_once '../extAPIs/jwt.php';
require_once '../includes/db.php';
require_once "../includes/common.php";

function checkAuthentication( $jwt ) {

  $baseUrl = getBaseUrl();

  // Check if null
  if( !$jwt ) {
    header('Location: ' . $baseUrl);
    return null;
  }

  // Check if valid
  $verifyResult = verifyJwt( $jwt );
  if( $verifyResult['error'] ) {
    header('Location: ' . $baseUrl);
    return null;
  }

  // Get email address from jwt
  $emailAddress = $verifyResult['emailAddress'];

  // Check if already registered in local database
  $conn = getDbConnection();

// Escape the email address to prevent SQL injection
  $emailAddressEscaped = $conn->real_escape_string($emailAddress);

  $sql = "SELECT * FROM users WHERE email_address = '$emailAddressEscaped' AND deleted_at IS NULL";
  $result = $conn->query($sql);

  if ($result->num_rows == 0) {
    header('Location: ' . $baseUrl);
    exit();  // Ensure script stops after redirection
  }

  return $emailAddress;
}
