import Link from 'next/link'
import {useRouter} from 'next/router';
import {useForm} from 'react-hook-form';
import {yupResolver} from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import {userService} from '/services';
import {toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {useState, useEffect} from "react";
import Swal from "sweetalert2";
import {getDecimalPlaceLength, roundUp, toUsNumber, truncateFloat} from './Utils/calc.js';

function BtcWithdraw({wallet, id, user, twofa, currencyInfo, isMobile}) {
  let btcCurrencyInfo = null;
  for( let i = 0; i < currencyInfo.length; i++ ){
    if( currencyInfo[i].currency_id === id )
      btcCurrencyInfo = currencyInfo[i];
  }
  const router = useRouter();
  const [title, setTitle] = useState(wallet.title);
  const balance = truncateFloat(parseFloat(wallet.data.balance.replace(',', '')), wallet.float);
  const [inputValue, setInputValue] = useState(0);
  const [feeAmount, setFeeAmount] = useState(0);
  const [ifNotValid, setIfNotValid] = useState(true);
  const [address, setAddress] = useState('');
  const withdraw_fee_fixed_amount = btcCurrencyInfo?.withdraw_fee_fixed_amount ? btcCurrencyInfo.withdraw_fee_fixed_amount*1 : 0.001;
  const withdraw_fee_percent = btcCurrencyInfo?.withdraw_fee_percent ? (btcCurrencyInfo.withdraw_fee_percent*1) : 0.1;
  const minimum = btcCurrencyInfo?.withdraw_min ? btcCurrencyInfo.withdraw_min * 1 : 0.0025;
  const availableAmount = (balance > 0 ? Math.max(0, truncateFloat((balance - withdraw_fee_fixed_amount) / (1 + withdraw_fee_percent/100), wallet.float)) : 0);

  const handleInputChange = (event) => {
    setIfNotValid(false);
    setError('amount', null);
    const newValue = event.target.value;
    if (!isNaN(newValue)) {
      if (getDecimalPlaceLength(newValue) >= wallet.float) {
        setInputValue(parseFloat(newValue).toFixed(wallet.float));
      } else {
        setInputValue(newValue);
      }
    }

    if (newValue >= minimum) {
      if (availableAmount < newValue) {
        setError('amount', {message: `You dont have enough amount to withdraw`});
        setIfNotValid(true);
      }
    } else {
      setError('amount', {message: `Amount should be greater than ${minimum}`});
      setIfNotValid(true);
    }
    const totalFeeAmount = truncateFloat(roundUp(parseFloat(newValue) * withdraw_fee_percent/100, wallet.float) + withdraw_fee_fixed_amount, wallet.float);
    totalFeeAmount > 0 ? setFeeAmount(totalFeeAmount + ` ` + id) : setFeeAmount(``);
  };

  const handleKeyDown = (event) => {
    if (event.key === '-' || event.key === '+') {
      event.preventDefault(); // prevent '-' or '+' from being entered
    }
    userService.PreventIncrement(event);
  }

  const validationSchema = Yup.object().shape({
    address: Yup.string()
      .required('Address field is required'),
    amount: Yup.string()
      .required('Amount is required'),
    password: Yup.string()
      .required('Password is required'),
    two_fa_code: Yup.string()
      .required('2FA Code is required'),
  });

  const formOptions = {
    resolver: yupResolver(validationSchema), defaultValues: {
      email_address: user.email_address,
      auth_token: user.auth_token,
      currency: id,
      amount: inputValue,
      address: '',
    }
  };

  // get functions to build form with useForm() hook
  const {register, handleSubmit, formState, setError} = useForm(formOptions);
  const {errors} = formState;

  function onSubmit(user) {
    if (inputValue >= minimum) {
      if (availableAmount < inputValue) {
        setError('amount', {message: `Amount exceeds available for withdrawal.`});
        return false;
      }
    } else {
      setError('amount', {message: `Amount should be greater than ${minimum}`});
      return false;
    }

    return Swal.fire({
      title: `Do you really want to Withdraw ${toUsNumber(inputValue)} ${id}?`,
      // html: `You Pay ${result} USD<br><em>The amount may vary slightly depending on the fluctuation.</em>`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No, cancel",
    }).then((result) => {
      if (result.isConfirmed) {
        userService.showLoader(true);
        return userService.runApi(`withdraw/`, user)
          .then((res) => {
            console.log(res.data);
            userService.showLoader(false)
            if (res.data.result === 'success') {
              const response = res.data.withdrawResponse
              toast.success('Withdrawal request has been sent successfully', {
                position: toast.POSITION.TOP_RIGHT
              });
              setAddress(response.address)
              openModal()
              // Send email using the server-side API route
              fetch('/api/sendEmail', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  currency: id,
                  address: response.address,
                  amount: inputValue,
                  email: user.email_address,
                }),
              })
                .then((/*res*/) => {
                  /*console.log(res);*/
                })
                .catch((error) => {
                  console.error(error);
                });
            } else {
              toast.error(res.data.error.errorMessage, {
                position: toast.POSITION.TOP_RIGHT
              });
            }
          })
          .catch((res) => {
            userService.showLoader(false);
            if (res.response.data.error.errorCode === 16) {
              toast.error('Invalid Password', {
                position: toast.POSITION.TOP_RIGHT
              });
            } else {
              toast.error(res.response.data.error.errorMessage, {
                position: toast.POSITION.TOP_RIGHT
              });
            }
          });
      }
    })
  }

  const openModal = () => {
    const modal = document.getElementById('exampleModal');
    modal.classList.add('show');
    modal.style.display = 'block';
    document.body.classList.add('modal-open');
    const backdrop = document.createElement('div');
    backdrop.classList.add('modal-backdrop', 'fade', 'show');
    document.body.appendChild(backdrop);
  }

  const closeModal = () => {
    const modal = document.getElementById('exampleModal');
    modal.classList.remove('show');
    modal.style.display = 'none';
    document.body.classList.remove('modal-open');
    const backdrop = document.querySelector('.modal-backdrop');
    backdrop.parentNode.removeChild(backdrop);
    router.reload();
  };

  useEffect(() => {
    async function fetchData() {
      if( id === 'BTC' )
        setTitle(` Bitcoin`);
      else
        setTitle(` ` + btcCurrencyInfo.network);
    }
    fetchData();
  }, []);

  return (
    <>
      <div className="container-fluid px-4">
        <div className="row pse-5 pt-3 pb-1">
          <div className="col-xl-12 col-md-6">
            {/* Sidebar Toggle*/}

            {twofa !== 'enabled' ? (<>
              <img src="/assets/img/redio.png" width="20px;" className="me-3" alt="redio"/>
              <label className="mt-1 me-3">
                You have to turn on 2-Factor Authentication in order to make any
                withdrawals. <Link href="/user/2fa" className="text-white font-800 text-decoration-underline"> Turn on 2-Factor Authentication now. </Link>
              </label> </>) : ('')}
          </div>
          <div className="col-sm-12 mt-4">
            <form className="mb-3" onSubmit={handleSubmit(onSubmit)}>
              <h4>
                <b>AMOUNT</b>
              </h4>
              <div className="d-flex position-relative">
                <div className='w-100'>
                  <input onKeyDown={handleKeyDown}
                         name="amount" step="0.0000001"
                         {...register('amount')} className={`amount-price ${ifNotValid ? 'is-invalid' : ''}`}
                         type="text"
                         value={inputValue}
                         onChange={handleInputChange}
                  />
                  <div className="invalid-feedback">{errors.amount?.message}</div>
                </div>
                <span className="input-group-text rounded-0" id="basic-addon2">
                  {id}
                </span>
              </div>
              <div className="col-sm-10 mt-2 tbl-s pes-3">
                {isMobile ? (
                  <table>
                    <tbody>
                    <tr>
                      <td>
                        <div className="ps-2">Minimum withdrawal amount</div>
                        <div className="ps-4">{toUsNumber(minimum)} {id}</div>
                        <div className="ps-2 pt-2">Withdrawal fee</div>
                        <div className="ps-4">{feeAmount ? (toUsNumber(truncateFloat(feeAmount, wallet.float))) : (`${toUsNumber(withdraw_fee_fixed_amount)} ${id} + ${withdraw_fee_percent}% of withdraw amount`)}</div>
                        <div className="ps-2 pt-2">Available amount for withdrawal</div>
                        <div className="ps-4">{toUsNumber(truncateFloat(availableAmount, wallet.float))} {id}</div>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                ) : (
                  <table>
                    <tbody>
                    <tr>
                      <td>Minimum withdrawal amount</td>
                      <td>{toUsNumber(minimum)} {id}</td>
                    </tr>
                    <tr>
                      <td>Withdrawal fee</td>
                      <td>
                        <div className="tbl-wdth">{feeAmount ? (toUsNumber(truncateFloat(feeAmount, wallet.float))) : (`${toUsNumber(withdraw_fee_fixed_amount)} ${id} + ${withdraw_fee_percent}% of withdraw amount`)}</div>
                      </td>
                    </tr>
                    <tr>
                      <td>Available amount for withdrawal</td>
                      <td>{toUsNumber(truncateFloat(availableAmount, wallet.float))} {id}</td>
                    </tr>
                    </tbody>
                  </table>
                )}
              </div>
              <h4 className="mt-4">
                <b>{title} Address </b>
              </h4>
              <div className="mb-3">
                <input
                  type="text"
                  name="address"
                  {...register('address')} className={`form-control ${errors.address ? 'is-invalid' : ''}`}
                  id="exampleInputEmail1"
                  aria-describedby="emailHelp"
                  placeholder={`Enter ${title} address`}
                />
                <div className="invalid-feedback">{errors.address?.message}</div>
              </div>
              <h4 className="mt-4">
                <b>2FA Code </b>
              </h4>
              <div className="mb-3">
                <input
                  type="text"
                  name="two_fa_code"
                  {...register('two_fa_code')} className={`form-control ${errors.two_fa_code ? 'is-invalid' : ''}`}
                  id="two_fa_code"
                  aria-describedby="emailHelp"
                  placeholder="Enter 2FA Code"
                />
                <div className="invalid-feedback">{errors.two_fa_code?.message}</div>
              </div>
              <h4 className="mt-4">
                <b>Password </b>
              </h4>
              <div className="mb-3">
                <input
                  type="password"
                  name="password"
                  {...register('password')} className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                  id="password"
                  aria-describedby="emailHelp"
                  placeholder="Enter Password"
                />
                <div className="invalid-feedback">{errors.password?.message}</div>
              </div>
              {twofa === 'enabled' ? (<button type="submit" className="mt-4 size-xl button primary col-sm-3"
                                              disabled={formState.isSubmitting || ifNotValid}
              >
                WITHDRAW {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
              </button>) : (<button type="submit" className="mt-4 size-xl button primary col-sm-3" disabled>
                WITHDRAW {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
              </button>)}<br/><span className='mx-2 mt-3'>Withdrawal requests are processed daily at 9:00 AM UTC.</span>
            </form>
          </div>
        </div>
      </div>
      <div
        className="modal fade"
        id="exampleModal"
        tabIndex={-1}
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header bg-mdl-ttl">
              <h5 className="modal-title text-center w-100" id="exampleModalLabel">
                Confirmation
              </h5>
            </div>
            <div className="modal-body">
              <p>The following withdrawal requests have been completed</p>
              <p className="ps-3 mt-2">Amount: {inputValue} {id}</p>
              <p className="ps-3">Address: {address}</p>

              <p className="mt-2">A confirmation email has been sent to
                <span className='text-white ps-1 font-800 font-16'>{user.email_address}</span><br/>
                Please confirm it and reply the email.</p>
              <p className="mt-3"> After confirmation your withdrawal
                will be processed at 9:00 AM UTC, so please wait patiently.
              </p>

            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="button ghost"
                data-bs-dismiss="modal"
                onClick={closeModal}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default BtcWithdraw;
