<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

date_default_timezone_set('Asia/Tokyo');

$base_path = "/var/www/my.bitquick.io/bitquick_pdf_api";
$site_path = "https://my.bitquick.io/bitquick_pdf_api";

require_once('../classes/fpdf/fpdf.php');
require_once('../classes/fpdi2/src/autoload.php');

use setasign\Fpdi\Fpdi;
use setasign\Fpdi\PdfParser\StreamReader;
use setasign\Fpdi\PdfReader\Page;

$data = array('msg' => 'proc_ok', 'msg_ex' => '', 'whichform' => 0, 'form2_page1_screenshot' => '', 'form2_page4_screenshot' => '');

$session_expired = 1;
if ($session_expired == 1) {
  function _log($line)
  {
    global $base_path;
    $log_file = $base_path . "/log/fileupload-test.log";
    $fline = date('[Ymd H:i:s] ') . $line . "\n";

    // Attempt to open the file for appending
    if ($fl = fopen($log_file, 'a')) {
      fwrite($fl, $fline);
      fclose($fl);
    } else {
      //echo "Error: Unable to open log file: $log_file\n";
    }

    // Output the log line to the screen
    //echo date('[Ymd H:i:s] ') . $line . "\n";

    // Flush the output buffer
    if (ob_get_level() > 0) {
      ob_flush();
    }
    flush();
  }

  $direction = 'landscape';
  $thefile = $_POST['mydata'] ?? '';
  $email_address = $_POST['email_address'] ?? '';
  $profile_id = md5($email_address);
  $whichform = $_POST['whichform'] ?? '';
  $direction = $_POST['direction'] ?? 'landscape';
  _log("whichform = " . $whichform . ", profile = " . $profile_id . ", direction = " . $direction);
  $img_filename = $profile_id . "_form_" . $whichform . ".png";
  $img_filename_rotate = $profile_id . "_form_" . $whichform . "_rotate.png";

  if ($profile_id != '') {
    if ($thefile != '') {
      $encoded_image = explode(",", $thefile)[1] ?? '';
      $decoded_image = base64_decode($encoded_image);
      file_put_contents($base_path . "/jdb/data/upload/" . $img_filename, $decoded_image);
      sleep(1);
      if (file_exists($base_path . "/jdb/data/upload/" . $img_filename)) {
        _log("upload successful!");

        //images (300dpi, A4 paper)
        $paper_width_px = 2480;
        $paper_height_px = 3508;

        if (intval($whichform) == 1) {
          //export pdf from templates
          $application_form_1_filename = 'application_form_1_' . $profile_id . '.pdf';
          $application_form_1_temp_page_1_filename = 'application_form_1_' . $profile_id . '_page_1_temp.pdf';
          $application_form_1_temp_page_2_filename = 'application_form_1_' . $profile_id . '_page_2_temp.pdf';
          $application_form_1_screenshot_page_1_filename = 'application_form_1_screenshot_page_1_' . $profile_id . '.png';
          $application_form_1_screenshot_page_2_filename = 'application_form_1_screenshot_page_2_' . $profile_id . '.png';
          $application_form_1_filepath = $base_path . '/jdb/data/download/' . $application_form_1_filename;
          $application_form_1_temp_page_1_filepath = $base_path . '/jdb/data/download/' . $application_form_1_temp_page_1_filename;
          $application_form_1_temp_page_2_filepath = $base_path . '/jdb/data/download/' . $application_form_1_temp_page_2_filename;
          $application_form_1_screenshot_page_1_filepath = $base_path . '/jdb/data/download/' . $application_form_1_screenshot_page_1_filename;
          $application_form_1_screenshot_page_2_filepath = $base_path . '/jdb/data/download/' . $application_form_1_screenshot_page_2_filename;

          if (file_exists($application_form_1_filepath)) {
            $paper_scale = 210 / $paper_width_px;
            $myscale = 3.74;

            if ($direction == "portrait") {
              // open the image file
              $im = imagecreatefrompng($base_path . "/jdb/data/upload/" . $img_filename);
              $transparency = imagecolorallocatealpha($im, 255, 255, 255, 0);

              // rotate, last parameter preserves alpha when true
              $rotated = imagerotate($im, 270, $transparency, 1);

              $background = imagecolorallocate($rotated, 255, 255, 255);
              imagecolortransparent($rotated, $background);

              imagealphablending($rotated, false);
              imagesavealpha($rotated, true);

              imagepng($rotated, $base_path . "/jdb/data/upload/" . $img_filename);
              imagedestroy($im);
              imagedestroy($rotated);
            }

            for ($form_1_page = 1; $form_1_page <= 2; $form_1_page++) {
              $pdf = new Fpdi();
              $pageCount2 = $pdf->setSourceFile($application_form_1_filepath);
              $templateId = $pdf->importPage($form_1_page);
              $pdf->AddPage();
              $pdf->useImportedPage($templateId, 0, 17, 210, 268, false);

              if ($form_1_page == 1) {
                $pdf->Image($base_path . "/jdb/data/upload/" . $img_filename, 50, 80, 75, 75 / $myscale);
                $pdf->Output($application_form_1_temp_page_1_filepath, 'F');
                _log("reached this point");
                if (file_exists($application_form_1_temp_page_1_filepath)) {
                  @unlink($application_form_1_screenshot_page_1_filepath);
                  $formtwo_page_4_url = $application_form_1_temp_page_1_filepath . '[0]';
                  $imagickObj2b = new Imagick();
                  $imagickObj2b->setResolution(300, 300);
                  $imagickObj2b->setSize(1400, 1979);
                  $imagickObj2b->readimage($formtwo_page_4_url);
                  $imagickObj2b->setImageBackgroundColor('#ffffff');
                  $imagickObj2b->resizeImage(1400, 1979, Imagick::FILTER_LANCZOS, 1);
                  $imagickObj2b->setImageFormat("png");
                  $imagickObj2b->writeImage($application_form_1_screenshot_page_1_filepath);
                  $imagickObj2b->clear();
                  $imagickObj2b->destroy();
                  $data['form1_page1_screenshot'] = $site_path . '/jdb/data/download/' . $application_form_1_screenshot_page_1_filename . "?t=" . time();
                }
              } else if ($form_1_page == 2) {
                $pdf->Image($base_path . "/jdb/data/upload/" . $img_filename, 20, 233, 20, 30 / $myscale);
                $pdf->Output($application_form_1_temp_page_2_filepath, 'F');
                _log("reached this point");
                if (file_exists($application_form_1_temp_page_2_filepath)) {
                  @unlink($application_form_1_screenshot_page_2_filepath);
                  $formtwo_page_4_url = $application_form_1_temp_page_2_filepath . '[0]';
                  $imagickObj2b = new Imagick();
                  $imagickObj2b->setResolution(300, 300);
                  $imagickObj2b->setSize(1400, 1979);
                  $imagickObj2b->readimage($formtwo_page_4_url);
                  $imagickObj2b->setImageBackgroundColor('#ffffff');
                  $imagickObj2b->resizeImage(1400, 1979, Imagick::FILTER_LANCZOS, 1);
                  $imagickObj2b->setImageFormat("png");
                  $imagickObj2b->writeImage($application_form_1_screenshot_page_2_filepath);
                  $imagickObj2b->clear();
                  $imagickObj2b->destroy();
                  $data['form1_page2_screenshot'] = $site_path . '/jdb/data/download/' . $application_form_1_screenshot_page_2_filename . "?t=" . time();
                }
              }
            }

            $data['msg'] = 'proc_ok';
            $data['whichform'] = intval($whichform);

          }
        } else if (intval($whichform) == 2) {
          $application_form_2_filename = 'application_form_2_' . $profile_id . '.pdf';
          $application_form_2_temp_page_1_filename = 'application_form_2_' . $profile_id . '_page_1_temp.pdf';
          $application_form_2_temp_page_2_filename = 'application_form_2_' . $profile_id . '_page_2_temp.pdf';
          $application_form_2_temp_page_3_filename = 'application_form_2_' . $profile_id . '_page_3_temp.pdf';
          $application_form_2_temp_page_4_filename = 'application_form_2_' . $profile_id . '_page_4_temp.pdf';
          $application_form_2_screenshot_page_1_filename = 'application_form_2_screenshot_page_1_' . $profile_id . '.png';
          $application_form_2_screenshot_page_4_filename = 'application_form_2_screenshot_page_4_' . $profile_id . '.png';
          $application_form_2_filepath = $base_path . '/jdb/data/download/' . $application_form_2_filename;
          $application_form_2_page_1_temp_filepath = $base_path . '/jdb/data/download/' . $application_form_2_temp_page_1_filename;
          $application_form_2_page_2_temp_filepath = $base_path . '/jdb/data/download/' . $application_form_2_temp_page_2_filename;
          $application_form_2_page_3_temp_filepath = $base_path . '/jdb/data/download/' . $application_form_2_temp_page_3_filename;
          $application_form_2_page_4_temp_filepath = $base_path . '/jdb/data/download/' . $application_form_2_temp_page_4_filename;
          $application_form_2_screenshot_page_1_filepath = $base_path . '/jdb/data/download/' . $application_form_2_screenshot_page_1_filename;
          $application_form_2_screenshot_page_4_filepath = $base_path . '/jdb/data/download/' . $application_form_2_screenshot_page_4_filename;

          if (file_exists($application_form_2_filepath)) {
            $paper_scale = 210 / $paper_width_px;
            $myscale = 3.74;

            if ($direction == "portrait") {
              // open the image file
              $im = imagecreatefrompng($base_path . "/jdb/data/upload/" . $img_filename);
              $transparency = imagecolorallocatealpha($im, 255, 255, 255, 0);

              // rotate, last parameter preserves alpha when true
              $rotated = imagerotate($im, 270, $transparency, 1);

              $background = imagecolorallocate($rotated, 255, 255, 255);
              imagecolortransparent($rotated, $background);

              imagealphablending($rotated, false);
              imagesavealpha($rotated, true);

              imagepng($rotated, $base_path . "/jdb/data/upload/" . $img_filename);
              imagedestroy($im);
              imagedestroy($rotated);
            }

            for ($page = 1; $page <= 4; $page++) {
              $pdf = new Fpdi();
              $pageCount2 = $pdf->setSourceFile($application_form_2_filepath);
              $templateId = $pdf->importPage($page);
              $pdf->AddPage();
              $pdf->useImportedPage($templateId, 0.4, 0, 209, null, false);

              if ($page == 1) {
                $pdf->Image($base_path . "/jdb/data/upload/" . $img_filename, 134, 145, 34, 34 / $myscale);
                $pdf->Output($application_form_2_page_1_temp_filepath, 'F');
                _log("form-2 : xuat duoc PDF trang 1");
                if (file_exists($application_form_2_page_1_temp_filepath)) {
                  @unlink($application_form_2_screenshot_page_1_filepath);
                  $formtwo_page_4_url = $application_form_2_page_1_temp_filepath . '[0]';
                  $imagickObj2b = new Imagick();
                  $imagickObj2b->setResolution(300, 300);
                  $imagickObj2b->setSize(1400, 1979);
                  $imagickObj2b->readimage($formtwo_page_4_url);
                  $imagickObj2b->setImageBackgroundColor('#ffffff');
                  $imagickObj2b->resizeImage(1400, 1979, Imagick::FILTER_LANCZOS, 1);
                  $imagickObj2b->setImageFormat("png");
                  $imagickObj2b->writeImage($application_form_2_screenshot_page_1_filepath);
                  $imagickObj2b->clear();
                  $imagickObj2b->destroy();
                  $data['form2_page1_screenshot'] = $site_path . '/jdb/data/download/' . $application_form_2_screenshot_page_1_filename . "?t=" . time();
                }
              } else if ($page == 2) {
                $pdf->Output($application_form_2_page_2_temp_filepath, 'F');
                _log("form-2 : xuat duoc PDF trang 2");
              } else if ($page == 3) {
                $pdf->Output($application_form_2_page_3_temp_filepath, 'F');
                _log("form-2 : xuat duoc PDF trang 3");
              } else if ($page == 4) {
                $pdf->Image($base_path . "/jdb/data/upload/" . $img_filename, 26, 231.5, 29, 29 / $myscale);
                $pdf->Output($application_form_2_page_4_temp_filepath, 'F');
                _log("form-2 : xuat duoc PDF trang 4");
                if (file_exists($application_form_2_page_4_temp_filepath)) {
                  @unlink($application_form_2_screenshot_page_4_filepath);
                  $formtwo_page_4_url = $application_form_2_page_4_temp_filepath . '[0]';
                  $imagickObj2b = new Imagick();
                  $imagickObj2b->setResolution(300, 300);
                  $imagickObj2b->setSize(1400, 1979);
                  $imagickObj2b->readimage($formtwo_page_4_url);
                  $imagickObj2b->setImageBackgroundColor('#ffffff');
                  $imagickObj2b->resizeImage(1400, 1979, Imagick::FILTER_LANCZOS, 1);
                  $imagickObj2b->setImageFormat("png");
                  $imagickObj2b->writeImage($application_form_2_screenshot_page_4_filepath);
                  $imagickObj2b->clear();
                  $imagickObj2b->destroy();
                  $data['form2_page4_screenshot'] = $site_path . '/jdb/data/download/' . $application_form_2_screenshot_page_4_filename . "?t=" . time();
                }
              }
            }

            if (($data['form2_page1_screenshot'] != '') && ($data['form2_page4_screenshot'] != '')) {
              $data['msg'] = 'proc_ok';
            } else {
              $data['msg'] = 'proc_ng';
            }
          }
        }
      } else {
        _log("failed to write to image file !");
        $data['msg'] = 'proc_ng';
        $data['msg_ex'] = 'upload failed';
      }
    } else {
      _log("Error: raw image is empty !");
      $data['msg'] = 'proc_ng';
      $data['msg_ex'] = 'upload failed';
    }
  } else {
    _log("Error: profile_id is blank !");
    $data['msg'] = 'proc_ng';
    $data['msg_ex'] = 'upload failed';
  }
} else {
  $data['msg'] = 'proc_ng2';
  $data['msg_ex'] = 'session has expired !';
}

echo json_encode($data);
die();
?>
