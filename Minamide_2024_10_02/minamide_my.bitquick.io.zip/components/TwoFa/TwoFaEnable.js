import { useRouter } from 'next/router';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { userService, alertService } from '/services';
import Swal from 'sweetalert2';
import {useEffect, useState} from "react";


function TwoFaEnable({user}) {
  const router = useRouter();
  const validationSchema = Yup.object().shape({
    two_fa_code: Yup.string()
      .required('2Fa is required'),
    password: Yup.string()
      .required('Password is required'),
  });
  const formOptions = { resolver: yupResolver(validationSchema) ,defaultValues: {
      email_address:user.email_address,
      auth_token:user.auth_token,
      type:0,
    }};

  // get functions to build form with useForm() hook
  const { register, handleSubmit, formState , setError } = useForm(formOptions);
  const { errors } = formState;
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  function onSubmit(user) {
    return userService.set2FA(user)
      .then((res) => {
        if(res.data.result === 'success')
        {
          Swal.fire({
            title: "Success",
            text: "Your 2-FA has been Disabled successfully",
            icon: "success"
          }).then(function (result)
          {
            router.push({
              pathname: '/user/2fa',
            });
          })
        }
        else
        {
          Swal.fire({
            title: "Error",
            text: res.data.error.errorMessage,
            icon: "error"
          }).then(function (result)
          {})
        }
      })
      .catch((ress) => {
        const res =  ress.response;
        if(res.data.result === "failed")
        {
          if(res.data.error.errorCode === 11)
          {
            setError('two_fa_code', { message: res.data.error.errorMessage });
          }
          if(res.data.error.errorCode === 12)
          {
            setError('password', { message: 'Invalid password' });
          }
        }
        else
        {
          Swal.fire({
            title: "Error",
            text: res.data.error.errorMessage,
            icon: "error"
          }).then(function (result)
          {})
        }
      });
  }
  return (
    <>
      <div className={`container-fluid ${isMobile ? "pe-2 ps-2" : "pe-4 ps-4"}`}>
        <form className="row g-3" onSubmit={handleSubmit(onSubmit)}>
          <div className={`row ${isMobile ? "pe-1 ps-1" : "pe-4 ps-4"} pt-5 pb-0`}>
            <div className="col-sm-12">
              <h1 className="mt-3 font-800 text-white">
                <b>2-Factor <br></br> Authentication is
                  <small
                    style={{ top: '-1px', fontSize: '1rem', marginLeft: '10px' }}
                    className="alert alert-info p-0 px-2">ON
                  </small>
                </b>
              </h1>
            </div>
            <div className="col-md-7 mt-3">
              <div className="fact p-4 text-center">
                <div className="mb-3">
                  <img src="/assets/img/check.png" className="two-fa-enabled-icon" />
                  <span className="mt-4 ps-2 two-fa-enabled-text">Enabled</span>
                </div>
                <p className="text-start mb-0">
                  If you want to turn off 2-Factor Authentication for your account, please enter 2-FA Code that started by BitQuick
                  ({user.email_address}) in your Google Authenticator App, and your login password, then click "Turn OFF 2-Factor
                  Authentication" button below.{" "}
                </p>
              </div>
            </div>
            <div className="col-md-5 mt-3">
              <div className="fact p-4 h-100">
                <p className="mb-4">
                  Enter the code from your Google
                  Authenticator App and your login
                  password{" "}
                </p>
                <div className="col-md-12">
                  <label htmlFor="inputPassword1" className="form-label">
                    Enter the code from your Google Authenticator App
                  </label>
                  <input
                    type="text"
                    name='two_fa_code'
                    {...register('two_fa_code')} className={`form-control ${errors.two_fa_code ? 'is-invalid' : ''}`}
                    id="inputPassword1"
                    placeholder="Enter the code from your Google Authenticator App"
                  />
                  <div className="invalid-feedback">{errors.two_fa_code?.message}</div>
                </div>
                <div className="col-md-12 mt-4">
                  <label htmlFor="inputPassword4" className="form-label">
                    Your login password
                  </label>
                  <input
                    type="password"
                    name='password'
                    {...register('password')} className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                    id="inputPassword4"
                    placeholder="Enter Your login password"
                  />
                  <div className="invalid-feedback">{errors.password?.message}</div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 mb-4">
            <div className={`${isMobile ? "" : "col-10"}`}>
              <div className="row">
                <div className="col-md-6 m-auto">
                  <button type="submit" className="button primary size-xl mt-2 w-100" disabled={formState.isSubmitting}>
                    Turn OFF 2-Factor Authentication
                    {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </>
  )
}

export {TwoFaEnable} ;
