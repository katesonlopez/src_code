export const constService = {
  IsMaintenance: true
};
