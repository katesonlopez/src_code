<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($line) {
    //global $fh;
    $fh2 = fopen(dirname(__FILE__) . "/log/reset_password.log" , 'a');
    $fline = date('[Ymd H:i:s] ') . $line."\n";
    fwrite($fh2, $fline);
    fclose($fh2);
    //echo date('[Ymd H:i:s] ').$line."\n";
    //@ob_flush();
    //flush();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../include/dbconfig.php';
    $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (mysqli_connect_errno() != 0) {


        header('Content-Type: application/json');
        http_response_code(500);
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
        echo json_encode($ret_rs);
        die();
    } else {
        _log("ket noi thanh cong");
        mysqli_query($dbhandle, "set names utf8;");
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
    $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
    $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
    $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
    $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
    $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
    $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
    $clientSecret4 = 'climbpot api access key';
    $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
    $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
    $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
    $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
    $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
    $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
    //$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
    $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
    $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
    $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
    $found = 0;
    $coin = 'USDT';
    $sandbox = 0;
    $partner = "";
    $req_api_key = "";
    $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
    foreach (getallheaders() as $name => $value) {
        //echo "$name: $value\n";
        if ($name == 'Authorization') {
            $req_api_key = trim($value);
            $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
            $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
            if (mysqli_num_rows($partner_rs) > 0) {
                while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
                    $cur_api_key = "Bearer " . $row_partner['api_key'];
                    if ($req_api_key == $cur_api_key) {
                        $req_partner['partner'] = trim($row_partner['partner']);
                        $req_partner['api_key'] = trim($row_partner['api_key']);
                        $req_partner['website'] = trim($row_partner['website']);
                        $selected_api_key = $req_api_key;
                        break;
                    }
                }
            } else {
                _log("not found in db");
            }
        }
    }

    function isValidPassword($password) {
        if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
            return FALSE;
        return TRUE;
    }

    _log("bat dau xu ly...");
    if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

        $json = file_get_contents('php://input');
        $data = json_decode($json, true);

        if (!($data)) {

            switch (json_last_error()) {
                case JSON_ERROR_DEPTH:
                    _log('Reached the maximum stack depth');
                    break;
                case JSON_ERROR_STATE_MISMATCH:
                    _log('Incorrect discharges or mismatch mode');
                    break;
                case JSON_ERROR_CTRL_CHAR:
                    _log('Incorrect control character');
                    break;
                case JSON_ERROR_SYNTAX:
                    _log('Syntax error or JSON invalid');
                    break;
                case JSON_ERROR_UTF8:
                    _log('Invalid UTF-8 characters, possibly invalid encoding');
                    break;
                default:
                    _log('Unknown error');
                    break;
            }

            @mysqli_close($dbhandle);
            _log('A non-empty request body is required.');
            header('Content-Type: application/json');
            http_response_code(400);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
            echo json_encode($ret_rs);
            die();

        } else {
            unset($errors);
            $errors = array();

            //email
            if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
                $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
                $errors[] = $error_obj;
            }

            if (count($errors) == 0) {

                $errors_sub = array();

                //proceed to shift api
                require_once '../include/common.php';

                //receive POST params
                $reg_email_address = strtolower(trim($data['email_address']));
                _log("reset password started...");

                //get user data from cryptocaah_users_proile table
                $is_signed_up = 0;
                $signup_info_sql = "SELECT * FROM cryptocash_users_profile WHERE email='$reg_email_address' AND created_from='" . $req_partner['partner'] . "' LIMIT 1";
                $signup_info_rs = mysqli_query($dbhandle, $signup_info_sql);
                _log($signup_info_sql);
                if (mysqli_num_rows($signup_info_rs) > 0) {
                    $is_signed_up = 1;
                } else {
                    _log("user not found in db");
                }
                @mysqli_close($dbhandle);

                $post_data = array();
                $post_data['ClientId'] = $aws_cognito_app_client_id;
                $post_data['Username'] = $reg_email_address;
                $post_data['exchange'] = "PLUSQO";

                $reset_password_res = api_call('/authentication/user_authentication/startForgotPassword', 0, '', $post_data, '');
                _log($reg_email_address  . ":: reset_password_res = " . json_encode($reset_password_res));
                if (($reset_password_res['http_code'] == "200") || ($reset_password_res['http_code'] == "200 OK")) {
                    if (!empty($reset_password_res['result']['CodeDeliveryDetails']))   {
                        $reset_password_response = array('email_address' => $reg_email_address, 'completeResetPassword' => false);
                        $ret_rs['result'] = 'success';
                        $ret_rs['resetPasswordResponse'] = $reset_password_response;
                        header('Content-Type: application/json');
                        echo json_encode($ret_rs);
                        die();
                    } else {
                        _log($reg_email_address . ": result.CodeDeliveryDetails is empty");
                        $ret_rs['result'] = 'failed';
                        $ret_rs['error'] = array('errorCode' => 3, 'errorMessage' => 'unknown error occurred. please contact administrator for help.');
                        header('Content-Type: application/json');
                        echo json_encode($ret_rs);
                        die();
                    }
                } else {
                    if (isset($reset_password_res['result']['__type'])) {
                        _log($reg_email_address . "tim dc __type : " . $reset_password_res['result']['__type']);
                        if (trim($reset_password_res['result']['__type']) == 'UserNotFoundException') {
                            _log($reg_email_address . ": __type = " . $reset_password_res['result']['__type']);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 3, 'errorMessage' => 'The email address <strong>' . $reg_email_address . '</strong> could not be found.');
                            header('Content-Type: application/json');
                            echo json_encode($ret_rs);
                            die();
                        } else if (trim($reset_password_res['result']['__type']) == 'LimitExceededException') {
                            _log($reg_email_address . ": __type = " . $reset_password_res['result']['__type']);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 3, 'errorMessage' => 'Too many requests. Please try again later.');
                            header('Content-Type: application/json');
                            echo json_encode($ret_rs);
                            die();
                        } else if (trim($reset_password_res['result']['__type']) == 'InvalidParameterException') {
                            _log($reg_email_address . ": __type = " . $reset_password_res['result']['__type']);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 3, 'errorMessage' => 'User is not confirmed.');
                            header('Content-Type: application/json');
                            echo json_encode($ret_rs);
                            die();
                        }
                    } else {
                        _log($reg_email_address . "kg tim dc __type : " . $reset_password_res['result']['__type']);
                        $data['msg'] = 'proc_ng';
                        $data['msg_ex'] = 'Unknown error occured. Please contact administrator for help.';
                        _log($reg_email_address . ':: Unknown error occured. Please contact administrator for help.');
                    }
                }
            } else {
                @mysqli_close($dbhandle);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = $errors[0];
                _log($ret_rs['error']['errorMessage']);
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
            }
        }

    } else {
        @mysqli_close($dbhandle);
        header('HTTP/1.0 403 Forbidden');
        die();
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
    http_response_code(405);
    die();
}