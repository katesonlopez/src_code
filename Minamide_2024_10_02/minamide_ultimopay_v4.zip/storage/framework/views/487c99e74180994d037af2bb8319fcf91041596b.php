<?php $__env->startSection('title', 'Login Page'); ?>

<?php $__env->startSection('page-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset(mix('/css/pages/authentication.css'))); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <section class="row flexbox-container">
    <div class="col-xl-8 col-11 d-flex justify-content-center">
      <div class="card bg-authentication mb-0" style="border: 1px solid #bb9700; border-radius: 20px; margin-top: -30px;">
        <div class="row m-0">
          <div class="col-lg-12 col-12 p-3">
            <div class="">
              <h3 class="text-center">Welcome to UltimoPay!</h3>
              <p>
                It looks like you've landed on this page directly. For the best experience and to access all features, please start from the dashboard at <a href="https://dashboard.ultimopay.io/">dashboard.ultimopay.io</a>.
              </p>
              <p>
                If you have any questions or need assistance, feel free to reach out to our support team.
              </p>
              <p>
                Thank you for using UltimoPay!
              </p>
              <a href="https://dashboard.ultimopay.io/" class="btn btn-warning authentication-login-btn mb-2 float-right btn-inline">
                Redirect to UltimoPay
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/fullLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Minamide\minamide_ultimopay_v4\resources\views//pages/auth-redirect.blade.php ENDPATH**/ ?>