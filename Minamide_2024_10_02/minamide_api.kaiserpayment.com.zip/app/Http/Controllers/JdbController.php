<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JdbController extends Controller
{
  public function home(Request $request): string
  {
    return view('pages.payment');
  }

  public function payment(Request $request): string
  {
    return view('pages.payment');
  }

  public function nonUiPayment(Request $request): string
  {
    return view('pages.non_ui_payment');
  }

  public function report(Request $request): string
  {
    return view('pages.report');
  }

  public function confirmation(Request $request): string
  {
    $orderNo = $request->input('orderNo');
    $productDescription = $request->input('productDescription');

    return view('pages.confirmation', [
      'orderNo' => $orderNo,
      'productDescription' => $productDescription,
    ]);
  }

  public function cancellation(Request $request): string
  {
    $orderNo = $request->input('orderNo');
    $productDescription = $request->input('productDescription');

    return view('pages.cancellation', [
      'orderNo' => $orderNo,
      'productDescription' => $productDescription,
    ]);
  }

  public function failed(Request $request): string
  {
    $orderNo = $request->input('orderNo');
    $productDescription = $request->input('productDescription');

    return view('pages.failed', [
      'orderNo' => $orderNo,
      'productDescription' => $productDescription,
    ]);
  }

  public function backend(Request $request): string
  {
    $orderNo = $request->input('orderNo');
    $productDescription = $request->input('productDescription');

    return view('pages.backend', [
      'orderNo' => $orderNo,
      'productDescription' => $productDescription,
    ]);
  }

  public function threeDSRedirect( Request $request ){
    $cReq = $request->input('cReq');
    $threeDSSessionData = $request->input('threeDSSessionData');
    $acsUrl = $request->input('acsUrl');

    // Initialize a cURL session
    $ch = curl_init();

    // Set the URL to send the request to
    curl_setopt($ch, CURLOPT_URL, $acsUrl);

    // Set the request method to POST
    curl_setopt($ch, CURLOPT_POST, true);

    // Set the request headers
    $headers = [
      "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "accept-encoding: gzip, deflate, br, zstd",
      "accept-language: en,en-US;q=0.9,ja;q=0.8",
      "cache-control: no-cache",
      "connection: keep-alive",
      "content-type: application/x-www-form-urlencoded",
      "host: acs-jcn.dnp-cdms.jp",
      "origin: https://payment.paco.2c2p.com",
      "pragma: no-cache",
      "referer: https://payment.paco.2c2p.com/",
      "sec-ch-ua: \"Not)A;Brand\";v=\"99\", \"Google Chrome\";v=\"127\", \"Chromium\";v=\"127\"",
      "sec-ch-ua-mobile: ?0",
      "sec-ch-ua-platform: \"Windows\"",
      "sec-fetch-dest: document",
      "sec-fetch-mode: navigate",
      "sec-fetch-site: cross-site",
      "upgrade-insecure-requests: 1",
      "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"
    ];

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Set the POST fields (form data)
    $postFields = "creq=$cReq&threeDSSessionData=$threeDSSessionData";
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);

    // Set this to true to return the response, but we'll set it to false since you don't want to receive the response
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);

    // Execute the cURL request
    curl_exec($ch);

    // Close the cURL session
    curl_close($ch);

    // Redirect to the target URL (or another URL of your choice)
    header("Location: $acsUrl");
    exit;
  }
}
