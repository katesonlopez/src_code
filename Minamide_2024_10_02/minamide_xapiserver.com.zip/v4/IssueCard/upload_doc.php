<?php

use \setasign\Fpdi\Fpdi;

require_once('../classes/fpdf/fpdf.php');
require_once('../classes/fpdi2/src/autoload.php');
include 'common.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

$test_people = array("keisuke@webknock.xyz", "minamide@optlynx.com", "kagya868@fuwari.be", "hebigusu@nezumi.be", "ribadafa@usako.net");
$data = [];
$data['status'] = 1;

$jdb_profile_country = '';
$kyc_doc_upload = (isset($_POST['kyc_doc_upload'])) ? trim($_POST['kyc_doc_upload']) : 'no';
$document_type = (isset($_POST['document_type'])) ? trim($_POST['document_type']) : '';
$my_email_address = (isset($_POST['email_address'])) ? $_POST['email_address'] : '';
$my_profile_id = md5($my_email_address);
$myData = array('passport_open' => '', 'passport_selfie' => '', 'id_card_front' => '', 'id_card_back' => '', 'id_card_selfie' => '');
$id_card_type = 'passport'; //default

if ($kyc_doc_upload == 'yes') {
	$total_files_cnt = 0;
	if ($my_profile_id != '') {
		if ($document_type == '1') {
			$kyc_file_path = BASE_PATH . "/jdb/data/upload/id_card_" . $my_profile_id . "*.*";
			$kyc_files = glob($kyc_file_path); // get all file names
			foreach ($kyc_files as $kyc_file) { // iterate files
				if (is_file($kyc_file)) {
					unlink($kyc_file); // delete file
				}
			}

			$passport_open_file_path = BASE_PATH . "/jdb/data/upload/passport_open_" . $my_profile_id . ".*";
			$passport_open_files = glob($passport_open_file_path); // get all file names
			foreach ($passport_open_files as $passport_open_file) { // iterate files
				if (is_file($passport_open_file)) {
					unlink($passport_open_file); // delete file
				}
			}

			$passport_selfie_file_path = BASE_PATH . "/jdb/data/upload/passport_selfie_" . $my_profile_id . ".*";
			$passport_selfie_files = glob($passport_selfie_file_path); // get all file names
			foreach ($passport_selfie_files as $passport_selfie_file) { // iterate files
				if (is_file($passport_selfie_file)) {
					unlink($passport_selfie_file); // delete file
				}
			}

			//passport open image
			$passport_open_orig_name = $_FILES['passport_open']['name'];
			if (is_uploaded_file($_FILES["passport_open"]["tmp_name"])) {
				$passport_open_file_name_arr = explode('.', $passport_open_orig_name);
				$passport_open_file_name_ext_pos = count($passport_open_file_name_arr) - 1;
				$passport_open_file_ext = strtolower($passport_open_file_name_arr[$passport_open_file_name_ext_pos]);
				$passport_open_file = BASE_PATH . "/jdb/data/upload/passport_open_" . $my_profile_id . '.' . $passport_open_file_ext;
				$passport_open_file_gomi = BASE_PATH . "/jdb/data/upload/passport_open_" . $my_profile_id . '.';

				if (move_uploaded_file($_FILES["passport_open"]["tmp_name"], $passport_open_file)) {
					chmod($passport_open_file, 0644);
					$total_files_cnt++;
					$myData['passport_open'] = "passport_open_" . $my_profile_id . '.' . $passport_open_file_ext;
				}
			}

			//selfie photo with passport
			$passport_selfie_orig_name = $_FILES['passport_selfie']['name'];
			if (is_uploaded_file($_FILES["passport_selfie"]["tmp_name"])) {
				$passport_selfie_file_name_arr = explode('.', $passport_selfie_orig_name);
				$passport_selfie_file_name_ext_pos = count($passport_selfie_file_name_arr) - 1;
				$passport_selfie_file_ext = strtolower($passport_selfie_file_name_arr[$passport_selfie_file_name_ext_pos]);
				$passport_selfie_file = BASE_PATH . "/jdb/data/upload/passport_selfie_" . $my_profile_id . '.' . $passport_selfie_file_ext;
				$passport_selfie_file_gomi = BASE_PATH . "/jdb/data/upload/passport_selfie_" . $my_profile_id . '.';

				if (move_uploaded_file($_FILES["passport_selfie"]["tmp_name"], $passport_selfie_file)) {
					chmod($passport_selfie_file, 0644);
					$total_files_cnt++;
					$myData['passport_selfie'] = "passport_selfie_" . $my_profile_id . '.' . $passport_selfie_file_ext;
				}
			}

			if ($total_files_cnt == 2) {
				$document_uploaded_ok = 1;
			}

			@unlink($passport_open_file_gomi);
			@unlink($passport_selfie_file_gomi);
		} else if ($document_type == '2') {
			$kyc_file_path = BASE_PATH . "/jdb/data/upload/id_card_" . $my_profile_id . "*.*";
			$kyc_files = glob($kyc_file_path); // get all file names
			foreach ($kyc_files as $kyc_file) { // iterate files
				if (is_file($kyc_file)) {
					unlink($kyc_file); // delete file
				}
			}

			$passport_open_file_path = BASE_PATH . "/jdb/data/upload/passport_open_" . $my_profile_id . ".*";
			$passport_open_files = glob($passport_open_file_path); // get all file names
			foreach ($passport_open_files as $passport_open_file) { // iterate files
				if (is_file($passport_open_file)) {
					unlink($passport_open_file); // delete file
				}
			}

			$passport_selfie_file_path = BASE_PATH . "/jdb/data/upload/passport_selfie_" . $my_profile_id . ".*";
			$passport_selfie_files = glob($passport_selfie_file_path); // get all file names
			foreach ($passport_selfie_files as $passport_selfie_file) { // iterate files
				if (is_file($passport_selfie_file)) {
					unlink($passport_selfie_file); // delete file
				}
			}

			//id card front image
			$id_card_front_orig_name = $_FILES['id_card_front']['name'];
			if (is_uploaded_file($_FILES["id_card_front"]["tmp_name"])) {
				$id_card_front_file_name_arr = explode('.', $id_card_front_orig_name);
				$id_card_front_file_name_ext_pos = count($id_card_front_file_name_arr) - 1;
				$id_card_front_file_ext = strtolower($id_card_front_file_name_arr[$id_card_front_file_name_ext_pos]);
				$id_card_front_file = BASE_PATH . "/jdb/data/upload/id_card_" . $my_profile_id . '_front.' . $id_card_front_file_ext;
				$id_card_front_file_gomi = BASE_PATH . "/jdb/data/upload/id_card_" . $my_profile_id . '_front.';

				if (move_uploaded_file($_FILES["id_card_front"]["tmp_name"], $id_card_front_file)) {
					chmod($id_card_front_file, 0644);
					$total_files_cnt++;
					$myData['id_card_front'] = "id_card_" . $my_profile_id . '_front.' . $id_card_front_file_ext;
				}
			}

			//id card back image
			$id_card_back_orig_name = $_FILES['id_card_back']['name'];
			if (is_uploaded_file($_FILES["id_card_back"]["tmp_name"])) {
				$id_card_back_file_name_arr = explode('.', $id_card_back_orig_name);
				$id_card_back_file_name_ext_pos = count($id_card_back_file_name_arr) - 1;
				$id_card_back_file_ext = strtolower($id_card_back_file_name_arr[$id_card_back_file_name_ext_pos]);
				$id_card_back_file = BASE_PATH . "/jdb/data/upload/id_card_" . $my_profile_id . '_back.' . $id_card_back_file_ext;
				$id_card_back_file_gomi = BASE_PATH . "/jdb/data/upload/id_card_" . $my_profile_id . '_back.';

				if (move_uploaded_file($_FILES["id_card_back"]["tmp_name"], $id_card_back_file)) {
					chmod($id_card_back_file, 0644);
					$total_files_cnt++;
					$myData['id_card_back'] = "id_card_" . $my_profile_id . '_back.' . $id_card_back_file_ext;
				}
			}

			//id card selfie image
			$id_card_selfie_orig_name = $_FILES['id_card_selfie']['name'];
			if (is_uploaded_file($_FILES["id_card_selfie"]["tmp_name"])) {
				$id_card_selfie_file_name_arr = explode('.', $id_card_selfie_orig_name);
				$id_card_selfie_file_name_ext_pos = count($id_card_selfie_file_name_arr) - 1;
				$id_card_selfie_file_ext = strtolower($id_card_selfie_file_name_arr[$id_card_selfie_file_name_ext_pos]);
				$id_card_selfie_file = BASE_PATH . "/jdb/data/upload/id_card_" . $my_profile_id . '_selfie.' . $id_card_selfie_file_ext;
				$id_card_selfie_file_gomi = BASE_PATH . "/jdb/data/upload/id_card_" . $my_profile_id . '_selfie.';

				if (move_uploaded_file($_FILES["id_card_selfie"]["tmp_name"], $id_card_selfie_file)) {
					chmod($id_card_selfie_file, 0644);
					$total_files_cnt++;
					$myData['id_card_selfie'] = "id_card_" . $my_profile_id . '_selfie.' . $id_card_selfie_file_ext;
				}
			}

			if ($total_files_cnt == 3) {
				$document_uploaded_ok = 1;
			}

			@unlink($id_card_front_file_gomi);
			@unlink($id_card_back_file_gomi);
			@unlink($id_card_selfie_file_gomi);
		} else {
			//todo
		}
		//////////////////////////////////////////////////////////

		$paper_width_px = 2480;
		$paper_height_px = 3508;
		if ($document_type == '1') {

			//// PASSPORT OPEN ///////////////////////////////////////////////////

			$passport_open_img_path = BASE_PATH . '/jdb/data/upload/' . $myData['passport_open'];
			$passport_open_exif = @exif_read_data($passport_open_img_path);

			$passport_open_file_name_arr2 = explode('.', $myData['passport_open']);
			$passport_open_file_name_ext_pos2 = count($passport_open_file_name_arr2) - 1;
			$passport_open_file_ext2 = strtolower($passport_open_file_name_arr2[$passport_open_file_name_ext_pos2]);

			if (($passport_open_file_ext2 == 'jpg') || ($passport_open_file_ext2 == 'jpeg')) {
				$passport_open_img_obj = @imagecreatefromjpeg($passport_open_img_path);
        if (!empty($passport_open_exif['Orientation'])) {
          switch ($passport_open_exif['Orientation']) {
            case 3:
              $passport_open_rotate_img = imagerotate($passport_open_img_obj, 180, 0);
              unlink($passport_open_img_path);
              imagejpeg($passport_open_rotate_img, $passport_open_img_path);
              @imagedestroy($passport_open_rotate_img);
              @imagedestroy($passport_open_img_obj);
              break;

            case 6:
              $passport_open_rotate_img = imagerotate($passport_open_img_obj, -90, 0);
              unlink($passport_open_img_path);
              imagejpeg($passport_open_rotate_img, $passport_open_img_path);
              @imagedestroy($passport_open_rotate_img);
              @imagedestroy($passport_open_img_obj);
              break;

            case 8:
              $passport_open_rotate_img = imagerotate($passport_open_img_obj, 90, 0);
              unlink($passport_open_img_path);
              imagejpeg($passport_open_rotate_img, $passport_open_img_path);
              @imagedestroy($passport_open_rotate_img);
              @imagedestroy($passport_open_img_obj);
              break;
          }
        }
			} else if ($passport_open_file_ext2 == 'png') {
				if ($passport_open_exif !== false) {
					///////////////////////////////////////////////////////////////////////
					$imagick_image = new Imagick($passport_open_img_path);
					$imagick_image->writeImage("png24:$passport_open_img_path");
					$passport_open_img_obj = @imagecreatefrompng($passport_open_img_path);
          if (!empty($passport_open_exif['Orientation'])) {
            _log("passport_open: orientation = " . $passport_open_exif['Orientation']);
            switch ($passport_open_exif['Orientation']) {
              case 3:
                $passport_open_rotate_img = imagerotate($passport_open_img_obj, 180, 0);
                unlink($passport_open_img_path);
                imagepng($passport_open_rotate_img, $passport_open_img_path);
                @imagedestroy($passport_open_rotate_img);
                @imagedestroy($passport_open_img_obj);
                break;

              case 6:
                $passport_open_rotate_img = imagerotate($passport_open_img_obj, -90, 0);
                unlink($passport_open_img_path);
                imagepng($passport_open_rotate_img, $passport_open_img_path);
                @imagedestroy($passport_open_rotate_img);
                @imagedestroy($passport_open_img_obj);
                break;

              case 8:
                $passport_open_rotate_img = imagerotate($passport_open_img_obj, 90, 0);
                unlink($passport_open_img_path);
                imagepng($passport_open_rotate_img, $passport_open_img_path);
                @imagedestroy($passport_open_rotate_img);
                @imagedestroy($passport_open_img_obj);
                break;
            }
          }
				}
			}

			list($passport_open_img_w, $passport_open_img_h, $passport_open_img_type, $passport_open_img_attr) = getimagesize($passport_open_img_path);

			$passport_open_img_scale = floatval($passport_open_img_w / $passport_open_img_h);
			$passport_open_img_mm_w = floatval($passport_open_img_w * 210 / $paper_width_px);
			$passport_open_img_mm_h = floatval($passport_open_img_h * 210 / $paper_width_px);

			if ($passport_open_img_mm_w > 190) {
				$passport_open_img_mm_w = 190;
				if ($passport_open_img_scale == 1) {
					$passport_open_img_mm_h = $passport_open_img_mm_w;
				} else {
					$passport_open_img_mm_h = floatval($passport_open_img_mm_w / $passport_open_img_scale);
				}
			} else {
				if ($passport_open_img_mm_w < 120) {
					$passport_open_img_mm_w = 190;
					if ($passport_open_img_scale == 1) {
						$passport_open_img_mm_h = $passport_open_img_mm_w;
					} else {
						$passport_open_img_mm_h = floatval($passport_open_img_mm_w / $passport_open_img_scale);
					}
				}
			}

			if ($passport_open_img_mm_h > 247) {
				$passport_open_img_mm_h = 247;
				$passport_open_img_mm_w = floatval(247 / 1.414);
			}
		} else if ($document_type == '2') {

			//// ID CARD FRONT ///////////////////////////////////////////////////
			$id_card_front_img_path = BASE_PATH . '/jdb/data/upload/' . $myData['id_card_front'];
			$id_card_front_exif = @exif_read_data($id_card_front_img_path);
			$id_card_front_file_name_arr2 = explode('.', $myData['id_card_front']);
			$id_card_front_file_name_ext_pos2 = count($id_card_front_file_name_arr2) - 1;
			$id_card_front_file_ext2 = strtolower($id_card_front_file_name_arr2[$id_card_front_file_name_ext_pos2]);

			if (($id_card_front_file_ext2 == 'jpg') || ($id_card_front_file_ext2 == 'jpeg')) {
				$id_card_front_img_obj = @imagecreatefromjpeg($id_card_front_img_path);
        if (!empty($id_card_front_exif['Orientation'])) {
          switch ($id_card_front_exif['Orientation']) {
            case 3:
              $id_card_front_rotate_img = imagerotate($id_card_front_img_obj, 180, 0);
              unlink($id_card_front_img_path);
              imagejpeg($id_card_front_rotate_img, $id_card_front_img_path);
              @imagedestroy($id_card_front_rotate_img);
              @imagedestroy($id_card_front_img_obj);
              break;

            case 6:
              $id_card_front_rotate_img = imagerotate($id_card_front_img_obj, -90, 0);
              unlink($id_card_front_img_path);
              imagejpeg($id_card_front_rotate_img, $id_card_front_img_path);
              @imagedestroy($id_card_front_rotate_img);
              @imagedestroy($id_card_front_img_obj);
              break;

            case 8:
              $id_card_front_rotate_img = imagerotate($id_card_front_img_obj, 90, 0);
              unlink($id_card_front_img_path);
              imagejpeg($id_card_front_rotate_img, $id_card_front_img_path);
              @imagedestroy($id_card_front_rotate_img);
              @imagedestroy($id_card_front_img_obj);
              break;
          }
        }
			} else if ($id_card_front_file_ext2 == 'png') {
				$imagick_image = new Imagick($id_card_front_img_path);
				$imagick_image->writeImage("png24:$id_card_front_img_path");
				$id_card_front_img_obj = @imagecreatefrompng($id_card_front_img_path);
        if (!empty($id_card_front_exif['Orientation'])) {
          switch ($id_card_front_exif['Orientation']) {
            case 3:
              $id_card_front_rotate_img = imagerotate($id_card_front_img_obj, 180, 0);
              unlink($id_card_front_img_path);
              imagepng($id_card_front_rotate_img, $id_card_front_img_path);
              @imagedestroy($id_card_front_rotate_img);
              @imagedestroy($id_card_front_img_obj);
              break;

            case 6:
              $id_card_front_rotate_img = imagerotate($id_card_front_img_obj, -90, 0);
              unlink($id_card_front_img_path);
              imagepng($id_card_front_rotate_img, $id_card_front_img_path);
              @imagedestroy($id_card_front_rotate_img);
              @imagedestroy($id_card_front_img_obj);
              break;

            case 8:
              $id_card_front_rotate_img = imagerotate($id_card_front_img_obj, 90, 0);
              unlink($id_card_front_img_path);
              imagepng($id_card_front_rotate_img, $id_card_front_img_path);
              @imagedestroy($id_card_front_rotate_img);
              @imagedestroy($id_card_front_img_obj);
              break;
          }
        }
			}

			list($id_card_front_img_w, $id_card_front_img_h, $id_card_front_img_type, $id_card_front_img_attr) = getimagesize($id_card_front_img_path);

			$id_card_front_img_scale = floatval($id_card_front_img_w / $id_card_front_img_h);
			$id_card_front_img_mm_w = floatval($id_card_front_img_w * 210 / $paper_width_px);
			$id_card_front_img_mm_h = floatval($id_card_front_img_h * 210 / $paper_width_px);
			if ($id_card_front_img_mm_w > 190) {
				$id_card_front_img_mm_w = 190;
				if ($id_card_front_img_scale == 1) {
					$id_card_front_img_mm_h = $id_card_front_img_mm_w;
				} else {
					$id_card_front_img_mm_h = floatval($id_card_front_img_mm_w / $id_card_front_img_scale);
				}
			} else {
				if ($id_card_front_img_mm_w < 120) {
					$id_card_front_img_mm_w = 190;
					if ($id_card_front_img_scale == 1) {
						$id_card_front_img_mm_h = $id_card_front_img_mm_w;
					} else {
						$id_card_front_img_mm_h = floatval($id_card_front_img_mm_w / $id_card_front_img_scale);
					}
				}
			}

			if ($id_card_front_img_mm_h > 247) {
				$id_card_front_img_mm_h = 247;
				$id_card_front_img_mm_w = floatval(247 / 1.414);
			}

			//// ID CARD BACK ///////////////////////////////////////////////////

			$id_card_back_img_path = BASE_PATH . '/jdb/data/upload/' . $myData['id_card_back'];
			$id_card_back_exif = @exif_read_data($id_card_back_img_path);
			$id_card_back_file_name_arr2 = explode('.', $myData['id_card_back']);
			$id_card_back_file_name_ext_pos2 = count($id_card_back_file_name_arr2) - 1;
			$id_card_back_file_ext2 = strtolower($id_card_back_file_name_arr2[$id_card_back_file_name_ext_pos2]);

			if (($id_card_back_file_ext2 == 'jpg') || ($id_card_back_file_ext2 == 'jpeg')) {
				$id_card_back_img_obj = @imagecreatefromjpeg($id_card_back_img_path);
        if (!empty($id_card_back_exif['Orientation'])) {
          switch ($id_card_back_exif['Orientation']) {
            case 3:
              $id_card_back_rotate_img = imagerotate($id_card_back_img_obj, 180, 0);
              unlink($id_card_back_img_path);
              imagejpeg($id_card_back_rotate_img, $id_card_back_img_path);
              @imagedestroy($id_card_back_rotate_img);
              @imagedestroy($id_card_back_img_obj);
              break;

            case 6:
              $id_card_back_rotate_img = imagerotate($id_card_back_img_obj, -90, 0);
              unlink($id_card_back_img_path);
              imagejpeg($id_card_back_rotate_img, $id_card_back_img_path);
              @imagedestroy($id_card_back_rotate_img);
              @imagedestroy($id_card_back_img_obj);
              break;

            case 8:
              $id_card_back_rotate_img = imagerotate($id_card_back_img_obj, 90, 0);
              unlink($id_card_back_img_path);
              imagejpeg($id_card_back_rotate_img, $id_card_back_img_path);
              @imagedestroy($id_card_back_rotate_img);
              @imagedestroy($id_card_back_img_obj);
              break;
          }
        }
			} else if ($id_card_back_file_ext2 == 'png') {
				$imagick_image2 = new Imagick($id_card_back_img_path);
				$imagick_image2->writeImage("png24:$id_card_back_img_path");
				$id_card_back_img_obj = @imagecreatefrompng($id_card_back_img_path);
        if (!empty($id_card_back_exif['Orientation'])) {
          switch ($id_card_back_exif['Orientation']) {
            case 3:
              $id_card_back_rotate_img = imagerotate($id_card_back_img_obj, 180, 0);
              unlink($id_card_back_img_path);
              imagepng($id_card_back_rotate_img, $id_card_back_img_path);
              @imagedestroy($id_card_back_rotate_img);
              @imagedestroy($id_card_back_img_obj);
              break;

            case 6:
              $id_card_back_rotate_img = imagerotate($id_card_back_img_obj, -90, 0);
              unlink($id_card_back_img_path);
              imagepng($id_card_back_rotate_img, $id_card_back_img_path);
              @imagedestroy($id_card_back_rotate_img);
              @imagedestroy($id_card_back_img_obj);
              break;

            case 8:
              $id_card_back_rotate_img = imagerotate($id_card_back_img_obj, 90, 0);
              unlink($id_card_back_img_path);
              imagepng($id_card_back_rotate_img, $id_card_back_img_path);
              @imagedestroy($id_card_back_rotate_img);
              @imagedestroy($id_card_back_img_obj);
              break;
          }
        }
			}

			list($id_card_back_img_w, $id_card_back_img_h, $id_card_back_img_type, $id_card_back_img_attr) = getimagesize($id_card_back_img_path);

			$id_card_back_img_scale = floatval($id_card_back_img_w / $id_card_back_img_h);
			$id_card_back_img_mm_w = floatval($id_card_back_img_w * 210 / $paper_width_px);
			$id_card_back_img_mm_h = floatval($id_card_back_img_h * 210 / $paper_width_px);

			if ($id_card_back_img_mm_w > 190) {
				$id_card_back_img_mm_w = 190;
				if ($id_card_back_img_scale == 1) {
					$id_card_back_img_mm_h = $id_card_back_img_mm_w;
				} else {
					$id_card_back_img_mm_h = floatval($id_card_back_img_mm_w / $id_card_back_img_scale);
				}
			} else {
				if ($id_card_back_img_mm_w < 120) {
					$id_card_back_img_mm_w = 190;
					if ($id_card_back_img_scale == 1) {
						$id_card_back_img_mm_h = $id_card_back_img_mm_w;
					} else {
						$id_card_back_img_mm_h = floatval($id_card_back_img_mm_w / $id_card_back_img_scale);
					}
				}
			}

			if ($id_card_back_img_mm_h > 247) {
				$id_card_back_img_mm_h = 247;
				$id_card_back_img_mm_w = floatval(247 / 1.414);
			}
		}

		//generate final pdf
		$template_arr = array();

		$template_arr[0] = BASE_PATH . '/jdb/data/download/application_form_1_' . $my_profile_id . '_page_1_temp.pdf';
		$template_arr[1] = BASE_PATH . '/jdb/data/download/application_form_1_' . $my_profile_id . '_page_2_temp.pdf';
		$template_arr[2] = BASE_PATH . '/jdb/data/download/application_form_2_' . $my_profile_id . '_page_1_temp.pdf';
		$template_arr[3] = BASE_PATH . '/jdb/data/download/application_form_2_' . $my_profile_id . '_page_2_temp.pdf';
		$template_arr[4] = BASE_PATH . '/jdb/data/download/application_form_2_' . $my_profile_id . '_page_3_temp.pdf';
		$template_arr[5] = BASE_PATH . '/jdb/data/download/application_form_2_' . $my_profile_id . '_page_4_temp.pdf';

		$myScale = 3.74;
		$pdf = new Fpdi('P', 'mm', array(210, 297));
		$pdf->SetAutoPageBreak(false);
		for ($page_cnt = 0; $page_cnt < count($template_arr); $page_cnt++) {
			$pageCount = $pdf->setSourceFile($template_arr[$page_cnt]);
			$curPage = $pdf->importPage(1);
			$pdf->AddPage();
			$pdf->useTemplate($curPage);

			if ($page_cnt == 0) {
				if ($document_type == '1') {
					/// PASSPORT OPEN ////////////////////////////////////////////
					list($width, $height) = getimagesize($passport_open_img_path);
					$ratio = $width / $height;

					// Calculate the maximum image size that fits the page width and height
					$page_width = 180; // page width
					$page_height = 80; // page height
					$max_width = $page_width - 25; // allow some margin
					$max_height = $page_height - 25; // allow some margin
					$max_ratio = $max_width / $max_height;
					if ($ratio > $max_ratio) {
						$image_width = $max_width;
						$image_height = $image_width / $ratio;
					} else {
						$image_height = $max_height;
						$image_width = $image_height * $ratio;
					}

					// Center the image vertically and horizontally
					$x = ($page_width) / 2;
					$y = 120;

					// Add the image to the PDF
					$pdf->Image($passport_open_img_path, $x, $y, $image_width, $image_height);
				} else if ($document_type == '2') {
					/// ID CARD FRONT ////////////////////////////////////////////
					// Calculate the image width and height ratio
					list($width, $height) = getimagesize($id_card_front_img_path);
					$ratio = $width / $height;

					// Calculate the maximum image size that fits the page width and height
					$page_width = 210; // page width
					$page_height = 72; // page height
					$max_width = ($page_width - 60) / 2; // allow some margin
					$max_height = $page_height; // allow some margin
					$max_ratio = $max_width / $max_height;
					if ($ratio > $max_ratio) {
						$image_width = $max_width;
						$image_height = $image_width / $ratio;
					} else {
						$image_height = $max_height;
						$image_width = $image_height * $ratio;
					}

					// Center the image vertically and horizontally
					$x = 210 / 2 - 5 - $image_width;
					$y = 120;

					// Add the image to the PDF
					$pdf->Image($id_card_front_img_path, $x, $y, $image_width, $image_height);

					/// ID CARD BACK ////////////////////////////////////////////

					// Calculate the image width and height ratio
					list($width, $height) = getimagesize($id_card_back_img_path);
					$ratio = $width / $height;

					// Calculate the maximum image size that fits the page width and height
					$page_width = 210; // page width
					$page_height = 72; // page height
          $max_width = ($page_width - 60) / 2; // allow some margin
          $max_height = $page_height; // allow some margin
					$max_ratio = $max_width / $max_height;
					if ($ratio > $max_ratio) {
						$image_width = $max_width;
						$image_height = $image_width / $ratio;
					} else {
						$image_height = $max_height;
						$image_width = $image_height * $ratio;
					}

					// Center the image vertically and horizontally
					$x = 210 / 2 + 5;
					$y = 120;

					// Add the image to the PDF
					$pdf->Image($id_card_back_img_path, $x, $y, $image_width, $image_height);
				}
			}
		}

		if ($document_type == '1') {
			//passport open image
			$pdf->AddPage();
			$passport_open_img_path = BASE_PATH . '/jdb/data/upload/' . $myData['passport_open'];
			$signature1 = BASE_PATH . "/jdb/data/upload/" . $my_profile_id . "_form_1.png";

			// Calculate the image width and height ratio
			list($width, $height) = getimagesize($passport_open_img_path);
			$ratio = $width / $height;

			// Calculate the maximum image size that fits the page width and height
			$page_width = 210; // page width
			$page_height = 297; // page height
			$max_width = $page_width - 100; // allow some margin
			$max_height = $page_height - 100; // allow some margin
			$max_ratio = $max_width / $max_height;
			if ($ratio > $max_ratio) {
				$image_width = $max_width;
				$image_height = $image_width / $ratio;
			} else {
				$image_height = $max_height;
				$image_width = $image_height * $ratio;
			}

			// Center the image vertically and horizontally
			$x = ($page_width - $image_width) / 2;
			$y = ($page_height - $image_height) / 2;

			// Add the image to the PDF
			$pdf->Image($passport_open_img_path, $x, $y, $image_width, $image_height);
			$fd = 260;
			$pdf->Image($signature1, 100, $fd, 50, 50 / 3.74);

			//passport_selfie image
			$pdf->AddPage();
			$passport_selfie_img_path = BASE_PATH . '/jdb/data/upload/' . $myData['passport_selfie'];
			$passport_selfie_exif = @exif_read_data($passport_selfie_img_path);
			$passport_selfie_file_name_arr2 = explode('.', $myData['passport_selfie']);
			$passport_selfie_file_name_ext_pos2 = count($passport_selfie_file_name_arr2) - 1;
			$passport_selfie_file_ext2 = strtolower($passport_selfie_file_name_arr2[$passport_selfie_file_name_ext_pos2]);

			if (($passport_selfie_file_ext2 == 'jpg') || ($passport_selfie_file_ext2 == 'jpeg')) {
				$passport_selfie_img_obj = @imagecreatefromjpeg($passport_selfie_img_path);
        if (!empty($passport_selfie_exif['Orientation'])) {
          switch ($passport_selfie_exif['Orientation']) {
            case 3:
              $passport_selfie_rotate_img = imagerotate($passport_selfie_img_obj, 180, 0);
              unlink($passport_selfie_img_path);
              imagejpeg($passport_selfie_rotate_img, $passport_selfie_img_path);
              @imagedestroy($passport_selfie_rotate_img);
              @imagedestroy($passport_selfie_img_obj);
              break;

            case 6:
              $passport_selfie_rotate_img = imagerotate($passport_selfie_img_obj, -90, 0);
              unlink($passport_selfie_img_path);
              imagejpeg($passport_selfie_rotate_img, $passport_selfie_img_path);
              @imagedestroy($passport_selfie_rotate_img);
              @imagedestroy($passport_selfie_img_obj);
              break;

            case 8:
              $passport_selfie_rotate_img = imagerotate($passport_selfie_img_obj, 90, 0);
              unlink($passport_selfie_img_path);
              imagejpeg($passport_selfie_rotate_img, $passport_selfie_img_path);
              @imagedestroy($passport_selfie_rotate_img);
              @imagedestroy($passport_selfie_img_obj);
              break;
          }
        }
			} else if ($passport_selfie_file_ext2 == 'png') {
				$imagick_image2 = new Imagick($passport_selfie_img_path);
				$imagick_image2->writeImage("png24:$passport_selfie_img_path");
				$passport_selfie_img_obj = @imagecreatefrompng($passport_selfie_img_path);
        if (!empty($passport_selfie_exif['Orientation'])) {
          switch ($passport_open_exif['Orientation']) {
            case 3:
              $passport_selfie_rotate_img = imagerotate($passport_selfie_img_obj, 180, 0);
              unlink($passport_selfie_img_path);
              imagepng($passport_selfie_rotate_img, $passport_selfie_img_path);
              @imagedestroy($passport_selfie_rotate_img);
              @imagedestroy($passport_selfie_img_obj);
              break;

            case 6:
              $passport_selfie_rotate_img = imagerotate($passport_selfie_img_obj, -90, 0);
              unlink($passport_selfie_img_path);
              imagepng($passport_selfie_rotate_img, $passport_selfie_img_path);
              @imagedestroy($passport_selfie_rotate_img);
              @imagedestroy($passport_selfie_img_obj);
              break;

            case 8:
              $passport_selfie_rotate_img = imagerotate($passport_selfie_img_obj, 90, 0);
              unlink($passport_selfie_img_path);
              imagepng($passport_selfie_rotate_img, $passport_selfie_img_path);
              @imagedestroy($passport_selfie_rotate_img);
              @imagedestroy($passport_selfie_img_obj);
              break;
          }
        }
			}

			list($passport_selfie_img_w, $passport_selfie_img_h, $passport_selfie_img_type, $passport_selfie_img_attr) = getimagesize($passport_selfie_img_path);

			$passport_selfie_img_scale = floatval($passport_selfie_img_w / $passport_selfie_img_h);
			$passport_selfie_img_mm_w = floatval($passport_selfie_img_w * 210 / $paper_width_px);
			$passport_selfie_img_mm_h = floatval($passport_selfie_img_h * 210 / $paper_width_px);

			if ($passport_selfie_img_mm_w > 190) {
				$passport_selfie_img_mm_w = 190;
				if ($passport_selfie_img_scale == 1) {
					$passport_selfie_img_mm_h = $passport_selfie_img_mm_w;
				} else {
					$passport_selfie_img_mm_h = floatval($passport_selfie_img_mm_w / $passport_selfie_img_scale);
				}
			} else {
				if ($passport_selfie_img_mm_w < 120) {
					$passport_selfie_img_mm_w = 190;
					if ($passport_selfie_img_scale == 1) {
						$passport_selfie_img_mm_h = $passport_selfie_img_mm_w;
					} else {
						$passport_selfie_img_mm_h = floatval($passport_selfie_img_mm_w / $passport_selfie_img_scale);
					}
				}
			}

			if ($passport_selfie_img_mm_h > 247) {
				$passport_selfie_img_mm_h = 247;
				$passport_selfie_img_mm_w = floatval(247 / 1.414);
			}

			$signature2 = BASE_PATH . "/jdb/data/upload/" . $my_profile_id . "_form_2.png";

			// Calculate the image width and height ratio
			list($width, $height) = getimagesize($passport_selfie_img_path);
			$ratio = $width / $height;

			// Calculate the maximum image size that fits the page width and height
			$page_width = 210; // page width
			$page_height = 297; // page height
			$max_width = $page_width - 100; // allow some margin
			$max_height = $page_height - 100; // allow some margin
			$max_ratio = $max_width / $max_height;
			if ($ratio > $max_ratio) {
				$image_width = $max_width;
				$image_height = $image_width / $ratio;
			} else {
				$image_height = $max_height;
				$image_width = $image_height * $ratio;
			}

			// Center the image vertically and horizontally
			$x = ($page_width - $image_width) / 2;
			$y = ($page_height - $image_height) / 2;

			// Add the image to the PDF
			$pdf->Image($passport_selfie_img_path, $x, $y, $image_width, $image_height);
			$fd = 260;
			$pdf->Image($signature2, 100, $fd, 50, 50 / 3.74);
		} else if ($document_type == '2') {

			//id_card_front image
			$pdf->AddPage();

			$id_card_front_img_path = BASE_PATH . '/jdb/data/upload/' . $myData['id_card_front'];
			$signature1 = BASE_PATH . "/jdb/data/upload/" . $my_profile_id . "_form_1.png";

			// Calculate the image width and height ratio
			list($width, $height) = getimagesize($id_card_front_img_path);
			$ratio = $width / $height;

			// Calculate the maximum image size that fits the page width and height
			$page_width = 210; // page width
			$page_height = 297; // page height
			$max_width = $page_width - 100; // allow some margin
			$max_height = $page_height - 100; // allow some margin
			$max_ratio = $max_width / $max_height;
			if ($ratio > $max_ratio) {
				$image_width = $max_width;
				$image_height = $image_width / $ratio;
			} else {
				$image_height = $max_height;
				$image_width = $image_height * $ratio;
			}

			// Center the image vertically and horizontally
			$x = ($page_width - $image_width) / 2;
			$y = ($page_height - $image_height) / 2;

			// Add the image to the PDF
			$pdf->Image($id_card_front_img_path, $x, $y, $image_width, $image_height);
			$fd = 260;
			$pdf->Image($signature1, 100, $fd, 50, 50 / 3.74);

			//id_card_back image
			$pdf->AddPage();
			$id_card_back_img_path = BASE_PATH . '/jdb/data/upload/' . $myData['id_card_back'];
			$signature2 = BASE_PATH . "/jdb/data/upload/" . $my_profile_id . "_form_2.png";

			// Calculate the image width and height ratio
			list($width, $height) = getimagesize($id_card_back_img_path);
			$ratio = $width / $height;

			// Calculate the maximum image size that fits the page width and height
			$page_width = 210; // page width
			$page_height = 297; // page height
			$max_width = $page_width - 100; // allow some margin
			$max_height = $page_height - 100; // allow some margin
			$max_ratio = $max_width / $max_height;
			if ($ratio > $max_ratio) {
				$image_width = $max_width;
				$image_height = $image_width / $ratio;
			} else {
				$image_height = $max_height;
				$image_width = $image_height * $ratio;
			}

			// Center the image vertically and horizontally
			$x = ($page_width - $image_width) / 2;
			$y = ($page_height - $image_height) / 2;

			// Add the image to the PDF
			$pdf->Image($id_card_back_img_path, $x, $y, $image_width, $image_height);
			$fd = 260;
			$pdf->Image($signature2, 100, $fd, 50, 50 / 3.74);

			//id_card_selfie image
			$pdf->AddPage();
			$id_card_selfie_img_path = BASE_PATH . '/jdb/data/upload/' . $myData['id_card_selfie'];
			$id_card_selfie_exif = @exif_read_data($id_card_selfie_img_path);
			$id_card_selfie_file_name_arr2 = explode('.', $myData['id_card_selfie']);
			$id_card_selfie_file_name_ext_pos2 = count($id_card_selfie_file_name_arr2) - 1;
			$id_card_selfie_file_ext2 = strtolower($id_card_selfie_file_name_arr2[$id_card_selfie_file_name_ext_pos2]);

			if (($id_card_selfie_file_ext2 == 'jpg') || ($id_card_selfie_file_ext2 == 'jpeg')) {
				$id_card_selfie_img_obj = @imagecreatefromjpeg($id_card_selfie_img_path);
        if (!empty($id_card_selfie_exif['Orientation'])) {
          switch ($id_card_selfie_exif['Orientation']) {
            case 3:
              $id_card_selfie_rotate_img = imagerotate($id_card_selfie_img_obj, 180, 0);
              unlink($id_card_selfie_img_path);
              imagejpeg($id_card_selfie_rotate_img, $id_card_selfie_img_path);
              @imagedestroy($id_card_selfie_rotate_img);
              @imagedestroy($id_card_selfie_img_obj);
              break;

            case 6:
              $id_card_selfie_rotate_img = imagerotate($id_card_selfie_img_obj, -90, 0);
              unlink($id_card_selfie_img_path);
              imagejpeg($id_card_selfie_rotate_img, $id_card_selfie_img_path);
              @imagedestroy($id_card_selfie_rotate_img);
              @imagedestroy($id_card_selfie_img_obj);
              break;

            case 8:
              $id_card_selfie_rotate_img = imagerotate($id_card_selfie_img_obj, 90, 0);
              unlink($id_card_selfie_img_path);
              imagejpeg($id_card_selfie_rotate_img, $id_card_selfie_img_path);
              @imagedestroy($id_card_selfie_rotate_img);
              @imagedestroy($id_card_selfie_img_obj);
              break;
          }
        }
			} else if ($id_card_selfie_file_ext2 == 'png') {
				$imagick_image3 = new Imagick($id_card_selfie_img_path);
				$imagick_image3->writeImage("png24:$id_card_selfie_img_path");
				$id_card_selfie_img_obj = @imagecreatefrompng($id_card_selfie_img_path);
        if (!empty($id_card_selfie_exif['Orientation'])) {
          switch ($id_card_selfie_exif['Orientation']) {
            case 3:
              $id_card_selfie_rotate_img = imagerotate($id_card_selfie_img_obj, 180, 0);
              unlink($id_card_selfie_img_path);
              imagepng($id_card_selfie_rotate_img, $id_card_selfie_img_path);
              @imagedestroy($id_card_selfie_rotate_img);
              @imagedestroy($id_card_selfie_img_obj);
              break;

            case 6:
              $id_card_selfie_rotate_img = imagerotate($id_card_selfie_img_obj, -90, 0);
              unlink($id_card_selfie_img_path);
              imagepng($id_card_selfie_rotate_img, $id_card_selfie_img_path);
              @imagedestroy($id_card_selfie_rotate_img);
              @imagedestroy($id_card_selfie_img_obj);
              break;

            case 8:
              $id_card_selfie_rotate_img = imagerotate($id_card_selfie_img_obj, 90, 0);
              unlink($id_card_selfie_img_path);
              imagepng($id_card_selfie_rotate_img, $id_card_selfie_img_path);
              @imagedestroy($id_card_selfie_rotate_img);
              @imagedestroy($id_card_selfie_img_obj);
              break;
          }
        }
			}

			list($id_card_selfie_img_w, $id_card_selfie_img_h, $id_card_selfie_img_type, $id_card_selfie_img_attr) = getimagesize($id_card_selfie_img_path);

			$id_card_selfie_img_scale = floatval($id_card_selfie_img_w / $id_card_selfie_img_h);
			$id_card_selfie_img_mm_w = floatval($id_card_selfie_img_w * 210 / $paper_width_px);
			$id_card_selfie_img_mm_h = floatval($id_card_selfie_img_h * 210 / $paper_width_px);

			if ($id_card_selfie_img_mm_w > 190) {
				$id_card_selfie_img_mm_w = 190;
				if ($id_card_selfie_img_scale == 1) {
					$id_card_selfie_img_mm_h = $id_card_selfie_img_mm_w;
				} else {
					$id_card_selfie_img_mm_h = floatval($id_card_selfie_img_mm_w / $id_card_selfie_img_scale);
				}
			} else {
				if ($id_card_selfie_img_mm_w < 120) {
					$id_card_selfie_img_mm_w = 190;
					if ($id_card_selfie_img_scale == 1) {
						$id_card_selfie_img_mm_h = $id_card_selfie_img_mm_w;
					} else {
						$id_card_selfie_img_mm_h = floatval($id_card_selfie_img_mm_w / $id_card_selfie_img_scale);
					}
				}
			}

			if ($id_card_selfie_img_mm_h > 247) {
				$id_card_selfie_img_mm_h = 247;
				$id_card_selfie_img_mm_w = floatval(247 / 1.414);
			}

			$signature3 = BASE_PATH . "/jdb/data/upload/" . $my_profile_id . "_form_1.png";

			// Calculate the image width and height ratio
			list($width, $height) = getimagesize($id_card_selfie_img_path);
			$ratio = $width / $height;

			// Calculate the maximum image size that fits the page width and height
			$page_width = 210; // page width
			$page_height = 297; // page height
			$max_width = $page_width - 100; // allow some margin
			$max_height = $page_height - 100; // allow some margin
			$max_ratio = $max_width / $max_height;
			if ($ratio > $max_ratio) {
				$image_width = $max_width;
				$image_height = $image_width / $ratio;
			} else {
				$image_height = $max_height;
				$image_width = $image_height * $ratio;
			}

			// Center the image vertically and horizontally
			$x = ($page_width - $image_width) / 2;
			$y = ($page_height - $image_height) / 2;

			// Add the image to the PDF
			$pdf->Image($id_card_selfie_img_path, $x, $y, $image_width, $image_height);
			$fd = 260;
			$pdf->Image($signature3, 100, $fd, 50, 50 / 3.74);
		}

		$application_form_final_filepath = BASE_PATH . '/jdb/data/upload/application_final_signed_' . $my_profile_id . '.pdf';
		$application_form_final_url = SITE_PATH . '/jdb/data/upload/application_final_signed_' . $my_profile_id . '.pdf';
		$pdf->Output($application_form_final_filepath, 'F');

		sleep(2);
		$kyc_pdf_file_created = 0;
		if (file_exists($application_form_final_filepath)) {
			clearstatcache();
			$kyc_file_size = filesize($application_form_final_filepath);
			if ($kyc_file_size > 0) {
				$kyc_pdf_file_created = 1;
			}
		}
		$data['application_form_final_url'] = $application_form_final_url;

		//try update date in profile table
		$ngaycapnhat = date('Y-m-d H:i:s');
	}
} else {
	$total_files_cnt = 0;
	if (is_uploaded_file($_FILES["application_signed_pdf001"]["tmp_name"])) {
		$destination_file001 = BASE_PATH . "/jdb/data/upload/application_form_1_signed_" . $_SESSION['ultimopay_profile_id'] . '.pdf';
		$destination_file001_chuyendoi = BASE_PATH . "/jdb/data/upload/application_form_1_signed_" . $_SESSION['ultimopay_profile_id'] . 'chuyendoi.pdf';
		if (move_uploaded_file($_FILES["application_signed_pdf001"]["tmp_name"], $destination_file001)) {
			chmod($destination_file001, 0644);
			$cmd001 = '/usr/bin/ghostscript -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dNOPAUSE -dQUIET -dBATCH -sOutputFile="' . $destination_file001_chuyendoi . '" "' . $destination_file001 . '"';
			exec($cmd001, $output_array001, $cmd_status001);
			$total_files_cnt++;
		}
	}

	if (is_uploaded_file($_FILES["application_signed_pdf002"]["tmp_name"])) {
		$destination_file002 = BASE_PATH . "/jdb/data/upload/application_form_2_p1_signed_" . $_SESSION['ultimopay_profile_id'] . '.pdf';
		$destination_file002_chuyendoi = BASE_PATH . "/jdb/data/upload/application_form_2_p1_signed_" . $_SESSION['ultimopay_profile_id'] . 'chuyendoi.pdf';
		if (move_uploaded_file($_FILES["application_signed_pdf002"]["tmp_name"], $destination_file002)) {
			chmod($destination_file002, 0644);
			$cmd002 = '/usr/bin/ghostscript -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dNOPAUSE -dQUIET -dBATCH -sOutputFile="' . $destination_file002_chuyendoi . '" "' . $destination_file002 . '"';
			exec($cmd002, $output_array002, $cmd_status002);
			$total_files_cnt++;
		}
	}

	if (is_uploaded_file($_FILES["application_signed_pdf003"]["tmp_name"])) {
		$destination_file003 = BASE_PATH . "/jdb/data/upload/application_form_2_p2_signed_" . $_SESSION['ultimopay_profile_id'] . '.pdf';
		$destination_file003_chuyendoi = BASE_PATH . "/jdb/data/upload/application_form_2_p2_signed_" . $_SESSION['ultimopay_profile_id'] . 'chuyendoi.pdf';
		if (move_uploaded_file($_FILES["application_signed_pdf003"]["tmp_name"], $destination_file003)) {
			chmod($destination_file003, 0644);
			$cmd003 = '/usr/bin/ghostscript -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dNOPAUSE -dQUIET -dBATCH -sOutputFile="' . $destination_file003_chuyendoi . '" "' . $destination_file003 . '"';
			exec($cmd003, $output_array003, $cmd_status003);
			$total_files_cnt++;
		}
	}

	if (is_uploaded_file($_FILES["application_signed_pdf004"]["tmp_name"])) {
		$destination_file004 = BASE_PATH . "/jdb/data/upload/application_form_2_p3_signed_" . $_SESSION['ultimopay_profile_id'] . '.pdf';
		$destination_file004_chuyendoi = BASE_PATH . "/jdb/data/upload/application_form_2_p3_signed_" . $_SESSION['ultimopay_profile_id'] . 'chuyendoi.pdf';
		if (move_uploaded_file($_FILES["application_signed_pdf004"]["tmp_name"], $destination_file004)) {
			chmod($destination_file004, 0644);
			$cmd004 = '/usr/bin/ghostscript -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dNOPAUSE -dQUIET -dBATCH -sOutputFile="' . $destination_file004_chuyendoi . '" "' . $destination_file004 . '"';
			exec($cmd004, $output_array004, $cmd_status004);
		}
	}

	if (is_uploaded_file($_FILES["application_signed_pdf005"]["tmp_name"])) {
		$destination_file005 = BASE_PATH . "/jdb/data/upload/application_form_2_p4_signed_" . $_SESSION['ultimopay_profile_id'] . '.pdf';
		$destination_file005_chuyendoi = BASE_PATH . "/jdb/data/upload/application_form_2_p4_signed_" . $_SESSION['ultimopay_profile_id'] . 'chuyendoi.pdf';
		if (move_uploaded_file($_FILES["application_signed_pdf005"]["tmp_name"], $destination_file005)) {
			chmod($destination_file005, 0644);
			$cmd005 = '/usr/bin/ghostscript -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dNOPAUSE -dQUIET -dBATCH -sOutputFile="' . $destination_file005_chuyendoi . '" "' . $destination_file005 . '"';
			exec($cmd005, $output_array005, $cmd_status005);
			$total_files_cnt++;
		}
	}
}

echo json_encode($data);
die();
