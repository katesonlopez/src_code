<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchase_check_tool_setting_partner extends Model
{

  protected $table = 'purchase_check_tool_setting_partner';
  protected $primaryKey = 'id';

  protected $fillable = [
    'partner_name',
    'other',
    'fee_percent'
  ];

  protected $casts = [
    'fee_percent' => 'float'
  ];

  public $timestamps = true;
}
