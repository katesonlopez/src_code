import { useState, useEffect } from "react";
import { useRouter } from 'next/router';
import { userService, alertService } from '/services';
import withAuth from '/hooks/withAuth';
import UserLayout from '/pages/user/layout/UserLayout'
import Loading from "../../../components/Loading";

const page = () => {
  const router = useRouter();
  const [user, setUserData] = useState(null)
  const [userdata, setUserrData] = useState(null)
  const [status, setstatus] = useState(1);
  const [kycData, setKycData] = useState([]);
  const [dashboardCopied, setDashboardCopied] = useState(false);
  const [dashboardLink , setDashboardLink] = useState(false);
  const [homeCopied, setHomeCopied] = useState(false);
  const [homeLink , setHomeLink] = useState(false);
  const [serviceCopied, setServiceCopied] = useState(false);
  const [serviceLink , setServiceLink] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const handleCopyDashboard = () => {
    navigator.clipboard.writeText(dashboardLink);
    setDashboardCopied(true);
    setTimeout(() => {
      setDashboardCopied(false);
    }, 3000);
  };

  const handleCopyHome = () => {
    navigator.clipboard.writeText(homeLink);
    setHomeCopied(true);
    setTimeout(() => {
      setHomeCopied(false);
    }, 3000);
  };

  const handleCopyService = () => {
    navigator.clipboard.writeText(serviceLink);
    setServiceCopied(true);
    setTimeout(() => {
      setServiceCopied(false);
    }, 3000);
  };

  useEffect(() => {
    async function fetchData() {
      const userJson = localStorage.getItem('user');
      if( userJson ){
        const userser = JSON.parse(userJson)
        const user = userser.res.data.signinResponse
        setUserData(user);
        await getUserInfo(user , true)
        getUserStatus(user)
        //await generatePDF()
      }
    }
    fetchData();
  }, [router])
  const getUserStatus = (userrr ) => {
    delete userrr.expires_in;
    delete userrr.wallet;
    userService.getUserStatus(userrr , 'both').then((d) => {
      setKycData(d.data);
      setstatus(d.status);
    }).catch((d) => {
    })
  }

  const getUserInfo = (userrr , is_open_popup=false) => {
    delete userrr.expires_in;
    delete userrr.wallet;
    setUserrData(false)
    userService.runApi(`userInfo/` , userrr).then((d) => {
      const resd = d.data.userInfoResponse;
      const { protocol, host } = window.location;
      const baseUrl = `${protocol}//${host}`;
      setUserrData(resd);
      setHomeLink(`${baseUrl}/?rid=${resd.pap_affiliate_refid}`)
      setDashboardLink(`${baseUrl}/register?rid=${resd.pap_affiliate_refid}`)
      setServiceLink(`https://www.bitquick.io?rid=${resd.pap_affiliate_refid}`)
    }).catch((d) => {
    })
  }

  return (
    <UserLayout>
      {user && userdata && kycData ? (
        <main className="p-3">
          <div className={`container-fluid ${isMobile ? "px-0" : "px-4"} pb-4`}>
            <div className='mt-4'>
              <div className="card">
                <div className="card-header pt-3">
                  <h5 className="card-title text-white font-800">My Affiliate Links </h5>
                </div>
                <div className={`card-body ${isMobile ? "p-3" : "p-5"}`}>
                  <p className="mb-4">
                    This is your affiliate link. you can copy and paste them to your website, blog or SNS (Facebook,
                    Twitter, Instagram, LinkedIn, etc.) to promote BitQuick service and
                    get rewards.
                  </p>
                  <div className="form-group">
                    <label htmlFor="dashboard-link">SignUp Link:</label>
                    <div className="input-group">
                      <input
                        type="text"
                        id="dashboard-link"
                        className="form-control"
                        value={dashboardLink}
                        readOnly
                      />
                      <div className="input-group-append">
                        <button
                          className={`button ghost size-xl button-half-round ${isMobile ? "ps-3 pe-3 min-width-0" : ""}`}
                          type="button"
                          onClick={handleCopyDashboard}
                        >
                          {dashboardCopied ? "Copied!" : "Copy"}
                        </button>
                      </div>
                    </div>
                    <small>
                      (this affiliate link will show BitQuick Sign
                      up page)
                    </small>
                  </div>
                  <div className="form-group mt-4">
                    <label htmlFor="dashboard-link">SignIn Link:</label>
                    <div className="input-group">
                      <input
                        type="text"
                        id="home-link"
                        className="form-control"
                        value={homeLink}
                        readOnly
                      />
                      <div className="input-group-append">
                        <button
                          className={`button ghost size-xl button-half-round ${isMobile ? "ps-3 pe-3 min-width-0" : ""}`}
                          type="button"
                          onClick={handleCopyHome}
                        >
                          {homeCopied ? "Copied!" : "Copy"}
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className="form-group mt-4">
                    <label htmlFor="dashboard-link">Service Home Page Link:</label>
                    <div className="input-group">
                      <input
                        type="text"
                        id="home-link"
                        className="form-control"
                        value={serviceLink}
                        readOnly
                      />
                      <div className="input-group-append">
                        <button
                          className={`button ghost size-xl button-half-round ${isMobile ? "ps-3 pe-3 min-width-0" : ""}`}
                          type="button"
                          onClick={handleCopyService}
                        >
                          {serviceCopied ? "Copied!" : "Copy"}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      ): (
        <Loading />
      )}
    </UserLayout>
  )
}

export default withAuth(page)