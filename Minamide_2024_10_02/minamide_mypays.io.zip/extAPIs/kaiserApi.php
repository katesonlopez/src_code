<?php
if( !defined('KAISER_API_KEY'))
  require_once '../includes/config.php';

/**
 * Basic API calling module
 **/
function callApiPost($action, $body = null)
{
  // Encoding the request data as JSON which will be sent in POST
  $encodedData = json_encode($body);

  // Initiate curl with the url to send request
  $curl = curl_init(KAISER_API_URL.$action);

  // Return CURL response
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

  // Set the request method
  curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

  // Data content-type is sent as JSON
  curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    'Content-Type:application/json',
    'Authorization:'.KAISER_API_KEY
  ));
  curl_setopt($curl, CURLOPT_POST, true);

  // Curl POST the JSON data to send the request
  curl_setopt($curl, CURLOPT_POSTFIELDS, $encodedData);

  // Execute the curl request
  $response = curl_exec($curl);
  $error = curl_error($curl);

  curl_close($curl);

  if ($error) {
    return json_encode(['result' => 'failed', 'error' => ['errorMessage' => $error]]);
  }

  // Return response
  return $response;
}

function callApiGet($action, $params = [])
{
  // Build the query string from the parameters array
  $queryString = http_build_query($params);

  // Construct the full URL with the query string
  $url = KAISER_API_URL . $action . '?' . $queryString;

  // Initiate curl with the full URL
  $curl = curl_init($url);

  // Return CURL response
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

  // Set the request method to GET
  curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    'Authorization:' . KAISER_API_KEY
  ));

  // Execute the curl request
  $response = curl_exec($curl);
  $error = curl_error($curl);

  curl_close($curl);

  if ($error) {
    return json_encode(['result' => 'failed', 'error' => ['errorMessage' => $error]]);
  }

  // Return response
  return $response;
}

/**
 * Start to call api
 **/
// Process AJAX request
$requestBody = json_decode(file_get_contents('php://input'), true);

if (isset($requestBody['action'])) {

  $response = '[]';

  // Check action.
  if ($requestBody['action'] == 'prepayment') {
    $response = callApiPost($requestBody['action'], $requestBody);
  }

  if ($requestBody['action'] == 'getReport') {
    $response = callApiGet($requestBody['action'], $requestBody);
  }

  echo $response;
}
