import Link from 'next/link'
import {useEffect, useState} from "react";
import {useRouter} from 'next/router';
import {userService} from '/services';
import withAuth from '/hooks/withAuth';
import UserLayout from './layout/UserLayout';
import DataTable from '/components/DataTable';


const Dashboard = () => {

  const router = useRouter();
  const [user, setUserData] = useState(null)
  const [wallet, setWalletData] = useState(null)
  const [reportData, setReportData] = useState([])
  const [activeReport, setactive] = useState(1)
  const [col, setCol] = useState([])
  const [isLoading, setisLoading] = useState(true)
  const [cardBalance, setCardBalance] = useState(0)
  const [pendingTotal, setPendingTotal] = useState(0)
  const reportcol = [
    {
      Header: 'Date/Time(UTC)',
      accessor: 'created_date',
    },
    {
      Header: 'Type',
      accessor: 'type',
    },
    {
      Header: 'Coin',
      accessor: 'currency',
    },
    {
      Header: 'Address',
      accessor: 'address',
    },
    {
      Header: 'Amount',
      accessor: 'amount',
    },
    {
      Header: 'Status',
      accessor: 'status',
    },
  ];
  const loadcol = [
    {
      Header: 'Date/Time(UTC)',
      accessor: 'datetime',
    },
    {
      Header: 'Amount',
      accessor: 'amount',
    },
    {
      Header: 'Status',
      accessor: 'status',
    },
  ];
  const activitycol = [
    {
      Header: 'Date/Time(UTC)',
      accessor: 'datetime',
    },

    {
      Header: 'Description',
      accessor: 'description',
    },
    {
      Header: 'Out(USD)',
      accessor: 'money_out',
    },
    {
      Header: 'In(USD)',
      accessor: 'money_in',
    },
    {
      Header: 'Balance(USD)',
      accessor: 'post_balance',
    },
  ];

  const [/*showModal*/, setShowModal] = useState(true);

  const getCardBalance = (userr) => {
    delete userr.wallet;
    delete userr.expires_in;
    userService.runApi('cardBalance/', userr).then((d) => {
      const resd = d.data.cardBalanceResponse;
      setCardBalance(resd.balance);
    }).catch(() => {
      setCardBalance(0.0);
      return null;
    })
    setCardBalance(0.0);
  }

  function getReport(type, userr) {
    setisLoading(true);
    let newCol = reportcol;
    if (type === 4) {
      return getLoad(type, userr);
    }
    if (type !== 2) {
      newCol = newCol.filter(col => col.accessor !== 'address');
    }
    if (type === 3) {
      newCol = newCol.map(col => col.accessor === 'type' ? {Header: 'Type', accessor: 'side'} : col);
      newCol = newCol.map(col => {
        if (col.accessor === 'amount') {
          return {
            ...col,
            Cell: ({value, row}) => {
              const {amount, currency, side} = row.original;
              const tx_amount = Number(row.original.tx_amount);
              const numericAmount = Number(amount); // Convert amount to a number
              if (!isNaN(numericAmount)) {
                if (side === 'Buy') {
                  return (
                    <>
                      Buy {numericAmount} {currency}
                      <br/>
                      Paid amount {tx_amount.toFixed(2)} USD
                    </>
                  );
                } else if (side === 'Sell') {
                  return (
                    <>
                      Sell {numericAmount} {currency}
                      <br/>
                      Received amount {tx_amount.toFixed(2)} USD
                    </>
                  );
                } else {
                  return numericAmount.toFixed(2); // Fallback for other cases
                }
              } else {
                return value; // Fallback if amount is not a number
              }
            },
          };
        }
        return col;
      });
    }

    if (type === 5) {
      return getCardTransaction(type, userr);
    }

    userr.type = type;
    userr.currency = 'USDT,BTC,USDC,BUSD';

    userService.runApi("getReport/", userr)
      .then((res) => {
        if (res.data && Array.isArray(res.data.reportResponse)) {
          // remove updated_date and instrument_id fields in response
          const modifiedReportData = res.data.reportResponse.map(item => {
            const {updated_date, instrument_id, ...newItem} = item;
            return newItem;
          });
          setCol(newCol);
          setReportData(modifiedReportData);
          setactive(type);
          setisLoading(false);
        }
      });
  }

  function getLoad(type, userr, is_first = 0) {
    userService.runApi("cardLoadHistory/", userr)
      .then((res) => {
        if (is_first === 0) {
          setReportData(res.data.cardLoadHistoryResponse);
          setactive(type);
          setCol(loadcol);
          setisLoading(false);
        }

        const transactions = res.data.cardLoadHistoryResponse;
        const pendingAmounts = transactions ? transactions.filter(transaction => transaction.status === "PENDING") : null;
        const pT = pendingAmounts ? pendingAmounts.reduce((total, transaction) => total + parseFloat(transaction.amount), 0).toFixed(2) : null;
        setPendingTotal(pT);
      })
  }

  function getCardTransaction(type, userr) {
    userService.runApi("cardTransaction/", userr)
      .then((res) => {
        setReportData(res.data.cardTransactionResponse.transaction_history);
        setactive(type);
        setCol(activitycol);
        setisLoading(false);
      });
  }

  useEffect(() => {
    setShowModal(true);
  }, []);

  useEffect(() => {
    async function fetchData() {
      const y = localStorage.getItem('user');
      const loggegedtime1 = localStorage.getItem('loginTime');
      const loggegedtime = new Date(loggegedtime1);
      const currentTime1 = Date().toLocaleString();
      const currentTime = new Date(currentTime1);
      const timeDifferenceInMillis = currentTime - loggegedtime;
      const userser = JSON.parse(y);
      const user = userser.res.data.signinResponse;
      const expiresInMillis = localStorage.getItem('expires_second');
      const timeDifference = timeDifferenceInMillis / 1000;

      if (timeDifference > expiresInMillis) {
        const Signout = () => {
          userService.runApi('signout/', user).then(() => {
            localStorage.removeItem('user');
            router.push('/');
          });
        }
        Signout();
      } else {
        console.log("Token is valid.");
      }

      setUserData(user);
      walletBalance(user);
      getCardBalance(user);
      getLoad(1, user, 1);
      getReport(activeReport, user);
      setCol(reportcol);
    }

    fetchData();
  }, [router]);

  const numberWithCommas = (x) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  const walletBalance = (user) => {
    userService.walletBalance(user).then((d) => {
      const resd = d.data.wallet;
      const order = userService.getCurrencyOrder();

      // Sort the array using the order
      resd.sort((a, b) => order.indexOf(a.currency) - order.indexOf(b.currency));
      resd.forEach(item => item.balance = parseFloat(item.balance.replace(",", "")));
      setWalletData(resd);
    }).catch(() => {
      localStorage.removeItem('user');
      router.push('/');
      return null;
    })
  }

  return (
    <UserLayout>
      {user && wallet ? (
        <main>
          <div className="container-fluid px-4 pt-5">
            <div className="row pe-4 ps-4 justify-content-start">
              <div className="col-xl-3 col-md-6 col-frm p-2">
                <div className="main-frm">
                  <div className="row p-3 align-items-center">
                    <div className="col-sm-6 col-6">
                      <p className="ttl-p text-start mb-0">US DOLLAR</p>
                      <p className="p-0 m-0 amount-p">
                        <b>{wallet ? numberWithCommas((Math.floor(wallet[2].balance * 100) / 100).toFixed(2)) : (
                          <i>loading..</i>)}</b>
                        <br/>
                        <font>USD</font>
                      </p>
                    </div>
                    <div className="col-sm-6 text-end col-6">
                      <div className="icon_d">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width={20}
                          height={20}
                          fill="currentColor"
                          className="bi bi-currency-dollar"
                          viewBox="0 0 16 16"
                        >
                          <path
                            d="M4 10.781c.148 1.667 1.513 2.85 3.591 3.003V15h1.043v-1.216c2.27-.179 3.678-1.438 3.678-3.3 0-1.59-.947-2.51-2.956-3.028l-.722-.187V3.467c1.122.11 1.879.714 2.07 1.616h1.47c-.166-1.6-1.54-2.748-3.54-2.875V1H7.591v1.233c-1.939.23-3.27 1.472-3.27 3.156 0 1.454.966 2.483 2.661 2.917l.61.162v4.031c-1.149-.17-1.94-.8-2.131-1.718H4zm3.391-3.836c-1.043-.263-1.6-.825-1.6-1.616 0-.944.704-1.641 1.8-1.828v3.495l-.2-.05zm1.591 1.872c1.287.323 1.852.859 1.852 1.769 0 1.097-.826 1.828-2.2 1.939V8.73l.348.086z"/>
                        </svg>
                      </div>
                    </div>
                    {pendingTotal > 0 ?
                      <div className="col-md-12">
                        <br/>
                        <p>Pending Load</p>
                        <b style={{color: "blue"}}>{pendingTotal}</b>
                        <br/>
                        <font>USD</font>
                      </div>
                      : ''}
                  </div>
                  <div className="row p-3 pt-0 amount-box">
                  </div>
                </div>
              </div>
              <div className="col-xl-3 col-md-6 col-frm p-2">
                <div className="main-frm">
                  <div className="row p-3 align-items-center">
                    <div className="col-sm-6 col-6">
                      <p className="ttl-p text-start mb-0">CARD</p>
                      <p className="p-0 m-0 amount-p">
                        <b>{cardBalance}</b>
                        <br/>
                        <font>USD</font>
                      </p>
                    </div>
                    <div className="col-sm-6 text-end col-6">
                      <div className="icon_d">
                        <i className='bi bi-credit-card'></i>
                      </div>
                    </div>
                  </div>
                  <div className="row p-3 pt-0 amount-box">
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href="/user/card/load">
                        Load
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="row pe-4 ps-4 mt-3">
              <div className="col-xl-3 col-md-6 col-frm p-2 ">
                <div className="main-frm">
                  <div className="row p-3 align-items-center">
                    <div className="col-sm-6 col-6">
                      <p className="ttl-p text-start mb-0">BITCOIN</p>
                      <p className="p-0 m-0 amount-p">
                        <b>{wallet ? Number(wallet[1].balance).toFixed(8) : (<i>loading..</i>)}</b>
                        <br/>
                        <font>BTC</font>
                      </p>
                    </div>
                    <div className="col-sm-6 text-end col-6">
                      <div className="icon_d">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width={20}
                          height={20}
                          fill="currentColor"
                          className="bi bi-currency-bitcoin"
                          viewBox="0 0 16 16"
                        >
                          <path
                            d="M5.5 13v1.25c0 .138.112.25.25.25h1a.25.25 0 0 0 .25-.25V13h.5v1.25c0 .138.112.25.25.25h1a.25.25 0 0 0 .25-.25V13h.084c1.992 0 3.416-1.033 3.416-2.82 0-1.502-1.007-2.323-2.186-2.44v-.088c.97-.242 1.683-.974 1.683-2.19C11.997 3.93 10.847 3 9.092 3H9V1.75a.25.25 0 0 0-.25-.25h-1a.25.25 0 0 0-.25.25V3h-.573V1.75a.25.25 0 0 0-.25-.25H5.75a.25.25 0 0 0-.25.25V3l-1.998.011a.25.25 0 0 0-.25.25v.989c0 .137.11.25.248.25l.755-.005a.75.75 0 0 1 .745.75v5.505a.75.75 0 0 1-.75.75l-.748.011a.25.25 0 0 0-.25.25v1c0 .138.112.25.25.25L5.5 13zm1.427-8.513h1.719c.906 0 1.438.498 1.438 1.312 0 .871-.575 1.362-1.877 1.362h-1.28V4.487zm0 4.051h1.84c1.137 0 1.756.58 1.756 1.524 0 .953-.626 1.45-2.158 1.45H6.927V8.539z"/>
                        </svg>
                      </div>
                    </div>
                  </div>
                  <div className="row p-3 pt-0 amount-box">
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/deposit/${wallet ? wallet[1].currency : ''}`}>
                        Deposit
                      </Link>
                    </div>
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/withdraw/${wallet ? wallet[1].currency : ''}`}>
                        Withdraw
                      </Link>
                    </div>
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/buy/${wallet ? wallet[1].currency : ''}`}>
                        Buy
                      </Link>
                    </div>
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/sell/${wallet ? wallet[1].currency : ''}`}>
                        Sell
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-3 col-md-6 col-frm p-2">
                <div className="main-frm">
                  <div className="row p-3 align-items-center">
                    <div className="col-sm-6 col-6">
                      <p className="ttl-p text-start mb-0">TETHER</p>
                      <p className="p-0 m-0 amount-p">
                        <b>{wallet ? Number(wallet[0].balance).toFixed(6) : (<i>loading..</i>)}</b>
                        <br/>
                        <font>USDT</font>
                      </p>
                    </div>
                    <div className="col-sm-6 text-end col-6">
                      <div className="icon_d">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
                             width="25" height="25"
                             viewBox="0 0 24 24">
                          <path
                            d="M 12 1 C 5.935 1 1 5.935 1 12 C 1 18.065 5.935 23 12 23 C 18.065 23 23 18.065 23 12 C 23 5.935 18.065 1 12 1 z M 12 3 C 16.963 3 21 7.038 21 12 C 21 16.963 16.963 21 12 21 C 7.038 21 3 16.963 3 12 C 3 7.038 7.038 3 12 3 z M 7 7 L 7 9 L 11 9 L 11 10.048828 C 8.7935403 10.157378 6 10.631324 6 12 C 6 13.368676 8.7935403 13.842622 11 13.951172 L 11 18 L 13 18 L 13 13.951172 C 15.20646 13.842622 18 13.368676 18 12 C 18 10.631324 15.20646 10.157378 13 10.048828 L 13 9 L 17 9 L 17 7 L 7 7 z M 11 11.027344 L 11 12 L 13 12 L 13 11.027344 C 15.42179 11.151768 16.880168 11.700988 17.003906 11.978516 C 16.863906 12.334516 15.021 13 12 13 C 8.978 13 7.1360937 12.335484 6.9960938 12.021484 C 7.1198324 11.706835 8.5777007 11.152269 11 11.027344 z"></path>
                        </svg>
                      </div>
                    </div>
                  </div>
                  <div className="row p-3 pt-0 amount-box">
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/deposit/${wallet ? wallet[0].currency : ''}`}>
                        Deposit
                      </Link>
                    </div>
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/withdraw/${wallet ? wallet[0].currency : ''}`}>
                        Withdraw
                      </Link>
                    </div>
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/buy/${wallet ? wallet[0].currency : ''}`}>
                        Buy
                      </Link>
                    </div>
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/sell/${wallet ? wallet[0].currency : ''}`}>
                        Sell
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-xl-3 col-md-6 col-frm p-2">
                <div className="main-frm">
                  <div className="row p-3 align-items-center">
                    <div className="col-sm-6 col-6">
                      <p className="ttl-p text-start mb-0">USDC</p>
                      <p className="p-0 m-0 amount-p">
                        <b>{wallet ? Number(Math.floor(wallet[3].balance * 1000000) / 1000000).toFixed(6) : (
                          <i>loading..</i>)}</b>
                        <br/>
                        <font>USDC </font>
                      </p>
                    </div>
                    <div className="col-sm-6 text-end col-6">
                      <div className="icon_d">
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.0"
                             width={20}
                             height={20}
                             fill="currentColor"
                             className="bi bi-currency-bitcoin"
                             viewBox="0 0 256.000000 256.000000">
                          <g transform="translate(0.000000,256.000000) scale(0.100000,-0.100000)" fill="#000000"
                             stroke="none">
                            <path
                              d="M920 2271 c-211 -79 -389 -217 -509 -395 -389 -576 -136 -1355 517 -1590 l72 -26 0 98 0 97 -60 23 c-142 56 -296 184 -388 325 -262 402 -149 944 251 1205 42 28 104 61 137 74 l60 23 0 97 c0 54 -1 98 -2 98 -2 -1 -37 -14 -78 -29z"/>
                            <path
                              d="M1552 2204 l3 -95 58 -24 c244 -99 433 -314 509 -580 33 -116 33 -334 0 -450 -76 -266 -265 -481 -509 -580 l-58 -24 -3 -95 c-1 -53 0 -96 2 -96 3 0 42 13 87 30 645 235 895 1013 509 1585 -122 180 -300 319 -509 395 -45 17 -84 30 -87 30 -2 0 -3 -43 -2 -96z"/>
                            <path
                              d="M1188 1904 l-3 -87 -40 -12 c-93 -28 -179 -95 -219 -173 -46 -90 -41 -195 15 -272 54 -74 144 -117 321 -150 105 -20 168 -47 192 -82 45 -64 19 -156 -57 -198 -34 -20 -56 -24 -117 -24 -117 0 -185 47 -205 142 l-7 32 -95 0 -96 0 6 -54 c7 -70 36 -124 92 -174 43 -38 143 -82 187 -82 15 0 18 -12 20 -87 l3 -88 87 -3 87 -3 3 87 3 87 52 13 c76 20 123 46 170 96 81 89 105 220 57 316 -50 101 -159 163 -338 193 -133 23 -159 32 -191 71 -42 50 -28 134 28 171 63 41 179 41 237 -2 37 -27 70 -80 70 -112 l0 -29 91 0 92 0 -6 54 c-11 109 -94 215 -201 255 l-51 19 -3 91 -3 91 -89 0 -89 0 -3 -86z"/>
                          </g>
                        </svg>
                      </div>
                    </div>
                  </div>
                  <div className="row p-3 pt-0 amount-box">
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/deposit/${wallet ? wallet[3].currency : ''}`}>
                        Deposit
                      </Link>
                    </div>
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/withdraw/${wallet ? wallet[3].currency : ''}`}>
                        Withdraw
                      </Link>
                    </div>
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/buy/${wallet ? wallet[3].currency : ''}`}>
                        Buy
                      </Link>
                    </div>
                    <div className="col-sm-12 mb-2">
                      <Link className="cstm-lbl" href={`/user/sell/${wallet ? wallet[3].currency : ''}`}>
                        Sell
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="container-fluid px-4 all-rw">
            <div className="row pe-4 ps-4 mt-5 pb-4">
              <div className="col-sm-12">
                <label>ALL TIME TRANSACTION HISTORY</label>
              </div>
            </div>
          </div>
          <div className="container-fluid px-4">
            <div className="row pe-4 ps-4 mt-4 pb-4 all-btn">
              <div className="col-sm-12">
                <label className="me-2">
                  <button type="button" onClick={() => getReport(1, user)}
                          className={`cstm-btn ${activeReport === 1 ? 'activ' : ''} `}>
                    Deposit
                  </button>
                </label>
                <label className="me-2">
                  <button type="button" onClick={() => getReport(2, user)}
                          className={`cstm-btn ${activeReport === 2 ? 'activ' : ''} `}>
                    Withdraw
                  </button>
                </label>
                <label className="me-2">
                  <button type="button" onClick={() => getReport(3, user)}
                          className={`cstm-btn ${activeReport === 3 ? 'activ' : ''} `}>
                    Exchange
                  </button>
                </label>
                <label className="me-2">
                  <button type="button" onClick={() => getReport(4, user)}
                          className={`cstm-btn ${activeReport === 4 ? 'activ' : ''} `}>
                    Load
                  </button>
                </label>
                <label className="me-2">
                  <button type="button" onClick={() => getReport(5, user)}
                          className={`cstm-btn ${activeReport === 5 ? 'activ' : ''} `}>
                    Card Activities
                  </button>
                </label>
              </div>
              <div className="col-sm-12 mt-5">
                {isLoading ? <p>Loading...</p> :
                  <DataTable data={reportData} col={col}/>
                }
              </div>
            </div>
          </div>
        </main>
      ) : (
        <p>Loading...</p>
      )}
    </UserLayout>
  )
}

export default withAuth(Dashboard)
