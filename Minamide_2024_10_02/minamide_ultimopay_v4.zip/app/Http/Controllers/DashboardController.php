<?php
namespace App\Http\Controllers;
use App\Report;
use App\UltimopayAPI_v4;
use App\Utils;
use Carbon\Carbon;
use Exception;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use setasign\Fpdi\Fpdi;

require_once (app_path().'/includes/PROD/api/Payment.php');
require_once (app_path().'/includes/PROD/api/Inquiry.php');
require_once (app_path().'/includes/PROD/api/VoidRequest.php');
require_once (app_path().'/includes/PROD/api/Settlement.php');
require_once (app_path().'/includes/PROD/api/Refund.php');

require_once (app_path().'/includes/UAT/api/Payment.php');
require_once (app_path().'/includes/UAT/api/Inquiry.php');
require_once (app_path().'/includes/UAT/api/VoidRequest.php');
require_once (app_path().'/includes/UAT/api/Settlement.php');
require_once (app_path().'/includes/UAT/api/Refund.php');

require_once (app_path().'/includes/PHPGangsta/GoogleAuthenticator.php');

class DashboardController extends Controller
{
  public function testEmail(){
    echo env("ADMIN_EMAIL");
    $email = "borismarkovica@outlook.com";
    $this->sendCompletedMail($email,1702861399991,0.003,0.003);
  }

  // Dashboard - Analytics
  public function home(Request $request) {
    //return $this->checkOrderNo('170528');
    // $request->input() method did not work for this situation.
    $email = Utils::getInputValue('email') ?? env('');
    $request->session()->put('email',  $email);
    $response = UltimopayAPI_v4::getAuthToken();
    if ($response["result"] === "success") {
      $response1 = UltimopayAPI_v4::walletBalance();
      if ($response1["result"] === "success") {
        $usdt_balance = 0;
        foreach( $response1['wallet'] as $wallet){
          if( $wallet['currency'] == 'USDT' )
            $usdt_balance = $wallet['balance'];
        }

        // If exist purchase confirmation code process for this user, redirect confirm to buy
        $confirmView = $this->isExistPurchaseConfirmationProcess( $request, $usdt_balance );
        if ( $confirmView != null )
          return $confirmView;

        // else
        return view('/pages/home', [
          'balance' => $usdt_balance,
          'email' =>  $request->session()->get("email"),
          'merchant' => $request->session()->get("merchant"),
          'withdraw' => $request->session()->get("withdraw"),
          'deposit' => $request->session()->get("deposit"),
          'buy' => $request->session()->get("buy")
        ]);
      } else {
        return view('/pages/home', [
          'error' => "Your session was expired. Please re-login and try again.",
          'email' =>  $request->session()->get("email"),
          'merchant' => $request->session()->get("merchant"),
          'balance' => 0
        ]);
      }
    } else {
      return view('/pages/home', [
        'error' => "Your session was expired. Please re-login and try again.",
        'email' =>  $request->session()->get("email"),
        'merchant' => $request->session()->get("merchant"),
        'balance' => 0
      ]);
    }
  }
  public function depositPage(Request $request) {
    try
    {
      $response1 = UltimopayAPI_v4::walletBalance();
      if ($response1["result"] === "success") {
        $usdt_balance = 0;
        foreach( $response1['wallet'] as $wallet){
          if( $wallet['currency'] == 'USDT' )
            $usdt_balance = $wallet['balance'];
        }

        return view('/pages/deposit', [
          'balance' => $usdt_balance,
          'email' => $request->session()->get("email"),
          'merchant' => $request->session()->get("merchant"),
          'withdraw' => $request->session()->get('withdraw'),
          'deposit' => $request->session()->get('deposit'),
          'buy' => $request->session()->get("buy")

        ]);
      } else {
        return view('/pages/deposit', [
          'error' => "Your session was expired. Please re-login and try again.",
          'email' =>  $request->session()->get("email"),
          'merchant' => $request->session()->get("merchant"),
          'withdraw' => $request->session()->get('withdraw'),
          'deposit' => $request->session()->get('deposit'),
          'buy' => $request->session()->get("buy")

        ]);
      }
    } catch (\Throwable $th) {
      //throw $th;
      return view('/pages/deposit', [
        'error' => "Network problem.",
        'email' =>  $request->session()->get("email"),
        'merchant' => $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy")
      ]);
    }
  }
  public function withdrawPage(Request $request) {
    try {
      //code...
      $response1 = UltimopayAPI_v4::walletBalance();
      if ($response1["result"] === "success") {
        $usdt_balance = 0;
        foreach( $response1['wallet'] as $wallet){
          if( $wallet['currency'] == 'USDT' )
            $usdt_balance = $wallet['balance'];
        }

        $tfaStatus = $this->check2FA();
        return view('/pages/withdraw', [
          'balance' => $usdt_balance,
          'email' =>  Session::get("email"),
          'merchant' => Session::get("merchant"),
          'tfaStatus' => $tfaStatus,
          'withdraw' => $request->session()->get('withdraw'),
          'deposit' => $request->session()->get('deposit'),
          'buy' => $request->session()->get("buy")

        ]);
      } else {
        return view('/pages/withdraw', [
          'error' => "Your session was expired. Please re-login and try again.",
          'email' =>  Session::get("email"),
          'merchant' => Session::get("merchant"),
          'withdraw' => $request->session()->get('withdraw'),
          'deposit' => $request->session()->get('deposit'),
          'buy' => $request->session()->get("buy")

        ]);
      }
    } catch (\Throwable $th) {
      //throw $th;
      $tfaStatus = $this->check2FA();

      return view('/pages/withdraw', [
        'error' => "Network problem.",
        'email' =>  Session::get("email"),
        'merchant' => Session::get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy")

      ]);
    }

  }
  public function getBalance(Request $request) {
    try {
      //code...
      $response1 = UltimopayAPI_v4::walletBalance();
      if ($response1["result"] === "success") {
        $usdt_balance = 0;
        foreach( $response1['wallet'] as $wallet){
          if( $wallet['currency'] == 'USDT' )
            $usdt_balance = $wallet['balance'];
        }
        return $usdt_balance;
      } else {
        return 0;
      }
    } catch (\Throwable $th) {
      return 0;
    }

  }
  public function withdraw(Request $request) {
    $verificationCode =  random_int(100000, 999999);
    $token = [ "code" => $verificationCode, "expire_at" => Carbon::now()->addMinutes(30)];
    $request->session()->put("token", $token);
    $request->session()->put("amount", $request->input("amount"));
    $email = $request->session()->get("email");


    $api_key = 'Bearer ' . env("API_KEY");
    try {
      //code...
      $amount = $request->input("amount");
      $address = $request->input("address");
      $network = $request->input("network");
      $code = $request->input("code");
      $password = $request->input("password");
      $response1 = Http::withHeaders([
        'Content-Type' => 'application/json',
        'Authorization' => $api_key
      ])->post("https://xapiserver.com/v4/withdraw/",  [
        'email_address' => $request->session()->get("email"),
        'auth_token' =>$request->session()->get("auth_token"),
        'amount' =>$amount,
        'address' =>$address,
        'network' =>$network,
        'two_fa_code' =>$code,
        'password' =>$password,
        'currency' => "USDT"
      ]);
      $rawtext ="Please reply to this email if there is no problem for approval of the withdrawal below.<br/><br/> Withdrawal address: ".$address."<br/>Withdrawal amount: ".$amount."<br/<br/>>Regards, <br/>UltimoPayment";
      Mail::send([], [], function ($message) use ($rawtext, $email) {
        $message->to($email)->subject('[UltimoPayment] Withdrawal Confirmation'); //info@cryptowire.vip
        $message->from(env("ADMIN_EMAIL"), 'Ultimo Payment');
        $message->setBody($rawtext, 'text/html');
      });
      return $response1;
    } catch (\Throwable $th) {
      //throw $th;
      $result["error"] = [];
      $result["error"]["errorMessage"] = "Network problem!";
      $result["result"] = "failed";
      return $result;
    }

  }
  public function withdrawVerifyCode(Request $request) {
    $result = [];
    $code = $request->input("code");
    $token = $request->session()->get("token");
    if($token["code"] == $code){
      if($token["expire_at"] > Carbon::now()){
        $result["status"] = "success";
        $rawtext ="You receive the following withdraw request.<br/>"."Email: ". $request->session()->get("email")."<br/>"."Amount: ".$request->session()->get("amount")."USDT";
        try {
          Mail::send([], [], function ($message) use ($rawtext) {
            $message->to(env("ADMIN_EMAIL"))->subject('Please confirm this withdraw request.');
            $message->from(env("ADMIN_EMAIL"), 'Ultimo Payment');
            $message->setBody($rawtext, 'text/html');
          });
        }
        catch(Exception $e){
          Log::error('');
          Log::error('');
          Log::error('error in withdrawVerifyCode()');
          Log::error( $e->getTraceAsString());
          Log::error('');
          Log::error('');
        }
      }
      else {
        $result["status"] = "failed";
        $result["message"] = "The code was already expired!";
      }
    }
    else {
      $result["status"] = "failed";
      $result["message"] = "The code is not correct!";
    }
    return $result;
  }

  public function buyPage(Request $request) {

    $pageData = [
      'balance' => 0,
      'email' =>  $request->session()->get("email"),
      'merchant' => $request->session()->get("merchant"),
      'withdraw' => $request->session()->get('withdraw'),
      'deposit' => $request->session()->get('deposit'),
      'buy' => $request->session()->get("buy"),
      'kyc_status' => '',
    ];
    $respWallet = UltimopayAPI_v4::walletBalance();
    if ($respWallet["result"] === "success") {
      $usdt_balance = 0;
      foreach( $respWallet['wallet'] as $wallet){
        if( $wallet['currency'] == 'USDT' )
          $usdt_balance = $wallet['balance'];
      }

      // If exist purchase confirmation code process for this user, redirect confirm to buy
      $confirmView = $this->isExistPurchaseConfirmationProcess( $request , $usdt_balance );
      if( $confirmView != null )
        return $confirmView;

      $pageData['balance'] = Utils::numberFormat($usdt_balance, 6);
      return view('/pages/buy', $pageData);
    }
    else {
      $pageData['error'] = 'Your session was expired. Please re-login and try again.';
      $pageData['balance'] = 0;
      return view('/pages/buy', $pageData);
    }
  }

  public function buyWithCard(Request $request) {
    $result = [];

    // Check if successes in 24 hours
    $email = $request->session()->get('email');
    $latestRecord = Report::where('email', $email)
      ->where('updated_at', '>=', Carbon::now()->subDay())
      ->whereNotIn('status', ['failed', 'canceled'])
      ->orderBy('updated_at', 'desc')
      ->first();

    if (!is_null($latestRecord)) {
      // Calculated remaining time
      $nextPurchaseTime = Carbon::parse($latestRecord->updated_at)->addDay();
      $currentTime = Carbon::now();
      $diffInMinutes = $nextPurchaseTime->diffInMinutes($currentTime);
      $remainingHours = intdiv($diffInMinutes, 60);
      $remainingMinutes = $diffInMinutes % 60;

      $result["status"] = "failed";
      $result["data"] = 'Purchase Restriction';
      $result["message"] = "
        You cannot make a purchase within 24 hours of your last purchase.
        <div class='sub-description'>
          You can make your next purchase in {$remainingHours} hour(s) and {$remainingMinutes} minute(s).
        </div>";
      return $result;
    }

    /*$respWallet = UltimopayAPI_v4::walletBalance();
    if ($respWallet["result"] === "success") {
      if( session()->get('merchant') == env('MERCHANT_CHECK_ON_BUY')){
        $respUserInfo = UltimopayAPI_v4::getUserInfo();
        if( !isset($respUserInfo['result']) || $respUserInfo['result'] != 'success' || !isset($respUserInfo['userInfoResponse']) || !isset($respUserInfo['userInfoResponse']['card_activation_status']) ){
          $result["status"] = "failed";
          $result["data"] = json_encode($respUserInfo).' Your session was expired. Please re-login and try again.';
          $result["message"] = 'Your session was expired. Please re-login and try again.';
          return $result;
        }
        if( $respUserInfo['userInfoResponse']['card_activation_status'] != 'approved' ){
          $result["status"] = "failed";
          $result["data"] = 'Card Activation';
          $result["message"] = 'You need to issue and activate your Ultimo card to use this function.';
          $result["userInfo"] = $respUserInfo;
          return $result;
        }
      }
    }
    else {
      $result["status"] = "failed";
      $result["data"] = 'Your session was expired. Please re-login and try again.';
      $result["message"] = 'Your session was expired. Please re-login and try again.';
      return $result;
    }*/

    try {
      // Check parameters
      $email = $request->session()->get('email');
      $amount = $request->input("amount");
      $amount = ceil($amount * 100) / 100;
      $request->session()->put('currency', $request->input("currency"));
      $crypto_amount = $amount * (1-env('FEE_PERCENT', 8) / 100);
      $crypto_amount = bcdiv($crypto_amount, 1, 6);
      $request->session()->put('crypto_amount', $crypto_amount);

      // Add transaction into local database
      $now = Carbon::now();
      $orderNo = $now->getPreciseTimestamp(3);
      $report = new Report;
      $report->email = $email;
      $report->usd = $amount;
      $report->usdt = $crypto_amount;
      $report->transaction_id = $orderNo;
      $report->status = "None";
      $report->save();

      // Call JDB payment
      if( $email == 'rebebubo@heisei.be' )
        $payment = new \App\includes\UAT\api\Payment();
      else
        $payment = new \App\includes\PROD\api\Payment();
      $response = $payment->ExecuteJose($orderNo, $amount);
      $request->session()->put('amount',$amount);
      $result["status"] = "success";
      $result["data"] = $response;
      return $result;
    }
    catch (Exception $e) {
      $result["status"] = "failed";
      $result["message"] = $e->getMessage();
      return $result;
    } catch (GuzzleException $e) {
      $result["status"] = "failed";
      $result["message"] = $e->getMessage();
      return $result;
    }
  }

  public function isExistPurchaseConfirmationProcess( Request $request, $usdt_balance ) {
    $email = $request->session()->get("email");
    $report =  Report::where('email', $email)
      ->where('status', 'Input Code')
      ->latest('created_at')
      ->first();
    $orderNoResponse = null;
    if( $report ) {
      try {
        if( Utils::isUatUser($email))
          $inquiry = new \App\includes\UAT\api\Inquiry();
        else
          $inquiry = new \App\includes\PROD\api\Inquiry();
        $orderNoResponse = $inquiry->transactionDetails($report->transaction_id);
        $orderNoResponse = json_decode($orderNoResponse)->data[0];

        if( $orderNoResponse->orderNo == $report->transaction_id &&
          ( $orderNoResponse->paymentStatusInfo->paymentStatus == 'S' || $orderNoResponse->paymentStatusInfo->paymentStatus == 'A' )){
          $request->session()->put("amount", $report->usd);
          $request->session()->put("crypto_amount", $report->usdt);
          $request->session()->put("productDescription", $report->product_description);
          $request->session()->put("controllerInternalId", $report->controller_internal_id);
          $request->session()->put("orderNo", $report->transaction_id);
          $request->session()->put("id", $report->id);

          return view('/pages/buy', [
            'balance' => $usdt_balance,
            'paymentSuccess' => true,
            'email' => $request->session()->get("email"),
            'merchant' => $request->session()->get("merchant"),
            'withdraw' => $request->session()->get('withdraw'),
            'deposit' => $request->session()->get('deposit'),
            'buy' => $request->session()->get("buy"),
            'showVerifyDialog'=> true,
            'date'=>$report->created_at,
            'orderNo'=>$report->transaction_id,
            'paid'=>$report->usd,
            'received'=>$report->usdt,
          ]);
        }
      } catch (\Exception $e) {
        Log::error('error in isExistPurchaseConfirmationProcess(), transaction_id: '.$report->transaction_id);
        Log::error('error in $inquiry->transactionDetails($order_no)');
      }
    }

    return null;
  }

  public function paymentConfirmation( Request $request ) {

    // Check parameters
    $email = $request->session()->get("email");
    $transaction_id = Utils::getInputValue('orderNo');

    // Check current wallet
    $walletBalance = UltimopayAPI_v4::walletBalance();
    if ($walletBalance["result"] != "success"){
      return view('/pages/buy', [
        'error' => "Your session was expired. Please re-login and try again.",
        'email' => $email,
        'merchant' => $request->session()->get("merchant"),
      ]);
    }

    $usdt_balance = 0;
    foreach( $walletBalance['wallet'] as $wallet){
      if( $wallet['currency'] == 'USDT' )
        $usdt_balance = $wallet['balance'];
    }

    // Check payment validation
    $redirectionView = $this->CheckPaymentValidation( $request, $usdt_balance, true );
    if( $redirectionView != null )
      return $redirectionView;

    // Update transaction
    $product_description = Utils::getInputValue("productDescription");
    $controller_internal_id = Utils::getInputValue("controllerInternalId");
    $status = "Input Code";

    // Save payment PDF file
    $filename = $this->saveTransactionPDF(Utils::getInputValue("orderNo"), $email);

    // Send confirmation email
    $verificationCode =  random_int(100000, 999999);
    $token = [ "code" => $verificationCode, "expire_at" => Carbon::now()->addMinutes(30)];
    $request->session()->put("token", $token);
    $request->session()->put("orderNo", Utils::getInputValue("orderNo"));
    $rawtext = "Verification code for buying ".$request->session()->get('crypto_amount')."USDT: ".$verificationCode;
    $rawtext .= '<br/>(Order number: '.Utils::getInputValue("orderNo").')';
    $rawtext .= '<br/>Date: '.date('Y-m-d H:i:s').' UTC';
    $rawtext .=  '<br><br>If you do not recognize this, <br>please contact support@ultimopay.io for assistance';

    if( $filename && strlen($filename) > 0 ){

      // Update transaction record with PDF status
      $pdf_status = 'creditcard_' . Utils::getInputValue("orderNo") . '.pdf';

      // Try to send email
      try {
        Mail::send([], [], function ($message) use ($rawtext, $email, $filename) {
          $message->to($email)->subject('Please confirm your buy.');
          $message->from(env("ADMIN_EMAIL"), 'Ultimo Payment');
          $message->bcc(env("ADMIN_EMAIL"));
          $message->setBody($rawtext, 'text/html');
          if ($filename && strlen($filename) > 0) $message->attach($filename);
        });

        // Update transaction record with emailing status
        $email_status = 'sent';
      }
      catch(\Exception $e){
        // save emailing status
        $email_status = 'failed';
        Log::error('');
        Log::error('');
        Log::error("error emailing");
        Log::error( $e->getTraceAsString());
      }
    }
    else{
      // Update transaction record with PDF and emailing status
      $pdf_status = 'error';
      $email_status = 'Failed because PDF creation failed.';
    }

    // Save transaction
    $report = $this->saveTransactionHistory(
      $email,
      null,
      null,
      $transaction_id,
      $status,
      $email_status,
      $pdf_status,
      $product_description,
      $controller_internal_id);

    // Return to confirmation page
    return view('/pages/buy', [
      'balance' => $usdt_balance,
      'paymentSuccess' => true,
      'email' => $email,
      'merchant' => $request->session()->get("merchant"),
      'withdraw' => $request->session()->get('withdraw'),
      'deposit' => $request->session()->get('deposit'),
      'buy' => $request->session()->get("buy"),
      'showVerifyDialog'=> true,
      'date'=>$report->created_at,
      'orderNo'=>$transaction_id,
      'paid'=>$report->usd,
      'received'=>$report->usdt,
    ]);
  }

  public function paymentCancellation(Request $request) {
    $crypto_amount = $request->session()->get('crypto_amount');
    $email = $request->session()->get("email");
    $transaction_id = Utils::getInputValue('orderNo');

    // Update transaction record status
    $status = "canceled";

    // Get balance
    $response = UltimopayAPI_v4::walletBalance();
    if ($response["result"] !== "success") {
      return view('/pages/buy', [
        'error' => "Your session was expired. Please re-login and try again.",
        'email' =>  $request->session()->get("email"),
        'merchant' => $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy")
      ]);
    }
    $usdt_balance = 0;
    foreach( $response['wallet'] as $wallet){
      if( $wallet['currency'] == 'USDT' )
        $usdt_balance = $wallet['balance'];
    }

    // Send cancellation email
    $rawtext ="You cancelled in buying {$crypto_amount}&#8202;USDT!";
    $rawtext .= '<br/>(Order number: '.$transaction_id.')';
    $rawtext .= '<br/>Date: '.date('Y-m-d H:i:s').' UTC';
    $rawtext .= '<br><br>If you do not recognize this, <br>please contact support@ultimopay.io for assistance';

    try {
      Mail::send([], [], function ($message) use ($rawtext, $email) {
        $message->to($email)->subject('You cancelled in buying.');
        $message->from(env("ADMIN_EMAIL"), 'Ultimo Payment');
        $message->bcc(env("ADMIN_EMAIL"), 'Ultimo Payment');
        $message->setBody($rawtext, 'text/html');
      });

      // Update transaction record with emailing status
      $email_status = 'sent';
    }
    catch (\Exception $e){
      Log::error('');
      Log::error('');
      Log::error('error in paymentCancellation()');
      Log::error( $e->getTraceAsString());
      Log::error('');
      Log::error('');

      // Update transaction record with emailing status
      $email_status = 'failed';
    }

    // Save transaction
    $this->saveTransactionHistory(
      $email,
      null,
      null,
      $transaction_id,
      $status,
      $email_status);

    return view('/pages/buy', [
      'balance' => $usdt_balance,
      'email' =>  $request->session()->get("email"),
      'merchant' => $request->session()->get("merchant"),
      'withdraw' => $request->session()->get('withdraw'),
      'deposit' => $request->session()->get('deposit'),
      'buy' => $request->session()->get("buy")
    ]);
  }

  public function paymentFailed(Request $request) {

    // Update transaction record status
    $status = "failed";

    // Check parameters
    $pay_amount = $request->session()->get('amount');
    $crypto_amount = $request->session()->get('crypto_amount');
    $email = $request->session()->get("email");
    $transaction_id = Utils::getInputValue('orderNo');

    // Get wallet balances
    $response = UltimopayAPI_v4::walletBalance();
    if ($response["result"] !== "success") {
      return view('/pages/buy', [
        'error' => "Your session was expired. Please re-login and try again.",
        'email' => $email,
        'merchant' => $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy")
      ]);
    }
    $usdt_balance = 0;
    foreach( $response['wallet'] as $wallet){
      if( $wallet['currency'] == 'USDT' )
        $usdt_balance = $wallet['balance'];
    }

    // Send cancellation email
    $rawtext ="You failed in buying {$crypto_amount}&#8202;USDT!";
    $rawtext .= '<br/>(Order number: '.$transaction_id.')';
    $rawtext .= '<br/>Date: '.date('Y-m-d H:i:s').' UTC';
    $rawtext .= '<br><br>If you do not recognize this, <br>please contact support@ultimopay.io for assistance';

    try {
      Mail::send([], [], function ($message) use ($rawtext, $email) {
        $message->to($email)->subject('You failed in buying.');
        $message->from(env("ADMIN_EMAIL"), 'Ultimo Payment');
        $message->bcc(env("ADMIN_EMAIL"), 'Ultimo Payment');
        $message->setBody($rawtext, 'text/html');
      });
      $email_status = 'sent';
    }
    catch (\Exception $e){
      Log::error('');
      Log::error('');
      Log::error('error in paymentFailed()');
      Log::error( $e->getTraceAsString());
      Log::error('');
      Log::error('');
      $email_status = 'failed';
    }

    // Save transaction
    $this->saveTransactionHistory(
      $email,
      $pay_amount,
      $crypto_amount,
      $transaction_id,
      $status,
      $email_status);

    return view('/pages/buy', [
      "paymentConfirm" => "You failed in buying {$crypto_amount}&#8202;USDT!",
      'balance' => $usdt_balance,
      'email' =>  $email,
      'merchant' => $request->session()->get("merchant"),
      'withdraw' => $request->session()->get('withdraw'),
      'deposit' => $request->session()->get('deposit'),
      'buy' => $request->session()->get("buy"),
      'status'=>'paymentFailed'// paymentFailed: means "failed!", otherwise "nothing"
    ]);
  }

  public function paymentBackend(Request $request) {

    $response1 = UltimopayAPI_v4::walletBalance();
    if ($response1["result"] === "success") {
      $usdt_balance = 0;
      foreach( $response1['wallet'] as $wallet){
        if( $wallet['currency'] == 'USDT' )
          $usdt_balance = $wallet['balance'];
      }
      return view('/pages/buy', [
        "paymentConfirm" => "You entered paymentBackend!",
        'balance' => $usdt_balance,
        'email' =>  $request->session()->get("email"),
        'merchant' => $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy")
      ]);
    } else {
      return view('/pages/buy', [
        'error' => "Your session was expired. Please re-login and try again.",
        'email' =>  $request->session()->get("email"),
        'merchant' => $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy")
      ]);
    }
  }
  public function twoFa(Request $request) {
    if($this->check2FA() === "enabled") {
      return view('/pages/2fa', [
        'status' => true,
        'email' => $request->session()->get("email"),
        'merchant' =>  $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy")
      ]);
    }
    $api_key = 'Bearer ' . env("API_KEY");
    $response1 = Http::withHeaders([
      'Content-Type' => 'application/json',
      'Authorization' => $api_key
    ])->post("https://xapiserver.com/v4/get2FASecretKey/",  [
      'email_address' => $request->session()->get("email"),
      'auth_token' =>$request->session()->get("auth_token"),
    ]);
    if ($response1["result"] === "success") {
      $ga = new \PHPGangsta_GoogleAuthenticator();
      $fixedcode = $response1['two_fa_secret_key'];
      $qrCodeUrl = $ga->getQRCodeGoogleUrl($request->session()->get("email"), $fixedcode, 'ULTIMOPAY.IO');
      return view('/pages/2fa', [
        'qrCodeUrl' => $qrCodeUrl,
        'secret' => $fixedcode,
        'email' => $request->session()->get("email"),
        'merchant' =>  $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy")
      ]);
    }
    else {
      return view('/pages/2fa', [
        'error' => "Your session was expired. Please re-login and try again.",
        'email' =>  $request->session()->get("email"),
        'merchant' => $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy")
      ]);
    }

  }
  public function setTwoFa(Request $request) {
    $api_key = 'Bearer ' . env("API_KEY");
    $code = $request->input("code");
    $password = $request->input("password");
    $response1 = Http::withHeaders([
      'Content-Type' => 'application/json',
      'Authorization' => $api_key
    ])->post("https://xapiserver.com/v4/set2FA/",  [
      'email_address' => $request->session()->get("email"),
      'auth_token' =>$request->session()->get("auth_token"),
      'two_fa_code' =>$code,
      'password' =>$password,
      'type' => 1
    ]);
    return $response1;
  }

  public function disableTwoFa(Request $request) {
    $api_key = 'Bearer ' . env("API_KEY");
    $code = $request->input("code");
    $password = $request->input("password");
    $response1 = Http::withHeaders([
      'Content-Type' => 'application/json',
      'Authorization' => $api_key
    ])->post("https://xapiserver.com/v4/set2FA/",  [
      'email_address' => $request->session()->get("email"),
      'auth_token' =>$request->session()->get("auth_token"),
      'two_fa_code' =>$code,
      'password' =>$password,
      'type' => 0
    ]);
    return $response1;
  }

  public function check2FA() {
    $api_key = 'Bearer ' . env("API_KEY");
    $response1 = Http::withHeaders([
      'Content-Type' => 'application/json',
      'Authorization' => $api_key
    ])->post("https://xapiserver.com/v4/check2FA/",  [
      'email_address' => Session::get("email"),
      'auth_token' =>Session::get("auth_token"),
    ]);
    if ($response1["result"] === "success") {
      return $response1["2FAStatus"]["status"] ;
    } else {
      return "failed";
    }

  }
  public function getDepositAddress(Request $request , $network, $email) {
    $api_key = 'Bearer ' . env("API_KEY");
    $response1 = Http::withHeaders([
      'Content-Type' => 'application/json',
      'Authorization' => $api_key
    ])->post("https://xapiserver.com/v4/deposit/",  [
      'email_address' => $request->session()->get("email"),
      'auth_token' =>$request->session()->get("auth_token"),
      'currency' => "USDT",
      'network' => $network,
    ]);
    if ($response1["result"] === "success") {
      return $response1["depositResponse"]["address"];
    } else {
      return json_encode($response1["error"]["errorMessage"]);
    }
  }

  public function transactionHistoryDetail( Request $request ){
    $result = new Report();
    $orderId = $request->input('order_id');
    $report = Report::where('transaction_id', '=', $orderId)->first();
    if( $report && $report->count() > 0 ){
      $report->created_at = $report->created_at->format('Y-m-d H:i:s');
      $report->updated_at = $report->updated_at->format('Y-m-d H:i:s');
      $result = $report;
    }
    return response()->json($result);
  }

  public function transactionHistory(Request $request) {
    $email =  $request->session()->get("email");
    $api_key = 'Bearer ' . env("API_KEY");
    try {
      //code...
      $response1 = UltimopayAPI_v4::walletBalance();
      if ($response1["result"] === "success") {
        $usdt_balance = 0;
        foreach( $response1['wallet'] as $wallet){
          if( $wallet['currency'] == 'USDT' )
            $usdt_balance = $wallet['balance'];
        }
        $histories = Report::where("email", $email)
          ->orderBy('updated_at', 'desc')
          ->get();
        return view('/pages/transaction-history', [
          'histories' => $histories,
          'balance' => $usdt_balance,
          'email' =>  $email,
          'merchant' => $request->session()->get("merchant"),
          'deposit' => $request->session()->get('deposit'),
          'withdraw' => $request->session()->get('withdraw')?$request->session()->get('withdraw') :  "off",
          'buy' => $request->session()->get("buy") ? $request->session()->get('buy') : "off"
        ]);

      } else {
        return view('/pages/transaction-history', [
          'error' => "Your session was expired. Please re-login and try again.",
          'email' =>  $email,
          'merchant' => $request->session()->get("merchant"),
          'deposit' => $request->session()->get('deposit'),
          'withdraw' => $request->session()->get('withdraw') ? $request->session()->get('withdraw') :  "off",
          'buy' => $request->session()->get("buy") ? $request->session()->get('buy') : "off"
        ]);
      }
    } catch (\Throwable $th) {
      //throw $th;
      $tfaStatus = $this->check2FA();

      return view('/pages/transaction-history', [
        'error' => "Network problem.",
        'email' =>  $email,
        'merchant' => $request->session()->get("merchant"),
        'deposit' => $request->session()->get('deposit'),
        'withdraw' => $request->session()->get('withdraw')?$request->session()->get('withdraw') :  "off",
        'buy' => $request->session()->get("buy") ? $request->session()->get('buy') : "off"
      ]);
    }

  }
  public function login(Request $request){

    $email = $request->input("username");
    $password = $request->input("password");

    $response1 = UltimopayAPI_v4::signIn( $email, $password );
    if ($response1["result"] === "success") {
      return redirect()->action([DashboardController::class, 'home'], ['email' => $email ]);
    }
    else {
      $data = [];
      if( session()->get('login_type') == env('LOGIN_2')){
        $data['msg_ex'] = "Cannot verify now, please re-enter your password again!";
        $url = 'login2?id='.session()->get('id');
        if(session()->has('buy') && session()->get('buy') == 'on')
          $url .= '&buy='.session()->get('buy');
        if(session()->has('withdraw') && session()->get('withdraw') == 'on')
          $url .= '&withdraw='.session()->get('withdraw');
        if(session()->has('deposit') && session()->get('deposit') == 'on')
          $url .= '&deposit='.session()->get('deposit');
        if(session()->has('merchant') && session()->get('merchant') == 'on')
          $url .= '&merchant='.session()->get('merchant');
        return Redirect::to(url($url))->with('data', $data);
      }
      else{
        $pageConfigs = [
          'bodyClass' => "bg-full-screen-image",
          'blankPage' => true
        ];
        $data['msg_ex'] = "Cannot login now, please try again later !";
        return view('/pages/auth-login', [
          'pageConfigs' => $pageConfigs,
          'data' => $data
        ]);
      }
    }
  }

  public function upload(Request $request): int
  {
    if($files=$request->file('csvFile')){
      $name = $files->getClientOriginalName();
      $files->move(public_path('uploads'), $name);

      $newFile = new File;
      $newFile->agent_id = Auth::user()->email;
      $newFile->file_name = $name;
      $newFile->date = date("Y-m-d");
      $newFile->save();

      $contents = [];
      $totalAmount = 0;
      if (($open = fopen(public_path() . "/uploads/" . $name, "r")) !== FALSE) {
        $index=0;
        while (($data = fgetcsv($open, 1000, ",")) !== FALSE) {

          $contents[] = $data;
          if($index != 0) $totalAmount += $data[1];

          $index++;
        }

        fclose($open);
      }

      return 1;
    }

    return 0;
  }

  public function buyVerifyCode(Request $request) {

    // Result statuses
    $transactionStatus = 'failed';
    $result = [];
    $result["status"] = "failed";

    // Check current wallet
    $walletBalance = UltimopayAPI_v4::walletBalance();
    if ($walletBalance["result"] != "success")
      return redirect(url('/buy-page'));

    $usdt_balance = 0;
    foreach( $walletBalance['wallet'] as $wallet){
      if( $wallet['currency'] == 'USDT' )
        $usdt_balance = $wallet['balance'];
    }

    // Check session parameters
    $email = $request->session()->get("email");
    $pay_amount = $request->session()->get('amount');
    $crypto_amount = $request->session()->get('crypto_amount');
    $currency = $request->session()->get('currency', 'USDT');
    $transaction_id = $request->session()->get("orderNo");

    // Check payment validation
    $redirectionView = $this->CheckPaymentValidation( $request, $usdt_balance, false );
    if( $redirectionView != null ) {
      $result["message"] = "You failed in buying {$crypto_amount}&#8202;USDT!";
      $result["status"] = $transactionStatus;
      return $result;
    }

    $code = $request->input("code");
    $token = $request->session()->get("token");
    $email_status = null;
    if($token["code"] == $code){
      if($token["expire_at"] > Carbon::now()){
        $response = UltimopayAPI_v4::balanceCorrection(
          $email,
          $crypto_amount,
          $currency,
          "$pay_amount USD Buy with Card(order number $transaction_id)"
        );
        if($response['result'] == 'success'){

          // clear verify token
          $token = [ "code" => "none", "expire_at" => Carbon::now()];
          $request->session()->put("token", $token);
          $result["status"] = "success";

          // Check balance
          $response1 = UltimopayAPI_v4::walletBalance();
          if ($response1["result"] === "success") {

            $result["message"] =  "You bought {$crypto_amount}&#8202;USDT successfully!";
            try {
              $this->sendCompletedMail($email, $transaction_id, $pay_amount, $crypto_amount);
              $email_status = 'sent';
            }
            catch (\Exception $e){
              Log::error('');
              Log::error('');
              Log::error("error in buyVerifyCode()");
              Log::error( $e->getTraceAsString());
              Log::error('');
              Log::error('');
              $result["message"] =  "You bought {$crypto_amount}&#8202;USDT successfully but failed to send complete email!";
              $email_status = 'failed';
            }
          }
          else {
            $result["message"] =  "Successes! But can not check wallet balance.";
          }

          $transactionStatus = "complete";
          $this->saveTransactionHistory(
            $email,
            $pay_amount,
            $crypto_amount,
            $transaction_id,
            $transactionStatus,
            $email_status);
        }
        else {
          $transactionStatus = "contact";
          $this->saveTransactionHistory(
            $email,
            $pay_amount,
            $crypto_amount,
            $transaction_id,
            $transactionStatus,
            $email_status);

          $response1 = UltimopayAPI_v4::walletBalance();
          if ($response1["result"] === "success")
            $result["message"] = "You failed in buying {$crypto_amount}&#8202;USDT!";
          else
            $result["message"] =  "Your session was expired. Please re-login and try again.";
        }
      }
      else {
        $transactionStatus = "Input Code";
        $this->saveTransactionHistory(
          $request->session()->get("email"),
          $request->session()->get('amount'),
          $request->session()->get('crypto_amount'),
          $request->session()->get("orderNo"),
          $transactionStatus,
          $email_status);

        $result["message"] = "The code was already expired!";
      }
    }
    else {
      $transactionStatus = "Input Code";
      $this->saveTransactionHistory(
        $request->session()->get("email"),
        $request->session()->get('amount'),
        $request->session()->get('crypto_amount'),
        $request->session()->get("orderNo"),
        $transactionStatus,
        $email_status);

      $result["message"] = "The code is not correct!";
    }

    return $result;
  }

  public function

  resendVerificationCode(Request $request): bool
  {
    try {
      //code...
      $verificationCode =  random_int(100000, 999999);
      $token = [ "code" => $verificationCode, "expire_at" => Carbon::now()->addMinutes(30)];
      $request->session()->put("token", $token);
      $email = $request->session()->get("email");
      $rawtext ="Verification code for buying ".
        $request->session()->get('crypto_amount').
        "USDT: ".
        $verificationCode.
        '<br/>(Order number: '.$request->session()->get("orderNo").')'.
        '<br><br>If you do not recognize this, <br>please contact support@ultimopay.io for assistance';

      Mail::send([], [], function ($message) use ($rawtext, $email) {
        $message->to($email)->subject('Please confirm your buy.');
        $message->from(env("ADMIN_EMAIL"), 'Ultimo Payment');
        $message->bcc(env("ADMIN_EMAIL"));
        $message->setBody($rawtext, 'text/html');
      });
      return true;
    } catch (\Throwable $th) {
      Log::error('');
      Log::error('');
      Log::error('error in resendVerificationCode()');
      Log::error('');
      Log::error('');
      return false;
    }
  }

  /*
   * Add or update transaction history
   *    If exist record that equal transaction_id, update it.
   *    Insert new record, else.
   * params
   *  $email: user account email
   *  $usd: payment amount
   *  $usdt: crypto amount
   *  $transaction_id: transaction id
   *  $status: One of 'complete', 'pending', 'contact', 'failed'
   * */
  private function saveTransactionHistory(
    $email,
    $usd,
    $usdt,
    $transaction_id,
    $status,
    $email_status,
    $pdf_status = null,
    $product_description = null,
    $controller_internal_id = null ){

    $report = Report::where('transaction_id', '=', $transaction_id)
      ->where('email', '=', $email)
      ->first();
    if( $report == null || $report->count() == 0 )
      $report = new Report();

    if( $email != null )
      $report->email = $email;

    if( $usd != null )
      $report->usd = $usd;

    if( $usdt != null )
      $report->usdt = $usdt;

    if( $transaction_id != null )
      $report->transaction_id = $transaction_id;

    if( $status != null )
      $report->status = $status;

    if( $pdf_status != null )
      $report->pdf_status = $pdf_status;

    if( $email_status != null )
      $report->email_status = $email_status;

    if( $product_description != null )
      $report->product_description = $product_description;

    if( $controller_internal_id != null )
      $report->controller_internal_id = $controller_internal_id;

    $report->save();
    return $report;
  }

  public function pdfTest(){
    $filename = $this->saveTransactionPDF('1697588615066');
    $rawtext = $filename.
      '<br><br>If you do not recognize this, <br>please contact support@ultimopay.io for assistance';
    $email = 'hamachandayori@icloud.com';
    Mail::send([], [], function ($message) use ($rawtext, $email,$filename) {
      $message->to($email)->subject('Test pdf.');
      $message->from(env("ADMIN_EMAIL"), 'Ultimo Payment');
      $message->setBody($rawtext, 'text/html');
      if($filename) $message->attach($filename);
    });
  }

  private function saveTransactionPDF($order_no, $email){
    // var_dump($order_no);
    $filename = '';
    $response = '';
    try {
      if( Utils::isUatUser($email))
        $inquiry = new \App\includes\UAT\api\Inquiry();
      else
        $inquiry = new \App\includes\PROD\api\Inquiry();
      $response = $inquiry->transactionDetails($order_no);
      $response = json_decode($response)->data[0];
    }
    catch (\Exception $e){
      Log::error('');
      Log::error('');
      Log::error('\n\n error in $inquiry->transactionDetails($order_no)\n\n');
      Log::error( $e->getTraceAsString());
      Log::error('');
      Log::error('');
      return $filename;
    }

    // var_dump($response);
    // exit;
    try {
      $date = date("Y-m-d H:i:s", strtotime($response->transactionDateTime)).' UTC';
      $product_description = $response->productDescription;
      $amount = number_format($response->transactionAmount->amount, 2);
      $qty = 1;
      $total_amount = $amount;
      $total_payment = $total_amount;
      $acct = $response->creditCardDetails->cardNumber;
      $card_holder_name = $response->creditCardDetails->payerName;

      require_once(app_path() . '/includes/pdf/fpdf/fpdf.php');
      require_once(app_path() . '/includes/pdf/fpdi2/src/autoload.php');
      // initiate FPDI
      $pdf = new Fpdi();
      //try to export pdf
      ///////////////////////////////////////////////////////////////////////////////////////////
      // get the page count
      $pageCount = $pdf->setSourceFile(app_path() . '/includes/pdf/tpl/e-sale-slip_template.pdf');
      $templateId = $pdf->importPage(1);

      $pdf->AddPage();
      $pdf->useImportedPage($templateId, 0, 17, 210, 268, false);
      $pdf->SetTextColor(0, 0, 0);
      // OrderNo
      $pdf->SetFont('Arial', 'B', 9);
      $pdf->SetXY(49, 64.8);
      $pdf->Write(0, $order_no);
      // Date
      $pdf->SetXY(40, 70.4);
      $pdf->Write(0, $date);
      //product_description
      $pdf->SetXY(25.7, 87.5);
      $pdf->Write(0, $product_description);
      //qty
      $pdf->SetXY(111.7, 87.5);
      $pdf->Write(0, $qty);
      //amount
      $pdf->SetXY(126, 84.5);
      $pdf->Cell(22, 5, '$' . $amount, 0, 0, 'R');
      //total_amount
      $pdf->SetXY(147.7, 84.5);
      $pdf->Cell(22, 5, '$' . $total_amount, 0, 0, 'R');

      $pdf->SetXY(147.7, 113);
      $pdf->Cell(22, 5, '$' . $total_amount, 0, 0, 'R');
      // acct
      $pdf->SetXY(58.7, 139.6);
      $pdf->Write(0, $acct);
      // card_holder_name
      $pdf->SetXY(87.7, 151);
      $pdf->Write(0, $card_holder_name);
      // total_payment
      $pdf->SetXY(147.7, 160);
      $pdf->Cell(22, 5, '$' . $total_payment, 0, 0, 'R');

      $filename = app_path() . '/includes/pdf/data/creditcard_' . $order_no . '.pdf';

      $pdf->Output($filename, 'F');
      sleep(1);

      return $filename;
    }
    catch (\Exception $e){
      Log::error('');
      Log::error('');
      Log::error('\n\n error in $inquiry->transactionDetails($order_no)\n\n');
      Log::error( $e->getTraceAsString());
      Log::error('');
      Log::error('');
      return $filename;
    }
  }


  public function mailTest(){
    $order_no = '1697588615066';
    $pay_amount = 2200;
    $crypto_amount = 2200;
    $email = 'hamachandayori@icloud.com';
    $this->sendCompletedMail($email,$order_no,$pay_amount,$crypto_amount);
  }

  private function sendCompletedMail($email,$order_no,$pay_amount,$crypto_amount){
    $date = date('Y-m-d H:i:s');
    $pay_amount = number_format($pay_amount,'2');
    $crypto_amount = number_format($crypto_amount,'2');

    $rawtext = "Greetings Valued Customer,<br><br>
    The following USDT purchases have been completed.<br>
    Please check your account balance.<br><br>

    OrderNumber {$order_no}<br>
    YOU PAID	$ {$pay_amount} USD<br>
    YOU PAID BY CreditCard/Debit Card<br>
    YOU GOT {$crypto_amount} USDT<br>
    EMAIL	{$email}<br>
    DATE	{$date} UTC<br><br>

    Kind regards,<br>
    Ultimo Team<br><br>

    CONFIDENTIALITY WARNING This message is intended only for the use of the individual or entity to which it is addressed and may contain information that is privileged, confidential and exempt from disclosure under applicable law.";

    Mail::send([], [], function ($message) use ($rawtext, $email) {
      $message->to($email)->subject('USDT purchases have been completed.');
      $message->from(env("ADMIN_EMAIL"), 'Ultimo Payment');
      $message->bcc(env("ADMIN_EMAIL"));
      $message->setBody($rawtext, 'text/html');
    });
  }

  private function checkOrderNo($orderNo){
    try {
      $inquiry = new \App\includes\PROD\api\Inquiry();
      $response = $inquiry->transactionDetails($orderNo);
      $response = json_decode($response)->data[0];
      return json_encode($response);
    }
    catch(\Exception $e){
    }
    return null;
  }

  /**
   * $orderNoDupChkType(default: true)
   *  if true, check if exist duplication orderNo in localDB
   *    this is used in payment-confirmation step when this orderNo used initially.
   *  if false, check if exist duplication orderNo and status is 'Input Code' in localDB
   *    this is used in buy-with-verify code when this orderNo already exists and did not proceed in shift.
   **/
  private function CheckPaymentValidation(Request $request, $usdt_balance, $orderNoDupChkType)
  {
    $orderNo = Utils::getInputValue('orderNo');
    if( $orderNo == null || strlen(trim($orderNo)) == 0 )
      $orderNo = $request->session()->get("orderNo");

    // Fetch current transaction from DB
    $report = Report::where('transaction_id', $orderNo)->first();

    // If there is no transaction with orderNo, this means that the transaction did not create by our system.
    if( !$report ){
      Log::info("Purchase error 01: $orderNo transaction try to confirmation, but it had not been created by our system.");

      // Redirect to buy page with failed status
      return view('/pages/buy', [
        'balance' => $usdt_balance,
        're_confirm' => true,
        'paymentSuccess' => false,
        'email' => $request->session()->get("email"),
        'merchant' => $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy"),
        'status' => 'paymentFailed',
        "paymentConfirm" => "You failed in buying {$request->session()->get('crypto_amount')}&#8202;USDT!",
        'message' => 'Error code: 01, Please contact the administrator to inquire about the reason for the failed buy USDT.'
        // This transaction did not create by our system
      ]);
    }

    // If the exist transaction's status is not 'None', this means that the processed transaction exists. Do nothing, just redirect.
    if( $orderNoDupChkType ) {
      $transaction_exist = Report::where('transaction_id', '=', $orderNo)
        ->where('status', '<>', 'None')
        ->where('status', '<>', 'Input Code')
        ->get()
        ->count();
      if ($transaction_exist) {
        $request->session()->put('id', null);
        Log::info("Purchase error 02: $orderNo transaction try to confirmation, but the another orderNo already exists in local DB.");

        // Redirect to buy page with failed status
        return view('/pages/buy', [
          'balance' => $usdt_balance,
          're_confirm' => true,
          'paymentSuccess' => false,
          'email' => $request->session()->get("email"),
          'merchant' => $request->session()->get("merchant"),
          'withdraw' => $request->session()->get('withdraw'),
          'deposit' => $request->session()->get('deposit'),
          'buy' => $request->session()->get("buy"),
          'status' => 'paymentFailed',
          "paymentConfirm" => "You failed in buying {$request->session()->get('crypto_amount')}&#8202;USDT!",
          'message' => 'Error code: 02, Please contact the administrator to inquire about the reason for the failed buy USDT.'
          // Already exist another orderNo in local DB
        ]);
      }
    }
    else{
      $transaction_exist = Report::where('transaction_id', '=', $orderNo)
        ->whereIn('status', ['complete'])
        ->get()
        ->count();
      if ($transaction_exist > 1) {
        $request->session()->put('id', null);
        Log::info("Purchase error 03: $orderNo transaction try to confirmation, but it had been already proceeded with 'completed' before.");

        // Redirect to buy page with failed status
        return view('/pages/buy', [
          'balance' => $usdt_balance,
          're_confirm' => true,
          'paymentSuccess' => false,
          'email' => $request->session()->get("email"),
          'merchant' => $request->session()->get("merchant"),
          'withdraw' => $request->session()->get('withdraw'),
          'deposit' => $request->session()->get('deposit'),
          'buy' => $request->session()->get("buy"),
          'status' => 'paymentFailed',
          "paymentConfirm" => "You failed in buying {$request->session()->get('crypto_amount')}&#8202;USDT!",
          'message' => 'Error code: 03, Please contact the administrator to inquire about the reason for the failed buy USDT.'
          // it had been already proceeded with 'completed' before.
        ]);
      }
    }

    // Check if orderNo is correct
    // 1. Whether orderNo has been published from JDB or not
    // 2. Whether orderNo was succeeded one or not.
    try {
      if(Utils::isUatUser($request->session()->get("email")))
        $inquiry = new \App\includes\UAT\api\Inquiry();
      else
        $inquiry = new \App\includes\PROD\api\Inquiry();
      $response = $inquiry->transactionDetails($orderNo);
      $response = json_decode($response)->data[0];
      if(Utils::isUatUser($request->session()->get("email")))
        $paymentStatus = $response->paymentStatusInfo->paymentStatus;
      else
        $paymentStatus = $response->paymentStatusInfo->paymentStatus;

      if( $response == null || ($paymentStatus != 'S' && $paymentStatus != 'A' )) {
        $request->session()->put('id', null);
        Log::info("Purchase error 04: $orderNo transaction try to confirmation, but it had not been approved in JDB.");

        $report->status = "contact";
        $report->reason = 4;
        $report->save();

        // Redirect to buy page with failed status
        return view('/pages/buy', [
          'balance' => $usdt_balance,
          're_confirm' => true,
          'paymentSuccess' => false,
          'email' => $request->session()->get("email"),
          'merchant' => $request->session()->get("merchant"),
          'withdraw' => $request->session()->get('withdraw'),
          'deposit' => $request->session()->get('deposit'),
          'buy' => $request->session()->get("buy"),
          'status' => 'paymentFailed',
          "paymentConfirm" => "You failed in buying {$request->session()->get('crypto_amount')}&#8202;USDT!",
          'message' => 'Error code: 04, Please contact the administrator to inquire about the reason for the failed buy USDT.'
          // it had not been approved in JDB
        ]);
      }
    } catch (\Exception $e) {
      Log::error('error in $inquiry->transactionDetails('.$orderNo.'); in CheckPaymentValidation(), transaction_id: '.$orderNo.', user: '.$request->session()->get("email"));
      Log::error('detailed error: '.$e->getMessage());
      $request->session()->put('id', null);
      Log::info("Purchase error 05: $orderNo transaction try to confirmation, but there is no orderNo in JDB.");

      $report->status = "contact";
      $report->reason = 5;
      $report->save();

      // Redirect to buy page with failed status
      return view('/pages/buy', [
        'balance' => $usdt_balance,
        're_confirm' => true,
        'paymentSuccess' => false,
        'email' =>  $request->session()->get("email"),
        'merchant' => $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy"),
        'status'=>'paymentFailed',
        "paymentConfirm" => "You failed in buying {$request->session()->get('crypto_amount')}&#8202;USDT!",
        'message'=>'Error code: 05, Please contact the administrator to inquire about the reason for the failed buy USDT.'
        // There is no orderNo in JDB.
      ]);
    }

    // Check amount from JDB and user tried one.
    if(Utils::isUatUser($request->session()->get("email")))
      $paymentAmount = $response->transactionAmount->amount;
    else
      $paymentAmount = $response->transactionAmount->amount;

    if( $paymentAmount != $request->session()->get('amount')){
      $request->session()->put('id', null);
      Log::info("Purchase error 06: $orderNo transaction try to confirmation, but user tried amount is not match with JDB transaction amount.");

      $report->status = "contact";
      $report->reason = 6;
      $report->save();

      // Redirect to buy page with failed status
      return view('/pages/buy', [
        'balance' => $usdt_balance,
        're_confirm' => true,
        'paymentSuccess' => false,
        'email' =>  $request->session()->get("email"),
        'merchant' => $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy"),
        'status'=>'paymentFailed',
        "paymentConfirm" => "You failed in buying {$request->session()->get('crypto_amount')}&#8202;USDT!",
        'message'=>'Error code: 06, Please contact the administrator to inquire about the reason for the failed buy USDT.'
        // User tried amount is not match with JDB transaction amount.
      ]);
    }

    // Check if shift already processed this orderNo or not.
    $response = UltimopayAPI_v4::getTransaction( $orderNo );
    if($response['result'] == 'success'){
      $data = $response['data'];
      if( count($data) > 0 ){
        $request->session()->put('id', null);
        Log::info("Purchase error 07: $orderNo transaction try to confirmation, but this orderNo has been already proceeded from Shift.");

        $report->status = "contact";
        $report->reason = 7;
        $report->save();

        // Redirect to buy page with failed status
        return view('/pages/buy', [
          'balance' => $usdt_balance,
          're_confirm' => true,
          'paymentSuccess' => false,
          'email' =>  $request->session()->get("email"),
          'merchant' => $request->session()->get("merchant"),
          'withdraw' => $request->session()->get('withdraw'),
          'deposit' => $request->session()->get('deposit'),
          'buy' => $request->session()->get("buy"),
          'status'=>'paymentFailed',
          "paymentConfirm" => "You failed in buying {$request->session()->get('crypto_amount')}&#8202;USDT!",
          'message'=>'Error code: 07, Please contact the administrator to inquire about the reason for the failed buy USDT.'
          // This orderNo has been already proceeded from Shift
        ]);
      }
    } else {
      $request->session()->put('id', null);
      Log::info("Purchase error 08: $orderNo transaction try to confirmation, Can not check if this orderNo has been already proceeded from Shift or not, because error occured while checking that.");

      $report->status = "contact";
      $report->reason = 8;
      $report->save();

      // Redirect to buy page with failed status
      return view('/pages/buy', [
        'balance' => $usdt_balance,
        're_confirm' => true,
        'paymentSuccess' => false,
        'email' =>  $request->session()->get("email"),
        'merchant' => $request->session()->get("merchant"),
        'withdraw' => $request->session()->get('withdraw'),
        'deposit' => $request->session()->get('deposit'),
        'buy' => $request->session()->get("buy"),
        'status'=>'paymentFailed',
        "paymentConfirm" => "You failed in buying {$request->session()->get('crypto_amount')}&#8202;USDT!",
        'message'=>'Error code: 08, Please contact the administrator to inquire about the reason for the failed buy USDT.'
        // Can not check if this orderNo has been already proceeded from Shift or not, because error occured while checking that.
      ]);
    }

    // Check if order number is valid transaction number
    $previousReport = Report::where('id', '<', $report->id)
      ->orderByDesc('id')
      ->first();
    if( $previousReport != null ){
      $previousTransactionId = $previousReport->transaction_id;
      if( $previousTransactionId > $orderNo ) {

        $request->session()->put('id', null);
        Log::info("Purchase error 09: $orderNo transaction try to confirmation, but transactionId value is less than previous one.");

        $report->status = "contact";
        $report->reason = 9;
        $report->save();

        // Redirect to buy page with failed status
        return view('/pages/buy', [
          'balance' => $usdt_balance,
          're_confirm' => true,
          'paymentSuccess' => false,
          'email' => $request->session()->get("email"),
          'merchant' => $request->session()->get("merchant"),
          'withdraw' => $request->session()->get('withdraw'),
          'deposit' => $request->session()->get('deposit'),
          'buy' => $request->session()->get("buy"),
          'status' => 'paymentFailed',
          "paymentConfirm" => "You failed in buying {$request->session()->get('crypto_amount')}&#8202;USDT!",
          'message' => 'Error code: 09, Please contact the administrator to inquire about the reason for the failed buy USDT.'
          // TransactionId value is less than previous one.
        ]);
      }
    }

    // If 'Input Code' status and did not proceed, redirect it to input code page
    if( $orderNoDupChkType ) {
      if ($report->status == 'Input Code') {
        Log::info("Purchase error 10: $orderNo transaction try to confirmation, but this transaction needs input confirmation code, will redirect to input code page.");
        // Return to confirmation page
        return view('/pages/buy', [
          'balance' => $usdt_balance,
          'paymentSuccess' => true,
          'email' => $request->session()->get("email"),
          'merchant' => $request->session()->get("merchant"),
          'withdraw' => $request->session()->get('withdraw'),
          'deposit' => $request->session()->get('deposit'),
          'buy' => $request->session()->get("buy"),
          'showVerifyDialog' => true,
          'date' => $report->created_at,
          'orderNo' => $orderNo,
          'paid' => $report->usd,
          'received' => $report->usdt,
          // redirect it to input code page
        ]);
      }
    }

    return null;
  }
}

