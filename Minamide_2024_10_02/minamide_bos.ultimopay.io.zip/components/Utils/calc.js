export function truncateFloat(number, decimalPlaces) {
    const factor = Math.pow(10, decimalPlaces);
    return parseFloat((Math.trunc(number * factor) / factor).toFixed(decimalPlaces));
}

export function truncateFloat1(number, decimalPlaces) {
    // Convert the number to a string and split it at the decimal point
    let parts = number.toString().split(".");

    // If there is no decimal part, add an empty string to parts[1]
    if (parts.length === 1) {
        parts.push("");
    }

    // Slice the decimal part to the specified number of decimal places
    // and pad with zeros if necessary
    parts[1] = (parts[1] + "0".repeat(decimalPlaces)).slice(0, decimalPlaces);

    // Join the integer and decimal parts back together
    return parts.join(".");
}

export function maskEmail(email) {
    const [localPart, domain] = email.split('@');

    const maskedLocalPart = localPart.slice(0, 2) + '*'.repeat(localPart.length - 2);
    const [domainName, domainExt] = domain.split('.');
    const maskedDomainName = '*'.repeat(domainName.length);

    return `${maskedLocalPart}@${maskedDomainName}.${domainExt}`;
}
