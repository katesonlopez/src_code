import Head from "next/head";
import Link from "next/link";
import withoutAuth from "/hooks/withoutAuth";
import Cookies from "js-cookie";
import { useState, useEffect } from "react";
import Waiting from "../../components/Waiting";
const Main = (props) => {
  const [isLoading, setIsLoading] = useState(true);
  const affid = getAffId("AffRefId");

  useEffect(() => {
    const AffRefId = document.getElementById("AffRefId");
    if (AffRefId) {
      AffRefId.value = affid;
    }
  }, [affid]);
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    setAffRefIdCookie();
    return () => clearTimeout(timer);
  }, []);
  function setAffRefIdCookie() {
    const rid = new URLSearchParams(window.location.search).get("rid");
    if (rid && rid.trim() !== "") {
      Cookies.set("AffRefId", rid.trim(), {
        expires: 7300, // set the cookie to expire in 20 years
        path: "/",
        domain: ".bitquick.io",
      });
    }
  }
  function getAffId(cname) {
    const refId = Cookies.get(cname);

    if (refId) {
      console.log(`The 'AffRefId' cookie is set with value: ${refId}`);
      return refId;
    } else {
      console.log("The 'AffRefId' cookie is not set");
      return "";
    }
  }
  return (
    <>
      <Head>
        <title>BitQuick</title>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta
          httpEquiv="Content-Security-Policy"
          content="upgrade-insecure-requests"
        />
        <link
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
          rel="stylesheet"
        />
        <link rel="icon" href="/favicon.ico" />
        <link rel="stylesheet" type="text/css" href="/assets/css/style.css" />
        <link href="/assets/css/inner.css" type="text/css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
        />
      </Head>
      {/* navbar */}
      {isLoading ? (
        <div/>
      ) : (
        <>
          <nav
            className="navbar navbar-expand-lg"
            style={{ backgroundColor: "#3e8eaf" }}
          >
            <div className="container justify-content-between">
              <Link href="/" className="d-block">
                <img width="150" height="*" src="/assets/img/whitelogo.png" />
              </Link>
              <button
                style={{ backgroundColor: "white !important" }}
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon" />
              </button>
              <div
                className="collapse navbar-collapse my-4 justify-content-end"
                id="navbarSupportedContent"
              >
                <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                </ul>
                <form className="d-flex">
                  <Link
                    className="button primary size-xl"
                    href={`/${props.page === "SIGN UP" ? "register" : ""}`}
                  >
                    {props.page ? props.page : "SIGN UP"}
                  </Link>
                </form>
              </div>
            </div>
          </nav>
          {props.children}
          <div className="login-footer">
            <footer>
              <div className="container-fluid">
                <div className="row">
                  <div className="col-sm-2">
                    <form>
                      <fieldset>
                        <div className="mt-12">
                          <select
                            id="disabledSelect"
                            className="form-control text-center slc-ftr w-100"
                          >
                            <option>English</option>
                          </select>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                  <div className="col-sm-6 last-footer mt-4 pb-2" style={{fontSize:'12px'}}>
                    Copyright © 2024&nbsp;&nbsp; | &nbsp;&nbsp;bitquick.io&nbsp;&nbsp; | &nbsp;&nbsp;All Rights Reserved.
                  </div>
                  <div className="col-sm-4 ps-5 text-end">
                    <div className="mt-4">
                      <a href="mailto:support@bitquick.io">
                        <img src="/assets/img/mail.png" width="20px;" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </footer>
          </div>
        </>
      )}
    </>
  );
};

export default withoutAuth(Main);
