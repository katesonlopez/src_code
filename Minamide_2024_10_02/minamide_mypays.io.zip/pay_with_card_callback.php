<?php
// Display all errors
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Report all errors
error_reporting(E_ALL);

require_once 'includes/db.php';
require_once 'extAPIs/kaiserApi.php';

// Get query parameters from the current URL
$requestUri = $_SERVER['REQUEST_URI'];
$queryParams = parse_url($requestUri, PHP_URL_QUERY);

// Parse query parameters into an associative array
parse_str($queryParams, $params);

// Access individual parameters
$cmd = $params['cmd'] ?? null;
$orderNo = $params['orderNo'] ?? null;
$productDescription = isset($params['productDescription']) ? str_replace('+', ' ', $params['productDescription']) : null;
$controllerInternalId = $params['controllerInternalId'] ?? null;

$title = 'Payment Callback';
$description = 'Payment Callback Message';

// Call kaiser API to add new report
$kaiserTransaction = getKaiserReport( $orderNo );
$kaiserTransaction = $kaiserTransaction['body']['data'];
if( count($kaiserTransaction) > 0 )
  addNewReport( $kaiserTransaction[0], $controllerInternalId );

if( $cmd == 'payment-confirmation' ) {
  $title = '<span class="text-success"><i class="fa fa-check"></i> Payment Successful</span>';
  $description = '<span class="text-success">Thank you! Your payment has been successfully processed. Your order will be processed shortly.</span>';
} else if( $cmd == 'payment-failed' ) {
  $title = '<span class="text-danger"><i class="fa fa-times-circle"></i> Payment Failed</span>';
  $description = '<span class="text-danger">We’re sorry, but your payment could not be processed at this time. Please try again later.</span>';
} else if( $cmd == 'payment-cancellation' ) {
  $title = '<span class="text-warning"><i class="fa fa-ban"></i> Payment Cancelled</span>';
  $description = '<span class="text-danger">Your payment has been cancelled. If you did this by mistake, please try again.</span>';
} else if( $cmd == 'payment-backend' ) {
  $title = '<span class="text-secondary"><i class="fa fa-info-circle"></i> Payment Callback</span>';
  $description = '<span class="text-secondary">Payment processed</span>';
}

function getKaiserReport( $orderNo )
{
  // Call kaiser API to report
  $response = callApiGet( 'getReport', ['orderNo' => $orderNo] );
  return json_decode( $response, true);
}

function addNewReport($kaiserTransaction, $controllerInternalId)
{
  // Check if already exists in local database
  $conn = getDbConnection();
  // Check if connection was successful
  if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
  }

  $orderNo = $conn->real_escape_string($kaiserTransaction['orderNo']);

  $sql = "SELECT * FROM reports WHERE transaction_id = '$orderNo'";
  $result = $conn->query($sql);

  $nullValue = 'NULL';
  $zeroValue = 0;

  if ($result->num_rows > 0) {
    // Update the existing record
    $email = $conn->real_escape_string($kaiserTransaction['email_address']);
    $amount = $kaiserTransaction['amount'];
    $fee = $kaiserTransaction['fee'];
    $cardHolderName = $conn->real_escape_string($kaiserTransaction['card_holder_name']);
    $status = $conn->real_escape_string($kaiserTransaction['status']);
    $emailSent = $conn->real_escape_string($kaiserTransaction['email_sent']);
    $productName = $conn->real_escape_string($kaiserTransaction['product_name']);
    $controllerInternalIdEscaped = $conn->real_escape_string($controllerInternalId);

    $sql = "
      UPDATE reports SET 
        email = '$email', 
        usd = $amount, 
        fee = $fee, 
        usdt = $zeroValue, 
        card_holder_name = '$cardHolderName', 
        status = '$status', 
        pdf_status = $nullValue, 
        email_status = '$emailSent', 
        product_description = '$productName', 
        controller_internal_id = '$controllerInternalIdEscaped', 
        reason = $zeroValue, 
        updated_at = NOW() 
      WHERE transaction_id = '$orderNo'
    ";

    if (!$conn->query($sql)) {
      // Log or handle the error
      echo('Update Error: ' . $conn->error);
    }
  } else {
    // Insert a new record
    $email = $conn->real_escape_string($kaiserTransaction['email_address']);
    $amount = $kaiserTransaction['amount'];
    $fee = $kaiserTransaction['fee'];
    $cardHolderName = $conn->real_escape_string($kaiserTransaction['card_holder_name']);
    $status = $conn->real_escape_string($kaiserTransaction['status']);
    $emailSent = $conn->real_escape_string($kaiserTransaction['email_sent']);
    $productName = $conn->real_escape_string($kaiserTransaction['product_name']);
    $controllerInternalIdEscaped = $conn->real_escape_string($controllerInternalId);

    $sql = "
      INSERT INTO reports (
        email,
        usd,
        fee,
        usdt,
        transaction_id,
        card_holder_name,
        status,
        pdf_status,
        email_status,
        product_description,
        controller_internal_id,
        reason,
        created_at,
        updated_at
      ) VALUES (
        '$email', 
        $amount, 
        $fee, 
        $zeroValue, 
        '$orderNo', 
        '$cardHolderName', 
        '$status', 
        $nullValue, 
        '$emailSent', 
        '$productName', 
        '$controllerInternalIdEscaped', 
        $zeroValue, 
        NOW(), 
        NOW()
      )
    ";

    if (!$conn->query($sql)) {
      // Log or handle the error
      echo('Insert Error: ' . $conn->error);
    }
  }

  // Close the connection
  $conn->close();
}


global $baseUrl;
echo $baseUrl;
include 'includes/header.php';
?>

<!-- Container start -->
<div class="main-content container d-flex justify-content-center">
  <div class="col-12 col-md-10 col-lg-12">
    <h3 class="text-center mt-4 mb-4">Payment Status</h3>

    <!-- Start payment status section -->
    <div class="card blue-boarder mt-4 mb-4">

      <div class="card-header bg-primary-opacity">
        <div class="panel-list">
          <div class="panel-list-left font-weight-bold fs-6">
            Payment Status Report
          </div>
        </div>
      </div>

      <div class="card-body justify-content-center align-content-center">
        <h5 class="font-weight-bold"><?php echo $title; ?></h5>
        <div class="">
          <?php echo $description; ?>
        </div>
        <hr>
        <div class="mt-3">
          <div class="text-secondary">Order Number: </div>
          <p class="pl-4"><?php echo $orderNo; ?></p>
        </div>
        <div class="mt-3">
          <div class="text-secondary">Product Description: </div>
          <p class="pl-4"><?php echo $productDescription; ?></p>
        </div>
      </div>

      <div class="card-footer text-right">
        <a href="<?php echo $baseUrl; ?>dashboard.php" class="btn btn-primary" type="button" id="btnAddressCopy">
          <i class="fa fa-home"></i> Back to Home
        </a>
      </div>
    </div>
    <!-- End payment status section -->

  </div>
</div>
<!-- Container end -->

<?php include 'includes/footer.php'; ?>
