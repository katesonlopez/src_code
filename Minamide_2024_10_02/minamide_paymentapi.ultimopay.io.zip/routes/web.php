<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'AdminController@showLoginPage')->name('page.login');
Route::get('/login', 'AdminController@showLoginPage')->name('login');
Route::post('/login', 'AdminController@login')->name('admin.login');

Route::get('/payment-confirmation', 'JdbController@confirmation')->name('page.confirmation');
Route::get('/payment-failed', 'JdbController@failed')->name('page.cancellation');
Route::get('/payment-cancellation', 'JdbController@cancellation')->name('page.failed');
Route::get('/payment-backend', 'JdbController@backend')->name('page.backend');

Route::get('/ultimo-payment-confirmation', 'PaymentController@ultimoPaymentConfirmation')->name('ultimoPaymentConfirmation');
Route::get('/ultimo-payment-failed', 'PaymentController@ultimoPaymentFailed')->name('ultimoPaymentFailed');
Route::get('/ultimo-payment-cancellation', 'PaymentController@ultimoPaymentCancellation')->name('ultimoPaymentCancellation');
Route::get('/ultimo-payment-backend', 'PaymentController@ultimoPaymentBackend')->name('ultimoPaymentBackend');

Route::middleware(['auth'])->group(function () {

    // Protected routes
    Route::get('/admin/reset-password-page', 'AdminController@showResetPasswordPage')->name('admin.resetPasswordPage');
    Route::post('/admin/reset-password', 'AdminController@resetPassword')->name('admin.resetPassword');
    Route::get('/admin/logout', 'AdminController@logout')->name('admin.logout');

    Route::get('/admin/apikey', 'ApiKeyController@showDashboard')->name('page.apikey.dashboard');
    Route::post('/admin/apikey-add-partner', 'ApiKeyController@addNewPartner')->name('apikey.add.partner');
    Route::post('/admin/apikey-get-partner', 'ApiKeyController@getPartner')->name('apikey.get.partner');
    Route::post('/admin/apikey-update-partner', 'ApiKeyController@updatePartner')->name('apikey.update.partner');
    Route::post('/admin/apikey-delete-partner', 'ApiKeyController@deletePartner')->name('apikey.delete.partner');
    Route::post('/admin/apikey-get-apikey', 'ApiKeyController@getApiKey')->name('apikey.get.apikey');
    Route::post('/admin/apikey-apply-apikey', 'ApiKeyController@applyApiKey')->name('apikey.apply.apikey');

    Route::get('/admin/home', 'JdbController@payment')->name('page.home');
    Route::get('/admin/paymentPage', 'JdbController@payment')->name('page.payment');
    Route::get('/admin/reportPage', 'JdbController@report')->name('page.report');
});
