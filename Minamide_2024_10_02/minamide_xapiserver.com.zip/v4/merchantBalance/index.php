<?php
mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
	
	//global $fh;
	if ($email == "") {
		$fh2 = fopen("/var/www/api.ultimopay.io/v4-dev/merchantBalance/log/merchant_balance.log" , 'a');
	} else {
		$fh2 = fopen("/var/www/api.ultimopay.io/v4-dev/walletBalance/log/" . $email . ".log" , 'a');
	}		
	$fline = date('[Ymd H:i:s] ') . $line."\n";
	fwrite($fh2, $fline);
	fclose($fh2);
	//echo date('[Ymd H:i:s] ').$line."\n";
	//@ob_flush(); 
	//flush();
	
	}
	
	
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		_log("", "ket noi thanh cong");
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$allowed_deposit_currency_arr = array('USDT');
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			/*
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				break;
			} else if ($value == $apikey_freelancer) {
				$found = 7;
				$coin = 'USDT';
				break;
			}
			*/
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
					
				}
			} else {
				_log("", "not found in db");
			}
		}
	}
	@mysqli_close($dbhandle);



	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}

	function generateRandomString($length, $bitmask) {
		$uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$lowercase = 'abcdefghijklmnopqrstuvwxyz';
		$numbers = '0123456789';
		$special  = '_.-';   
		$characters = '';
		$characters .= $uppercase . $lowercase . $numbers . $special;
		/*
		if ($bitmask & 1) {
		$characters .= $uppercase;
		}      
		if ($bitmask & 2) {
		$characters .= $lowercase;
		}
		if ($bitmask & 4) {
		$characters .= $numbers;
		}
		if ($bitmask & 8) {
		$characters .= $special;
		}

		if (!$characters) {
		$characters = $uppercase . $lowercase;
		}
		*/
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
		  $randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	function merchant_signin($username, $pwd) {
		$signin_res = array('auth_token' => '', 'auth_refresh_token' => '', 'wallet_auth_token' => '', 'wallet_auth_refresh_token' => '', 'error' => '', 'token_expires_in' => 0);
		$signin_data = array();
		$signin_data['username'] = $username;
		$signin_data['password'] = $pwd;
		$signin_data['exchange'] = "PLUSQO";
		$shift_signin_res = api_call('/authentication/user_authentication/exchangeToken', 0, '', $signin_data, '');				
		if ($shift_signin_res['result']['result'] == 'success') {
			
			
			$signin_res['auth_token'] = (!is_null($shift_signin_res['result']['exchange_access_token']))?trim($shift_signin_res['result']['exchange_access_token']):'';
			$signin_res['auth_refresh_token'] =  (!is_null($shift_signin_res['result']['exchange_refresh_token']))?trim($shift_signin_res['result']['exchange_refresh_token']):'';
			$signin_res['wallet_auth_token'] = (!is_null($shift_signin_res['result']['client_access_token']))?trim($shift_signin_res['result']['client_access_token']):'';
			$signin_res['wallet_auth_refresh_token'] =  (!is_null($shift_signin_res['result']['client_refresh_token']))?trim($shift_signin_res['result']['client_refresh_token']):'';
			$signin_res['token_expires_in'] =  (!is_null($shift_signin_res['result']['expires_in']))?intval($shift_signin_res['result']['expires_in']):0;
			
			
		} else {
			/*
			$error_message = 'error occurred. please contact administrator for help.';
			$res_code = 500;
			$error_code = 999;
			_log("", $merchant_signin_res['result']['message']);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
			header('Content-Type: application/json');
			http_response_code($res_code);
			echo json_encode($ret_rs);
			die();
			*/
			if ( strpos(strtolower($shift_signin_res['result']['message']), "incorrect username or password") !== false ) {
				$signin_res['error'] = 'invalid_credentials';				
			} else if ( strpos(strtolower($shift_signin_res['result']['message']), "invalid credentials") !== false ) {
				$signin_res['error'] = 'invalid_credentials';
			} else if ( strpos(strtolower($shift_signin_res['result']['message']), "could not connect to PLUSQO") !== false ) {
				$signin_res['error'] = 'system_under_maintenance';
			} else if ( strpos(strtolower($login_first_res['result']['message']), "2fa required") !== false ) {
				$signin_res['error'] = '2fa_required';
			} else if ( strpos(strtolower($login_first_res['result']['message']), "2fa code invalid") !== false ) {
				$signin_res['error'] = '2fa_code_invalid';
			} else {
				$signin_res['error'] = 'system_under_maintenance';				
			}
		}
		return $signin_res;
	}
	
	//if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6)) {
	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

		require_once '../include/common.php';
		//require_once '../include/dbconfig.php';

		$allow_access_api = 0;
		$allowed_shift_currency_arr = array('USDT', 'BTC', 'USD');
		$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
		if (mysqli_connect_errno() == 0) {
			
			mysqli_query($dbhandle, "set names utf8;");
			
			$merchant = '';
			////$merchant = ($found==6)?'LUCKY8':'';
			//if ($found == 6) {
			//	$merchant = 'UltimoCasino';
			//}
			$shift_wallet_arr = array();
			//$master_account_auth_token = '';
			//$master_account_auth_refresh_token = '';
			//$master_account_sigin_dt = '';
			//$master_account_token_refresh_dt = '';	

			$is_fresh_shift_signin = 0;
			$shift_auth_token =	'';	
			$shift_auth_refresh_token =	'';	
			$shift_wallet_auth_token =	'';	
			$shift_wallet_auth_refresh_token ='';	
			$shift_account_sigin_dt = '';
			$shift_account_token_refresh_dt = '';
			$shift_account_token_expires_in = 0;
			
			$sql_check_signin = "select a.*, b.shift_account_currency, b.address, b.address_usdt_tron, b.address_usdt_binance, b.network, b.balance, b.added_dt, b.added_dt_tron, b.added_dt_binance from cryptocash_merchant_user_signin a, cryptocash_shift_wallet b where a.email_address = '" . ULTIMOCASINO_MASTER_EMAIL . "' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_login_email";
			$rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
			if (mysqli_num_rows($rs_check_signin) >= 1) { //allow access API
				while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
					
					$shift_auth_token = trim($row_signin['auth_token']);
					$shift_auth_refresh_token = trim($row_signin['auth_refresh_token']);
					$shift_wallet_auth_token = trim($row_signin['wallet_auth_token']);
					$shift_wallet_auth_refresh_token = trim($row_signin['wallet_auth_refresh_token']);
					$shift_account_sigin_dt = $row_signin['signin_dt'];
					$shift_account_token_refresh_dt = $row_signin['token_refresh_dt'];
					$shift_account_token_expires_in = intval($row_signin['token_expires_in']);
					
				}
				
			} else {
				//first login by shift api
				_log("", 'try sign in by shift api...');
				////////////////////////////////////////////////////////////
				$signin_res = merchant_signin(ULTIMOCASINO_MASTER_EMAIL, ULTIMOCASINO_MASTER_PASSWORD);
				if ($signin_res['error'] == '') {
					if ($signin_res['auth_token'] != '') {
						$shift_auth_token = trim($signin_res['auth_token']);
						$shift_auth_refresh_token = trim($signin_res['auth_refresh_token']);
						$shift_wallet_auth_token = trim($signin_res['wallet_auth_token']);
						$shift_wallet_auth_refresh_token = trim($signin_res['wallet_auth_refresh_token']);
						$shift_account_token_expires_in = intval($signin_res['token_expires_in']);
						
						//insert to db
						$the_private_key = generateRandomString(128, 0);
						$sql_add_master_signin = "INSERT INTO cryptocash_merchant_user_signin (email_address, auth_token, auth_refresh_token, wallet_auth_token, wallet_auth_refresh_token, merchant, private_key, token_expires_in) VALUES ('" . ULTIMOCASINO_MASTER_EMAIL . "', '$shift_auth_token', '$shift_auth_refresh_token', '$shift_wallet_auth_token', '$shift_wallet_auth_refresh_token', '" . $req_partner['partner'] . "', '$the_private_key', $shift_account_token_expires_in)";
						//mysqli_query($dbhandle, $sql_add_master_signin);
						if (!mysqli_query($dbhandle, $sql_add_master_signin)) {
							//echo("Error description: " . mysqli_error($con));														
							$error_message = 'error occurred. please contact administrator for help.';
							$res_code = 500;
							$error_code = 2;
							_log("", "failed to insert cryptocash_merchant_user_signin : " . mysqli_error($dbhandle));
							@mysqli_close($dbhandle);
							$ret_rs['result'] = 'failed';
							$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
							header('Content-Type: application/json');
							http_response_code($res_code);
							echo json_encode($ret_rs);
							die();
						} else {
							if (mysqli_affected_rows($dbhandle) > 0) {
							_log("", "insert cryptocash_merchant_user_signin ok for " . ULTIMOCASINO_MASTER_EMAIL);
								$is_fresh_shift_signin = 1;
											
							} else {
															
								$error_message = 'error occurred. please try again or contact administrator for help';
								$res_code = 500;
								$error_code = 999;
								_log("", "failed to insert cryptocash_merchant_user_signin : " . mysqli_error($dbhandle));
								@mysqli_close($dbhandle);
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
								header('Content-Type: application/json');
								http_response_code($res_code);
								echo json_encode($ret_rs);
								die();
							}
						}
						
						
						
					} else {
						@mysqli_close($dbhandle);
						_log("", "auth_token returns empty!");
						$error_message = 'error occurred. please try again or contact administrator for help.';
						$res_code = 500;
						$error_code = 1;
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
						header('Content-Type: application/json');
						http_response_code($res_code);
						echo json_encode($ret_rs);
						die();
					}
					
				} else {		
					@mysqli_close($dbhandle);
					_log("", $signin_res['error']);
					$error_message = 'error occurred. please try again or contact administrator for help.';
					$res_code = 500;
					$error_code = 1;
					$ret_rs['result'] = 'failed';
					$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
					header('Content-Type: application/json');
					http_response_code($res_code);
					echo json_encode($ret_rs);
					die();
				}
				////////////////////////////////////////////////////////////				
				
			}
			
						
				
			///////////////////////////////////////////////////////////////////////////			
			if ($shift_auth_token != '') {
				
				if ($is_fresh_shift_signin == 0) {
					//check whether current token has expired, if so, try to sign in again
					$curtime = time();
					$shift_account_sigin_dt_tm = strtotime($shift_account_sigin_dt);
					$tmp_expires_in = $shift_account_token_expires_in - 60;
					_log("", $curtime . " / " . $shift_account_sigin_dt_tm . " / " . $tmp_expires_in);
					if ($tmp_expires_in > 0) {
						if ($curtime - $shift_account_sigin_dt_tm > $tmp_expires_in) { //need to sign in again
						//if ($curtime - $shift_account_sigin_dt_tm > 500) { //need to sign in again
						
							_log("", "token expired ! try to sign in again...");
							/////////////////////////////////////////////////							
							$signin_res = merchant_signin(ULTIMOCASINO_MASTER_EMAIL, ULTIMOCASINO_MASTER_PASSWORD);
							if ($signin_res['error'] == '') {
								if ($signin_res['auth_token'] != '') {
									$shift_auth_token = trim($signin_res['auth_token']);
									$shift_auth_refresh_token = trim($signin_res['auth_refresh_token']);
									$shift_wallet_auth_token = trim($signin_res['wallet_auth_token']);
									$shift_wallet_auth_refresh_token = trim($signin_res['wallet_auth_refresh_token']);
									$shift_account_token_expires_in = intval($signin_res['token_expires_in']);
									
									//update db									
									$update_signin_dt = date('Y-m-d H:i:s');
									$sql_update_signin = "UPDATE cryptocash_merchant_user_signin SET auth_token='$shift_auth_token', auth_refresh_token='$shift_auth_refresh_token', wallet_auth_token='$shift_wallet_auth_token', wallet_auth_refresh_token='$shift_wallet_auth_refresh_token', signin_dt='$update_signin_dt', token_refresh_dt = NULL, token_expires_in=$shift_account_token_expires_in WHERE email_address='" . ULTIMOCASINO_MASTER_EMAIL . "' AND merchant='" . $req_partner['partner'] . "' LIMIT 1";
									_log("", $sql_update_signin);
									if (!mysqli_query($dbhandle, $sql_update_signin)) {
										$error_message = 'error occurred. please contact administrator for help.';
										$res_code = 500;
										$error_code = 2;
										_log("", "failed to update cryptocash_merchant_user_signin : " . mysqli_error($dbhandle));
										@mysqli_close($dbhandle);
										$ret_rs['result'] = 'failed';
										$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
										header('Content-Type: application/json');
										http_response_code($res_code);
										echo json_encode($ret_rs);
										die();
									}
									
								} else {
									@mysqli_close($dbhandle);
									_log("", "auth_token returns empty!");
									$error_message = 'error occurred. please try again or contact administrator for help.';
									$res_code = 500;
									$error_code = 1;
									$ret_rs['result'] = 'failed';
									$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
									header('Content-Type: application/json');
									http_response_code($res_code);
									echo json_encode($ret_rs);
									die();
								}
								
							} else {		
								@mysqli_close($dbhandle);
								_log("", $signin_res['error']);
								$error_message = 'error occurred. please try again or contact administrator for help.';
								$res_code = 500;
								$error_code = 1;
								_log("", $merchant_signin_res['result']['message']);
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
								header('Content-Type: application/json');
								http_response_code($res_code);
								echo json_encode($ret_rs);
								die();
							}
							/////////////////////////////////////////////////
						}
					}
					
				}
				
				//try using shift api to get wallet balance
				////////////////////////////////////////////////////////////////////////
				$nonce = millitime();
				$nonce = $nonce + 1;
				$tmp_dto_arr = array();
				$authorization_value = "Bearer " . $shift_auth_token;
				$accounts_res = api_call('/api/v1/accounts', $nonce, '', $tmp_dto_arr, $authorization_value);
				if (($accounts_res['http_code'] == "200") || ($accounts_res['http_code'] == "200 OK")) {
					if (is_array($accounts_res['result'])) {
						/////////////////////////////////////////////////////////
						$accounts_arr = $accounts_res['result'];
						if (count($accounts_arr) > 0) {
							_log("", "/api/v1/accounts: ok vao roi");
							
							for ($coin_cnt=0; $coin_cnt<count($accounts_arr); $coin_cnt++) {
								$cur_coin_stat = $accounts_arr[$coin_cnt];
								unset($shift_wallet_obj);
								$shift_wallet_obj = array('currency' => '', 'balance' => 0);
								if ( (!is_null($cur_coin_stat['id'])) && (!is_null($cur_coin_stat['currency_id'])) ) {
									
									_log("", $cur_coin_stat['currency_id'] . " / " . $cur_coin_stat['balance']);
								
									//$shift_wallet_obj['id'] = strtoupper($cur_coin_stat['id']);
									$shift_wallet_obj['currency'] = strtoupper($cur_coin_stat['currency_id']);
									$shift_wallet_obj['balance'] = format_coin(number_format($cur_coin_stat['balance'], 10, '.', ','));
									
									if (in_array($shift_wallet_obj['currency'], $allowed_shift_currency_arr)) {	
										$shift_wallet_arr[] = $shift_wallet_obj;
									}
								}
								
							}
							
							if (count($shift_wallet_arr)> 0) {
								@mysqli_close($dbhandle);
								$ret_rs['result'] = 'success';
								$ret_rs['wallet'] = $shift_wallet_arr;
								header('Content-Type: application/json');
								echo json_encode($ret_rs);
								die();		
							}
							
							
						} else {
							_log("", "/api/v1/accounts error array empty");
							$error_message = 'error occurred. please try again or contact administrator for help.';
							$res_code = 500;
							$error_code = 1;
							@mysqli_close($dbhandle);
							$ret_rs['result'] = 'failed';
							$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
							header('Content-Type: application/json');
							http_response_code($res_code);
							echo json_encode($ret_rs);
							die();							
						}
						
						/////////////////////////////////////////////////////////
					} else {
						$error_message = 'error occurred. please try again or contact administrator for help.';
						$res_code = 500;
						$error_code = 1;
						_log("", "/api/v1/accounts error not array");
						@mysqli_close($dbhandle);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
						header('Content-Type: application/json');
						http_response_code($res_code);
						echo json_encode($ret_rs);
						die();
					}
				} else {
					@mysqli_close($dbhandle);
					$error_message = 'error occurred. please try again or contact administrator for help.';
					$res_code = 500;
					$error_code = 1;
					_log("", "/api/v1/accounts::not 200 OK response");
					$ret_rs['result'] = 'failed';
					$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
					header('Content-Type: application/json');
					http_response_code($res_code);
					echo json_encode($ret_rs);
					die();
					
				}
				///////////////////////////////////////////////////////////////////////
				
				
			} else { //failed to get shift token when sign in, it also mean that failed sign in, return error here
				@mysqli_close($dbhandle);
				$error_message = 'error occurred. please try again or contact administrator for help.';
				$res_code = 500;
				$error_code = 1;
				_log("", $merchant_signin_res['result']['message']);
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
				header('Content-Type: application/json');
				http_response_code($res_code);
				echo json_encode($ret_rs);
				die();
			}
			
			///////////////////////////////////////////////////////////////////////////
			
			
		} else {			
			
			$error_message = 'error occurred. please contact administrator for help.';
			$res_code = 500;
			$error_code = 1;
			_log("", "could not connect db !");
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
			header('Content-Type: application/json');
			http_response_code($res_code);
			echo json_encode($ret_rs);
			die();
			
		}



	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>