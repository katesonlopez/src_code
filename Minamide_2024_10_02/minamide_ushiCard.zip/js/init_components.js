function init_components(){
  /* Menu Initializer*/
  $('.menu-toggle').click(function(e) {
    e.preventDefault();
    $('#verticalMenu').toggleClass('show');
  });

  /* Currency scrollbar initializer */
  const $scrollContainer = $('.currency-scroll');

  let isDown = false;
  let startX;
  let scrollLeft;

  $scrollContainer.on('mousedown', function(e) {
    isDown = true;
    $scrollContainer.addClass('active');
    startX = e.pageX - $scrollContainer.offset().left;
    scrollLeft = $scrollContainer.scrollLeft();
  });

  $scrollContainer.on('mouseleave mouseup', function() {
    isDown = false;
    $scrollContainer.removeClass('active');
  });

  $scrollContainer.on('mousemove', function(e) {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - $scrollContainer.offset().left;
    const walk = (x - startX); // Scroll speed
    $scrollContainer.scrollLeft(scrollLeft - walk);
  });
}