// components/CardIssue.js

import { useState, useEffect } from "react";
import { useRouter } from 'next/router';
import { userService } from '../../services';
import countryList from "../../lib/countryList";
import { Form1, Form2, Form3, FormPending, PaymentForm, PaidSuccess, PostSuccess, AllComplete } from '../CardIssue';
import Loading from "../Loading";
import Swal from "sweetalert2";
import {Form0} from "./form0";

/**
 * memberCard
 *    0: means normal card, 1: means member card
 * **/
const CardIssue = ({memberCard}) => {
  const router = useRouter();
  const [user, setUserData] = useState(null);
  const [userdata, setUserrData] = useState(null);
  const [step, setStep] = useState(memberCard === 1 ? 0 : 1);
  const [form1, setForm1] = useState([]);
  const [form2, setForm2] = useState([]);
  const [kycData, setKycData] = useState([]);
  const [countryOptions, setCountryOptions] = useState([]);
  const [isMobile, setIsMobile] = useState(false);

  // Check if user can apply issue the normal card.
  useEffect(() => {
    if (user) {
      userService.runApi("updateUserStatus/", user)
        .then((res) => {
          const cardType = res.data.updateStatusResponse.card_type * 1;
          // cardType 0: none, 1: normal card, 2: member card
          if ( memberCard === 0  && cardType > 1) {
            Swal.fire({
              title: "Application Restriction Notice",
              text: "You cannot apply for a debit card because you are already in the process of applying for a member card.",
              icon: "error",
            }).then(() => {
              router.push('/user/dashboard');
            });
          } else if (memberCard === 1 && cardType === 1) {
            Swal.fire({
              title: "Application Restriction Notice",
              text: "You cannot apply for a member card because you are already in the process of applying for a debit card.",
              icon: "error",
            }).then(() => {
              router.push('/user/dashboard');
            });
          }
        })
        .catch((res) => {
          Swal.fire({
            title: "Error",
            text: res.response.data.error.errorMessage,
            icon: "error",
          });
        });
    }
  }, [user, router]);

  useEffect(() => {
    const fetchData = async () => {
      const userJson = localStorage.getItem('user');
      if (userJson) {
        const userser = JSON.parse(userJson);
        const user = userser.res.data.signinResponse;
        setStep(memberCard === 1 ? 0 : 1);
        setUserData(user);
        await getUserInfo(user, true);
        getUserStatus(user);
      }
    };

    if (countryOptions.length === 0) {
      const fetchCountries = async () => {
        const options = await countryList();
        setCountryOptions(options);
      };
      fetchCountries();
    } else {
      fetchData();
    }
  }, [router, countryOptions]);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const getUserStatus = (userrr) => {
    delete userrr.expires_in;
    delete userrr.wallet;
    userService.getUserStatus(userrr, 'both').then((d) => {
      setKycData(d.data);
      if (d.status === 1) setStep(4);
      if (d.status === 2) setStep(5);
      if (d.status === 3 || d.status === 19) setStep(6);
      if (d.status === 5) setStep(7);
      if (d.status === 4) setStep(8);
    }).catch(() => {});
  };

  const closeModal = () => {
    const modal = document.getElementById('exampleModal');
    modal.classList.remove('show');
    modal.style.display = 'none';
    document.body.classList.remove('modal-open');
    const backdrop = document.querySelector('.modal-backdrop');
    backdrop.parentNode.removeChild(backdrop);
  };

  const getCountryCode = (country) => {
    if (countryOptions.length > 0) {
      const option = countryOptions.find(option => option.label === country);
      return option ? option.value : '';
    }
    return '';
  };

  const getUserInfo = async (userrr, is_open_popup = false) => {
    delete userrr.expires_in;
    delete userrr.wallet;
    const feeRes = await userService.runApi("getAmountFee/", userrr);
    const feeAmount = feeRes.data.response.card_issue_fee;
    setUserrData(false);
    userService.runApi('userInfo/', userrr).then((d) => {
      const resd = d.data.userInfoResponse;
      resd.card_issue_fee = feeAmount;
      setUserrData(resd);
      const dateParts = resd.date_of_birth.split("/");
      const occ = ["CEO", "Director", "Employee", "Housewife", "Student"];
      const occupation = resd.occupation ? (occ.includes(resd.occupation) ? resd.occupation : "Other") : "";
      const form1Data = {
        cellphone_number: resd.cellphone_number,
        cellphone_country_code: resd.cellphone_country_code ? resd.cellphone_country_code : getCountryCode(resd.country),
        country: resd.country,
        postal_code: resd.postal_code,
        prefecture: resd.province,
        city: resd.district,
        address: resd.address,
        nationality: resd.nationality ? resd.nationality : resd.country,
        occupation_other_detail: resd.occupation,
        occupation: occupation,
        title: resd.title ? (resd.title === "Ms." ? 2 : 1) : "",
        marriage_status: resd.marriage_status ? (resd.marriage_status === "Single" ? 1 : 2) : "",
        given_name: resd.given_name,
        sur_name: resd.sur_name,
        middle_name: resd.middle_name,
        birthday_year: dateParts[0],
        birthday_month: dateParts[1],
        birthday_day: dateParts[2],
      };
      const id_card_issued_date = resd.id_card_issued_date.split("/");
      const id_card_expired_date = resd.id_card_expired_date.split("/");
      const form2Data = {
        id_type: resd.id_card_type,
        id_number: resd.id_card_number,
        id_issue_year: id_card_issued_date[0] || '',
        id_issue_month: id_card_issued_date[1] || '',
        id_issue_day: id_card_issued_date[2] || '',
        id_expire_year: id_card_expired_date[0] || '',
        id_expire_month: id_card_expired_date[1] || '',
        id_expire_day: id_card_expired_date[2] || '',
        profile: { email_address: resd.email_address },
        pdf_data: {
          application_form_1_screenshot_page_1_url: `https://my.bitquick.io/bitquick_pdf_api/jdb/data/download/application_form_1_screenshot_651610b99f104ba2c891cc217fc59490_0.png`,
          application_form_1_screenshot_page_2_url: `https://my.bitquick.io/bitquick_pdf_api/jdb/data/download/application_form_1_screenshot_651610b99f104ba2c891cc217fc59490_1.png`,
          application_form_2_screenshot_page_1_url: `https://my.bitquick.io/bitquick_pdf_api/jdb/data/download/application_form_2_screenshot_651610b99f104ba2c891cc217fc59490_0.png`,
          application_form_2_screenshot_page_2_url: `https://my.bitquick.io/bitquick_pdf_api/jdb/data/download/application_form_2_screenshot_651610b99f104ba2c891cc217fc59490_1.png`,
          application_form_2_screenshot_page_3_url: `https://my.bitquick.io/bitquick_pdf_api/jdb/data/download/application_form_2_screenshot_651610b99f104ba2c891cc217fc59490_2.png`,
          application_form_2_screenshot_page_4_url: `https://my.bitquick.io/bitquick_pdf_api/jdb/data/download/application_form_2_screenshot_651610b99f104ba2c891cc217fc59490_3.png`,
        },
      };
      setForm1(form1Data);
      setForm2(form2Data);
    }).catch(() => {});
  };

  const handleNextClick = async (data, stepp, goto) => {
    window.scrollTo(0, 0);
    if (stepp === 1) setForm1(data);
    if (stepp === 2) setForm2(data);
    if (stepp === 3) getUserStatus(user);
    if (goto === 1) await getUserInfo(user);
    setStep(goto);
  };

  return (
    <>
      {user && userdata && kycData ? (
        <main>
          <div className="container-fluid px-1 px-sm-4">
            <div className={`row ${isMobile ? "pe-1 ps-1" : "pe-3 ps-3"} pe-sm-5 ps-sm-5 pt-4 pb-4`}>
              {step === 1 || step === 2 || step === 3  ?
                <div className="col-md-12">
                  <div className="row">
                    <div className="col-sm-4">
                      <h1 className="mt-2 font-800 line-height-1p5 text-white">
                        <b>
                          {memberCard === 0 ? "Apply For A Debit Card" : "BITQUICK MEMBER CARD"}
                        </b>
                      </h1>
                    </div>
                    <div className="col-sm-8 p-3">
                      <h6 className="line-height-1p5">
                        You are going to apply for issuance a {memberCard === 0 ? "debit" : "member"} card.
                        We will use your profile data in below to issue
                        the {memberCard === 0 ? "debit" : "member"} card for you. Please double check your
                        data, and if you found no problem, click
                        "Proceed to next step" button.{" "}
                      </h6>
                    </div>
                  </div>
                </div>
                : ''}
              <div>
                {step === 0 && userdata && <Form0 user={user} form1={form1} userdata={userdata} countryOptions={countryOptions} onNextClick={(userData ,goto) => handleNextClick(userData, 0 , goto)} isMobile={isMobile} memberCard={memberCard}/>}
                {step === 1 && userdata && <Form1 user={user} form1={form1} userdata={userdata} countryOptions={countryOptions} onNextClick={(formData1 ,goto) => handleNextClick(formData1, 1 , goto)} isMobile={isMobile} memberCard={memberCard}/>}
                {step === 2 && userdata && <Form2 user={user} form1={form1} form2={form2} countryOptions={countryOptions} onNextClick={(formData2 , goto) => handleNextClick(formData2, 2, goto)} isMobile={isMobile} memberCard={memberCard}/>}
                {step === 3 && userdata && <Form3 user={user} form2={form2} userdata={userdata} form1={form1} onNextClick={(formData3 , goto) => handleNextClick(formData3, 3 , goto)} isMobile={isMobile} memberCard={memberCard}/>}
                {step === 4 && userdata && <FormPending user={user} form2={form2} fullUserData={userdata} userdata={kycData} form1={form1} onNextClick={(formData2 , goto) => handleNextClick(formData2, 4, goto)} isMobile={isMobile} memberCard={memberCard}/>}
                {step === 5 && userdata && <PaymentForm user={user} form2={form2} userdata={userdata} form1={form1} onNextClick={(formData2 , goto) => handleNextClick(formData2, 5, goto)} isMobile={isMobile} memberCard={memberCard}/>}
                {step === 6 && userdata && <PaidSuccess user={user} form2={form2} userdata={userdata} form1={form1} onNextClick={(formData2 , goto) => handleNextClick(formData2, 6, goto)} isMobile={isMobile} memberCard={memberCard}/>}
                {step === 7 && userdata && <PostSuccess user={user} form2={form2} userdata={kycData} form1={form1} onNextClick={(formData2 , goto) => handleNextClick(formData2, 7, goto)} isMobile={isMobile} memberCard={memberCard}/>}
                {step === 8 && userdata && <AllComplete user={user} form2={form2} userdata={userdata} form1={form1} onNextClick={(formData2 , goto) => handleNextClick(formData2, 8, goto)} isMobile={isMobile} memberCard={memberCard}/>}
              </div>
            </div>
          </div>
          <div
            className="modal fade"
            id="exampleModal"
            tabIndex={-1}
            aria-labelledby="exampleModalLabel"
            aria-hidden="true"
          >
            <div className="modal-dialog">
              <div className="modal-content">
                <div className="modal-header bg-mdl-ttl">
                  <h5 className="modal-title text-center w-100" id="exampleModalLabel">
                    ATTENTION
                  </h5>
                </div>
                <div className="modal-body">
                  Please have your passport or ID card ready for identification purposes.
                  <br />
                  Fill out the form with the same information as appears on your
                  identification documents, paying particular attention to the following
                  <ul className="mt-3">
                    <li>Name (including middie name, if applicable)</li>
                    <li>Date of birth</li>
                    <li>Date of ID issuance</li>
                    <li>ID expiration date</li>
                  </ul>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-bs-dismiss="modal"
                    onClick={closeModal}
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </main>
      ) : (
        <Loading />
      )}
    </>
  );
};

export default CardIssue;
