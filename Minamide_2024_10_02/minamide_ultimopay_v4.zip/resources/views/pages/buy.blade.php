
@extends('layouts/contentLayoutMaster')

@section('title', 'Payment.Ultimopay')

@section('vendor-style')
  {{-- vendor files --}}
  <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/datatables.min.css')) }}">
  <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/extensions/dataTables.checkboxes.css')) }}">
  <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.css')) }}">
@endsection
@section('page-style')
  {{-- Page css files --}}
  {{-- <link rel="stylesheet" href="{{ asset(mix('css/pages/data-list-view.css')) }}"> --}}
  <link rel="stylesheet" href="{{ asset('css/plugins/extensions/toastr.css') }}">
@endsection

@section('content')
  <style>

    #DataTables_Table_0_length select{
      width: 50px;
      height: 30px;
      font-size: 11px;
    }
    .main {
      color: black;
    }
    .crypto_content {
      padding: 10px;
      background-color: rgb(250, 200, 10);
      justify-content: space-between;
      min-height: 50px;
    }
    .title {
      font-size: 30px;
      color: black;
      align-items: center;
      font-weight: bold;
      padding: 0px;
      padding-left: 10px;
      padding-top: 30px;
    }
    .menu {
      align-items: center;
      justify-content: center;
      flex-direction: column;
    }
    .content {
      margin-left: 0 !important;
    }
    .menu_btn {
      width: 100px;
      padding: 10px;
      margin-top: 10px;
      background-color: white;
      font-weight: 700;
      line-height: 1.4;
    }
    .menu_btn:hover {
      background-color: black;
      color: white;
    }
    .menu .active {
      background-color: black;
      color: white;
    }
    .withdraw_content {
      padding: 10px 25px 25px 25px;
    }
    .content_title {
      text-align: left;
      font-size: 1.1rem;
      font-weight: bold;
    }
    .content_btn {
      background-color: rgb(250, 200, 10);
      font-weight: bold;
      border: none;
      color: black;
    }
    .amount_input {
      width: 100%;
      border: none;
      border-radius: 10px;
      background: rgb(250, 200, 10);
      padding: 15px;
      font-size: 1rem;
      color: black;
      font-weight: bold;
    }
    .address_input {
      width: 100%;
      border: none;
      border-bottom: 1px solid rgb(250, 200, 10);
      padding: 15px;
      font-size: 1rem;
      color: black;
    }
    .address_input:focus-visible, .amount_input:focus-visible {
      outline: none;
    }
    .left_side {
      width: 60%;
      padding: 5px;
      /* border-right: 1px solid rgb(119, 117, 117); */

    }
    .right_side {
      width: 40%;
      padding: 5px;
      padding-left: 20px;
    }
    .notice_item {
      font-size: .9rem;
      margin: auto;
      /* border-bottom: 1px solid rgb(119, 117, 117); */
    }
    .form-control:focus {
      border: 1px solid rgb(250, 200, 10);
    }
    .coin_icon {
      width: 50px;
      height: 50px;
      margin-right: 10px;
    }
    .card_icon{
      width: 66px;
      height: 40px;
    }
    .important_notice {
      color: red;
    }
    .fonticon-wrap {
      margin: 8px;
      position: absolute;
      font-size: 25px;
      left: 5px;
      color: black;
    }
    .two_desc {
      margin-bottom: 15px;
      display: flex;
    }
    .buy-input {
      display: flex;
      position: relative;
    }
    .buy-input img {
      position: absolute;
      right: 0;
      top: 10px;
      width: 25px;
      height: 25px;
    }
    .error {
      font-size: 1.5rem;
      text-align: center;
      margin: 20px;
    }
    .buy_success_desc {
      font-size: 22px;
      text-align: center;
      display: block;
      margin-bottom: 20px;
    }
    .payment-confirm-email{
      color: #a58200;
      font-size: large;
      text-shadow: 1px 1px 2px #00000021;
      word-break: break-all;
      font-weight: bold;
    }
    .note-red{
      text-shadow: 1px 0px 1px #00000038;
      color: red !important;
      font-size: 15px;
      word-break: break-all;
    }
    .kyc-alert{
      font-size: large; text-shadow: 1px 1px 1px white;
    }
    .hide{
      display: none;
    }
    .btn:disabled {
      cursor: no-drop;
    }
    .invalid-feedback{
      text-align: left;
      margin-left: 20px;
      color: red;
    }
    .sub-description{
      font-size: small;
    }
  </style>

  <input type="hidden" id="baseUrl" value="{{ url("/") }}">
  <div class="main">
    <a href="{{url('/?email='.($email ?? null).'&withdraw='.($withdraw ?? null).'&deposit='.($deposit ?? null).'&buy='.($buy ?? null).'&merchant='.($merchant ?? null ))}}" class="fonticon-wrap">
      <i class="feather icon-arrow-left"></i>
    </a>
    @if (isset($error))
      <div class="row crypto_content p-2">
      </div>
      <div class="error">
        {{ $error }}
      </div>
    @elseif(!isset($buy) || $buy !== "on")
      <div class="row crypto_content p-2">
      </div>
      <div class="error">
        {{ "You are not permitted!" }}
      </div>
    @else
      <div class="row crypto_content p-2">
        <div class="text-center title align-center justify-content-center">
          <p class="text-left"><img alt="Icon" class="coin_icon"src="images/logo/usdt.png"/>Tether USD</p>
          <span id="balance" class="text-left" style="display1: none">  {{$balance}} </span>
          <span class="text-left" style="font-weight:300; font-size:25px"> USDT</span>
        </div>
        <div class="d-flex menu">
          @if(isset($deposit) && $deposit === "on")
            <a href="{{url('deposit-page')}}" class="btn menu_btn " >Deposit</a>
          @endif
          @if(isset($withdraw) && $withdraw === "on")
            <a href="{{url('withdraw-page')}}" class="btn menu_btn" >Withdraw</a>
          @endif
          @if (isset($buy) && $buy === "on")
            <a href="{{url('buy-page')}}" class="btn menu_btn active" >Buy with card</a>
          @endif
            <a href="#verifyDialog" id="showVerifyDialog"
               class="btn menu_btn {{ isset($showVerifyDialog) && $showVerifyDialog ? '' : 'hide' }}"
               data-toggle="modal">Input Verification Code</a>
        </div>
      </div>
      <div class="withdraw_content">
        <div class="two_desc">
          <div>
            You can buy USDT with Credit Card or Debit card. The card brands that can be used are MasterCard and UnionPay.
            <br/>You will receive it instantly in your USDT wallet in your account.
          </div>
        </div>
        <div align="center" class="kyc-alert">
          <div class="alert alert-danger mt-1 alert-validation-msg kyc" role="alert" style="display: none; width: fit-content;">
            <i class="feather icon-info mr-1 align-middle"></i>
            <span class="kyc-message">You need to issue and activate your Ultimo card to use this function.</span>
          </div>
        </div>
        <div class="d-flex justify-content-start">
          <a href="{{ url('transaction-history')}}">Order History</a>
        </div>
        <div class="w-75 m-auto text-center">
          <div class="content_title mt-2">YOU SPEND</div>
          <div class="buy-input">
            <input type="text" class="amount_input" id="spend_amount" placeholder="0.00" onchange="onChangeSpendAmount()"/>
            <img alt="Icon" class="coin_icon"src="images/logo/usd.svg"/>
          </div>
          <div class="invalid-feedback"></div>
          <div class="content_title mt-2">YOU RECEIVE</div>
          <div class="buy-input">
            <input type="text" class="amount_input" id="receive_amount" placeholder="0.000000" />
            <img alt="Icon" class="coin_icon"src="images/logo/usdt.png"/>
          </div>
          <div class="invalid-feedback"></div>

          <div class="mt-2">
            <button class="btn content_btn" type="button" disabled  id="buy-processing" style="display: none">
              <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
              Processing...
            </button>
            <button class="btn content_btn" id="buy-with-card-btn" disabled>Buy with card</button>
          </div>
          <div class="mt-2 ">
            <img alt="Icon" class="card_icon"src="images/logo/visa.png"/>
            <img alt="Icon" class="card_icon"src="images/logo/mastercard.png"/>
            <img alt="Icon" class="card_icon"src="images/logo/unionpay.png"/>
          </div>
          <div class="mt-2" align="center">
            <div>
              <p class="note-red">
                Remark: Support only debit/credit card with 3D Secure.

              </p>
              <p class="note-red" style="margin-left: 4.2em;">
                Support only debit/credit card with own card.
              </p>
            </div>
          </div>
        </div>

      </div>
    @endif
  </div>
  {{-- Data list view end --}}
@endsection

@if( isset($status) && $status == 'paymentFailed')
  <!-- start failed detail modal -->
  <div class="modal fade text-left" id="failedDetailDialog" tabindex="-1" role="dialog" data-backdrop="static"
       aria-labelledby="myModalLabel130" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
      <div class="modal-content">
        <div class="modal-header white" style="background-color: rgb(250, 200, 10)">
          <h5 class="modal-title white" id="myModalLabel130">Failed in Buying</h5>
          <button type="button" class="close closeModal" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body p-3">
          <div class="alert alert-danger mt-1 alert-validation-msg" role="alert">
            <i class="feather icon-info mr-1 align-middle"></i>
            @if(isset($paymentConfirm))
              {!! $paymentConfirm !!}
            @endif
          </div>
          <div class="text-right">
            <a href="{{ url('transaction-history') }}">Order History</a>
          </div>
          <div class="mt-2">
            <p class="note-red">
              @if(isset($message))
                {!! $message !!}
              @else
                Please contact the card issuer to inquire about the reason for the failed card payment.
              @endif
            </p>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-gray closeModal" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <input type="hidden" id="buy_process_status" value="{{$status ?? ''}}">
  <button class="trigger_show_modal_buy_failed" data-toggle="modal" data-target="#failedDetailDialog" style="display: none">showModal</button>

@endif
<!-- end failed detail modal -->

<input class="trigger_show_modal_verifyDialog" type="button" data-toggle="modal" data-target="#verifyDialog" style="display: none">
<div class="modal fade text-left" id="verifyDialog" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel130" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header  white" style="background-color: rgb(250, 200, 10);">
        <h5 class="modal-title white"  id="myModalLabel130">Confirmation Modal</h5>
        <button type="button" data-dismiss="modal" class="close closeModal"  id="closeConfirmDialog" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body pt-3">
        <div class="text-center mb-1">
          We have sent a confirmation email to <span class="payment-confirm-email">@if(isset($email)) {{ $email }} @else {{ session()->get("email") }} @endif</span> to complete your USDT purchase. If there is no problem, please enter the Verification code specified in the confirmation email.
        </div>
        <div class="d-flex">
          <div class="offset-3 col-md-3 text-right">Date: </div>
          <div class="col-md-5 text-left">@if(isset($date)) {{ $date }} @else {{ '' }} @endif</div>
        </div>
        <div class="d-flex">
          <div class="offset-3 col-md-3 text-right">Order No: </div>
          <div class="col-md-4 text-left">@if(isset($orderNo)) {{ $orderNo }} @else {{ '' }} @endif</div>
        </div>
        <div class="d-flex">
          <div class="offset-3 col-md-3 text-right">Paid: </div>
          <div class="col-md-4 text-left">@if(isset($paid)) {{ $paid }} @else {{ '' }} @endif</div>
        </div>
        <div class="d-flex">
          <div class="offset-3 col-md-3 text-right">Received: </div>
          <div class="col-md-4 text-left">@if(isset($received)) {{ $received }} @else {{ '' }} @endif</div>
        </div>
        <div class="d-flex mt-1">
          <div class="col-md-4 d-flex align-items-center">Verification Code: </div>
          <input type="text" class="address_input col-md-8" id="verifyCode" placeholder="Enter the verification code" />
        </div>
      </div>
      <div class="text-right"><a href="#" id="resend-code" class="mr-3">Re-send verification code</a> </div>
      <div class="modal-footer">
        <button class="btn content_btn white" type="button" disabled  id="verify-processing" style="display: none">
          <span class="spinner-grow spinner-grow-sm white" role="status" aria-hidden="true"></span>
          Checking...
        </button>
        <button type="button" class="btn white" style="background-color: rgb(250, 200, 10);" id="verifyBtn" >Verify</button>
      </div>
    </div>
  </div>
</div>
@section('vendor-script')
  {{-- vendor js files --}}
  <script src="{{ asset(mix('vendors/js/extensions/dropzone.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.bootstrap4.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/tables/datatable/buttons.bootstrap.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.select.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.checkboxes.min.js')) }}"></script>
  <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection
@section('page-script')
  <script>
    let base_url = '<?php echo url(""); ?>'
    let balance = '<?php echo isset($balance) ?  $balance : 0 ?>';
    let paymentSuccess = '<?php echo isset($paymentSuccess) ?  $paymentSuccess : false ?>'
  </script>
  {{-- Page js files --}}
  <script src="{{ asset('js/scripts/ui/buy.js?ver=202406110001') }}"></script>
@endsection
