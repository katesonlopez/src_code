<?php
ini_set('memory_limit','50M');
$url = "http://172.21.22.203:7867/jdbcardws.asmx?wsdl";
$cardnum = (isset($_GET['cardnum']))?trim($_GET['cardnum']):'';

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "Content-Type: text/xml"
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$data = <<<DATA
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:jdb="http://jdbinhouse.local.net/">
   <soapenv:Header/>
   <soapenv:Body>
      <jdb:GetDebitCardTransaction>         
         <jdb:card_no>$cardnum</jdb:card_no>        
         <jdb:first_date>1-Jan-2015</jdb:first_date>     
         <jdb:end_date>30-Dec-2050</jdb:end_date>
      </jdb:GetDebitCardTransaction>
   </soapenv:Body>
</soapenv:Envelope>
DATA;

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);

if ($resp === false) {
	echo "response is empty !";
}
	
//var_dump($resp);

/*
$count = 0;
$doc = new DOMDocument();
$doc->loadXML($resp);
//$balance_node = $doc->getElementsByTagName('tbCard');
$nodeList = $doc->getElementsByTagName('tbCard') ;
echo "<br/>";
for ($i = 0; $i < $nodeList->length; $i++) {
    echo $nodeList->item($i)->nodeName . " = " . $nodeList->item($i)->nodeValue . "<br/>";
}
*/

$doc = new DomDocument();
$doc->loadXML($resp);
$xpath = new DOMXPath($doc);
$app_urls = array();
$appNodes = $xpath->query('//tbCard/*');
echo "<br/>";
for($i=0;$i<$appNodes->length;$i++) {
	echo $appNodes->item($i)->nodeName . " = " . $appNodes->item($i)->nodeValue . "<br/>";
	//echo $app_urls[$i]."<br/>";
}



?>

