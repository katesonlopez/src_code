export const constService = {
  IsMaintenance: false
};
