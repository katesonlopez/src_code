<?php
global $baseUrl;
include 'includes/header.php';

// Check currency parameter
if (isset($_GET['id']))
  $id = $_GET['id'];
else
  header('Location: '.$baseUrl);
?>
<!-- Necessary js start-->
<script src="<?php echo $baseUrl; ?>assets/js/auth.js"></script>
<!-- Necessary js end -->

<!-- Container start -->
<div class="main-content container d-flex justify-content-center">
  <div class="col-12 col-md-10 col-lg-12">
    <h3 class="text-center mt-4 mb-4"><?php echo $id; ?> Deposit Report</h3>

    <!-- Start define parameters -->
    <input type="hidden" id="id" value="<?php echo $id; ?>"/>
    <!-- End define parameters -->

    <!-- Start table section -->
    <div class="card blue-boarder mt-4 mb-4">
      <div class="card-body justify-content-center align-content-center">
        <div class="loading">
          <span class="spinner-anim spinner-border spinner-border-sm text-primary" role="status"></span>
          <span class="spinner-text">Loading Report Data...</span>
        </div>
        <table class="table deposit-table">
          <thead id="deposit_thead" class="bg-primary-opacity">
          <tr>
            <th>Currency</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
          </thead>
          <tbody id="deposit_tbody">
          </tbody>
        </table>
      </div>
    </div>
    <!-- End table section -->
  </div>
</div>
<!-- Container end -->

<script>
  $(document).ready(function() {

    // Load deposit report
    loadReport(REPORT_TYPE['DEPOSIT']);

    $(window).resize(function() {
      loadReport(REPORT_TYPE['DEPOSIT']);
    });
  });

  // Get wallet deposit report
  function loadReport(reportType = 0) {

    // Check validation
    const id = $('#id').val();
    $('.loading').show();
    $('.deposit-table').hide();

    // Load report data
    const jwt = localStorage.getItem('jwt');
    const auth_token = localStorage.getItem('auth_token');

    $.ajax({
      url: API_URL + 'ultimoApi.php',
      type: 'POST',
      data: JSON.stringify({
        action: 'getReport',
        currency: id,
        type: reportType,
        jwt: jwt,
        auth_token: auth_token
      }),
      contentType: 'application/json',
      success: function(response) {
        if (response.result === 'success') {
          let tbody = '';
          if( isMobileView()){
            $('#deposit_thead').hide();

            if( response.reportResponse.length === 0 ){
              tbody = '\
                <tr>\
                  <td>\
                    <span>No report data</span>\
                  </td>\
                </tr>';
            }
            else{
              response.reportResponse.forEach(report => {
                tbody += '\
                  <tr>\
                    <td>\
                      <span class="font-weight-bold text-primary">'+ report.currency +'</span>\
                      <br/>\
                      <span class="text-secondary">'+ report.updated_date +'</span>\
                    </td>\
                    <td class="text-right">\
                      <span class="font-weight-bold">'+ (report.amount*1).toFixed(DECIMAL_POINTS[id]) +'</span>\
                      <br/>\
                      '+ reportStatusBadge(report.status) +'\
                    </td>\
                  </tr>';
              });
            }
          }
          else{
            $('#deposit_thead').show();

            if( response.reportResponse.length === 0 ){
              tbody = '\
                <tr>\
                  <td colspan="4">\
                    <span>No report data</span>\
                  </td>\
                </tr>';
            }
            else{
              response.reportResponse.forEach(report => {
                tbody += '\
                  <tr>\
                    <td>\
                      <span class="font-weight-bold text-primary">'+ report.currency +'</span>\
                    </td>\
                    <td>\
                      <span class="font-weight-bold">'+ (report.amount*1).toFixed(DECIMAL_POINTS[id]) +'</span>\
                    </td>\
                    <td>\
                      '+ reportStatusBadge(report.status) +'\
                    </td>\
                    <td>\
                      <span class="text-secondary">'+ report.updated_date +'</span>\
                    </td\
                  </tr>';
              });
            }
          }

          $('#deposit_tbody').html(tbody);
          $('.deposit-table').show();
          $('.loading').hide();
        }
        else {
          $('.deposit-table').show();
          $('.loading').hide();
          showToast(response.error.errorMessage);
          console.log(response.error.errorMessage);
        }
      },
      error: function(error) {
        $('.deposit-table').show();
        $('.loading').hide();
        showToast(error);
        console.log('An error occurred:', error);
      }
    });
  }
</script>
<?php include 'includes/footer.php'; ?>
