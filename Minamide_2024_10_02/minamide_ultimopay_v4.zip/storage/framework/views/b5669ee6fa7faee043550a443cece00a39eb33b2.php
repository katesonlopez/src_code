


<?php $__env->startSection('title', 'Payment.Ultimopay'); ?>

<?php $__env->startSection('vendor-style'); ?>
        
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/datatables.min.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/extensions/dataTables.checkboxes.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/toastr.css'))); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
        
        <link rel="stylesheet" href="<?php echo e(asset('css/pages/data-list-view.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/plugins/extensions/toastr.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <style>

   #DataTables_Table_0_length select {
     width: 50px;
     height: 36px;
     font-size: initial;
   }
   .main {
    color: black;
   }
   .crypto_content {
    padding: 10px;
    background-color: rgb(250, 200, 10);
    justify-content: space-between;
    min-height: 50px;
   }
   .title {
    font-size: 30px;
    color: black;
    align-items: center;
    font-weight: bold;
    padding: 0px;
    padding-left: 10px;
    padding-top: 30px;
   }
   .menu {
    align-items: center;
    justify-content: center;
    flex-direction: column;
   }
   .content {
    margin-left: 0 !important;
   }
   .menu_btn {
    width: 100px;
    padding: 10px;
    margin-top: 10px;
    background-color: white;
    font-weight: 700;
   }
   .menu_btn:hover {
    background-color: black;
    color: white;
   }
   .menu .active {
    background-color: black;
    color: white;
   }
   .withdraw_content {
    padding: 10px 25px 25px 25px;
   }
   .content_title {
    text-align: left;
    font-size: 1.1rem;
    font-weight: bold;
   }
   .content_btn {
    background-color: rgb(250, 200, 10);
    font-weight: bold;
    border: none;
    color: black;
   }
   .amount_input {
    width: 100%;
    border: none;
    border-radius: 10px;
    background: rgb(250, 200, 10);
    padding: 15px;
    font-size: 1rem;
    color: black;
    font-weight: bold;
   }
   .address_input {
    width: 100%;
    border: none;
    border-bottom: 1px solid rgb(250, 200, 10);
    padding: 15px;
    font-size: 1rem;
    color: black;
   }
   .address_input:focus-visible, .amount_input:focus-visible {
      outline: none;
   }
   .left_side {
     width: 60%;
     padding: 5px;
     /* border-right: 1px solid rgb(119, 117, 117); */

   }
   .right_side {
     width: 40%;
     padding: 5px;
     padding-left: 20px;
   }
   .notice_item {
    font-size: .9rem;
    margin: auto;
    /* border-bottom: 1px solid rgb(119, 117, 117); */
   }
   .form-control:focus {
    border: 1px solid rgb(250, 200, 10);
   }
   .coin_icon {
    width: 50px;
    height: 50px;
    margin-right: 10px;
   }
   .card_icon{
    width: 66px;
    height: 40px;
   }
   .important_notice {
    color: red;
   }
   .fonticon-wrap {
    margin: 8px;
    position: absolute;
    font-size: 25px;
    left: 5px;
    color: black;
   }
   .two_desc {
    margin-bottom: 25px;
    display: flex;
   }
   .buy-input {
    display: flex;
    position: relative;
   }
   .buy-input img {
    position: absolute;
    right: 0;
    top: 10px;
    width: 25px;
    height: 25px;
   }
   .error {
        font-size: 1.5rem;
        text-align: center;
        margin: 20px;
   }
   .buy_success_desc {
      font-size: 22px;
      text-align: center;
      display: block;
      margin-bottom: 20px;
   }
   #contact-description{
     color: red;
     word-break: break-all;
     margin-top: 20px;
     text-shadow: 1px 1px 1px #00000038;
   }
   .contact-address{
     font-size: large;
     color: #ef0000;
     font-weight: bold;
   }

 </style>

  <div class="main">
        <a href="<?php echo e(url('/?email='.$email.'&merchant='.$merchant.'&withdraw='.$withdraw.'&deposit='.$deposit.'&buy='.$buy)); ?>" class="fonticon-wrap">
          <i class="feather icon-arrow-left"></i>
        </a>
        <?php if(isset($error)): ?>
          <div class="row crypto_content p-2">
          </div>
          <div class="error">
                <?php echo e($error); ?>

          </div>
        <?php else: ?>
            <div class="row crypto_content p-2">
              <div class="text-center title align-center justify-content-center">
                  <p class="text-left"><img alt="Icon" class="coin_icon"src="images/logo/usdt.png"/>Tether USD</p>
                  <p id="balance" class="text-left" id="balance">  <?php echo e($balance); ?>

                  </p>
                  <p class="text-left" style="font-weight:300; font-size:25px"> USDT</p>
                </div>
              <div class="d-flex menu">
                          <?php if(isset($deposit) && $deposit === "on"): ?>
                            <a href="<?php echo e(url('deposit-page')); ?>" class="btn menu_btn " >Deposit</a>
                          <?php endif; ?>
                          <?php if(isset($withdraw) && $withdraw === "on"): ?>
                            <a href="<?php echo e(url('withdraw-page')); ?>" class="btn menu_btn" >Withdraw</a>
                          <?php endif; ?>
                          <?php if(isset($buy) && $buy === "on"): ?>
                            <a href="<?php echo e(url('buy-page')); ?>" class="btn menu_btn active" >Buy with card</a>
                          <?php endif; ?>
              </div>
            </div>
              <div class="withdraw_content">
                  
                    <section id="data-list-view" class="data-list-view-header">
                      
                      <div class="table-responsive">
                        <table class="table data-list-view">
                          <thead>
                            <tr>
                              <th>Date</th>
                              <th>Order No</th>
                              <th>Paid(USD)</th>
                              <th>Recieved(USDT)</th>
                              <th>Status</th>
                              <th>Detail</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php if(isset($histories)): ?>
                              <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $color = "" ?>
                                <?php if($history["status"] === 'complete'): ?>
                                  <?php $color = "success" ?>
                                <?php elseif($history["status"] === 'pending'): ?>
                                  <?php $color = "primary" ?>
                                <?php elseif($history["status"] === 'Input Code'): ?>
                                    <?php $color = "primary" ?>
                                <?php elseif($history["status"] === 'on hold'): ?>
                                  <?php $color = "warning" ?>
                                <?php elseif($history["status"] === 'failed'): ?>
                                    <?php $color = "danger" ?>
                                <?php elseif($history["status"] === 'contact'): ?>
                                    <?php $color = "warning" ?>
                                <?php endif; ?>
                                <?php
                                  $arr = array('success', 'primary', 'info', 'warning', 'danger');
                                ?>

                                <tr>
                                  <td class="product-name"><?php echo e(date('Y-m-d G:i', strtotime($history["updated_at"] ))); ?></td>
                                  <td class="product-category"><?php echo e($history["transaction_id"]); ?></td>
                                  <td class="product-category"><?php echo e($history["usd"]); ?></td>
                                  <td class="product-category"><?php echo e($history["usdt"]); ?></td>
                                  <td class="product-price <?php echo e($color); ?>"><?php echo e(strtoupper($history["status"])); ?></td>
                                  <td class="product-action">
                                    <span class="action-edit" onclick="viewDetail(<?php echo e($history); ?>)" style="cursor: pointer"><i class="feather icon-eye"></i></span>
                                  </td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                          </tbody>
                        </table>
                      </div>
                      

                  </section>
                  
              </div>
        <?php endif; ?>
</div>

  
<?php $__env->stopSection(); ?>
<button class="detailDialogTrigger" data-toggle="modal" href="#detailDialog" style="display: none"></button>
<div class="modal fade text-left" id="detailDialog" tabindex="-1" role="dialog"
  aria-labelledby="myModalLabel130" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
      <div class="modal-content">
        <div class="modal-header white" style="background-color: rgb(250, 200, 10)">
          <h5 class="modal-title white" id="myModalLabel130">Detail Modal</h5>
          <button  type="button" class="close closeModal" data-dismiss="modal" id="closeDetail" aria-label="Close" >
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body p-3">
            <div class="d-flex justify-content-between">
              <p>Date: </p>
              <p id="date" class="">No Data</p>
            </div>
            <div class="d-flex justify-content-between">
              <p>Order Id: </p>
              <p id="orderId"  class="">No Data</p>

            </div>
            <div class="d-flex justify-content-between">

              <p>Card Holder Name:</p>
              <p id="cardHolderName"  class="" style="word-break: break-all;">No Data</p>
            </div>
            <div class="d-flex justify-content-between">
                <p>Card Number:</p>
              <p id="cardNumber"  class="">No Data</p>
            </div>
            <div class="d-flex justify-content-between">
                <p>Email:</p>
              <p id="email"  class=""></p>
            </div>
            <div class="d-flex justify-content-between">
                <p>Amount:</p>
              <p id="amount"  class="">No Data</p>
            </div>
            <div class="d-flex justify-content-between">
                <p>Status:</p>
              <p id="status"  class="">No Data</p>
            </div>
            <div class="d-flex justify-content-between">
                <p>Detail: </p>
              <div class="d-flex">
                <p id="transactionDetail" >No Data</p>
              </div>
            </div>
          <div id="contact-description" style="display: none">
            <p>
            The verification code has not been entered.
            </p>
            <p>
              Please contact to <span class="contact-address">support@ultimopay.io</span> for assistance.
            </p>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-gray closeModal" data-dismiss="modal" id="closeModal" >Close</button>
        </div>
      </div>
  </div>
</div>
<?php $__env->startSection('vendor-script'); ?>

        <script src="<?php echo e(asset(mix('vendors/js/extensions/dropzone.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.bootstrap4.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.bootstrap.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/dataTables.select.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.checkboxes.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/extensions/toastr.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
        <script>
            let base_url = '<?php echo url(""); ?>'
            // let balance = '<?php echo isset($balance) ?  $balance : 0 ?>'
        </script>
        
        <script src="<?php echo e(asset('js/scripts/ui/transaction_history.js?ver=20240215')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Minamide\minamide_ultimopay_v4\resources\views//pages/transaction-history.blade.php ENDPATH**/ ?>