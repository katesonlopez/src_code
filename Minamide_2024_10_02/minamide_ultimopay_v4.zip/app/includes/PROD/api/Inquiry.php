<?php

namespace App\includes\PROD\api;

use App\includes\PROD\ActionRequest;
use App\includes\PROD\SecurityData;
use Carbon\Carbon;
use GuzzleHttp\Exception\GuzzleException;

// use Paco\PhpDemo\ActionRequest;
// use Paco\PhpDemo\SecurityData;

class Inquiry extends ActionRequest
{
  /**
   * @throws GuzzleException
   */
  public function transactionDetails($order_no)
  {
    $response = $this->client->get('api/1.0/Inquiry/transactionDetails?orderNo=' . $order_no, [
      'headers' => [
        'apiKey' => SecurityData::$AccessToken,
        'Authorization' => "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6Im1YTXlJSnE0ejFWbzFKMWI5LXpZX2ciLCJ0eXAiOiJhdCtqd3QifQ.eyJuYmYiOjE2MDM0MzkxODksImV4cCI6MTYzNDk5NjE0MSwiaXNzIjoiaHR0cHM6Ly9pZGVudGl0eS1zZXJ2ZXIuc2l0LXBhY28uMmMycC5jb20iLCJhdWQiOiJQYUNvQVBJIiwiY2xpZW50X2lkIjoiQXNwTmV0Q29yZUlkZW50aXR5Iiwic3ViIjoiNjhiMzJmYjMtNzM0Ny00YTdlLWE4ODItNWVlYzcyZjdmMjAzIiwiYXV0aF90aW1lIjoxNjAzNDM5MTg3LCJpZHAiOiJsb2NhbCIsImNvbXBhbnlJZCI6ImYyOTNiZjM1M2VjMjRlZWFiMzdiOTllYjg0NmZkNjExIiwib3JnYW5pemF0aW9uSWQiOiIyIiwibmFtZSI6Im1yIENvbXBhbnkgQWRtaW4iLCJlbWFpbCI6ImNvbXBhbnlhZG1pbkAyYzJwLmNvbSIsInRlbmFudCI6Im1hYiIsImdyb3VwSWQiOiI0ZTcwZDE1Yy01ODhlLTQxMTUtOTU5Mi1jMWRmMmFmNDQzMzQiLCJncm91cE5hbWUiOiJQQUNPLkNvbXBhbnkuQWRtaW4iLCJvZmZpY2VHcm91cElkIjoiZWRhZDc2YzI4ZmQ5NGY0M2JkOTdjYzEwNGIwYWFiYTciLCJsYXN0TG9nZ2VkSW4iOiIxMC8yMy8yMDIwIDA3OjQ2OjI3Iiwic2NvcGUiOlsib3BlbmlkIiwicHJvZmlsZSIsIlBhQ29BUEkiLCJvZmZsaW5lX2FjY2VzcyJdLCJhbXIiOlsicHdkIl19.P4RaPMWhsKpq4rF5cAS4QpqMQtkAqWCSFY2kta1wb6Ocbdxn3NjgPG0kxY8vlGwIUwP1h0XchWThkF0JtTeAOzVBBd52bJpva9hlJWWLW6xZgqZkWKAg9dwqbDfixsaYCLAOy-H78CIs_1SqX_2r1XT5rkPpYnOzcuud60bqqt7-jV7xr4tYC9W6udaK9nEfoIR_T5D8tup2hwgksPcJ1zMUrKkwzLGpQQfEQCzWTAmXnzQNWoZ79IV6Uq8EVdVZqXJsFB-0zsfCCpkaUWNM9Mw0ksJ3JchZwws61WlhxkGv-eaiGfFVyqgBoWUCCs_M3YA1MZDQ-hwcsn2lO3rv_A",
        'Content-Type' => 'application/json; charset=utf-8'
      ],
    ]);
    return $response->getBody()->getContents();
  }


  public function Execute(): string
  {
    $now = Carbon::now();

    $officeId = "DEMOOFFICE";
    $orderNo = "1635476979216";

    $request = [
      "apiRequest" => [
        "requestMessageID" => $this->Guid(),
        "requestDateTime" => $now->utc()->format('Y-m-d\TH:i:s.v\Z'),
        "language" => "en-US",
      ],
      "advSearchParams" => [
        "controllerInternalID" => null,
        "officeId" => [
          $officeId
        ],
        "orderNo" => [
          "$orderNo"
        ],
        "invoiceNo2C2P" => null,
        "fromDate" => "0001-01-01T00:00:00",
        "toDate" => "0001-01-01T00:00:00",
        "amountFrom" => null,
        "amountTo" => null
      ],
    ];

    $stringRequest = json_encode($request);

    //third-party http client https://github.com/guzzle/guzzle
    $response = $this->client->post('api/1.0/Inquiry/transactionList', [
      'headers' => [
        'Accept' => 'application/json',
        'apiKey' => SecurityData::$AccessToken,
        'Content-Type' => 'application/json; charset=utf-8'
      ],
      'body' => $stringRequest
    ]);

    return $response->getBody()->getContents();
  }

  /**
   * @throws GuzzleException
   * @throws Exception
   */
  public function ExecuteJose(): string
  {
    $now = Carbon::now();

    $officeId = "DEMOOFFICE";
    $orderNo = "1635476979216";

    $request = [
      "apiRequest" => [
        "requestMessageID" => $this->Guid(),
        "requestDateTime" => $now->utc()->format('Y-m-d\TH:i:s.v\Z'),
        "language" => "en-US",
      ],
      "advSearchParams" => [
        "controllerInternalID" => null,
        "officeId" => [
          $officeId
        ],
        "orderNo" => [
          $orderNo
        ],
        "invoiceNo2C2P" => null,
        "fromDate" => "0001-01-01T00:00:00",
        "toDate" => "0001-01-01T00:00:00",
        "amountFrom" => null,
        "amountTo" => null
      ],
    ];

    $payload = [
      "request" => $request,
      "iss" => SecurityData::$AccessToken,
      "aud" => "PacoAudience",
      "CompanyApiKey" => SecurityData::$AccessToken,
      "iat" => $now->unix(),
      "nbf" => $now->unix(),
      "exp" => $now->addHour()->unix(),
    ];

    $stringPayload = json_encode($payload);
    $signingKey = $this->GetPrivateKey(SecurityData::$MerchantSigningPrivateKey);
    $encryptingKey = $this->GetPublicKey(SecurityData::$PacoEncryptionPublicKey);

    $body = $this->EncryptPayload($stringPayload, $signingKey, $encryptingKey);

    //third-party http client https://github.com/guzzle/guzzle
    $response = $this->client->post('api/1.0/Inquiry/transactionList', [
      'headers' => [
        'Accept' => 'application/jose',
        'CompanyApiKey' => SecurityData::$AccessToken,
        'Content-Type' => 'application/jose; charset=utf-8'
      ],
      'body' => $body
    ]);

    $token = $response->getBody()->getContents();
    $decryptingKey = $this->GetPrivateKey(SecurityData::$MerchantDecryptionPrivateKey);
    $signatureVerificationKey = $this->GetPublicKey(SecurityData::$PacoSigningPublicKey);

    return $this->DecryptToken($token, $decryptingKey, $signatureVerificationKey);
  }

}
