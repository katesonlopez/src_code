<?php
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  // Handle preflight request
  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type, Authorization');
  exit(0);
}

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

date_default_timezone_set('Asia/Tokyo');

include 'common.php';

use \setasign\Fpdi\Fpdi;
require_once('../classes/fpdf/fpdf.php');
require_once('../classes/fpdi2/src/autoload.php');

$data = array(
  'msg' => 'proc_ok',
  'msg_ex' => '',
  'whichForm' => 0,
  'form2_page1_screenshot' => '',
  'form2_page4_screenshot' => '');

$direction = 'landscape';
$theFile = (isset($_POST['mydata']))?trim($_POST['mydata']):'';
$email_address = isset($_POST['email_address'])?($_POST['email_address']):'';
$profile_id = md5($email_address);
$whichForm = (isset($_POST['whichForm']))?trim($_POST['whichForm']):'';
$direction = (isset($_POST['direction']))?trim($_POST['direction']):'landscape';
$img_filename = $profile_id . "_form_" . $whichForm . ".png";
$img_filename_rotate = $profile_id . "_form_" . $whichForm . "_rotate.png";

if ($profile_id != '') {
  if ($theFile != '') {
    $encoded_image = explode(",", $theFile)[1];
    $decoded_image = base64_decode($encoded_image);
    file_put_contents(BASE_PATH."/jdb/data/upload/" . $img_filename, $decoded_image);
    sleep(1);

    if (file_exists(BASE_PATH."/jdb/data/upload/" . $img_filename)) {
      //images (300dpi, A4 paper)
      $paper_width_px = 2480;
      $paper_height_px = 3508;
      //////////////////////////////////////////////////////////////
      if (intval($whichForm) == 1) {
        //export pdf from templates
        $application_form_1_filename = 'application_form_1_' . $profile_id . '.pdf';
        $application_form_1_temp_page_1_filename = 'application_form_1_' . $profile_id . '_page_1_temp.pdf';
        $application_form_1_temp_page_2_filename = 'application_form_1_' . $profile_id . '_page_2_temp.pdf';
        $application_form_1_screenshot_page_1_filename = 'application_form_1_screenshot_page_1_' . $profile_id . '.png';
        $application_form_1_screenshot_page_2_filename = 'application_form_1_screenshot_page_2_' . $profile_id . '.png';
        $application_form_1_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_1_filename;
        $application_form_1_temp_page_1_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_1_temp_page_1_filename;
        $application_form_1_temp_page_2_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_1_temp_page_2_filename;
        $application_form_1_screenshot_page_1_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_1_screenshot_page_1_filename;
        $application_form_1_screenshot_page_2_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_1_screenshot_page_2_filename;
        if (file_exists($application_form_1_filepath)) {
          $paper_scale = 210 / $paper_width_px;
          $myScale = 3.74;
          if ($direction=="portrait") {
            // open the image file
            $im = imagecreatefrompng( BASE_PATH."/jdb/data/upload/" . $img_filename );

            // create a transparent "color" for the areas which will be new after rotation
            $transparency = imagecolorallocatealpha( $im,255,255,255,0 );

            // rotate, last parameter preserves alpha when true
            $rotated = imagerotate( $im, 270, $transparency, 1);

            //maybe there have make white color is transparent
            $background = imagecolorallocate($rotated , 255,  255,  255);
            imagecolortransparent($rotated,$background);

            // disable blendmode, we want real transparency
            imagealphablending( $rotated, false );

            // set the flag to save full alpha channel information
            imagesavealpha( $rotated, true );

            imagepng( $rotated , BASE_PATH."/jdb/data/upload/" . $img_filename);

            // clean up the garbage
            imagedestroy( $im );
            imagedestroy( $rotated );
          }

          for ($form_1_page = 1; $form_1_page <= 2; $form_1_page++) {

            // initiate FPDI
            $pdf = new Fpdi();
            //try to export application form 1
            ///////////////////////////////////////////////////////////////////////////////////////////
            // get the page count
            $pageCount = $pdf->setSourceFile($application_form_1_filepath);
            $templateId = $pdf->importPage($form_1_page);
            $pdf->AddPage();
            $pdf->useImportedPage($templateId, 0, 17, 210 , 268, false);

            if($form_1_page == 1) {
              $pdf->Image(BASE_PATH."/jdb/data/upload/" . $img_filename, 50, 80, 75, 75/$myScale);
              $pdf->Output($application_form_1_temp_page_1_filepath,'F');
              if (file_exists($application_form_1_temp_page_1_filepath)) {
                //try to export image screenshot for form-1
                @unlink($application_form_1_screenshot_page_1_filepath);
                $formone_url = $application_form_1_temp_page_1_filepath.'[0]';
                $imagickObj1 = new Imagick();
                $imagickObj1->setResolution(300,300);
                $imagickObj1->setSize(1400,1979);
                $imagickObj1->readimage($formone_url);
                $imagickObj1->setImageBackgroundColor('#ffffff');
                $imagickObj1->resizeImage(1400,1979,Imagick::FILTER_LANCZOS,1);
                $imagickObj1->setImageFormat("png");
                $imagickObj1->writeImage($application_form_1_screenshot_page_1_filepath);
                $imagickObj1->clear();
                $imagickObj1->destroy();

                $data['form1_page1_screenshot'] = SITE_PATH.'/jdb/data/download/' . $application_form_1_screenshot_page_1_filename . "?t=" . time();
              }
            } else if($form_1_page == 2) {
              $pdf->Image(BASE_PATH."/jdb/data/upload/" . $img_filename, 20, 233, 20, 30/$myScale);
              $pdf->Output($application_form_1_temp_page_2_filepath,'F');
              if (file_exists($application_form_1_temp_page_2_filepath)) {
                //try to export image screenshot for form-1
                @unlink($application_form_1_screenshot_page_2_filepath);
                $formone_url = $application_form_1_temp_page_2_filepath.'[0]';
                $imagickObj1 = new Imagick();
                $imagickObj1->setResolution(300,300);
                $imagickObj1->setSize(1400,1979);
                $imagickObj1->readimage($formone_url);
                $imagickObj1->setImageBackgroundColor('#ffffff');
                $imagickObj1->resizeImage(1400,1979,Imagick::FILTER_LANCZOS,1);
                $imagickObj1->setImageFormat("png");
                $imagickObj1->writeImage($application_form_1_screenshot_page_2_filepath);
                $imagickObj1->clear();
                $imagickObj1->destroy();

                $data['form1_page2_screenshot'] = SITE_PATH.'/jdb/data/download/' . $application_form_1_screenshot_page_2_filename . "?t=" . time();
              }
            }
          }

          $data['msg'] = 'proc_ok';
          $data['whichForm'] = intval($whichForm);
        }
      } else if (intval($whichForm) == 2) {
        $application_form_2_filename = 'application_form_2_' . $profile_id . '.pdf';
        $application_form_2_temp_page_1_filename = 'application_form_2_' . $profile_id . '_page_1_temp.pdf';
        $application_form_2_temp_page_2_filename = 'application_form_2_' . $profile_id . '_page_2_temp.pdf';
        $application_form_2_temp_page_3_filename = 'application_form_2_' . $profile_id . '_page_3_temp.pdf';
        $application_form_2_temp_page_4_filename = 'application_form_2_' . $profile_id . '_page_4_temp.pdf';
        $application_form_2_screenshot_page_1_filename = 'application_form_2_screenshot_page_1_' . $profile_id . '.png';
        $application_form_2_screenshot_page_4_filename = 'application_form_2_screenshot_page_4_' . $profile_id . '.png';
        $application_form_2_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_2_filename;
        $application_form_2_page_1_temp_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_2_temp_page_1_filename;
        $application_form_2_page_2_temp_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_2_temp_page_2_filename;
        $application_form_2_page_3_temp_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_2_temp_page_3_filename;
        $application_form_2_page_4_temp_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_2_temp_page_4_filename;
        $application_form_2_screenshot_page_1_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_2_screenshot_page_1_filename;
        $application_form_2_screenshot_page_4_filepath = BASE_PATH.'/jdb/data/download/' . $application_form_2_screenshot_page_4_filename;

        if (file_exists($application_form_2_filepath)) {
          //////////////////////////////////////////////////////////
          $paper_scale = 210 / $paper_width_px;
          $myScale = 3.74;
          if ($direction=="portrait") {
            // open the image file
            $im = imagecreatefrompng( BASE_PATH."/jdb/data/upload/" . $img_filename );
            // create a transparent "color" for the areas which will be new after rotation
            // r=255,b=255,g=255 ( white ), 127 = 100% transparency - we choose "invisible black"
            $transparency = imagecolorallocatealpha( $im,255,255,255,0 );

            // rotate, last parameter preserves alpha when true
            $rotated = imagerotate( $im, 270, $transparency, 1);

            //maybe there have make white color is transparent
            $background = imagecolorallocate($rotated , 255,  255,  255);
            imagecolortransparent($rotated,$background);

            // disable blendmode, we want real transparency
            imagealphablending( $rotated, false );
            // set the flag to save full alpha channel information
            imagesavealpha( $rotated, true );

            imagepng( $rotated , BASE_PATH."/jdb/data/upload/" . $img_filename);
            // clean up the garbage
            imagedestroy( $im );
            imagedestroy( $rotated );
          }

          //try to export application form 1
          ///////////////////////////////////////////////////////////////////////////////////////////
          // get the page count
          for ($page = 1; $page <= 4; $page++) {

            // initiate FPDI
            unset($pdf);
            $pdf = null;
            unset($templateId);
            $templateId = null;
            $pdf = new Fpdi();
            $pageCount2 = $pdf->setSourceFile($application_form_2_filepath);
            $templateId = $pdf->importPage($page);
            $pdf->AddPage();
            $pdf->useImportedPage($templateId, 0.4, 0, 209 , null, false);
            if ($page==1) {
              //////////////////////////////////////////////////////////////////////////////
              $pdf->Image(BASE_PATH."/jdb/data/upload/" . $img_filename, 139, 147, 22, 22 / $myScale);
              $pdf->Output($application_form_2_page_1_temp_filepath, 'F');
              if (file_exists($application_form_2_page_1_temp_filepath)) {
                //try to export image screenshot page 1 for form-2
                @unlink($application_form_2_screenshot_page_1_filepath);
                $formtwo_page_1_url = $application_form_2_page_1_temp_filepath.'[0]';
                $imagickObj2a = new Imagick();
                $imagickObj2a->setResolution(300,300);
                $imagickObj2a->setSize(1400,1979);
                $imagickObj2a->readimage($formtwo_page_1_url);
                $imagickObj2a->setImageBackgroundColor('#ffffff');
                $imagickObj2a->resizeImage(1400,1979,Imagick::FILTER_LANCZOS,1);
                $imagickObj2a->setImageFormat("png");
                $imagickObj2a->writeImage($application_form_2_screenshot_page_1_filepath);
                $imagickObj2a->clear();
                $imagickObj2a->destroy();

                $data['form2_page1_screenshot'] = SITE_PATH.'/jdb/data/download/' . $application_form_2_screenshot_page_1_filename . "?t=" . time();
              }
            } else if ($page==2) {
              $pdf->Output($application_form_2_page_2_temp_filepath,'F');
            } else if ($page==3) {
              $pdf->Output($application_form_2_page_3_temp_filepath,'F');
            } else if ($page==4) {
              $pdf->Image(BASE_PATH."/jdb/data/upload/" . $img_filename, 29.5, 233, 20, 20 / $myScale);
              $pdf->Output($application_form_2_page_4_temp_filepath, 'F');
              if (file_exists($application_form_2_page_4_temp_filepath)) {
                //try to export image screenshot page 4 for form-2
                @unlink($application_form_2_screenshot_page_4_filepath);
                $formtwo_page_4_url = $application_form_2_page_4_temp_filepath.'[0]';
                $imagickObj2b = new Imagick();
                $imagickObj2b->setResolution(300,300);
                $imagickObj2b->setSize(1400,1979);
                $imagickObj2b->readimage($formtwo_page_4_url);
                $imagickObj2b->setImageBackgroundColor('#ffffff');
                $imagickObj2b->resizeImage(1400,1979,Imagick::FILTER_LANCZOS,1);
                $imagickObj2b->setImageFormat("png");
                $imagickObj2b->writeImage($application_form_2_screenshot_page_4_filepath);
                $imagickObj2b->clear();
                $imagickObj2b->destroy();

                $data['form2_page4_screenshot'] = SITE_PATH.'/jdb/data/download/' . $application_form_2_screenshot_page_4_filename . "?t=" . time();
              }
            }
          }

          if (($data['form2_page1_screenshot'] != '') && ($data['form2_page4_screenshot'] != '')) {
            $data['msg'] = 'proc_ok';
          } else {
            $data['msg'] = 'proc_ng';
          }
        }
      }
    } else {
      $data['msg'] = 'proc_ng';
      $data['msg_ex'] = 'upload that bai';
    }
  } else {
    $data['msg'] = 'proc_ng';
    $data['msg_ex'] = 'upload that bai';
  }
} else  {
  $data['msg'] = 'proc_ng';
  $data['msg_ex'] = 'upload that bai';
}

echo json_encode($data);
die();
