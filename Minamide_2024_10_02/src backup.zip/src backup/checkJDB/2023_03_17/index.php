<?php
const APP_KEY = 'HKHyrmRKEziT5Pv2ez6EahKV1CTaU8nG7h9qoYo4fLlV2UksopQiboiuBZYsTj2RNKgbd2xBCOrPbEpBQg8sb54IfDVrQXyPHoSjTy1p3w5fsR8w9zVgwVn0BmvmWdPe';
const TYPE_EMAIL = 0;
const TYPE_CARD_NUM = 1;
const TYPE_ACCOUNT_NUM = 2;

// Get Params $cmd(getUser), $type(0 or 1 or 2), $param(email or card number or account number)
extract($_POST);
if( isset($cmd) && isset($type) && isset($param) && $cmd == 'getUser' ){
    $result = array('result'=>'success', 'users'=>array());
    $key = 'email_address';
    if( $type == TYPE_EMAIL){
        $key = 'email_address';
    }
    else if( $type == TYPE_CARD_NUM){
        $key = 'card_number';
    }
    else if( $type == TYPE_ACCOUNT_NUM){
        $key = 'bank_account_number';
    }
    $users = (array)json_decode(curlJson( $key, $param ));
    if( isset($users['result']) && $users['result'] == 'success' ){
        $userInfos = (array)$users['usersInfoResponse'];
        if( count($userInfos) > 0 ){
            foreach( $userInfos as $user ){
                $subUser = (array)$user;
                $subResult = array(
                    'name'=>$subUser['name'].'<br>('.$subUser['group'].')',
                    'email'=>$subUser['email_address'],
                    'account_num'=>$subUser['bank_account_number'],
                    'card_num'=>$subUser['card_number'],
                    'balance'=>getBalanceFromCardNum( $subUser['card_number'] ));
                $result['users'][] = $subResult;
            }
        }
        else{
            $result['result'] = 'failed';
        }
    }
    else{
        $result['result'] = 'failed';
    }
    echo json_encode( $result );
    return;
}

function curlJson( $key, $param ){
    // API URL
    $url = 'https://api.ultimopay.io/v1/searchUser/';

    // request data that is going to be sent as POST to API
    $data = array(
        $key => $param
    );

    // encoding the request data as JSON which will be sent in POST
    $encodedData = json_encode($data);

    // initiate curl with the url to send request
    $curl = curl_init($url);

    // return CURL response
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    // Send request data using POST method
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");

    // Data content-type is sent as JSON
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Content-Type:application/json',
        'Authorization:Bearer '.APP_KEY
    ));
    curl_setopt($curl, CURLOPT_POST, true);

    // Curl POST the JSON data to send the request
    curl_setopt($curl, CURLOPT_POSTFIELDS, $encodedData);

    // execute the curl POST request and send data
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}

function makeErrText( $errorTxt ){
    return '<span class="text-danger">'.$errorTxt.'</span>';
}
function getBalanceFromCardNum( $cardnum ){

    if( strlen(trim($cardnum)) == 0 )
        return makeErrText('ERR');

    $result = '';
    try{
        //05620010100133108,4284719007177821
        //$cardnum = "4284714014793975";
        $req_body  = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:jdb=\"http://jdbinhouse.local.net/\">";
        $req_body .= "<soapenv:Header/>";
        $req_body .= "<soapenv:Body>";
        $req_body .= "<jdb:GetDebitCheckBalance>";
        $req_body .= "<jdb:card_no>" . $cardnum . "</jdb:card_no>";
        $req_body .= "</jdb:GetDebitCheckBalance>";
        $req_body .= "</soapenv:Body>";
        $req_body .= "</soapenv:Envelope>";

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'http://172.21.22.203:7867/jdbcardws.asmx?wsdl%0A',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $req_body,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: text/xml'
            ),
        ));

        $response2 = curl_exec($curl);
        curl_close($curl);
        if( strlen($response2) > 0 ){
            $doc = new DOMDocument();
            $doc->loadXML($response2);
            $balance_node = $doc->getElementsByTagName('AVL_BALANCE');
            $tblCardErrCode = $doc->getElementsByTagName('ERR_CODE');
            $tblCardErrDesc = $doc->getElementsByTagName('ERR_DESC');
            if ($balance_node->length==0) {
                $result .= makeErrText("not found !");
            } else {
                $balance = $balance_node->item(0)->nodeValue;
                $result .= $balance;
            }

            if ($tblCardErrCode->length>0) {
                $errCode = $tblCardErrCode->item(0)->nodeValue;
                $result .= makeErrText("Error Code = " . $errCode);
            }

            if ($tblCardErrDesc->length>0) {
                $errDesc = $tblCardErrDesc->item(0)->nodeValue;
                $result .= makeErrText("Error Desc = " . $errDesc);
            }
        }
        else{
            $result = makeErrText("ERR");
        }
    }
    catch (Exception $e){
        $result = makeErrText('ERR');
    }

    return $result;
}
?>


<!--  ==========================================   HTML Design   =====================================  -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2, minimum-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>JDB Balance Check</title>
    <style>
        td{
            padding-left: 0 !important;
            padding-right: 0 !important;
            text-align: center;
        }
        .hide{
            display: none;
        }
        .form-check-inline {
            width: auto;
        }
        .small-font{
            font-size: small;
        }
        .form-check-label{
            cursor: pointer !important;
        }
    </style>
</head>
<body>
<div class="container">
    <input type="hidden" id="server_url" value="<?php echo $_SERVER['REQUEST_URI']; ?>">
    <br>
    <div class="text-center"><span class="display-4">JDB Balance Check<sup><small style="font-size: .375em;">@2023 Minamide</small></sup></span></div>
    <hr>
    <div class="row">
        <div class="form-check form-check-inline">
            <input type="radio" class="form-check-input" id="radio_email" name="optradio" value="email" checked>
            <label class="form-check-label" for="radio_email">Email</label>
        </div>
        <div class="form-check form-check-inline">
            <input type="radio" class="form-check-input" id="radio_account_number" name="optradio" value="account_number">
            <label class="form-check-label" for="radio_account_number">Account Number</label>
        </div>
        <div class="form-check form-check-inline">
            <input type="radio" class="form-check-input" id="radio_card_number" name="optradio" value="card_number">
            <label class="form-check-label" for="radio_card_number">Card Number</label>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-sm-4">
                <div class="form-outline">
                    <textarea class="form-control p-3" id="textarea" rows="10" placeholder="Please type..."></textarea>
                    <label class="form-label area-label" for="textarea">Please type EMAIL ADDRESS of your clients</label>
                </div>
                <button type="button" class="btn btn-primary mt-3 check-balance-btn" >
                    <span class="normal">Check Balance</span>
                    <span class="spinner-border spinner-border-sm hide" role="status" aria-hidden="true"></span>
                </button>
        </div>
        <div class="col-sm-8">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th scope="col" style="min-width: 50px;">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Account Number</th>
                    <th scope="col">Care Number</th>
                    <th scope="col">Balance</th>
                </tr>
                </thead>
                <tbody id="body">
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>



<!--  ==========================================   Java script   =====================================  -->
<script>
    let gServerUrl = '';
    let gEmailType = 0;
    let gCardNumType = 1;
    let gAccountNumType = 2;
    $(document).ready(function (){
        gServerUrl = $('#server_url').val();
        $('.check-balance-btn').on('click', onClickBtn);
        $('.form-check-input').click(function (e){
           onClickRadio(e);
        });
    });

    function onClickRadio(e){
        if(e.currentTarget.id === 'radio_email')
            $('.area-label').text("Please type EMAIL ADDRESS of your clients");
        else if(e.currentTarget.id === 'radio_account_number')
            $('.area-label').text("Please type BANK ACCOUNT NUMBER of your clients");
        else if(e.currentTarget.id === 'radio_card_number')
            $('.area-label').text("Please type CARD NUMBER of your clients");
    }
    function onClickBtn(){
        $('#body').html('');

        if( $("#radio_email").prop("checked"))
            forEmail();
        else if( $("#radio_card_number").prop("checked"))
            forCardNumber();
        else if( $("#radio_account_number").prop("checked"))
            forAccountNumber();
  }

    function disableBtn(){
        $('.check-balance-btn .normal').text('Checking...');
        $('.check-balance-btn .spinner-border').removeClass('hide');
        $('.check-balance-btn').attr('disabled', 'disabled');
    }

    function enableBtn(){
        $('.check-balance-btn .normal').text('Check Balance');
        $('.check-balance-btn').removeAttr('disabled');
        $('.check-balance-btn .normal').show();
        $('.check-balance-btn .spinner-border').addClass('hide')
    }

    function forAccountNumber(){
        // Do request as many as typed.
        let originlines = $('#textarea').val().split('\n');
        let lines = [];
        for(let i = 0; i < originlines.length; i++ ){
            if( originlines[i].trim().length === 0 )
                continue;
            lines.push(originlines[i]);
        }
        let counter = lines.length;
        for(let i = 0; i < lines.length; i++){

            // disable submit button
            disableBtn();

            let param = lines[i].trim();
            let html = '\
                        <tr id="tr_'+i+'">\
                            <td id="spin_'+i+'">\
                                <div class="spinner-border text-primary spinner-border-sm" role="status">\
                                    <span class="visually-hidden"><span class="text-muted small-font">Loading...</span></span>\
                                </div>\
                            </td>\
                            <td id="name_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                            <td id="email_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                            <td id="an_'+i+'" class="text-primary">'+ param +'</td>\
                            <td id="cn_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                            <td id="balance_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                        </tr>';
            $('#body').append( html );
            $.post(gServerUrl,{
                    cmd: "getUser",
                    type: gAccountNumType,
                    param: param,
                },
                function(resp, textStatus, jqXHR){
                    counter--;
                    if( counter === 0 )
                        enableBtn();
                    if( resp.trim().length === 0 ){
                        applyFailed( gAccountNumType, i );
                        return;
                    }
                    let data = JSON.parse(resp);
                    if( data.result === 'success' ){
                        for( let j = 0; j < data.users.length; j++ ){
                            if( j === 0 ){
                                $('#spin_' + i).html('<span class="text-success">OK</span>');
                                $('#name_' + i).html('<span class="text-success">'+ data.users[j].name  +'</span>');
                                $('#cn_' + i).html('<span class="text-success">'+ data.users[j].card_num +'</span>');
                                $('#email_' + i).html('<span class="text-success">'+ data.users[j].email +'</span>');
                                $('#balance_' + i).html('<span class="text-success">'+ data.users[j].balance +'</span>');
                            }
                            else{
                                html = '\
                                <tr>\
                                    <td>\
                                        <span class="text-success">OK</span>\
                                    </td>\
                                    <td id="name_'+i+'">'+ '<span class="text-success">'+ data.users[j].name +'</td>\
                                    <td id="email_'+i+'">'+ '<span class="text-success">'+ data.users[j].email  +'</span>' +'</td>\
                                    <td id="cn_'+i+'">'+ '<span class="text-primary">'+ data.users[j].account_num +'</td>\
                                    <td id="an_'+i+'">'+ '<span class="text-success">'+ data.users[j].card_num +'</td>\
                                    <td id="balance_'+i+'">'+ '<span class="text-success">'+ data.users[j].balance +'</td>\
                                </tr>';
                                $('#tr_' + i).after(html);
                            }
                        }
                    }
                    else{
                        $('#spin_' + i).html('<span class="text-danger">ERR</span>');
                        $('#name_' + i).html('<span class="text-danger">-</span>');
                        $('#email_' + i).html('<span class="text-danger">-</span>');
                        $('#cn_' + i).html('<span class="text-danger">-</span>');
                        $('#balance_' + i).html('<span class="text-danger">-</span>');
                        $('#an_' + i).removeClass('text-primary').addClass('text-danger');
                    }
                }).fail(function(jqXHR, textStatus, errorThrown){
                counter--;
                if( counter === 0 )
                    enableBtn();

                $('#spin_' + i).html('<span class="text-danger">ERR</span>');
                $('#name_' + i).html('<span class="text-danger">-</span>');
                $('#cn_' + i).html('<span class="text-danger">-</span>');
                $('#email_' + i).html('<span class="text-danger">-</span>');
                $('#balance_' + i).html('<span class="text-danger">-</span>');
                $('#an_' + i).removeClass('text-primary').addClass('text-danger');
            });
        }
    }

    function forCardNumber(){
        // Do request as many as typed.
        let originlines = $('#textarea').val().split('\n');
        let lines = [];
        for(let i = 0; i < originlines.length; i++ ){
            if( originlines[i].trim().length === 0 )
                continue;
            lines.push(originlines[i]);
        }
        let counter = lines.length;
        for(let i = 0; i < lines.length; i++){

            // disable submit button
            disableBtn();

            let param = lines[i].trim();
            let html = '\
                        <tr id="tr_'+i+'">\
                            <td id="spin_'+i+'">\
                                <div class="spinner-border text-primary spinner-border-sm" role="status">\
                                    <span class="visually-hidden"><span class="text-muted small-font">Loading...</span></span>\
                                </div>\
                            </td>\
                            <td id="name_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                            <td id="email_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                            <td id="an_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                            <td id="cn_'+i+'" class="text-primary">'+ param +'</td>\
                            <td id="balance_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                        </tr>';
            $('#body').append( html );
            $.post(gServerUrl,{
                    cmd: "getUser",
                    type: gCardNumType,
                    param: param,
                },
                function(resp, textStatus, jqXHR){
                    counter--;
                    if( counter === 0 )
                        enableBtn();
                    if( resp.trim().length === 0 ){
                        applyFailed( gCardNumType, i );
                        return;
                    }
                    let data = JSON.parse(resp);
                    if( data.result === 'success' ){
                        for( let j = 0; j < data.users.length; j++ ){
                            if( j === 0 ){
                                $('#spin_' + i).html('<span class="text-success">OK</span>');
                                $('#name_' + i).html('<span class="text-success">'+ data.users[j].name  +'</span>');
                                $('#an_' + i).html('<span class="text-success">'+ data.users[j].account_num +'</span>');
                                $('#email_' + i).html('<span class="text-success">'+ data.users[j].email +'</span>');
                                $('#balance_' + i).html('<span class="text-success">'+ data.users[j].balance +'</span>');
                            }
                            else{
                                html = '\
                                <tr>\
                                    <td>\
                                        <span class="text-success">OK</span>\
                                    </td>\
                                    <td id="name_'+i+'">'+ '<span class="text-success">'+ data.users[j].name +'</td>\
                                    <td id="email_'+i+'">'+ '<span class="text-success">'+ data.users[j].email  +'</span>' +'</td>\
                                    <td id="an_'+i+'">'+ '<span class="text-success">'+ data.users[j].account_num +'</td>\
                                    <td id="cn_'+i+'">'+ '<span class="text-primary">'+ data.users[j].card_num +'</td>\
                                    <td id="balance_'+i+'">'+ '<span class="text-success">'+ data.users[j].balance +'</td>\
                                </tr>';
                                $('#tr_' + i).after(html);
                            }
                        }
                    }
                    else{
                        $('#spin_' + i).html('<span class="text-danger">ERR</span>');
                        $('#name_' + i).html('<span class="text-danger">-</span>');
                        $('#email_' + i).html('<span class="text-danger">-</span>');
                        $('#an_' + i).html('<span class="text-danger">-</span>');
                        $('#balance_' + i).html('<span class="text-danger">-</span>');
                        $('#cn_' + i).removeClass('text-primary').addClass('text-danger');
                    }
                }).fail(function(jqXHR, textStatus, errorThrown){
                counter--;
                if( counter === 0 )
                    enableBtn();
                $('#spin_' + i).html('<span class="text-danger">ERR</span>');
                $('#name_' + i).html('<span class="text-danger">-</span>');
                $('#an_' + i).html('<span class="text-danger">-</span>');
                $('#email_' + i).html('<span class="text-danger">-</span>');
                $('#balance_' + i).html('<span class="text-danger">-</span>');
                $('#cn_' + i).removeClass('text-primary').addClass('text-danger');
            });
        }
    }

    function forEmail(){
        // Do request as many as typed.
        let originlines = $('#textarea').val().split('\n');
        let lines = [];
        for(let i = 0; i < originlines.length; i++ ){
            if( originlines[i].trim().length === 0 )
                continue;
            lines.push(originlines[i]);
        }
        let counter = lines.length;
        for(let i = 0; i < lines.length; i++){

            // disable submit button
            disableBtn();

            let param = lines[i].trim();
            let html = '\
                        <tr id="tr_'+i+'">\
                            <td id="spin_'+i+'">\
                                <div class="spinner-border text-primary spinner-border-sm" role="status">\
                                    <span class="visually-hidden"><span class="text-muted small-font">Loading...</span></span>\
                                </div>\
                            </td>\
                            <td id="name_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                            <td id="email_'+i+'" class="text-primary">'+ param +'</td>\
                            <td id="an_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                            <td id="cn_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                            <td id="balance_'+i+'"><span class="text-muted small-font">Loading...</span></td>\
                        </tr>';
            $('#body').append( html );
            $.post(gServerUrl,{
                    cmd: "getUser",
                    type: gEmailType,
                    param: param,
                },
                function(resp, textStatus, jqXHR){
                    counter--;
                    if( counter === 0 )
                        enableBtn();
                    if( resp.trim().length === 0 ){
                        applyFailed( gEmailType, i );
                        return;
                    }
                    let data = JSON.parse(resp);
                    if( data.result === 'success' ){
                        for( let j = 0; j < data.users.length; j++ ){
                            if( j === 0 ){
                                $('#spin_' + i).html('<span class="text-success">OK</span>');
                                $('#name_' + i).html('<span class="text-success">'+ data.users[j].name  +'</span>');
                                $('#an_' + i).html('<span class="text-success">'+ data.users[j].account_num +'</span>');
                                $('#cn_' + i).html('<span class="text-success">'+ data.users[j].card_num +'</span>');
                                $('#balance_' + i).html('<span class="text-success">'+ data.users[j].balance +'</span>');
                            }
                            else{
                                html = '\
                                <tr>\
                                    <td>\
                                        <span class="text-success">OK</span>\
                                    </td>\
                                    <td id="name_'+i+'">'+ '<span class="text-success">'+ data.users[j].name +'</td>\
                                    <td id="email_'+i+'">'+ '<span class="text-primary">'+ data.users[j].email  +'</span>' +'</td>\
                                    <td id="an_'+i+'">'+ '<span class="text-success">'+ data.users[j].account_num +'</td>\
                                    <td id="cn_'+i+'">'+ '<span class="text-success">'+ data.users[j].card_num +'</td>\
                                    <td id="balance_'+i+'">'+ '<span class="text-success">'+ data.users[j].balance +'</td>\
                                </tr>';
                                $('#tr_' + i).after(html);
                            }
                        }
                    }
                    else{
                        $('#spin_' + i).html('<span class="text-danger">ERR</span>');
                        $('#name_' + i).html('<span class="text-danger">-</span>');
                        $('#an_' + i).html('<span class="text-danger">-</span>');
                        $('#cn_' + i).html('<span class="text-danger">-</span>');
                        $('#balance_' + i).html('<span class="text-danger">-</span>');
                        $('#email_' + i).removeClass('text-primary').addClass('text-danger');
                    }
                }).fail(function(jqXHR, textStatus, errorThrown){
                counter--;
                if( counter === 0 )
                    enableBtn();
                $('#spin_' + i).html('<span class="text-danger">ERR</span>');
                $('#name_' + i).html('<span class="text-danger">-</span>');
                $('#an_' + i).html('<span class="text-danger">-</span>');
                $('#cn_' + i).html('<span class="text-danger">-</span>');
                $('#balance_' + i).html('<span class="text-danger">-</span>');
                $('#email_' + i).removeClass('text-primary').addClass('text-danger');
            });
        }
    }

    function applyFailed( type, orderNumber ){
        if( type === gEmailType){
            $('#spin_' + orderNumber).html('<span class="text-danger">ERR</span>');
            $('#name_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#an_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#cn_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#balance_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#email_' + orderNumber).removeClass('text-primary').addClass('text-danger');
        }
        else if( type === gCardNumType){
            $('#spin_' + orderNumber).html('<span class="text-danger">ERR</span>');
            $('#name_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#an_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#email_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#balance_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#cn_' + orderNumber).removeClass('text-primary').addClass('text-danger');
        }
        else if( type === gAccountNumType){
            $('#spin_' + orderNumber).html('<span class="text-danger">ERR</span>');
            $('#name_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#cn_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#email_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#balance_' + orderNumber).html('<span class="text-danger">-</span>');
            $('#an_' + orderNumber).removeClass('text-primary').addClass('text-danger');
        }
    }
</script>
</body>
</html>
