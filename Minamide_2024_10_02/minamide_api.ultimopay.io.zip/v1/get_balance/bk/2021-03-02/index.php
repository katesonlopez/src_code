<?php
mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}
$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
$found = 0;
foreach (getAllHeaders() as $name => $value) {
    //echo "$name: $value\n";
	if ($name == 'Authorization') {
		if ($value == $apikey) {
			$found=1;
			break;
		}
	}
}

/**
 * Checks if the given string is an address
 *
 * @param String $address the given HEX adress
 * @return Boolean
*/
function isAddress($address) {
    if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
        // Check if it has the basic requirements of an address
        return false;
    } elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
        // If it's all small caps or all all caps, return true
        return true;
    } else {
        // Otherwise check each case
        return isChecksumAddress($address);
    }
}

/**
 * Checks if the given string is a checksummed address
 *
 * @param String $address the given HEX adress
 * @return Boolean
*/
function isChecksumAddress($address) {
    // Check each case
    $address = str_replace('0x','',$address);
    //$addressHash = hash('sha3',strtolower($address));
	$addressHash = hash('sha3-256', strtolower($address));
    $addressArray=str_split($address);
    $addressHashArray=str_split($addressHash);

    for($i = 0; $i < 40; $i++ ) {
        // The nth letter should be uppercase if the nth digit of casemap is 1
        if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
            return false;
        }
    }
    
    return true;
}

if ($found==1) {
	$failed_rs = array('result' => 'failed', 'error' => 'invalid data');
	
	//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
	//echo "payment_id: " . $payment_id . "<br/>";
	$json = file_get_contents('php://input');
	$data = json_decode($json, true);
	
	if (!($data)) {
		switch (json_last_error()) {
			case JSON_ERROR_DEPTH:
				$failed_rs['error'] = 'Reached the maximum stack depth';
				break;
			case JSON_ERROR_STATE_MISMATCH:
				$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
				break;
			case JSON_ERROR_CTRL_CHAR:
				$failed_rs['error'] = 'Incorrect control character';
				break;
			case JSON_ERROR_SYNTAX:
				$failed_rs['error'] = 'Syntax error or JSON invalid';
				break;
			case JSON_ERROR_UTF8:
				$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
				break;
			default:
				$failed_rs['error'] = 'Unknown error';
		}

		//throw new Exception($error);
		
	} else {
		$errors = array();
		if ((!isset($data['requested_crypto_currency'])) || (empty($data['requested_crypto_currency']))) {
			$errors[] = 'requested_crypto_currency is empty';
		} else {
			if (trim($data['requested_crypto_currency']) != 'USDT') {
				$errors[] = 'requested_crypto_currency must be USDT';
			}
		}
		
		if ((!isset($data['fiat_total_amount_to_pay'])) || (empty($data['fiat_total_amount_to_pay']))) {
			$errors[] = 'fiat_total_amount_to_pay is empty';			
		} 
		
		if ((!isset($data['fiat_total_amount_to_pay']['amount'])) || (empty($data['fiat_total_amount_to_pay']['amount']))) {
			$errors[] = 'invalid fiat_total_amount_to_pay data: amount is empty';			
		} else {
			if (floatval($data['fiat_total_amount_to_pay']['amount']) == 0) {
				$errors[] = 'invalid fiat_total_amount_to_pay data: amount must be a number and greater than zero';
			}
			
			if (floatval($data['fiat_total_amount_to_pay']['amount']) < 50) {
				$errors[] = 'invalid fiat_total_amount_to_pay data: amount must be at least 50';
			}
			
			if (floatval($data['fiat_total_amount_to_pay']['amount']) > 20000) {
				$errors[] = 'invalid fiat_total_amount_to_pay data: amount cannot exceed 20000';
			}
		}
		
		if ((!isset($data['fiat_total_amount_to_pay']['currency'])) || (empty($data['fiat_total_amount_to_pay']['currency']))) {
			$errors[] = 'invalid fiat_total_amount_to_pay data: currency is empty';			
		} else {
			if (trim($data['fiat_total_amount_to_pay']['currency']) != 'USD') {
				$errors[] = 'invalid fiat_total_amount_to_pay data: currency must be USD';	
			}			
		}
		
		if ((!isset($data['usdt_wallet_address'])) || (empty($data['usdt_wallet_address']))) {
			$errors[] = 'usdt_wallet_address is empty';			
		} else {
			if (!isAddress($data['usdt_wallet_address'])) {
				$errors[] = 'invalid USDT address';
			}
		} 
		
		if ((!isset($data['user_agent'])) || (empty($data['user_agent']))) {
			$errors[] = 'user_agent is empty';			
		} 
		
		if ((!isset($data['ip'])) || (empty($data['ip']))) {
			$errors[] = 'ip is empty';			
		} 
		
		if ((!isset($data['accept_language'])) || (empty($data['accept_language']))) {
			$errors[] = 'accept_language is empty';			
		} 
		
		if ((!isset($data['partner'])) || (empty($data['partner']))) {
			$errors[] = 'partner is empty';			
		} else {
			if (trim($data['partner']) != 'YOUSCASINO') {
				$errors[] = 'partner must be YOUSCASINO';
			}
		}
		
		if (count($errors) == 0) {
			$errors_sub = array();
			require '../include/dbconfig.php';
			require '../include/common.php';
			
			$fh = @fopen("/var/www/api.xbuy.io/v1/get_payment_id/transaction.log" , 'a');

			function _log($line) {
				global $fh;
				$fline = date('[Ymd H:i:s] ') . $line."\n";
				fwrite($fh, $fline);
				//echo date('[Ymd H:i:s] ').$line."\n";
				//@ob_flush(); 
				//flush();
			}
			
			//prepare data
			$quote_id = '';
			$amount_fiat_to_pay = '';
			$amount_fiat_to_get = '';
			$amount_crypto_to_get = '';
			$email = 'xbuy_user_' . uniqid() . '@xbuy.io';
			$app_end_user_id = common_uuid();
			$payment_id = common_uuid();
			$success_rs = array();
			$success_rs['payment_id'] = $payment_id;
			$fiat_total_amount_to_pay_arr = array();
			$fiat_total_amount_to_pay_arr['amount'] = $data['fiat_total_amount_to_pay']['amount'];
			$fiat_total_amount_to_pay_arr['currency'] = $data['fiat_total_amount_to_pay']['currency'];
			$success_rs['fiat_total_amount_to_pay'] = $fiat_total_amount_to_pay_arr;
			$success_rs['usdt_wallet_address'] = $data['usdt_wallet_address'];
			$success_rs['user_agent'] = $data['user_agent'];
			$success_rs['ip'] = $data['ip'];
			$success_rs['accept_language'] = $data['accept_language'];
			$success_rs['partner'] = $data['partner'];
			
			//get the quote
			$quote_post_data = array();
			$quote_post_data['end_user_id'] = $app_end_user_id;
			$quote_post_data['digital_currency'] = 'USDT';
			$quote_post_data['fiat_currency'] = 'USD';	
			$quote_post_data['requested_currency'] = 'USD';
			$quote_post_data['requested_amount'] = floatval($data['fiat_total_amount_to_pay']['amount']);
			$quote_post_data['wallet_id'] = "xbuy";
			$quote_post_data['client_ip'] = $data['ip'];
			_log(json_encode($quote_post_data));
			$simplex_authorization = "ApiKey " . $simplex_prod_api_key;
			$simplex_quote_res = simplex_api_call('/wallet/merchant/v2/quote', $quote_post_data, $simplex_authorization, "production");
			
			if ($simplex_quote_res['result'] != '') {
				if (isset($simplex_quote_res['result']['error'])) { //error
					//$data['msg'] = "proc_ng";
					//$data['error'] = $simplex_quote_res['result']['error'];
					//_log("BUY::ERROR::" . $simplex_quote_res['result']['error']);
					_log($payment_id . "::error::" . $simplex_quote_res['result']['error']);
					 $errors_sub[] = 'failed to get exchange rate, please contact administrator';
					
					
					
				} else {
					if(isset($simplex_quote_res['result']['quote_id']) && !empty($simplex_quote_res['result']['quote_id'])) {
						
						$quote_id = $simplex_quote_res['result']['quote_id'];
						$amount_fiat_to_pay = $simplex_quote_res['result']['fiat_money']['total_amount'];
						if (floatval($amount_fiat_to_pay) <= 0) {
							$amount_fiat_to_pay = '0.00';
						}
						$amount_fiat_to_get = $simplex_quote_res['result']['fiat_money']['base_amount'];
						if (floatval($amount_fiat_to_get) <= 0) {
							$amount_fiat_to_get = '0.00';
						}
						$fiat_currency = $simplex_quote_res['result']['fiat_money']['currency'];
						$amount_crypto_to_get = $simplex_quote_res['result']['digital_money']['amount'];						
						if (floatval($amount_crypto_to_get) <= 0) {
							$amount_crypto_to_get = '0.00000000';
						}
						
						$crypto_total_amount_to_get_arr = array();
						$crypto_total_amount_to_get_arr['amount'] = $amount_crypto_to_get;
						$crypto_total_amount_to_get_arr['currency'] = 'USDT';
						$success_rs['crypto_total_amount_to_get'] = $crypto_total_amount_to_get_arr;
						$exchange_rate = floatval($amount_crypto_to_get) / floatval($amount_fiat_to_pay);
						$exchange_rate_final = number_format($exchange_rate, 10, '.', '');
						$exchange_rate_final = format_coin($exchange_rate_final);
						$success_rs['exchange_rate'] = $exchange_rate_final;
						
						
						
						
					} else {
						
						_log($payment_id . "::error::unknown error");
						$errors_sub[] = 'failed to get exchange rate, please contact administrator';		
					}
				}
				
				
			} else {
			
				_log($payment_id. "::ERROR::" . $simplex_quote_res['error']);
				$errors_sub[] = 'failed to get exchange rate, please contact administrator';
				
				
			}
			
			if (count($errors_sub) == 0) {
				$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
				if (mysqli_connect_errno() == 0) {
					mysqli_query($dbhandle, "set names utf8;");
					//add to payment
					$fiat_amount_db = mysqli_real_escape_string($dbhandle, $data['fiat_total_amount_to_pay']['amount']);
					$fiat_currency_db = "USD";
					$usdt_wallet_address_db = mysqli_real_escape_string($dbhandle, $data['usdt_wallet_address']);
					$user_agent_db = mysqli_real_escape_string($dbhandle, $data['user_agent']);
					$ip_address_db = mysqli_real_escape_string($dbhandle, $data['ip']);
					$accept_language_db = mysqli_real_escape_string($dbhandle, $data['accept_language']);
					
					$cur_time = time();
					$created_dt_db = date('Y-m-d H:i:s', $cur_time);
					$sql  = "INSERT INTO youscasino_generated_payment (payment_id, created_tm, created_dt, quote_id, fiat_amount, crypto_amount_to_get, fiat_amount_to_get, crypto_currency, fiat_currency, usdt_wallet_address, user_agent, ip_address, accept_language, app_end_user_id, email) VALUES ('$payment_id', $cur_time, '$created_dt_db', ";
					$sql .= "'$quote_id', '$fiat_amount_db', '$amount_crypto_to_get', '$amount_fiat_to_get', 'USDT', 'USD', '$usdt_wallet_address_db', '$user_agent_db', '$ip_address_db', '$accept_language_db', '$app_end_user_id', '$email')";
					_log($sql);					
					if (!mysqli_query($dbhandle, $sql)) {
						_log($payment_id . "::error::cannot insert data");
						@fclose($fh);
						@mysqli_close($dbhandle);						
						$failed_rs['error'] = 'unknown system error, please contact administrator';
						header('Content-Type: application/json');
						echo json_encode($failed_rs);
						die();
						
					} else {
						_log($payment_id . "::success !");
						@fclose($fh);
						header('Content-Type: application/json');
						echo json_encode($success_rs);
						die();
					}
					
				} else {					
					_log($payment_id . "::error::cannot connect db");
					@fclose($fh);
					$failed_rs['error'] = 'unknown system error, please contact administrator';
					header('Content-Type: application/json');
					echo json_encode($failed_rs);
					die();
				}
			} else {
				_log($payment_id . "::error::" . $errors_sub[0]);
				@fclose($fh);
				$failed_rs['error'] = $errors_sub[0];
				header('Content-Type: application/json');
				echo json_encode($failed_rs);
				die();
			}
			
			
		} else {
			$failed_rs['error'] = $errors[0];
			header('Content-Type: application/json');
			echo json_encode($failed_rs);
			die();
		}
			
		
	}

} else {
	header('HTTP/1.0 403 Forbidden');
}
?>