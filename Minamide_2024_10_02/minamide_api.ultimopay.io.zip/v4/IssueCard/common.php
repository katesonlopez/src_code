<?php
/*$base_path = "D:\\xampp\\htdocs\\minamide\\ApiUltimopayIo\\v4";*/
$base_path = "/usr/share/nginx/xapiserver.com/v4-dev";
/*$site_path = "http://localhost/minamide/ApiUltimopayIo/v4";*/
$site_path = "https://xapiserver.com/v4-dev";
