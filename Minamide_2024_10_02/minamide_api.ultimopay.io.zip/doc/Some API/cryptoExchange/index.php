<?php

//header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
//header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding("UTF-8");
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders')) {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line)
{
    // Determine the log file path based on the operating system
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // Windows
        if ($email == "") {
            $logFilePath = 'C:' . DIRECTORY_SEPARATOR . '_cryptoExchange.log';
        } else {
            $logFilePath = 'C:' . DIRECTORY_SEPARATOR . $email . '_cryptoExchange.log';
        }
    } else {
        // Non-Windows (e.g., Unix/Linux)
        if ($email == "") {
            $logFilePath = '/var/www/api.ultimopay.io/v4/cryptoExchange/log/cryptoExchange.log';
        } else {
            $logFilePath = '/var/www/api.ultimopay.io/v4/cryptoExchange/log/' . $email . '.log';
        }
    }

    // Create the directory if it doesn't exist
    $logDirectory = dirname($logFilePath);
    if (!is_dir($logDirectory)) {
        mkdir($logDirectory, 0755, true);
    }

    // Create the log file if it doesn't exist
    if (!file_exists($logFilePath)) {
        touch($logFilePath);
    }

    // Open the log file for appending
    $fh2 = fopen($logFilePath, 'a');

    if ($fh2) {
        $fLine = date('[Ymd H:i:s] ') . $line . "\n";

        // Write the log line to the file
        fwrite($fh2, $fLine);

        // Close the log file
        fclose($fh2);
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../include/dbconfig.php';
    $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (mysqli_connect_errno() != 0) {


        header('Content-Type: application/json');
        http_response_code(500);
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
        echo json_encode($ret_rs);
        die();
    } else {
        _log("", "ket noi thanh cong");
        mysqli_query($dbhandle, "set names utf8;");
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
    $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
    $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
    $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
    $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
    $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
    $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
    $clientSecret4 = 'climbpot api access key';
    $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
    $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
    $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
    $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
    $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
    $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
    //$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
    $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
    $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
    $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
    $apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
    $found = 0;
    $coin = 'USDT';
    $sandbox = 0;
    $partner = "";
    $crypto_pair_arr = array('USDTUSD', 'BTCUSD', 'BUSDUSD', 'USDCUSD');
    $exchange_type_arr = array('buy', 'sell');
    $req_api_key = "";
    $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

    foreach (getallheaders() as $name => $value) {
        //echo "$name: $value\n";
        if ($name == 'Authorization') {
            /*
            if ($value == $apikey) {
                $found=1;
                break;
            } else if ($value == $apikey2) {
                $found = 2;
                break;
            } else if ($value == $apikey3) {
                $found = 3;
                break;
            } else if ($value == $apikey4) {
                $found = 4;
                $coin = 'BTC';
                break;
            } else if ($value == $apikey4_sanbox) {
                $found = 4;
                $sandbox = 1;
                $coin = 'BTC';
                break;
            } else if ($value == $apikey_skynet) {
                $found = 5;
                $coin = 'BTC';
                break;
            } else if ($value == $apikey_sabong) {
                $found = 6;
                $coin = 'USDT';
                $partner = "UltimoCasino";
                break;
            } else if ($value == $apikey_freelancer) {
                $found = 7;
                $coin = 'USDT';
                break;
            } else if ($value == $apikey_bos) {
                $found = 8;
                $coin = 'USDT';
                $partner = "BOS";
                break;
            }
            */
            $req_api_key = trim($value);
            $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
            $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
            if (mysqli_num_rows($partner_rs) > 0) {
                while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
                    $cur_api_key = "Bearer " . $row_partner['api_key'];
                    if ($req_api_key == $cur_api_key) {
                        $req_partner['partner'] = trim($row_partner['partner']);
                        $req_partner['api_key'] = trim($row_partner['api_key']);
                        $req_partner['website'] = trim($row_partner['website']);
                        $selected_api_key = $req_api_key;
                        break;
                    }

                }
            } else {
                _log("", "not found in db");
            }
        }
    }
    @mysqli_close($dbhandle);


    function isValidPassword($password)
    {
        if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
            return FALSE;
        return TRUE;
    }

    function uuid()
    {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    function decimal_notation($float)
    {
        $parts = explode('E', $float);

        if (count($parts) === 2) {
            $exp = abs(end($parts)) + strlen($parts[0]);
            $decimal = number_format($float, $exp);
            return rtrim($decimal, '.0');
        } else {
            return $float;
        }
    }

    function get_crypto_price($_crypto_pair, $_auth_token)
    {
        global $api_graphql_host;
        global $api_host;
        $crypto_price_info = array('buy_price' => '', 'sell_price' => '', 'error' => '', 'raw_error' => '');
        ///////////////////////////////////////////////////
        $tmp_dto_price_arr = array();
        $instruments_price_query = sprintf('{"query":"query ($instrument_id: String!, $is_active: ToggleSwitch) {\n  instruments(instrument_id: $instrument_id, is_active: $is_active) {\n    name\n    instrument_id\n    base_currency_id\n    quote_currency_id\n    price {\n      instrument_id\n      ask\n      bid\n      price_24h_change\n      ts\n    }\n  }\n}","variables":{"instrument_id":"%s"}}', $_crypto_pair);
        unset($instruments_price_res);
        $instruments_price_res = api_call('/api/v4/securities/statistics', 0, $instruments_price_query, $tmp_dto_price_arr, $_auth_token);
        $raw_res_body = json_encode($instruments_price_res);
        if (($instruments_price_res['http_code'] == "200") || ($instruments_price_res['http_code'] == "200 OK")) {
            if (is_array($instruments_price_res['result']['data']['instruments'])) {
                $target_instrument = $instruments_price_res['result']['data']['instruments'][0];
                if (!empty($target_instrument)) {
                    if (!empty($target_instrument['price'])) {
                        if ((!empty($target_instrument['price']['instrument_id'])) && (!empty($target_instrument['price']['bid'])) && (!empty($target_instrument['price']['ask']))) {
                            if (strtoupper($target_instrument['price']['instrument_id']) == $_crypto_pair) {
                                $crypto_price_info['buy_price'] = $target_instrument['price']['bid'];
                                $crypto_price_info['sell_price'] = $target_instrument['price']['ask'];
                            }
                        } else {
                            //_log("api call /api/v4/securities/statistics ERROR: price.instrument_id or price.ask are empty.");
                            $crypto_price_info['error'] = 'data.instruments.price_bid_ask_are_empty';
                            $crypto_price_info['raw_error'] = $raw_res_body;
                        }
                    } else {
                        //_log("api call /api/v4/securities/statistics ERROR: price is empty.");
                        $crypto_price_info['error'] = 'data.instruments.price_is_empty';
                        $crypto_price_info['raw_error'] = $raw_res_body;
                    }
                } else {
                    //_log("api call /api/v4/securities/statistics ERROR: array is empty");
                    $crypto_price_info['error'] = 'data.instruments_array_is_empty';
                    $crypto_price_info['raw_error'] = $raw_res_body;
                }
            } else {
                //_log("api call /api/v4/securities/statistics ERROR: is not array");
                $crypto_price_info['error'] = 'data.instruments_is_not_array';
                $crypto_price_info['raw_error'] = $raw_res_body;
            }


        } else {
            $crypto_price_info['error'] = 'ng_http_response_code';
            $crypto_price_info['raw_error'] = $raw_res_body;
        }
        ///////////////////////////////////////////////////
        return $crypto_price_info;
    }

    function get_wallet_balance($currency_id, $_auth_token)
    {
        global $api_graphql_host;
        global $api_host;
        $wallet_balance_info = array('crypto_balance' => '', 'usd_balance' => '', 'error' => '');
        ///////////////////////////////////////////////////
        $tmp_dto_arr = array();
        $my_account_balances_query = '{"query":"{\\n  accounts_balances {\\n    currency_id\\n    total_balance\\n    exposed_balance\\n    currency {\\n      type\\n      precision\\n      payment_routes {\\n        crypto_network\\n        crypto_address_tag_type\\n      }\\n    }\\n    free_balance\\n    free_balance_USD: free_balance_quoted(quote_currency_id: \\"USD\\")\\n    free_balance_BTC: free_balance_quoted(quote_currency_id: \\"BTC\\")\\n    free_balance_ETH: free_balance_quoted(quote_currency_id: \\"ETH\\")\\n    free_balance_USDT: free_balance_quoted(quote_currency_id: \\"USDT\\")\\n  }\\n}","variables":{}}';
        unset($accounts_res);
        $accounts_res = api_call('/api/v4/accounts', 0, $my_account_balances_query, $tmp_dto_arr, $_auth_token);
        if (($accounts_res['http_code'] == "200") || ($accounts_res['http_code'] == "200 OK")) {
            if (!empty($accounts_res['result']['errors'])) {
                $wallet_balance_info['error'] = 'access_token_expired';
            } else {
                if (is_array($accounts_res['result']['data']['accounts_balances'])) {
                    $accounts_arr = $accounts_res['result']['data']['accounts_balances'];
                    if (count($accounts_arr) > 0) {
                        $found_currency = 0;
                        for ($coin_cnt = 0; $coin_cnt < count($accounts_arr); $coin_cnt++) {
                            $cur_coin_stat = $accounts_arr[$coin_cnt];
                            if (strtoupper($cur_coin_stat['currency_id']) == $currency_id) {
                                if (isset($cur_coin_stat['total_balance'])) {
                                    $wallet_balance_info['crypto_balance'] = $cur_coin_stat['total_balance'];
                                    //$found_currency = 1;
                                }
                            } else if (strtoupper($cur_coin_stat['currency_id']) == 'USD') {
                                if (isset($cur_coin_stat['total_balance'])) {
                                    $wallet_balance_info['usd_balance'] = $cur_coin_stat['total_balance'];
                                    //$found_currency = 1;
                                }
                            }
                        }
                        //if ($found_currency == 0) {
                        //	$wallet_balance_info['error'] = 'currency_not_found';
                        //}
                    }
                } else {
                    $wallet_balance_info['error'] = 'data.account_balances_is_empty';
                }
            }
        } else {
            $wallet_balance_info['error'] = 'ng_http_response_code';
        }
        ///////////////////////////////////////////////////
        return $wallet_balance_info;
    }

    function backoffice_sign_in($_backoffice_dec_pwd)
    {
        global $api_graphql_host;
        global $api_host;
        $backoffice_data = array('result' => '', 'error' => '', 'backoffice_access_token' => '', 'backoffice_refresh_token' => '');
        $backofice_signin_res = signIn(BACKOFFICE_ADMIN_USERNAME, $_backoffice_dec_pwd, $api_graphql_host, $api_host, 'admin');
        if ($backofice_signin_res['result'] == 'success') {
            if (!isset($backofice_signin_res['data']['AuthenticationResult'])) {
                $backoffice_data['error'] = "Cannot login now due to system error, please try again later";
                //_log($username . " :: AuthenticationResult.AccessToken is empty !");
            } else {
                $backoffice_data['result'] = 'success';
                $backoffice_data['error'] = '';
                $backoffice_data['backoffice_access_token'] = $backofice_signin_res['data']['AuthenticationResult']['AccessToken'];
                $backoffice_data['backoffice_refresh_token'] = $backofice_signin_res['data']['AuthenticationResult']['RefreshToken'];
            }
        } else {
            $backoffice_data['result'] = 'failed';
            if (strpos(strtolower($backofice_signin_res['message']), "incorrect username or password") !== false) {
                $backoffice_data['error'] = "Incorrect login email or password";
                //_log("LOGIN (backoffice) : incorrect username or password");
            } else if (strpos(strtolower($backofice_signin_res['message']), "user does not exist") !== false) {
                $backoffice_data['error'] = "User does not exist";
                //_log("LOGIN (backoffice) : user does not exist");
            } else if (strpos(strtolower($backofice_signin_res['message']), "invalid credentials") !== false) {
                $backoffice_data['error'] = "Incorrect login email or password";
                //_log("LOGIN (backoffice) : Incorrect login email or password");
            } else if (strpos(strtolower($backofice_signin_res['message']), "could not connect to plusqo") !== false) {
                $backoffice_data['error'] = "Cannot login now, please try again later !";
                //_log("LOGIN (backoffice) : " . $backofice_signin_res['result']['message']);
            } else if (strpos(strtolower($backofice_signin_res['message']), "2fa required") !== false) {
                $data['error'] = "need_2fa_shift";
                //_log("LOGIN (backoffice) : 2fa required");
            } else if (strpos(strtolower($backofice_signin_res['message']), "2fa code invalid") !== false) {
                $backoffice_data['error'] = "Invalid 2FA Code";
                //_log("LOGIN:: " . $username . " : invalid 2fa code");
            } else if (strpos(strtolower($backofice_signin_res['message']), "user is not confirmed") !== false) {
                //$backoffice_data['msg'] = 'proc_ng_not_completed';
                $backoffice_data['error'] = "user is not confirmed";
                //_log("LOGIN (backoffice) : user is not confirmed");
            } else {
                $backoffice_data['error'] = "Cannot login now due to system error, please try again later";
                //_log("LOGIN (backoffice) : " . $backofice_signin_res['message']);
            }
        }
        return $backoffice_data;
    }


    /*
    function format_coin($in_amount) {

        $in_amount_temp = "" . $in_amount;
        $dotpos = strpos($in_amount_temp,".",0);
        if ( $dotpos !== false ) {
            $p1 = substr($in_amount_temp,0, $dotpos);
            $p2 = substr($in_amount_temp,$dotpos + 1);
            $p2_len = strlen($p2);
            if ($p2_len > 8) {
                $p2_final =	substr($p2, 0, 8);
            } else {
                $p2_final = $p2;
            }
            $amount_final = $p1 . "." . $p2_final;
        } else {
            $amount_final = $in_amount_temp;
        }
        return $amount_final;
    }

    function format_fiat($in_amount, $float_point) {

        $in_amount_temp = "" . $in_amount;
        $dotpos = strpos($in_amount_temp,".",0);
        if ( $dotpos !== false ) {
            $p1 = substr($in_amount_temp,0, $dotpos);
            $p2 = substr($in_amount_temp,$dotpos + 1);
            $p2_len = strlen($p2);
            if ($p2_len > $float_point) {
                $p2_final =	substr($p2, 0, $float_point);
            } else {
                $p2_final = $p2;
            }
            $amount_final = $p1 . "." . $p2_final;
        } else {
            $amount_final = $in_amount_temp;
        }
        return $amount_final;
    }

    function common_uuid()
    {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
    */
    /**
     * Checks if the given string is an address
     *
     * @param String $address the given HEX adress
     * @return Boolean
     */
    /*
    function isAddress($address) {
        if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
            // Check if it has the basic requirements of an address
            return false;
        } elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
            // If it's all small caps or all all caps, return true
            return true;
        } else {
            // Otherwise check each case
            return isChecksumAddress($address);
        }
    }
    */
    /**
     * Checks if the given string is a checksummed address
     *
     * @param String $address the given HEX adress
     * @return Boolean
     */
    /*
    function isChecksumAddress($address) {
        // Check each case
        $address = str_replace('0x','',$address);
        //$addressHash = hash('sha3',strtolower($address));
        $addressHash = hash('sha3-256', strtolower($address));
        $addressArray=str_split($address);
        $addressHashArray=str_split($addressHash);

        for($i = 0; $i < 40; $i++ ) {
            // The nth letter should be uppercase if the nth digit of casemap is 1
            if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
                return false;
            }
        }

        return true;
    }
    */

    /**
     * @example truncate(-1.49999, 2); // returns -1.49
     * @example truncate(.49999, 3); // returns 0.499
     * @param float $val
     * @param int f
     * @return float
     */
    /*
   function truncate($val, $f="0")
   {
       if(($p = strpos($val, '.')) !== false) {
           $val = floatval(substr($val, 0, $p + 1 + $f));
       }
       return $val;
   }


   function my_number($val) {
       $tmp_val = "" . $val;
       $dotpos = strpos($tmp_val,".",0);
       if ( $dotpos !== false ) {
           $p1 = substr($tmp_val,0, $dotpos);
           $p2 = substr($tmp_val,$dotpos + 1);
           $p2_len = strlen($p2);
           if ($p2_len > 8) {
               $p2_final =	substr($p2, 0, 8);
           } else {
               $p2_final = $p2;
           }
           $amount_final = $p1 . "." . $p2_final;
       } else {
           $amount_final = $tmp_val;
       }
       return $amount_final;
   }
   */
    //_log("bat dau xu ly...");
    //if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6) || ($found==7) || ($found==8)) {
    if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {


        //$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);

        //echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
        //echo "payment_id: " . $payment_id . "<br/>";
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);

        if (!($data)) {

            switch (json_last_error()) {
                case JSON_ERROR_DEPTH:
                    //$failed_rs['error'] = 'Reached the maximum stack depth';
                    _log("", 'Reached the maximum stack depth');
                    break;
                case JSON_ERROR_STATE_MISMATCH:
                    //$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
                    _log("", 'Incorrect discharges or mismatch mode');
                    break;
                case JSON_ERROR_CTRL_CHAR:
                    //$failed_rs['error'] = 'Incorrect control character';
                    _log("", 'Incorrect control character');
                    break;
                case JSON_ERROR_SYNTAX:
                    //$failed_rs['error'] = 'Syntax error or JSON invalid';
                    _log("", 'Syntax error or JSON invalid');
                    break;
                case JSON_ERROR_UTF8:
                    //$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
                    _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
                    break;
                default:
                    //$failed_rs['error'] = 'Unknown error';
                    _log("", 'Unknown error');
                    break;
            }

            //throw new Exception($error);
            //_log($failed_rs['error']);
            _log("", 'A non-empty request body is required.');
            header('Content-Type: application/json');
            http_response_code(400);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
            echo json_encode($ret_rs);
            die();

        } else {
            unset($errors);
            $errors = array();

            //email
            if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
                $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
                $errors[] = $error_obj;
            }


            //auth_token
            if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
                $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
                $errors[] = $error_obj;
            }

            //type
            if ((!isset($data['type'])) || (empty($data['type']))) {
                $error_obj = array('errorCode' => 4, 'errorMessage' => 'type parameter is required.');
                $errors[] = $error_obj;
            } else {
                if (!in_array(strtolower($data['type']), $exchange_type_arr)) {
                    $error_obj = array('errorCode' => 5, 'errorMessage' => "unsupported type. Only 'buy' or 'sell' are allowed.");
                    $errors[] = $error_obj;
                }
            }

            //pair
            if ((!isset($data['pair'])) || (empty($data['pair']))) {
                $error_obj = array('errorCode' => 6, 'errorMessage' => 'pair parameter is required.');
                $errors[] = $error_obj;
            } else {
                if (!in_array(strtoupper($data['pair']), $crypto_pair_arr)) {
                    $error_obj = array('errorCode' => 7, 'errorMessage' => 'unsupported pair.');
                    $errors[] = $error_obj;
                }
            }


            if (count($errors) == 0) {

                $errors_sub = array();


                //proceed to shift api
                require_once '../include/common.php';
                require_once '../include/cognito.php';
                //require_once '../include/dbconfig.php';

                ////////////////////////////////////////////////////

                //$allowed_currency_arr = array('USDT');
                $allowed_shift_currency_arr = array('USDT', 'BTC', 'BUSD', 'USDC', 'USD');
                //receive POST params
                $reg_email_address = trim($data['email_address']);
                //$auth_token = trim($data['auth_token']);
                $private_key = trim($data['auth_token']);
                $type = trim(strtolower($data['type']));
                $pair = trim(strtoupper($data['pair']));
                $amount = trim($data['amount']);
                //$buyable_balance_before_order = 0;
                //$sellable_balance_before_order = 0;
                $currency = '';
                $pair2 = '';
                if ($pair == "USDTUSD") {
                    $currency = 'USDT';
                    $pair2 = $pair;
                } else if ($pair == "BUSDUSD") {
                    $currency = 'BUSD';
                    $pair2 = "BUSDUSDT";
                } else if ($pair == "BTCUSD") {
                    $currency = 'BTC';
                    $pair2 = $pair;
                } else if ($pair == "USDCUSD") {
                    $currency = 'USDC';
                    $pair2 = $pair;
                }

                //$currency = strtoupper(trim($data['currency']));
                //$crypto_price_arr = array();

                _log($reg_email_address, "crypto exchange started...");

                //$post_data = array();
                //$post_data['exchange'] = "PLUSQO";
                //$post_data['refreshToken'] = $auth_refresh_token;


                //$signin_user_data = array();

                $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
                if (mysqli_connect_errno() == 0) {
                    mysqli_query($dbhandle, "set names utf8;");
                    $allow_access_api = 0;

                    $my_db_private_key = '';
                    $my_db_auth_token = '';
                    $my_db_wallet_auth_token = '';
                    $my_db_sigin_dt = '';
                    $my_db_token_refresh_dt = '';
                    $my_db_shift_user_id = '';
                    $nonce = millitime();
                    $usd_balance_before_order = 0;
                    $usd_balance_after_order = 0;
                    $crypto_balance_before_order = 0;
                    $crypto_balance_after_order = 0;
                    $sql_check_signin = "select a.*, b.shift_user_id from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_email_address";
                    //_log($sql_check_signin);
                    $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
                    if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
                        $allow_access_api = 1;
                        while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
                            $my_db_auth_token = trim($row_signin['auth_token']);
                            $my_db_wallet_auth_token = trim($row_signin['wallet_auth_token']);
                            $my_db_sigin_dt = $row_signin['signin_dt'];
                            $my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
                            $my_db_private_key = trim($row_signin['private_key']);
                            $my_db_shift_user_id = $row_signin['shift_user_id'];

                        }
                    }
                    $authorization_value = "Bearer " . $my_db_auth_token;

                    $shift_user_id = '';
                    $sql_get_shift_user_id = "select * from cryptocash_shift_user_ids where shift_email_address='$reg_email_address' limit 1";
                    $rs_get_shift_user_id = mysqli_query($dbhandle, $sql_get_shift_user_id);
                    if (mysqli_num_rows($rs_get_shift_user_id) == 1) {
                        while ($row_shift_user_id = mysqli_fetch_array($rs_get_shift_user_id, MYSQLI_ASSOC)) {
                            $shift_user_id = $row_shift_user_id['shift_user_sub_id'];
                        }
                    }


                    if ($allow_access_api == 1) {

                        if ($private_key != $my_db_private_key) {
                            @mysqli_close($dbhandle);
                            header('Content-Type: application/json');
                            http_response_code(500);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'Unauthorized.');
                            echo json_encode($ret_rs);
                            die();
                        } else {
                            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            //try getting wallet USD wallet balance before execution of order...
                            ////////////////////////////////////////////////////////////////////////////
                            $before_order_wallet_info = get_wallet_balance($currency, $authorization_value);
                            if (($before_order_wallet_info['error'] == '') && ($before_order_wallet_info['crypto_balance'] !== '') && ($before_order_wallet_info['usd_balance'] !== '')) {
                                $usd_balance_before_order = $before_order_wallet_info['usd_balance'];
                                $crypto_balance_before_order = $before_order_wallet_info['crypto_balance'];
                            } else {
                                _log($reg_email_address, "get_wallet_balance (before order) error : " . $before_order_wallet_info['error']);
                            }
                            _log($reg_email_address, "usd_balance_before_order = " . $usd_balance_before_order);
                            //sleep(1);

                            ///////////////////////////////////////////////////////////////////////////////////////////
                            if ($currency == 'BUSD' || $currency == 'USDT' || $currency == 'USDC') {

                                $securities_sell_price = 0;
                                $securities_buy_price = 0;

                                $crypto_price_data = get_crypto_price($pair2, $authorization_value);
                                if (($crypto_price_data['error'] == '') && ($crypto_price_data['buy_price'] !== '') && ($crypto_price_data['sell_price'] !== '')) {
                                    $securities_buy_price = $crypto_price_data['buy_price'];
                                    $securities_sell_price = $crypto_price_data['sell_price'];
                                } else {
                                    _log($reg_email_address, "get_crypto_price error : " . $crypto_price_data['error'] . " / " . $crypto_price_data['raw_error']);
                                    @mysqli_close($dbhandle);
                                    header('Content-Type: application/json');
                                    http_response_code(500);
                                    $ret_rs['result'] = 'failed';
                                    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'unknown error occurred. please contact administrator for help #1');
                                    echo json_encode($ret_rs);
                                    die();
                                }
                                ////////////////////////////////////////////////////////////
                                /*
                                $tmp_dto_securities_arr = array();
                                $instruments_price_query = sprintf('{"query":"query ($instrument_id: String!, $is_active: ToggleSwitch) {\n  instruments(instrument_id: $instrument_id, is_active: $is_active) {\n    name\n    instrument_id\n    base_currency_id\n    quote_currency_id\n    price {\n      instrument_id\n      ask\n      bid\n      price_24h_change\n      ts\n    }\n  }\n}","variables":{"instrument_id":"%s"}}', $pair2);
                                unset($instruments_price_res);
                                $instruments_price_res = api_call('/api/v4/securities/statistics', 0, $instruments_price_query , $tmp_dto_securities_arr, $authorization_value);
                                if (($instruments_price_res['http_code'] == "200") || ($instruments_price_res['http_code'] == "200 OK")) {
                                    if (is_array($instruments_price_res['result']['data']['instruments'])) {
                                        $target_instrument = $instruments_price_res['result']['data']['instruments'][0];
                                        if (!empty($target_instrument)) {
                                            if (!empty($target_instrument['price'])) {
                                                if ((!empty($target_instrument['price']['instrument_id'])) && (!empty($target_instrument['price']['bid'])) && (!empty($target_instrument['price']['ask']))) {
                                                    if (strtoupper($target_instrument['price']['instrument_id']) == $pair2) {
                                                        //$crypto_buy_max_price = $target_instrument['price']['bid'];
                                                        if (!empty($target_instrument['price']['ask'])) {
                                                            $securities_sell_price = $target_instrument['price']['ask'];
                                                        }
                                                        if (isset($cur_pair_stat['bid'])) {
                                                            $securities_buy_price = $target_instrument['price']['bid'];
                                                        }
                                                    } else {
                                                        _log($reg_email_address, "api call /api/v4/securities/statistics ERROR: target pair not found : " . $target_instrument['price']['instrument_id']);
                                                    }
                                                } else {
                                                    _log($reg_email_address, "api call /api/v4/securities/statistics ERROR: price.instrument_id or price.ask or price.bid are empty.");
                                                }
                                            } else {
                                                _log($reg_email_address, "api call /api/v4/securities/statistics ERROR: price is empty");
                                            }
                                        } else {
                                            _log($reg_email_address, "api call /api/v4/securities/statistics ERROR: array is empty");
                                        }
                                    } else {
                                        _log($reg_email_address, "api call /api/v4/securities/statistics ERROR: is not array");

                                    }


                                } else {
                                    $raw_error = json_encode($instruments_price_res);
                                    _log($reg_email_address, "api call /api/v4/securities/statistics ERROR: " . $raw_error);
                                }
                                */
                                ////////////////////////////////////////////////////////////

                                $amount_flag = 0;
                                if ($type == "sell") {
                                    _log($reg_email_address, "usd_balance_before_sell = " . $usd_balance_before_order . ", sell amount = " . $amount);
                                    if ($crypto_balance_before_order >= $amount) {
                                        $amount_flag = 1;
                                    }
                                } else if ($type == "buy") {
                                    $feePercent = 1.03;
                                    $needed_usd_amount = $amount * $securities_sell_price * $feePercent;
                                    //_log($reg_email_address, "usd_balance_before_buy = " . $usd_balance_before_order . "amount_usd = " . $amount_usd);
                                    _log($reg_email_address, "usd_balance_before_buy = " . $usd_balance_before_order . ", buy amount = " . $amount);
                                    if ($usd_balance_before_order >= $needed_usd_amount) {
                                        $amount_flag = 1;
                                    }
                                }

                                if ($amount_flag == 1) {

                                    $dec_configurator_key = '';
                                    _log($reg_email_address, "try call get_configurator_key api...");
                                    $plusqo_configurator_info_res = get_configurator_key($reg_email_address, $my_db_auth_token, 'plusqo_backoffice_key_salt_v4', 'plusqo_backoffice_ec_key_v4');
                                    if (($plusqo_configurator_info_res['http_code'] == "200") || ($plusqo_configurator_info_res['http_code'] == "200 OK")) {
                                        _log($reg_email_address, "call get_configurator_key api success.");
                                        //_log($reg_email_address, "::target_key_value = " . $plusqo_configurator_info_res['result']['target_key_value']);
                                        if (!empty($plusqo_configurator_info_res['result']['target_key_value'])) {
                                            $dec_configurator_key = trim($plusqo_configurator_info_res['result']['target_key_value']);
                                            _log($reg_email_address, "::get dec_configurator_key success : " . $dec_configurator_key);
                                        }
                                    } else {
                                        _log($reg_email_address, "call dec_configurator_key api failed.");
                                    }

                                    if ($dec_configurator_key == '') {
                                        _log($reg_email_address, "failed logging by Configurator Account (get dec_configurator_key failed)! try use default value...");
                                        $dec_configurator_key = BACKOFFICE_ADMIN_PWD;
                                    }

                                    _log($reg_email_address, "try logging in by Configurator Account...");
                                    $configurator_access_token = '';
                                    $admin_auth_res = _cognito_getAdminAuthToken();
                                    //if ($admin_auth_res['data'] != null) {
                                    //	_log($reg_email_address, "call getAdminAuthToken api success.");
                                    //	$configurator_access_token = $admin_auth_res['data'];
                                    //}


                                    $configurator_access_token = '';
                                    //$backoffice_signin_result = backoffice_sign_in($dec_configurator_key);
                                    if ($admin_auth_res['data'] != null) {
                                        //if ($backoffice_signin_result['result'] == 'success') {
                                        //_log($reg_email_address, "Access Token (Backoffice) = " . $backoffice_signin_result['backoffice_access_token']);
                                        //_log($reg_email_address, "Refresh Token (Backoffice) = " . $backoffice_signin_result['backoffice_refresh_token']);
                                        _log($reg_email_address, "Access Token (Backoffice) = " . $admin_auth_res['data']);
                                        //$configurator_access_token = trim($backoffice_signin_result['backoffice_access_token']);
                                        $configurator_access_token = trim($admin_auth_res['data']);
                                        $configurator_auth_value = "Bearer " . $configurator_access_token;
                                        if ($configurator_access_token != '') {
                                            _log($reg_email_address, "::Configurator Account logged in successful. Try execute balancecorrection...");
                                            $final_usd_amount = 0;
                                            if ($type == "sell") {
                                                //$deducted_amount_crypto = format_fiat(number_format($inputSellAmount, 10, '.', ''), 2);
                                                //$received_amount_usd = format_fiat(number_format($amount_usd, 10, '.', ''), 2);
                                                $feePercent = 0.97;
                                                $received_amount_usd = $amount * $securities_buy_price * $feePercent;
                                                $received_amount_usd = format_fiat(number_format($received_amount_usd, 10, '.', ''), 2);
                                                $added_currency_id = "USD";
                                                $create_account_transaction_comment = 'Sell ' . $amount . ' ' . $currency;
                                                $create_account_transaction_debit_query = sprintf('{"query":"mutation ($items: [RecordTransactionItem!]!) {\\n  create_account_transaction(items: $items) {\\n    parent_transaction_id\\n    account_transactions {\\n      account_transaction_id\\n      type\\n      amount\\n    }\\n  }\\n}","variables":{"items":[{"user_id":"%s","currency_id":"%s","type":"debit","transaction_class":"payment","amount":%s,"comment":"%s"}]}}',
                                                    $shift_user_id, $currency, $amount, $create_account_transaction_comment);

                                                $create_account_transaction_credit_query = sprintf('{"query":"mutation ($items: [RecordTransactionItem!]!) {\\n  create_account_transaction(items: $items) {\\n    parent_transaction_id\\n    account_transactions {\\n      account_transaction_id\\n      type\\n      amount\\n    }\\n  }\\n}","variables":{"items":[{"user_id":"%s","currency_id":"%s","type":"credit","transaction_class":"payment","amount":%s,"comment":"%s"}]}}',
                                                    $shift_user_id, $added_currency_id, $received_amount_usd, $create_account_transaction_comment);

                                                $final_usd_amount = $received_amount_usd;
                                            } else if ($type == "buy") {
                                                $feePercent = 1.03;
                                                $pay_amount_usd = $amount * $securities_sell_price * $feePercent;
                                                $pay_amount_usd = format_fiat(number_format($pay_amount_usd, 10, '.', ''), 2);
                                                $deduction_currency_id = "USD";
                                                $create_account_transaction_comment = 'Buy ' . $amount . ' ' . $currency;
                                                $create_account_transaction_debit_query = sprintf('{"query":"mutation ($items: [RecordTransactionItem!]!) {\\n  create_account_transaction(items: $items) {\\n    parent_transaction_id\\n    account_transactions {\\n      account_transaction_id\\n      type\\n      amount\\n    }\\n  }\\n}","variables":{"items":[{"user_id":"%s","currency_id":"%s","type":"debit","transaction_class":"payment","amount":%s,"comment":"%s"}]}}',
                                                    $shift_user_id, $deduction_currency_id, $pay_amount_usd, $create_account_transaction_comment);

                                                $create_account_transaction_credit_query = sprintf('{"query":"mutation ($items: [RecordTransactionItem!]!) {\\n  create_account_transaction(items: $items) {\\n    parent_transaction_id\\n    account_transactions {\\n      account_transaction_id\\n      type\\n      amount\\n    }\\n  }\\n}","variables":{"items":[{"user_id":"%s","currency_id":"%s","type":"credit","transaction_class":"payment","amount":%s,"comment":"%s"}]}}',
                                                    $shift_user_id, $currency, $amount, $create_account_transaction_comment);

                                                $final_usd_amount = $pay_amount_usd;
                                            }

                                            unset($create_account_transaction_debit_res);
                                            _log($reg_email_address, $create_account_transaction_debit_query);
                                            $tmp_dto_debit_arr = array();
                                            $create_account_transaction_debit_res = api_call(
                                                '/api/v4/create_account_transaction',
                                                0,
                                                $create_account_transaction_debit_query,
                                                $tmp_dto_debit_arr,
                                                $configurator_auth_value);
                                            if (($create_account_transaction_debit_res['http_code'] == "200") || ($create_account_transaction_debit_res['http_code'] == "200 OK")) {
                                                if (!empty($create_account_transaction_debit_res['result']['errors'])) {
                                                    _log($reg_email_address, "balancecorrection execution(1) failed : " . $create_account_transaction_debit_res['result']['errors'][0]['message']);
                                                    @mysqli_close($dbhandle);
                                                    header('Content-Type: application/json');
                                                    http_response_code(500);
                                                    $ret_rs['result'] = 'failed';
                                                    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #2.');
                                                    echo json_encode($ret_rs);
                                                    die();
                                                } else {
                                                    _log($reg_email_address, "executed balancecorrection(1) successful. Try execute balancecorrection(2)...");
                                                    unset($create_account_transaction_credit_res);
                                                    _log($reg_email_address, $create_account_transaction_credit_query);
                                                    $tmp_dto_credit_arr = array();
                                                    $create_account_transaction_credit_res = api_call('/api/v4/create_account_transaction', 0, $create_account_transaction_credit_query, $tmp_dto_credit_arr, $configurator_auth_value);
                                                    if (($create_account_transaction_credit_res['http_code'] == "200") || ($create_account_transaction_credit_res['http_code'] == "200 OK")) {
                                                        if (!empty($create_account_transaction_credit_res['result']['errors'])) {
                                                            _log($reg_email_address, "balancecorrection execution(2) failed : " . $create_account_transaction_credit_res['result']['errors'][0]['message']);
                                                            @mysqli_close($dbhandle);
                                                            header('Content-Type: application/json');
                                                            http_response_code(500);
                                                            $ret_rs['result'] = 'failed';
                                                            $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #3.');
                                                            echo json_encode($ret_rs);
                                                            die();
                                                        } else {
                                                            _log($reg_email_address, "executed balancecorrection(2) successful.");
                                                            $tx_history_date = date('Y/m/d H:i:s');
                                                            $sql_add_tx_history = "INSERT INTO cryptocash_exchange_history (id, email_address, currency, type, amount, usd_amount, status, date, tx_id, created_from) VALUES (null, '$reg_email_address', '$currency', '$type', '$amount','$final_usd_amount', 'completely_filled', '$tx_history_date', '', '" . $req_partner['partner'] . "')";
                                                            if (mysqli_query($dbhandle, $sql_add_tx_history)) {
                                                                $exchange_res = array('email_address' => $reg_email_address, 'id' => '');
                                                                $exchange_res_details = array();

                                                                $exchange_res_details['type'] = $type;
                                                                $exchange_res_details['pair'] = $pair;
                                                                $exchange_res_details['currency'] = $currency;
                                                                $exchange_res_details['amount'] = $amount;
                                                                $exchange_res_details['status'] = "success";
                                                                if ($type == "sell") {
                                                                    $exchange_res_details['received_amount'] = abs($final_usd_amount);
                                                                } else if ($type == "buy") {
                                                                    $exchange_res_details['paid_amount'] = abs($final_usd_amount);
                                                                }
                                                                $tx_history_date_utc = strtotime($tx_history_date) - 32400; //change to UTC
                                                                $exchange_res_details['created_dt'] = date('Y/m/d H:i:s', $tx_history_date_utc);

                                                                $exchange_res['details'] = $exchange_res_details;
                                                                //_log($reg_email_address, "ra toi day roi !");
                                                                ////////////////////////////////////////////////////////

                                                                @mysqli_close($dbhandle);
                                                                $ret_rs['result'] = 'success';
                                                                $ret_rs['exchange_response'] = $exchange_res;
                                                                header('Content-Type: application/json');
                                                                echo json_encode($ret_rs);
                                                                die();
                                                            } else {
                                                                _log($reg_email_address, $sql_add_tx_history);
                                                            }
                                                        }
                                                    } else {
                                                        _log($reg_email_address, "balancecorrection execution(2) failed: not 200 ok");
                                                        @mysqli_close($dbhandle);
                                                        header('Content-Type: application/json');
                                                        http_response_code(500);
                                                        $ret_rs['result'] = 'failed';
                                                        $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #4.');
                                                        echo json_encode($ret_rs);
                                                        die();
                                                    }
                                                }
                                            } else {
                                                _log($reg_email_address, "balancecorrection execution(1) failed: not 200 ok");
                                                @mysqli_close($dbhandle);
                                                header('Content-Type: application/json');
                                                http_response_code(500);
                                                $ret_rs['result'] = 'failed';
                                                $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #5.');
                                                echo json_encode($ret_rs);
                                                die();
                                            }

                                        } else {
                                            _log($reg_email_address, "failed to get Backoffice Access Token");
                                            @mysqli_close($dbhandle);
                                            header('Content-Type: application/json');
                                            http_response_code(500);
                                            $ret_rs['result'] = 'failed';
                                            $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #6.');
                                            echo json_encode($ret_rs);
                                            die();
                                        }
                                    } else {
                                        //_log($reg_email_address, "failed logging by Configurator Account : " . $backoffice_signin_result['error']);
                                        @mysqli_close($dbhandle);
                                        header('Content-Type: application/json');
                                        http_response_code(500);
                                        $ret_rs['result'] = 'failed';
                                        $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #7.');
                                        echo json_encode($ret_rs);
                                        die();
                                    }


                                } else {
                                    @mysqli_close($dbhandle);
                                    header('Content-Type: application/json');
                                    http_response_code(500);
                                    $ret_rs['result'] = 'failed';
                                    $ret_rs['error'] = array('errorCode' => 8, 'errorMessage' => 'Insufficiency balance to execute this order.');
                                    echo json_encode($ret_rs);
                                    die();
                                }


                            } else {
                                $tmp_dto_create_order_arr = array();
                                $create_order_query = sprintf('{"query":"mutation ($instrument_id: String!, $type: OrderType!, $price: Float, $side: OrderSide!, $time_in_force: OrderTimeInForce!, $quantity: Float!, $expires_at: String, $quantity_mode: OrderQuantityMode) {\\n  create_order(instrument_id: $instrument_id, type: $type, price: $price, side: $side, time_in_force: $time_in_force, quantity: $quantity, expires_at: $expires_at, quantity_mode: $quantity_mode) {\\n    order_id\\n    type\\n    side\\n    status\\n    price\\n    quantity\\n    executed_quantity\\n    remaining_quantity\\n    quantity_mode\\n    instrument_id\\n    message\\n    updated_at\\n    created_at\\n    expires_at\\n  }\\n}","variables":{"instrument_id":"%s","type":"market","price":null,"side":"%s","time_in_force":"ioc","quantity":%s,"quantity_mode":"base"}}', $pair, $type, $amount);
                                _log($reg_email_address, $create_order_query);
                                unset($create_order_res);
                                $create_order_res = api_call('/api/v4/create_order/', 0, $create_order_query, $tmp_dto_create_order_arr, $authorization_value);
                                if (($create_order_res['http_code'] == "200") || ($create_order_res['http_code'] == "200 OK")) {
                                    if (!empty($create_order_res['result']['errors'])) {
                                        _log($reg_email_address, "::/api/v4/create_order/ failed : " . $create_order_res['result']['errors'][0]['message']);
                                        @mysqli_close($dbhandle);
                                        header('Content-Type: application/json');
                                        http_response_code(500);
                                        $ret_rs['result'] = 'failed';
                                        $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #8.');
                                        echo json_encode($ret_rs);
                                        die();
                                    } else {
                                        $res_order_id = (!empty($create_order_res['result']['data']['create_order']['order_id'])) ? $create_order_res['result']['data']['create_order']['order_id'] : '';
                                        $res_order_status = (!empty($create_order_res['result']['data']['create_order']['status'])) ? $create_order_res['result']['data']['create_order']['status'] : '';
                                        $res_order_quantity = (!empty($create_order_res['result']['data']['create_order']['quantity'])) ? $create_order_res['result']['data']['create_order']['quantity'] : '';
                                        $res_order_side = (!empty($create_order_res['result']['data']['create_order']['side'])) ? $create_order_res['result']['data']['create_order']['side'] : '';
                                        $res_order_instrument_id = (!empty($create_order_res['result']['data']['create_order']['instrument_id'])) ? strtoupper($create_order_res['result']['data']['create_order']['instrument_id']) : '';
                                        $res_order_created_at = (!empty($create_order_res['result']['data']['create_order']['created_at'])) ? $create_order_res['result']['data']['create_order']['created_at'] : '';
                                        _log($reg_email_address, "create_order OK : " . $res_order_side . "/" . $res_order_id . "/status: " . $res_order_status . "/ quantity: " . $res_order_quantity);
                                        sleep(2);
                                        $after_order_wallet_info = get_wallet_balance($currency, $authorization_value);
                                        if (($after_order_wallet_info['error'] == '') && ($after_order_wallet_info['crypto_balance'] !== '') && ($after_order_wallet_info['usd_balance'] !== '')) {
                                            $usd_balance_after_order = $after_order_wallet_info['usd_balance'];
                                            $crypto_balance_after_order = $after_order_wallet_info['crypto_balance'];
                                        } else {
                                            _log($reg_email_address, "get_wallet_balance (ater order) error: " . $after_order_wallet_info['error']);
                                        }
                                        _log($reg_email_address, "usd_balance_after_order = " . $usd_balance_after_order);

                                        $exchange_res = array('email_address' => $reg_email_address, 'id' => $res_order_id);
                                        $exchange_res_details = array();
                                        $used_currency = "";
                                        if ($pair == 'BTCUSD') {
                                            $used_currency = "BTC";
                                        } else if ($pair == 'USDTUSD') {
                                            $used_currency = "USDT";
                                        } else if ($pair == 'USDCUSD') {
                                            $used_currency = "USDC";
                                        }

                                        $exchange_res_details['type'] = strtolower($res_order_side);
                                        $exchange_res_details['pair'] = $res_order_instrument_id;
                                        $coin_type = '';
                                        if ($exchange_res_details['pair'] == 'BTCUSD') {
                                            $coin_type = "BTC";
                                        } else if ($exchange_res_details['pair'] == 'USDTUSD') {
                                            $coin_type = "USDT";
                                        } else if ($exchange_res_details['pair'] == 'USDCUSD') {
                                            $coin_type = "USDC";
                                        }
                                        $exchange_res_details['currency'] = $coin_type;
                                        $exchange_res_details['amount'] = $amount;
                                        $exchange_res_details['status'] = "completed";
                                        if ($type == "sell") {
                                            $diff_wallet_usd_amount = abs($usd_balance_after_order - $usd_balance_before_order);
                                            $exchange_res_details['received_amount'] = $diff_wallet_usd_amount;
                                        } else if ($type == "buy") {
                                            $diff_wallet_usd_amount = abs($usd_balance_before_order - $usd_balance_after_order);
                                            //$diff_wallet_usd_amount = abs($before_buy_usd_balance - $after_buy_usd_balance);
                                            $exchange_res_details['paid_amount'] = $diff_wallet_usd_amount;
                                        }

                                        //save to db

                                        if ($res_order_created_at != '') {
                                            $tx_history_date = str_replace("-", "/", $res_order_created_at);
                                        } else {
                                            $tx_history_date = date('Y/m/d H:i:s');
                                        }

                                        $sql_add_tx_history = "INSERT INTO cryptocash_exchange_history (id, email_address, currency, type, amount, usd_amount, status, date, tx_id, created_from, shift_order_id) VALUES (null, '$reg_email_address', '$currency', '$type', '$amount','$diff_wallet_usd_amount', 'completely_filled', '$tx_history_date', '', '" . $req_partner['partner'] . "', '$res_order_id')";

                                        _log($reg_email_address, $sql_add_tx_history);
                                        mysqli_query($dbhandle, $sql_add_tx_history);
                                        if (mysqli_affected_rows($dbhandle) <= 0) {
                                            _log($reg_email_address, "add to cryptocash_exchange_history failed");
                                        }

                                        $exchange_res['details'] = $exchange_res_details;
                                        @mysqli_close($dbhandle);
                                        $ret_rs['result'] = 'success';
                                        $ret_rs['exchange_response'] = $exchange_res;
                                        header('Content-Type: application/json');
                                        echo json_encode($ret_rs);
                                        die();

                                    }
                                } else {
                                    _log($reg_email_address, "::/api/v4/create_order/ failed: not 200 ok");
                                    @mysqli_close($dbhandle);
                                    header('Content-Type: application/json');
                                    http_response_code(500);
                                    $ret_rs['result'] = 'failed';
                                    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #9.');
                                    echo json_encode($ret_rs);
                                    die();
                                }
                            }

                        }

                    } else {
                        @mysqli_close($dbhandle);
                        header('Content-Type: application/json');
                        http_response_code(500);
                        $ret_rs['result'] = 'failed';
                        $ret_rs['error'] = array('errorCode' => 10, 'errorMessage' => 'you must sign in to use this API.');
                        echo json_encode($ret_rs);
                        die();
                    }

                } else {
                    //_log($reg_email_address, "could not connect db !");
                    //@mysqli_close($dbhandle);
                    header('Content-Type: application/json');
                    http_response_code(500);
                    $ret_rs['result'] = 'failed';
                    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'system is under maintenance.');
                    echo json_encode($ret_rs);
                    die();
                }


            } else {
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = $errors[0];
                _log("", $ret_rs['error']['errorMessage']);
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
            }


        }

    } else {
        header('HTTP/1.0 403 Forbidden');
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
    http_response_code(405);
    die();
}
