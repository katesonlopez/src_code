<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, X-Requested-With, Authorization');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 3600');
mb_internal_encoding("UTF-8");
date_default_timezone_set('Asia/Tokyo');
ini_set('memory_limit', '50M');

$requestBodyString = file_get_contents('php://input');
echo generateHash($requestBodyString);

function generateHash($originalString)
{
    $SECRET_KEY = '2BUedUhCZEv6taCknNpkE7c0K/XQUM4XTflTDZtP7xJvTNz5suTLvqZ92x1Iv0tzSEO/rHmGxfRZbAs8YhUG8omAh3k08qnMdKUx2B4iEJZ2n2wSmsr8';

    try {
        $encodedHash = hash_hmac('sha256', $originalString, $SECRET_KEY, true);

        return bytesToHex($encodedHash);
    } catch (Exception $e) {
        echo 'An error occurred: ' . $e->getMessage();
    }

    return null;
}

function bytesToHex($hash)
{
    $hexString = '';

    for ($i = 0; $i < strlen($hash); $i++) {
        $hex = dechex(ord($hash[$i]));

        if (strlen($hex) === 1) {
            $hexString .= '0';
        }

        $hexString .= $hex;
    }

    return $hexString;
}

