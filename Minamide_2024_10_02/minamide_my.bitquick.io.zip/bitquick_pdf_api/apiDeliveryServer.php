<!DOCTYPE html>
<html>
<head>
    <title>Red Text</title>
</head>
<body>

<h1 style="color: red;">Hello World</h1>

</body>
</html>
