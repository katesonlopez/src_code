<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class File extends Model
{
  protected $fillable = [
    'dup_check_id',
    'agent_id',
    'date',
    'file_name',
    'success',
    'fail',
    'merchant',
    'usdt',
    'usd',
    'agent_proc',
  ];

  public function user()
  {
    return $this->belongsTo('App\User');
  }
  public function file_details()
  {
    return $this->hasMany('App\FileDetail', 'file_id', 'id');
  }

  public function getUpdatedAtAttribute($value)
  {
    return date('Y-m-d H:i:s', strtotime($value));
  }
}
