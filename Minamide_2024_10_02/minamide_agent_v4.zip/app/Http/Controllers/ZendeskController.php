<?php

namespace App\Http\Controllers;

use App\User;
use Firebase\JWT\JWT;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class ZendeskController extends Controller
{
  public function index()
  {
    if (Auth::check()) {
      return view('zendesk.admin.dashboard');
    }
    else{
      return redirect(route('zendesk.login'));
    }
  }

  public function redirectToAdmin(): RedirectResponse
  {
    return redirect()->route('zendesk.admin');
  }

  // Signup function
  public function showSignupForm()
  {
    return view('zendesk.user.signup');
  }

  /**
   * @throws GuzzleException
   */
  public function signup(Request $request)
  {
    // Validate the input data
    $request->validate([
      'name' => 'required|string',
      'email' => 'required|email',
      'password' => 'required|confirmed',
    ]);

    // Create a new zendesk user
    $userData = [
      'user' => [
        'name' => $request->name,
        'email' => $request->email,
        'skip_verify_email' => true
      ],
    ];

    // Initialize cURL session
    $jsonUserData = json_encode($userData);
    $apiUrl = config('constants.SUB_DOMAIN').'/api/v2/users.json';

    // Set your Zendesk API credentials
    $email = config('constants.ADMIN_EMAIL_ADDRESS');
    $password = config('constants.ADMIN_PASSWORD');

    try {
      $ch = curl_init();
      curl_setopt_array($ch, [
        CURLOPT_URL => $apiUrl,
        CURLOPT_HTTPHEADER => [
          'Content-Type: application/json',
        ],
        CURLOPT_USERPWD => "$email:$password",
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => $jsonUserData,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => true, // Disable SSL verification if needed
      ]);
      $response = curl_exec($ch);
      if (curl_errno($ch)) {
        return 'cURL Error: ' . curl_error($ch);
      }
      curl_close($ch);
    }
    catch (\Exception $exception){
      return redirect()->route('zendesk.signup.form')->with('error', $exception->getMessage());
    }

    // Process the response data
    $responseData = json_decode($response, true);
    if( isset($responseData['error'])){
      if( isset($responseData['details']['email'][0]['description'])){
        return redirect()->route('zendesk.signup.form')->with('error', strip_tags($responseData['details']['email'][0]['description']));
      }
      else{
        return redirect()->route('zendesk.signup.form')->with('error', json_encode($responseData['details']));
      }
    }
    $userId = $responseData['user']['id'];
    try {
      $responseBody = $this->setPasswordByAdmin($userId, $request->password);
    }
    catch (\Exception $exception){
      return redirect()->route('zendesk.signup.form')->with('error', $exception->getMessage());
    }

    // Create a new Guzzle Response instance with the response body
    if ($responseBody['http_code'] === 200) {
      // Check if a user with the provided email already exists
      $existingUser = User::where('email', $request->email)->first();

      if (!$existingUser) {
        $user = User::create([
          'name' => $request->name,
          'email' => $request->email,
          'password' => Hash::make($request->password),
          'is_admin' => $request->has('is_admin'), // Set the is_admin field based on checkbox
        ]);
        if ($user) {
          // User sign up successful, you can redirect the user to a success page
          return redirect()->route('zendesk.login')->with('success', 'Signup successful! Please login.');
        }
        else {
          // User creation failed
          return redirect()->route('zendesk.signup.form')->with('error', 'User creation failed on site. Please try again.');
        }
      }
      else{
        // User creation failed
        return redirect()->route('zendesk.signup.form')->with('error', 'User creation failed on site. Already exists.');
      }
    }
    else {
      $responseData = json_decode($responseBody['response'], true);
      if( isset($responseData['error'])){
        if( isset($responseData['details']['password'][0]['description'])){
          return redirect()->route('zendesk.signup.form')->with('error', strip_tags($responseData['details']['password'][0]['description']));
        }
        else{
          return redirect()->route('zendesk.signup.form')->with('error', 'Failed to sign up because can not set password.');
        }
      }
      return redirect()->route('zendesk.signup.form')->with('error', 'Failed to sign up because can not set password.');
    }
  }

  // Login function
  public function showLoginForm(Request $request)
  {
    $brand_id = request('brand_id'); // Get 'brand_id' parameter
    $locale_id = request('locale_id'); // Get 'locale_id' parameter
    $return_to = request('return_to'); // Get 'return_to' parameter

    return view('zendesk.user.login', [
      'brand_id' => $brand_id,
      'locale_id' => $locale_id,
      'return_to' => $return_to,
    ]);
  }

  public function login(Request $request)
  {
    $request->validate([
      'email' => 'required|string|email',
      'password' => 'required|string',
    ]);

    // Check if redirection url is set
    if ($request->has('return_to')) {

      // Retrieve user by email (username)
      $user = User::where('email', $request->email)->first();
      if ($user)
        Auth::login($user);
      else
        return redirect()->route('zendesk.login')->with('error', 'Login failed! Invalid Credential.');
    }
    else{
      $credentials = $request->only('email', 'password');
      if (Auth::attempt($credentials)) {
        $user = Auth::user();
      }
      else{
        // Authentication failed in our site
        return redirect()->route('zendesk.login')->with('error', 'Login failed! Invalid Credential.');
      }
    }
    $userName = $user->name;

    // Code from https://github.com/zendesk/zendesk_jwt_sso_examples/blob/master/php_jwt.php
    $key       = config('constants.SHARED_SECRET');
    $subdomain = config('constants.SUB_DOMAIN');
    $now       = time();

    $header = [
      "typ" => "JWT",
      "alg" => "HS256" // Specify the JWT algorithm as HS256
    ];

    $token = array(
      "jti"   => md5($now . rand()),
      "iat"   => $now,
      "name"  => $userName,
      "email" => $request->email
    );

    $jwt = JWT::encode($token, $key, 'HS256', null, $header); // Include the header

    $location = $subdomain . "/access/jwt?jwt=" . $jwt;

    // Check if redirection url is set
    if ($request->has('redirect_to_admin')) {
      $location .= "&return_to=" . url(route('zendesk.admin'));
    }

    // Redirect
    return redirect(url($location));
  }

  public function logout()
  {
    Auth::logout();
    return redirect()->route('zendesk.login');
  }

  // Change password function
  public function showChangePasswordForm()
  {
    $userData = [
      'email'=>auth()->user()->email,
    ];

    return view('zendesk.user.change_password', compact('userData'));
  }

  public function changePassword(Request $request)
  {
    $request->validate([
      'email' => 'required|email',
      'new_password' => 'required',
    ]);

    $zendeskUser = $this->getUserInfoFromZendesk( $request->email );
    $zendeskUser = json_decode( $zendeskUser, true );
    if( $zendeskUser == null || count($zendeskUser['results']) == 0 ){
      return redirect()->route('zendesk.password.form')->with('error', 'Invalid email address! Not exist user.');
    }
    else{
      $zendeskUserEmail = $zendeskUser['results'][0]['email'];
      $zendeskUserId = $zendeskUser['results'][0]['id'];
      if( auth()->user()->email != $zendeskUserEmail ){
        return redirect()->route('zendesk.password.form')->with('error', 'It is not your email. Input your email');
      }
      else{
        try {
          $responseBody = $this->setPasswordByAdmin( $zendeskUserId, $request->new_password );
        }
        catch (\Exception $exception){
          return redirect()->route('zendesk.password.form')->with('error', $exception->getMessage());
        }

        if ($responseBody['http_code'] === 200) {
          auth()->user()->update([
            'password' => Hash::make($request->new_password),
          ]);
          return redirect()->route('zendesk.password.form')->with('success', 'Password changed successfully!');
        }
        else {
          $responseData = json_decode($responseBody['response'], true);
          if( isset($responseData['error'])){
            if( isset($responseData['details']['password'][0]['description'])){
              return redirect()->route('zendesk.password.form')->with('error', strip_tags($responseData['details']['password'][0]['description']));
            }
            else{
              return redirect()->route('zendesk.password.form')->with('error', 'Failed to change password.');
            }
          }
          return redirect()->route('zendesk.password.form')->with('error', 'Failed to change password.');
        }
      }
    }
  }

  // set zendesk user's password by admin
  public function setPasswordByAdmin($userId, $newPassword): array
  {
    // Set your Zendesk API credentials
    $email = config('constants.ADMIN_EMAIL_ADDRESS');
    $password = config('constants.ADMIN_PASSWORD');

    $passwordData = [
      'password' => $newPassword,
    ];
    $jsonPasswordData = json_encode($passwordData);
    $apiUrl = config('constants.SUB_DOMAIN').'/api/v2/users/'.$userId.'/password.json';

    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $apiUrl,
      CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
      ],
      CURLOPT_USERPWD => "$email:$password",
      CURLOPT_POST => 1,
      CURLOPT_POSTFIELDS => $jsonPasswordData,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_SSL_VERIFYPEER => true, // Disable SSL verification if needed
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); // Get the HTTP response code
    curl_close($ch);

    return [
      'http_code' => $httpCode,
      'response' => $response,
    ];
  }

  // Update profile function
  public function showUpdateProfileForm()
  {
    $adminProfileData = [
      'email'=>auth()->user()->email,
      'card_number'=>'',
      'account_number'=>'',
    ];

    $zendeskUser = $this->getUserInfoFromZendesk( auth()->user()->email );
    $zendeskUser = json_decode( $zendeskUser, true );
    if( count($zendeskUser['results']) == 0 ){
      return view('zendesk.admin.update_profile', compact('adminProfileData'));
    }

    $adminProfileData = [
      'email'=>$zendeskUser['results'][0]['email'],
      'card_number'=>$zendeskUser['results'][0]['user_fields']['other01'],
      'account_number'=>$zendeskUser['results'][0]['user_fields']['other02'],
    ];

    return view('zendesk.admin.update_profile', compact('adminProfileData'));
  }

  public function updateProfile(Request $request)
  {
    $request->validate([
      'email' => 'required|email'
    ]);

    $zendeskUser = $this->getUserInfoFromZendesk( $request->email );
    $zendeskUser = json_decode( $zendeskUser, true );
    if( count($zendeskUser['results']) == 0 ){
      return redirect()->route('zendesk.admin.profile.form')->with('error', 'Invalid email address! Not exist user.');
    }
    else{
      $zendeskUserEmail = $zendeskUser['results'][0]['email'];
      $zendeskUserId = $zendeskUser['results'][0]['id'];
      if( auth()->user()->email != $zendeskUserEmail ){
        return redirect()->route('zendesk.admin.profile.form')->with('error', 'It is not your email. Input your email');
      }
      else{
        $zendeskUser = $this->setUserFieldToZendesk( $zendeskUserId, $request->card_number, $request->account_number );
        $zendeskUser = json_decode( $zendeskUser, true );
        if( $zendeskUser['user']['user_fields']['other01'] != $request->card_number ||
            $zendeskUser['user']['user_fields']['other02'] != $request->account_number ){
          return redirect()->route('zendesk.admin.profile.form')->with('error', 'Failed to update profile!');
        }
      }
    }

    return redirect()->route('zendesk.admin.profile.form')->with('success', 'Profile updated successfully!');
  }

  public function getUserInfoFromZendesk( $userEmail ){
    // Set your Zendesk API credentials
    $email = config('constants.ADMIN_EMAIL_ADDRESS');
    $password = config('constants.ADMIN_PASSWORD');

    $query = 'type:user email:'.$userEmail;
    $query = str_replace(['+', '@'], ['%20', '%40'], urlencode($query));
    $apiUrl = config('constants.SUB_DOMAIN').'/api/v2/search.json?query='.$query;

    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $apiUrl,
      CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
      ],
      CURLOPT_USERPWD => "$email:$password",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_SSL_VERIFYPEER => true, // Disable SSL verification if needed
    ]);
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
      return 'cURL Error: ' . curl_error($ch);
    }
    curl_close($ch);

    return $response;
  }

  public function setUserFieldToZendesk( $userId, $other01, $other02 ){
    // Set your Zendesk API credentials
    $email = config('constants.ADMIN_EMAIL_ADDRESS');
    $password = config('constants.ADMIN_PASSWORD');

    $data = [
      'user' => [
        'user_fields' => [
          'other01' => $other01,
          'other02' => $other02
        ],
      ]
    ];
    $jsonRequestBodyData = json_encode($data);
    $apiUrl = config('constants.SUB_DOMAIN').'/api/v2/users/'.$userId.'.json';

    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $apiUrl,
      CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
      ],
      CURLOPT_USERPWD => "$email:$password",
      CURLOPT_CUSTOMREQUEST => 'PUT', // Use PUT request for updating
      CURLOPT_POSTFIELDS => $jsonRequestBodyData,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_SSL_VERIFYPEER => true, // Disable SSL verification if needed
    ]);
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
      return 'cURL Error: ' . curl_error($ch);
    }
    curl_close($ch);

    return $response;
  }

  public function callKaiser1(){

    $data = [
      'amount' => 220,
      'product_name' => 'agent-tool'
    ];
    $jsonRequestBodyData = json_encode($data);
    $apiUrl = 'https://api.kaiserpayment.com/api/prepayment/';

    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $apiUrl,
      CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6IjMiLCJuYW1lIjoiQUdFTlRfVE9PTCIsImRvbWFpbiI6IkFHRU5UX1RPT0wuQ09NIiwiZmVlIjoiMTAiLCJleHAiOjQ4NDk2MzUxNDB9.tB5296J9Ufx6jVXRmwn-pl2Sl4cy5VvPuZ7HNW1RpZs',
      ],
      CURLOPT_POST => 1,
      CURLOPT_POSTFIELDS => $jsonRequestBodyData,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_SSL_VERIFYPEER => true, // Disable SSL verification if needed
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
  }

  public function callKaiser2(){

    $data = [];
    $jsonRequestBodyData = json_encode($data);
    $apiUrl = 'https://api.kaiserpayment.com/api/getReport/';

    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $apiUrl,
      CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6IjMiLCJuYW1lIjoiQUdFTlRfVE9PTCIsImRvbWFpbiI6IkFHRU5UX1RPT0wuQ09NIiwiZmVlIjoiMTAiLCJleHAiOjQ4NDk2MzUxNDB9.tB5296J9Ufx6jVXRmwn-pl2Sl4cy5VvPuZ7HNW1RpZs',
      ],
      CURLOPT_POST => 1,
      CURLOPT_POSTFIELDS => $jsonRequestBodyData,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_SSL_VERIFYPEER => true, // Disable SSL verification if needed
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
  }

  public function callKaiser3(){

    $data = [
      'amount' => 0.220,
      'productName' => 'agent-tool',
      'currency' => 'TRX_USDT_S2UZ'
    ];
    $jsonRequestBodyData = json_encode($data);
    $apiUrl = 'https://api.kaiserpayment.com/api/getCryptoPaymentAddress/';

    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL => $apiUrl,
      CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6IjMiLCJuYW1lIjoiQUdFTlRfVE9PTCIsImRvbWFpbiI6IkFHRU5UX1RPT0wuQ09NIiwiZmVlIjoiMTAiLCJleHAiOjQ4NDk2MzUxNDB9.tB5296J9Ufx6jVXRmwn-pl2Sl4cy5VvPuZ7HNW1RpZs',
      ],
      CURLOPT_POST => 1,
      CURLOPT_POSTFIELDS => $jsonRequestBodyData,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_SSL_VERIFYPEER => true, // Disable SSL verification if needed
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
  }

  public function callKaiser4(){

    $apiUrl = 'https://api.kaiserpayment.com/api/getCryptoPaymentReport/';

    // Prepare query parameters
    $queryParams = [
        'orderId' => null,
        'fromDate' => null,
        'toDate' => null,
        'address' => null,
        'paymentStatus' => null,
        'pageNo' => 1,
        'pageSize' => 10,
    ];

    // Build the query string
    $query = http_build_query($queryParams);

    // Combine the API URL and query string
    $apiUrlWithQuery = $apiUrl . '?' . $query;

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $apiUrlWithQuery,
        CURLOPT_HTTPHEADER => [
            'Authorization: eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6IjMiLCJuYW1lIjoiQUdFTlRfVE9PTCIsImRvbWFpbiI6IkFHRU5UX1RPT0wuQ09NIiwiZmVlIjoiMTAiLCJleHAiOjQ4NDk2MzUxNDB9.tB5296J9Ufx6jVXRmwn-pl2Sl4cy5VvPuZ7HNW1RpZs',
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => true, // Disable SSL verification if needed
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
  }
}
