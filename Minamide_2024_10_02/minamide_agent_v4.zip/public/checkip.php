<?php
$ip_whitelist = array("60.139.58.168", "133.155.3.148");
function getUserIpAddr(){
	if(!empty($_SERVER['CF_CONNECTING_IP'])){
        //ip pass from proxy
        $ip = $_SERVER['CF_CONNECTING_IP'];
    } elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
        //ip from share internet
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif(!empty($_SERVER['HTTP_X_REAL_IP'])){
        //ip from share internet
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    } else{
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
$remote_ip = getUserIpAddr();
$receive_ip = (!empty($remote_ip))?$remote_ip:'';
echo "your ip : " . $receive_ip;

?>