<?php
return [
    'SUB_DOMAIN' => 'https://plusqo.zendesk.com',
    'ADMIN_EMAIL_ADDRESS'=>'info@plusqo.ai',
    'ADMIN_PASSWORD'=>'fF23NskUgEzc',
    'API_KEY'=>'WMULzOrnwye7Zvmu4zeIzQl65bumQ14tnjnURGeJ',
    'SHARED_SECRET'=>'gHKOxKG3kwaWjvC21lSNXOFR2lSWZHBQbafM5hb57ivdG2UR',
];
