<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>IssueCard API Test</title>
  <link rel="icon" href="{{ asset('favicon_issue_card.ico') }}" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!--  <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">-->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!--  <script src="{{ asset('js/jquery-3.6.0.min.js') }}"></script>-->
  <style>
    body{
      overflow-x: hidden;
    }
    #errorResp {
      color: #721c24; /* Text color for visibility */
      padding: 10px; /* Padding for spacing */
      border: 1px solid #f5c6cb; /* Border for separation */
      border-radius: 5px; /* Rounded corners */
      white-space: pre-wrap; /* Preserve whitespace */
      font-family: monospace; /* Monospaced font for code-like appearance */
      overflow-x: auto; /* Horizontal scrolling if necessary */
      display: none;
    }
    .no-break {
      white-space: nowrap;
    }
  </style>
</head>
<body>
<div class="ps-3 pe-3 mt-4 row">
  <div class="d-flex align-items-center">
    <div class="col-auto">
      <img src="{{ asset('images/logo/logo_issue_card.png') }}" width="50" height="50" alt="logo">
    </div>
    <div class="col text-center">
      <h2 class="">IssueCard API Test Page</h2>
    </div>
  </div>
  <div class="">
    <form id="submissionForm">

      <!-- First Group: JDB Profile Data -->
      <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
          <label class="flex-grow-1">The Parameters for IssueCard</label>
        </div>
        <div class="card-body">
          <h5>Profile Data</h5>
          <div class="row mb-4">
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="gender">Gender</label>
              <select type="text" class="form-control" id="gender" name="profile[gender]">
                <option value="1">Male</option>
                <option value="2">Female</option>
              </select>
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="full_name">Name Romaji</label>
              <input type="text" class="form-control" id="full_name" name="profile[full_name]" value="Test Boris">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="marriage_status">Marriage Status</label>
              <select type="text" class="form-control" id="marriage_status" name="profile[marriage_status]">
                <option value="1">Single</option>
                <option value="2">Married</option>
              </select>
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="occupation">Occupation</label>
              <select type="text" class="form-control" id="occupation" name="profile[occupation]">
                <option value="CEO">CEO</option>
                <option value="Director">Director</option>
                <option value="Employee">Employee</option>
                <option value="Housewife">Housewife</option>
                <option value="Student">Student</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="country">Country</label>
              <input type="text" class="form-control" id="country" name="profile[country]" value="Serbia">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="nationality">Nationality</label>
              <input type="text" class="form-control" id="nationality" name="profile[nationality]" value="Serbia">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="date_of_birth">Date of Birth</label>
              <input type="date" class="form-control" id="date_of_birth" name="profile[date_of_birth]" value="1992-06-21">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="place_of_birth">Place of Birth</label>
              <input type="text" class="form-control" id="place_of_birth" name="profile[place_of_birth]" value="Serbia">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="id_card_number">ID Card Number</label>
              <input type="text" class="form-control" id="id_card_number" name="profile[id_card_number]" value="000013856">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="id_card_issued_dt">ID Card Issued Date</label>
              <input type="date" class="form-control" id="id_card_issued_dt" name="profile[id_card_issued_dt]" value="2013-01-01">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="id_card_expired_dt">ID Card Expired Date</label>
              <input type="date" class="form-control" id="id_card_expired_dt" name="profile[id_card_expired_dt]" value="2050-12-31">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="id_card_issuer">ID Card Issuer</label>
              <input type="text" class="form-control" id="id_card_issuer" name="profile[id_card_issuer]" value="Serbia">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="id_card_type">ID Card Type</label>
              <select type="text" class="form-control" id="id_card_type" name="profile[id_card_type]">
                <option value="driving_license">driving_license</option>
                <option value="passport">passport</option>
              </select>
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="residence_address">Residence Address</label>
              <input type="text" class="form-control" id="residence_address" name="profile[residence_address]" value="Test Address">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="district">District</label>
              <input type="text" class="form-control" id="district" name="profile[district]" value="Test District">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="province">Province</label>
              <input type="text" class="form-control" id="province" name="profile[province]" value="Test province">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="postal_code">Postal Code</label>
              <input type="text" class="form-control" id="postal_code" name="profile[postal_code]" value="19200">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="cellphone_country_code">Cellphone Country Code</label>
              <input type="text" class="form-control" id="cellphone_country_code" name="profile[cellphone_country_code]" value="+381">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="cellphone_number">Cellphone Number</label>
              <input type="text" class="form-control" id="cellphone_number" name="profile[cellphone_number]" value="987654321">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="name_on_card">Name on Card</label>
              <input type="text" class="form-control" id="name_on_card" name="profile[name_on_card]" value="TEST BORIS">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="card_provider">Card Provider</label>
              <select type="text" class="form-control" id="card_provider" name="profile[card_provider]">
                <option value="visa">Visa</option>
                <option value="unionpay">UnionPay</option>
              </select>
            </div>
          </div>

          <!-- Image Url Data Group -->
          <h5>Image Url Data</h5>
          <div class="row">
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="passport_open_file">Passport Open File</label>
              <input type="text" class="form-control" id="passport_open_file" name="image[passport_open_file]" value="{{ asset('images/ultimo_passport.png') }}">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="passport_selfie_file">Passport Selfie File</label>
              <input type="text" class="form-control" id="passport_selfie_file" name="image[passport_selfie_file]" value="{{ asset('images/ultimo_passport_selfie.png') }}">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="id_card_front_file">ID Card Front File</label>
              <input type="text" class="form-control" id="id_card_front_file" name="image[id_card_front_file]" value="{{ asset('images/ultimo_id_front.png') }}">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="id_card_back_file">ID Card Back File</label>
              <input type="text" class="form-control" id="id_card_back_file" name="image[id_card_back_file]" value="{{ asset('images/ultimo_id_back.png') }}">
            </div>
            <div class="col-md-2 mt-3 col-sm-12">
              <label for="id_card_back_file">ID Card Selfie File</label>
              <input type="text" class="form-control" id="id_card_selfie_file" name="image[id_card_selfie_file]" value="{{ asset('images/ultimo_id_selfie.png') }}">
            </div>
          </div>
        </div>
        <div class="card-footer">
          <div class="row align-items-center justify-content-between">
            <!-- Group: Email, Password, and SignIn button on the left -->
            <div class="col-12 col-md-auto d-flex flex-column flex-md-row align-items-center mb-3 mb-md-0">
              <!-- Email Address -->
              <div class="d-flex align-items-center mb-2 mb-md-0 me-md-3 w-100 justify-content-end">
                <label for="email_address" class="form-label me-2 text-md-end no-break">Email Address:</label>
                <input type="text" class="form-control" id="email_address" name="email_address" value="agent-tool-test@ruru.be" style="width: auto;">
              </div>

              <!-- Password -->
              <div class="d-flex align-items-center mb-2 mb-md-0 me-md-3 w-100 justify-content-end">
                <label for="password" class="form-label me-2 text-md-end">Password:</label>
                <input type="password" class="form-control" id="password" name="password" value="KnRUV#YSucu)rQke&quot;F6nj!sZcX762FE5" style="width: auto;">
                <input type="hidden" id="auth_token" name="auth_token">
              </div>

              <!-- Sign In Button -->
              <div class="">
                <button id="signin" type="button" class="btn btn-outline-success" style="width: 100px;">
                  <span class="spinner-anim spinner-border spinner-border-sm text-success" role="status" style="display: none"></span>
                  <span class="spinner-text"> SignIn </span>
                </button>
              </div>
            </div>

            <!-- Submit Button on the right -->
            <div class="col-12 col-md d-flex flex-wrap justify-content-end">
              <button id="submitBtn" type="submit" class="btn btn-primary">
                <span class="spinner-anim spinner-border spinner-border-sm text-white" role="status" style="display: none"></span>
                <span class="spinner-text">Call IssueCard API and Display Response in Iframe</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>

  <h5 class="text-center text-info" style="font-weight: 800;">Iframe for displaying the response from IssueCard</h5>
  <div class="iframe-card mb-3">
    <iframe id="iframe" class="border-info"
            style="display: block; width: 100%; height: 100%; border: 1px solid;">
    </iframe>
    <div id="errorResp"></div>
  </div>
</div>

<script>
  let base_url = 'https://xapiserver.com/v4/';
  /*let base_url = 'http://localhost/minamide/xapiserver.com_v4/';*/
  $(document).ready(function(){
    $('#signin').click(function(){
      SpinBtnCtrl('signin', true);
      $.ajax({
        url: base_url + 'signin/',
        /*url: base_url + 'signin_local/',*/
        type: "POST",
        headers: {
          "Authorization": 'Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56',
          "Content-Type": "application/json"
        },
        data: JSON.stringify({
          email_address: $('#email_address').val(),
          password: $('#password').val(),
        }),
        success: function(response) {
          SpinBtnCtrl('signin', false);
          $('#auth_token').val(response.signinResponse.auth_token);
          alert(response.signinResponse.auth_token);
        },
        error: function(xhr, status, error) {
          SpinBtnCtrl('signin', false);
          console.error("Error:", status, error);
          alert(error);
        }
      });
    });
  });

  document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('submissionForm');

    if(!form) {
      console.error('Form with ID "submissionForm" not found.');
      return;
    }

    form.addEventListener('submit', function(event) {
      event.preventDefault();

      SpinBtnCtrl('submitBtn', true);

      // Create a new iframe element
      document.querySelector('.iframe-card').innerHTML = '<iframe id="iframe" class="border-info" style="display: block; width: 100%; height: 100%; border: 1px solid;"></iframe><div id="errorResp"></div>';
      let iframeObj = document.getElementById('iframe');
      let errorResp = document.getElementById('errorResp');

      // Make request
      let xhr = new XMLHttpRequest();
      xhr.open('POST', base_url + 'IssueCard/', true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.setRequestHeader('Authorization', 'Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56');

      xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
          if (xhr.status === 200) {
            iframeObj.style.display = 'block';
            errorResp.style.display = 'none';

            let respData = JSON.parse(xhr.responseText);
            // After the iframe is cleared, load the new content
            setTimeout(function() {
              let iframe = iframeObj;

              // Check if iframe is properly selected
              if (iframe) {
                let doc = iframe.contentDocument || iframe.contentWindow.document;

                // Check if doc is available
                if (doc) {
                  doc.open();
                  doc.write(decodeBase64(respData.challengeHtml));
                  doc.close();

                  // Set the iframe height to match the page height
                  iframeObj.style.height = 700 + 'px';
                } else {
                  console.error('Document is not accessible.');
                }
              } else {
                console.error('Iframe object is not available.');
              }
            }, 100);

            SpinBtnCtrl('submitBtn', false);
          } else {
            iframeObj.style.display = 'none';
            errorResp.style.display = 'block';
            try {
              let errorData = JSON.parse(xhr.responseText);
              errorResp.innerHTML = '<pre>' + JSON.stringify(errorData, null, 2) + '</pre>';
            } catch (e) {
              errorResp.textContent = 'Error parsing JSON response.';
            }

            SpinBtnCtrl('submitBtn', false);
          }
        }
      };

      // Send request
      xhr.send(JSON.stringify(getFormData()));
    });
  });

  function getFormData(){
    // Gather form data
    return {
      email_address: document.getElementById('email_address').value,
      auth_token: document.getElementById('auth_token').value,
      profile: {
        gender: document.getElementById('gender').value,
        full_name: document.getElementById('full_name').value,
        marriage_status: document.getElementById('marriage_status').value,
        occupation: document.getElementById('occupation').value,
        country: document.getElementById('country').value,
        nationality: document.getElementById('nationality').value,
        date_of_birth: document.getElementById('date_of_birth').value,
        place_of_birth: document.getElementById('place_of_birth').value,
        id_card_number: document.getElementById('id_card_number').value,
        id_card_issued_dt: document.getElementById('id_card_issued_dt').value,
        id_card_expired_dt: document.getElementById('id_card_expired_dt').value,
        id_card_issuer: document.getElementById('id_card_issuer').value,
        id_card_type: document.getElementById('id_card_type').value,
        residence_address: document.getElementById('residence_address').value,
        district: document.getElementById('district').value,
        province: document.getElementById('province').value,
        postal_code: document.getElementById('postal_code').value,
        cellphone_country_code: document.getElementById('cellphone_country_code').value,
        cellphone_number: document.getElementById('cellphone_number').value,
        name_on_card: document.getElementById('name_on_card').value,
        card_provider: document.getElementById('card_provider').value,
      },
      image: {
        passport_open_file: document.getElementById('passport_open_file').value,
        passport_selfie_file: document.getElementById('passport_selfie_file').value,
        id_card_front_file: document.getElementById('id_card_front_file').value,
        id_card_back_file: document.getElementById('id_card_back_file').value,
        id_card_selfie_file: document.getElementById('id_card_selfie_file').value,
      }
    };
  }

  function decodeBase64( encodedString ){
    let decodedString = atob(encodedString); // Decode Base64
    let utf8Decoder = new TextDecoder('utf-8');
    return utf8Decoder.decode(new Uint8Array([...decodedString].map(c => c.charCodeAt(0))));
  }

  function SpinBtnCtrl(btnID, showSpin) {
    let button = document.getElementById(btnID);
    let spinner = button.querySelector('.spinner-anim');

    if (showSpin) {
      spinner.style.display = 'inline-block';
      button.disabled = true;
    } else {
      spinner.style.display = 'none';
      button.disabled = false;
    }
  }

</script>
</body>
</html>
