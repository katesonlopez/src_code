function Waiting({message}) {
  return (
    <>
      <div className='d-flex justify-content-between'>
        <div className="loading-container">
          <div className="loading"></div>
          <div className="loading-text" dangerouslySetInnerHTML={{ __html: message }}></div>
        </div>
      </div>
    </>
  )
}

export default Waiting;
