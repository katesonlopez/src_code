<?php
error_reporting(E_ERROR | E_PARSE);
mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
ini_set("session.gc_maxlifetime", 5*60*60);
@session_set_cookie_params(5*60*60);
session_start();

$session_expired = 0;
$data = array('msg' => '', 'msg_ex' => '', 'address' => '', 'currency' => '', 'network' => '', 'wallet_address_qr_code' => '', 'wallet_address_content' => '');
$currency = isset($_POST['currency'])?($_POST['currency']):'';
$network = isset($_POST['network'])?($_POST['network']):'';
$access_api_key = '';

if (!isset($_SESSION['ultimopay_exchange_access_token'])) {
	$session_expired = 1;
} else {
	if (isset($_SESSION['ultimopay_LAST_ACTIVITY']) && ($cur_time - $_SESSION['ultimopay_LAST_ACTIVITY']) > 3300) {
		unset($_SESSION['ultimopay_signin_time']);
		unset($_SESSION['ultimopay_username']);
		unset($_SESSION['ultimopay_pwd']);
		unset($_SESSION['ultimopay_backoffice_access_token']);
		unset($_SESSION['ultimopay_exchange_access_token']);
		unset($_SESSION['ultimopay_client_access_token']);
		unset($_SESSION['ultimopay_exchange_refresh_token']);
		unset($_SESSION['ultimopay_setting_security']);
		unset($_SESSION['ultimopay_btc_address']);
		unset($_SESSION['ultimopay_usdt_address']);
		unset($_SESSION['ultimopay_usdt_tron_address']);
		unset($_SESSION['ultimopay_usdt_binance_address']);
		// begin add 20230326 busd,usdc k.o.
		unset($_SESSION['ultimopay_busd_address']);
		unset($_SESSION['ultimopay_usdc_address']);
		unset($_SESSION['ultimopay_usdc_polygon_address']);
		// end add 20230326 busd,usdc k.o.
		unset($_SESSION['ultimopay_app_end_user_id']);
		unset($_SESSION['ultimopay_original_http_ref_url']);
		unset($_SESSION['ultimopay_given_name']);	
		unset($_SESSION['ultimopay_sur_name']);	
		unset($_SESSION['pap_merchant_session']);
		unset($_SESSION['pap_affiliate_session']);	
		unset($_SESSION['pap_affiliate_userid']);
		unset($_SESSION['pap_affiliate_refid']);
		unset($_SESSION['temp_email']);
		unset($_SESSION['signup_count']);
		unset($_SESSION['ultimopay_profile_id']);
		unset($_SESSION['ultimopay_LAST_ACTIVITY']);
		unset($_SESSION['ultimopay_shift_user_id']);
		unset($_SESSION['ultimopay_shift_client_user_id']);
		unset($_SESSION['ultimopay_upgraded_system_admin_auth_value']);
		session_unset();
		session_destroy();
		$session_expired = 1;
	}
}

if ($session_expired == 1) {
	$data['msg'] = 'proc_ng2';
	$data['msg_ex'] = 'Your session expired! Please sign in again.';
} else {

	require_once 'common.php';
	require_once 'dbconfig.php';
	
	function _log($line) {
		
		$fh2 = @fopen(dirname(dirname( __FILE__ )) . "/log/generate_wallet_address.log" , 'a');
		$fline = date('[Ymd H:i:s] ') . $line."\n";
		fwrite($fh2, $fline);
		fclose($fh2);
	}
	
	function get_wallet($currency, $network) {
		global $access_api_key;
		$rs = array ('error' => '', 'result' => '', 'http_code' => 0);
		
		$signed_in_email = $_SESSION['ultimopay_username'];
		$my_auth_token = $_SESSION['ultimopay_exchange_access_token'];
		//$bearer_authorization = 'Bearer UgOnGgj3RscUmIm1vpEtYj5uE2gm5g0cwv3BhDfVK9w5hky9AItXAxzE2b2dgizJPTdvaiepvosdSicvNRhnpS2y8Lu8j0xP7avBj1uRTdYXMcRmSr6nTcDVv3wzhOu6';
		/*
		if ($network == 'Ethereum_ERC20') {
			$network = "Ethereum";		
		} else if ($network == 'Tron_TRC20') {
			$network = "Tron";		
		} else if ($network == 'Binance_BEP20') {
			$network = "Binance";		
		}*/	
		////////////////////////////////////
		$curl = curl_init();
		
		$raw_postdata = array();
		$raw_postdata['email_address'] = $signed_in_email;
		$raw_postdata['auth_token'] = $my_auth_token;
		$raw_postdata['currency'] = $currency;
		$raw_postdata['network'] = $network;
		$postdata = json_encode($raw_postdata);
		_log("day la : " . $postdata);
						
		curl_setopt_array($curl, array(
				CURLOPT_URL => 'https://api.ultimopay.io/v4/deposit_ultimo/',
				// CURLOPT_URL => 'https://api.ultimopay.io/v4/deposit_ultimo_dev/',
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => '',
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 0,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => 'POST',
				CURLOPT_POSTFIELDS => $postdata,
				CURLOPT_HTTPHEADER => array(
				'Content-Type: application/json', 'Authorization: ' . $access_api_key
			),
		));

		$response = curl_exec($curl);
		$rs['http_code']  = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		if ($response === false) { //CURL call failed
			//throw new Exception('Could not get reply: ' . curl_error($ch));
			$rs['error'] = 'could not get reply with error : ' . curl_error($curl);
			//return $rs;
		} else {
			$result_decode = json_decode($response, true );
			if (!($result_decode)) {
				switch (json_last_error()) {
					case JSON_ERROR_DEPTH:
						$rs['error'] = 'Reached the maximum stack depth';
						break;
					case JSON_ERROR_STATE_MISMATCH:
						$rs['error'] = 'Incorrect discharges or mismatch mode';
						break;
					case JSON_ERROR_CTRL_CHAR:
						$rs['error'] = 'Incorrect control character';
						break;
					case JSON_ERROR_SYNTAX:
						$rs['error'] = 'Syntax error or JSON invalid ne ban';
						break;
					case JSON_ERROR_UTF8:
						$rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
						break;
					default:
						$rs['error'] = 'Unknown error';
				}

				//throw new Exception($error);
				
			} else {
				_log("result_decode : " . $result_decode);
				$rs['result'] = $result_decode;
			}
		}
		
		curl_close($curl);
		return $rs;
		////////////////////////////////////
		
	}	
	
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		_log("failed connected to ultimo db");
	} else {
		_log("success connected to ultimo db");
		mysqli_query($dbhandle, "set names utf8;");
		$get_api_key_sql = "SELECT * FROM cryptocash_partner_master WHERE partner='ULTIMOPAY' LIMIT 1";
		$api_key_rs = mysqli_query($dbhandle, $get_api_key_sql);
		if (mysqli_num_rows($api_key_rs) > 0) {
			while ($row_api_key = mysqli_fetch_array($api_key_rs, MYSQLI_ASSOC)) {
				
				$access_api_key = 'Bearer ' . trim($row_api_key['api_key']);
				
				
			}
		}
		mysqli_close($dbhandle);
	}
	
	$wallet_rs = get_wallet($currency, $network);
	if ($wallet_rs['result'] != '') {
		$raw_wallet_info = $wallet_rs['result'];
		if ($raw_wallet_info['result'] == 'success') {
			if (!empty($raw_wallet_info['depositResponse'])) { 
				if ((!empty($raw_wallet_info['depositResponse']['currency'])) && (!empty($raw_wallet_info['depositResponse']['address']))) {
					
					//$decided_crypto_address = $raw_wallet_info['depositResponse']['address'];
					$data['msg'] = 'proc_ok';
					$data['address'] = $raw_wallet_info['depositResponse']['address'];
					$data['currency'] = $raw_wallet_info['depositResponse']['currency'];
					$data['network'] = $raw_wallet_info['depositResponse']['network'];
					$data['wallet_address_qr_code'] = 'https://chart.googleapis.com/chart?chs=200x200&cht=qr&chl=' . $data['address'];
					$data['wallet_address_content'] = '<textarea class="banner_code" id="btc_address" rows="2" readonly>' . $data['address'] . '</textarea>';
	
				} else {
					//TODO
				}
			} else {
				//TODO
			}
		} else {
			_log($_SESSION['ultimopay_username'] . ":: " . $raw_wallet_info['error']['errorMessage']);
			$data['msg'] = 'proc_ng';
			$data['msg_ex'] = $raw_wallet_info['error']['errorMessage'];
		}
	} else {
		_log($_SESSION['ultimopay_username'] . ":: " . $raw_wallet_info['error']['errorMessage']);
		$data['msg'] = 'proc_ng';
		$data['msg_ex'] = $raw_wallet_info['error']['errorMessage'];
	}
	
	

}

echo json_encode($data);
die();

?>