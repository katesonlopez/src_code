<?php

require_once( 'server_env.php');

/**
 * Get Account Balances API
 * @throws Exception
 */
function _shift_getAccountBalance($authToken): array
{
    $result = array('result' => 'failed', 'message' => '', 'data' => null);

    try {
        // Define the request body
        $request_body = [
            'query' => 'query  { alias_get_accounts_balances: accounts_balances  { currency_id, total_balance, exposed_balance, currency { type, precision, is_active, name, payment_routes { crypto_network, payment_route_id, crypto_network_name, crypto_address_tag_type, fiat_transfer_type, fiat_transfer_type_name, fiat_iframe_withdrawal_url, fiat_iframe_deposit_url, is_active, psp_balance, psp_service_id, is_development, verification_type } }, free_balance, free_balance_USD: free_balance_quoted (quote_currency_id: "USD"), free_balance_BTC: free_balance_quoted (quote_currency_id: "BTC"), free_balance_ETH: free_balance_quoted (quote_currency_id: "ETH"), free_balance_USDT: free_balance_quoted (quote_currency_id: "USDT") } }',
            'variables' => (object)[], // You can add variables if needed
        ];

        // Initialize stream context for HTTP request
        $options = [
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/json' . "\r\n" .
                            'Authorization: Bearer ' . $authToken,
                'content' => json_encode($request_body),
                'ignore_errors' => true,
            ],
        ];

        // Set the URL
        $url = GRAPHQL_URL;

        // Create a stream context
        $context = stream_context_create($options);

        // Perform the HTTP request and capture the response
        $response = @file_get_contents($url, false, $context); // Use @ to suppress warnings

        preg_match('/^HTTP\/\d\.\d\s+(\d+)\s+(.*)$/', $http_response_header[0], $matches);
        $httpCode = (int) $matches[1];
        $result['http_code'] = $httpCode;

        if (strpos($httpCode, '200') !== false) {
            $responseObj = json_decode($response, true);
            if( isset($responseObj['errors'])){
                $result['http_code'] = 400;
                $result['message'] = $responseObj['errors'][0]['message'];
                $result['data'] = $responseObj;
            }
            else{
                $result['result'] = 'success';
                $result['data'] = $responseObj;
            }
        } else {
            $result['message'] = 'Failed to get account balances.';
            $result['data'] = json_decode($response, true);
        }
    } catch (Exception $e) {
        $result['http_code'] = 500;
        $result['message'] = 'exception: ' . $e->getMessage();
        $result['data'] = $e;
    }

    return $result;
}


/**
 * Get Admin Auth Token API
 **@throws Exception
 */
function _shift_getAdminAuthToken($email): array
{
    $result = array('result' => 'failed', 'message' => '', 'data' => null);

    try {
        // Define the GraphQL query
        $graphqlQuery = "mutation {
                          admin_demo_signin(username:\"$email\") {
                            jwt
                            expires_at
                          }
                        }";

        // Initialize stream context for HTTP request
        $options = [
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/json',
                'content' => json_encode(['query' => $graphqlQuery]),
                'ignore_errors' => true
            ],
        ];

        // Set the URL
        $url = GRAPHQL_URL;

        // Create a stream context
        $context = stream_context_create($options);

        // Perform the HTTP request and capture the response
        $response = @file_get_contents($url, false, $context); // Use @ to suppress warnings

        preg_match('/^HTTP\/\d\.\d\s+(\d+)\s+(.*)$/', $http_response_header[0], $matches);
        $httpCode = (int) $matches[1];
        $result['http_code'] = $httpCode;

        if (strpos($httpCode, '200') !== false) {
            $responseObj = json_decode($response, true);
            if( isset($responseObj['errors'])){
                $result['http_code'] = 400;
                $result['message'] = $responseObj['errors'][0]['message'];
                $result['data'] = $responseObj;
            }
            else{
                $result['result'] = 'success';
                $result['data'] = $responseObj;
            }
        }
        else{
            $result['message'] = 'Failed to get admin auth token.';
            $result['data'] = json_decode($response, true);
        }
    }
    catch (Exception $e) {
        $result['http_code'] = 500;
        $result['message'] = 'exception: ' . $e->getMessage();
        $result['data'] = $e;
    }

    return $result;
}

/**
 * Listing users with a parameter
 * @examples
 * @Param $searchParam: user_id, @param $searchValue: 3d03ff57-2940-4ae2-93e9-528a84eac2b4
 * @Param $searchParam: email, @param $searchValue: userdasd@example.com
 **@throws Exception
 */
function _shift_listUsers($adminAuthToken, $searchParam, $searchValue): array
{
    $result = array('result' => 'failed', 'message' => '', 'data' => null);

    try {
        // Define the GraphQL query
        $graphqlQuery = 'query ($username: String, $email: String, $user_id: String, $search: String, $pager: PagerInput, $dateRange: DateRangeInput, $sort: SortInput, $kyc_status: UserKycStatus, $kyc_level: String) {
                          users(username: $username, email: $email, user_id: $user_id, search: $search, pager: $pager, dateRange: $dateRange, sort: $sort, kyc_status: $kyc_status, kyc_level: $kyc_level) {
                            serial_id
                            username
                            user_id
                            email
                            language
                            timezone
                            favorite_instruments
                            profile_pic_url
                            passport_url
                            national_identity_url
                            driver_license_url
                            birth_certificate_url
                            bank_statement_url
                            utility_bill_url
                            is_active
                            mfa_status
                            kyc_level
                            kyc_status
                            fee_group_id
                            limit_group_id
                            kyc_message
                            created_at_iso
                            updated_at_iso
                            company_registration_url
                            proof_of_residence_url
                            proof_of_id_front_url
                            proof_of_id_back_url
                            memorandum_of_association_url
                            crypto_pay
                            mobile_nr
                            first_name
                            last_name
                            address_country
                            address_state
                            address_city
                            address_line_1
                            address_line_2
                            address_zip
                            date_of_birth_iso
                            tax_id
                            account_opening_purpose
                            company_registration_nr
                            company_name
                            company_position
                          }
                        }';

        $graphqlVariables = '{
                                "pager": {
                                    "offset": 0,
                                    "limit": 15
                                },
                                "dateRange": {
                                    "time_from": null,
                                    "time_to": null
                                },
                                "sort": {
                                    "direction": "DESC"
                                },
                                "'.$searchParam.'": "'.$searchValue.'"
                            }';

        // Initialize stream context for HTTP request
        $options = [
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/json' . "\r\n" .
                            'Authorization: Bearer ' . $adminAuthToken,
                'content' => json_encode([
                    'query' => $graphqlQuery,
                    'variables' => json_decode($graphqlVariables, true),
                ]),
                'ignore_errors' => true
            ],
        ];

        // Set the URL
        $url = GRAPHQL_URL;

        // Create a stream context
        $context = stream_context_create($options);

        // Perform the HTTP request and capture the response
        $response = @file_get_contents($url, false, $context); // Use @ to suppress warnings

        preg_match('/^HTTP\/\d\.\d\s+(\d+)\s+(.*)$/', $http_response_header[0], $matches);
        $httpCode = (int) $matches[1];
        $result['http_code'] = $httpCode;

        if (strpos($httpCode, '200') !== false) {
            $responseObj = json_decode($response, true);
            if( isset($responseObj['errors'])){
                $result['http_code'] = 400;
                $result['message'] = $responseObj['errors'][0]['message'];
                $result['data'] = $responseObj;
            }
            else{
                $result['result'] = 'success';
                $result['data'] = $responseObj;
            }
        }
        else{
            $result['message'] = 'Failed to get users.';
            $result['data'] = json_decode($response, true);
        }
    }
    catch (Exception $e) {
        $result['http_code'] = 500;
        $result['message'] = 'exception: ' . $e->getMessage();
        $result['data'] = $e;
    }

    return $result;
}

/**
 * Balance Correction API
 * @throws Exception
 */
function _shift_balanceCorrection($adminAuthToken, $target_user_id, $target_account_currency, $amount, $transaction_class, $comment): array
{
    $result = array('result' => 'failed', 'message' => '', 'data' => null);

    $type = 'credit';
    if ($amount < 0) {
        $type = 'debit';
        $amount = $amount * (-1);
    }

    try {
        // Define the GraphQL mutation and variables
        $graphqlQuery = 'mutation ($items: [RecordTransactionItem!]!) {
                          create_account_transaction(items: $items) {
                            parent_transaction_id
                            account_transactions {
                              account_transaction_id
                              type
                              amount
                            }
                          }
                        }';

        $graphqlVariables = '{
                              "items": [
                                {
                                  "user_id": "' . $target_user_id . '",
                                  "currency_id": "' . $target_account_currency . '",
                                  "type": "' . $type . '",
                                  "transaction_class": "' . $transaction_class . '",
                                  "amount": ' . $amount . ',
                                  "comment": "' . $comment . '"
                                }
                              ]
                            }';

        // Initialize stream context for HTTP request
        $options = [
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/json' . "\r\n" .
                            'Authorization: Bearer ' . $adminAuthToken,
                'content' => json_encode([
                    'query' => $graphqlQuery,
                    'variables' => json_decode($graphqlVariables, true),
                ]),
                'ignore_errors' => true,
            ],
        ];

        // Set the URL
        $url = GRAPHQL_URL;

        // Create a stream context
        $context = stream_context_create($options);

        // Perform the HTTP request and capture the response
        $response = @file_get_contents($url, false, $context); // Use @ to suppress warnings

        preg_match('/^HTTP\/\d\.\d\s+(\d+)\s+(.*)$/', $http_response_header[0], $matches);
        $httpCode = (int) $matches[1];
        $result['http_code'] = $httpCode;

        if (strpos($httpCode, '200') !== false) {
            $responseObj = json_decode($response, true);
            if( isset($responseObj['errors'])){
                $result['http_code'] = 400;
                $result['message'] = $responseObj['errors'][0]['message'];
                $result['data'] = $responseObj;
            }
            else{
                $result['result'] = 'success';
                $result['data'] = $responseObj;
            }
        } else {
            $result['message'] = 'Failed to perform balance correction.';
            $result['data'] = json_decode($response, true);
        }
    } catch (Exception $e) {
        $result['http_code'] = 500;
        $result['message'] = 'exception: ' . $e->getMessage();
        $result['data'] = $e;
    }

    return $result;
}
