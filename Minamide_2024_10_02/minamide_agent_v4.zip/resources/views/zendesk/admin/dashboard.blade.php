@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="d-flex justify-content-center align-items-center">
            <h1>Welcome to the Admin Dashboard</h1>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
            <a href="{{ route('zendesk.admin.profile.form') }}" class="btn btn-primary mr-3" style="margin-right: 20px;">Update Profile</a>
            <a href="{{ route('zendesk.password.form') }}" class="btn btn-danger">Change Password</a>
        </div>
    </div>
@endsection
