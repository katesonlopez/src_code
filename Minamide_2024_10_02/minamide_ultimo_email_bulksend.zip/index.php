<?php
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Mass Emailer with CSV</title>
<!--<link rel="icon" type="image/png" sizes="32x32" href="./assets/images/favicon.png">
    <link rel="apple-touch-icon" sizes="180x180" href="./assets/images/apple-touch-icon.png">-->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
  </head>
  <style>
      body {
          font-family: Arial, sans-serif;
      }
      /* Custom styles to reduce y-padding */
      th, td {
          padding-top: 5px !important;
          padding-bottom: 5px !important;
      }
      .custom-table {
          width: 600px; /* Set fixed width */
          margin: 0 auto; /* Center the table */
      }
      .status{
          display: none;
      }
      .progress {
          position: relative;
          background-color: #797979;
      }
      .progress-status {
          position: absolute;
          width: 100%;
          text-align: center;
          color: white;
          font-weight: bold;
          top: 8px;
      }
      .badge-container {
          display: inline; /* Ensures the badge is inline */
          margin-left: 10px; /* Adds some space between the input and badge */
          vertical-align: middle; /* Aligns badge with the input vertically */
          color: white;
      }
      #msgBodyPreview {
          height: 150px;
      }
  </style>
  <body class="bg-light">
    <div class="container my-5">
      <h1 class="text-center mb-5">Bulk <small> Email Sender</small></h1>

      <div class="form-group row">
        <label for="csvFile" class="col-sm-6 col-form-label text-right">Upload CSV File:</label>
        <div class="col-sm-6">
          <input type="file" class="form-control-file ctrl" id="csvFile" name="csvFile" accept=".csv">
          <small class="form-text text-muted" style="display: inline">
            Please upload a .csv file (max size 5MB).
          </small>
          <span id="rowCount" class="badge bg-danger badge-container" style="display: none;"></span>
        </div>
      </div>

      <hr class="seperator">

      <form id="emailForm" enctype="multipart/form-data">
        <h5 class="mb-3">SMTP Service Settings:</h5>
        <div class="row">
          <div class="col-sm-2">
            <div class="form-group">
              <label for="smtpHost">Host:</label>
              <input type="text" id="smtpHost" name="smtpHost" class="form-control ctrl" placeholder="e.g. smtp.yourserver.com" required>
            </div>
          </div>
          <div class="col-sm-2">
            <div class="form-group">
              <label for="smtpUsername">Username:</label>
              <input type="text" id="smtpUsername" name="smtpUsername" class="form-control ctrl" placeholder="e.g. your-email@domain.com" required>
            </div>
          </div>
          <div class="col-sm-2">
            <div class="form-group">
              <label for="smtpPassword">Password:</label>
              <input type="password" id="smtpPassword" name="smtpPassword" class="form-control ctrl" placeholder="Input SMTP password" required>
            </div>
          </div>
          <div class="col-sm-2">
            <div class="form-group">
              <label for="smtpPort">Port:</label>
              <input type="number" id="smtpPort" name="smtpPort" class="form-control ctrl" placeholder="e.g. 465 or 587" required>
            </div>
          </div>
          <div class="col-sm-2">
            <div class="form-group">
              <label for="senderEmail">Sender Address:</label>
              <input type="email" id="senderEmail" name="senderEmail" class="form-control ctrl" placeholder="e.g. your-email@domain.com" required>
            </div>
          </div>
          <div class="col-sm-2">
            <div class="form-group">
              <label for="senderName">Sender Name:</label>
              <input type="text" id="senderName" name="senderName" class="form-control ctrl" placeholder="e.g. UltimoPay" required>
            </div>
          </div>
        </div>

        <hr class="seperator">

        <div class="container mt-3">
          <form>
            <div class="d-flex align-items-center flex-wrap">
              <label for="batchSize" class="mr-2 mb-0">Send</label>
              <input type="number" id="batchSize" name="batchSize" class="form-control mr-2 ctrl" style="width: 80px;" value="10" min="1" required>
              <span class="mr-2">emails at once, then wait for</span>
              <label for="delaySec"></label>
              <input type="number" id="delaySec" name="delaySec" class="form-control mr-2 ctrl" style="width: 80px;" value="1" min="0" required>
              <span>seconds before sending the next batch.</span>
            </div>
          </form>
        </div>

        <hr class="seperator">

        <h5 class="mb-3 mt-3">Email Content Settings:</h5>
        <div class="form-group">
          <label for="msgSubject">Subject:</label>
          <input type="text" id="msgSubject" name="msgSubject" class="form-control ctrl" placeholder="Please input the title of email" required value="Hello">
        </div>
        <div class="form-group">
          <label for="msgBody">Body:</label>
          <textarea id="msgBody" name="msgBody" rows="6" class="form-control ctrl" placeholder="Please input your message to send" required>Every body!</textarea>
        </div>
        <div class="form-group">
          <label for="msgBodyPreview">Body Preview:</label>
          <pre id="msgBodyPreview" class="form-control ctrl bg-light"></pre>
        </div>

        <hr class="seperator">

        <div class="row">
          <div class="col-sm-4">
            <button type="submit" id="sendEmailsBtn" class="btn btn-success btn-block btn-lg ctrl">
              <span class="spinner-anim spinner-border spinner-border-sm text-white me-2" role="status" style="display: none;"></span>
              <i class="fas fa-paper-plane"></i> Send Emails
            </button>
          </div>
          <div class="col-sm-4">
            <button type="button" id="stopSendBtn" class="btn btn-danger btn-block btn-lg">
              <i class="fas fa-ban"></i> Stop
            </button>
          </div>
          <div class="col-sm-4">
            <button type="button" id="downloadReportBtn" class="btn btn-success btn-block btn-lg">
              <i class="fas fa-download"></i> Download Report
            </button>
          </div>
        </div>

        <hr class="seperator">

        <h5 class="mb-3 status">Emailing Status:</h5>
        <div class="progress my-4" id="my-upload-progress">
          <span class="progress-status"></span>
          <div class="progress-bar progress-bar-striped progress-bar-animated bg-success"
               style="width:0;">
          </div>
        </div>

        <div class="container mt-4 status">
          <h6 class="table-caption text-center">Email Sending Error Report</h6>
          <table class="table table-bordered custom-table">
            <thead class="bg-light">
            <tr>
              <th>Email Address</th>
              <th>Status</th>
            </tr>
            </thead>
            <tbody class="report">
            </tbody>
          </table>
        </div>
      </form>
    </div>
    <!-- . -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.3.0/papaparse.min.js"></script>
    <script>
      let gEmails = [];
      let gReport = [];
      let gTimer = 0;
      let gCurrentIndex = 0;
      let gIsStop = false;

      $(document).ready(function () {
        $('#my-upload-progress').css('display', 'none');

        $("#csvFile").on("change", function (evt) {
          const file = evt.target.files[0];
          if (!file) {
            return;
          }

          Papa.parse(file, {
            header: true,
            skipEmptyLines: true,
            complete: function (results) {
              const csvData = results.data;
              gEmails = csvData.map(row => row['email address']);
              $('.bg-danger').css('display', 'inline');
              $('.bg-danger').html(`${gEmails.length} Email Addresses`);
              console.log(gEmails);
            }
          });
        });

        $('#sendEmailsBtn').click(function(){
          if( gEmails.length <= 0 ){
            alert('Pls select valid email list csv file, first');
            return;
          }

          // Initialize
          gReport = [];
          setStatus(true);
          $('#my-upload-progress').css('display', 'flex');
          $('.progress-status').html(`0/${gEmails.length} (0%)`);
          $('.progress-bar').css('width', `0%`);
          $('.report').html('');
          gCurrentIndex = 0;
          gIsStop = false;
          onTimer();
        })

        $('#downloadReportBtn').click(function(){
          downloadReport();
        })

        //-- email preview (init)
        $('#msgBodyPreview').text($('#msgBody').val());
        //-- email preview (live)
        $('#msgBody').on('input', function() {
          let msg = $(this).val();
          $('#msgBodyPreview').text(msg);
        });
      });

      $('#stopSendBtn').click(function(){
        gIsStop = true;
        $('.progress-status').html(`Stopped!`);
        setStatus(false);
      });

      function onTimer(){
        if( gIsStop ){
          clearTimeout(gTimer);
          $('.progress-status').html(`Stopped!`);
          setStatus(false);
          return;
        }
        if (gCurrentIndex >= gEmails.length) {
          // If all emails are processed, log the status and return
          console.log(gReport);
          $('.progress-status').html(`Completed!`);
          setStatus(false);
          return;
        }

        let bulkSize = $('#batchSize').val() * 1;
        const emailBatch = gEmails.slice(gCurrentIndex, gCurrentIndex + bulkSize);
        $.ajax({
          url: 'send_emails.php',
          type: 'POST',
          contentType: 'application/json',
          data: JSON.stringify({
            emails: emailBatch,
            host: $('#smtpHost').val(),
            username: $('#smtpUsername').val(),
            password: $('#smtpPassword').val(),
            port: $('#smtpPort').val(),
            senderAddress: $('#senderEmail').val(),
            senderName: $('#senderName').val(),
            subject: $('#msgSubject').val(),
            body: $('#msgBody').val()
          }),
          dataType: 'json',
          success: function(response) {
            // Assume response is an array of objects with email and status
            response.forEach(item => {
              gReport.push(item);
              if( item.status === 'failed' ){
                let html = `<tr><td>${item.email}</td><td>${item.status}</td></tr>`;
                $('.report').append(html);
              }
            });

            // Set progress bar
            let total = gEmails.length;
            let proceed = gReport.length;
            let percent = (proceed * 100) / total;
            $('.progress-status').html(`${proceed}/${total} (${percent.toFixed(1)}%)`);
            $('.progress-bar').css('width', `${percent}%`);

            // If stopped
            if( gIsStop ){
              clearTimeout(gTimer);
              $('.progress-status').html(`Stopped!`);
              setStatus(false);
            }
            else{
              gCurrentIndex += bulkSize;

              const interval = $('#delaySec').val() * 1000;
              gTimer = setTimeout(onTimer, interval);
            }
          },
          error: function(jqXHR, textStatus, errorThrown) {
            console.error("Error sending emails:", textStatus, errorThrown);
          }
        });
      }

      function downloadReport() {
        // Convert gReport to CSV
        const csvData = convertToCSV(gReport);

        // Create a blob and an anchor element to facilitate the download
        const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);

        link.setAttribute('href', url);
        link.setAttribute('download', 'email_report.csv');
        link.style.visibility = 'hidden';

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }

      function convertToCSV(data) {
        // Extract headers from the first object in the data array
        const headers = Object.keys(data[0]).join(',') + '\n';

        // Map each object to a CSV string
        const rows = data.map(item => Object.values(item).join(',')).join('\n');

        return headers + rows;
      }

      function setStatus(status){
        if( status ){
          $('.spinner-anim').show();
          $('.ctrl').attr('disabled', true);
          $('.status').show();
        }
        else{
          $('.ctrl').removeAttr('disabled');
          $('.spinner-anim').hide();
        }
      }
    </script>
  </body>
</html>
