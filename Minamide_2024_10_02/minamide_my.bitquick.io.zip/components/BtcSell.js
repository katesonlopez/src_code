import {useRouter} from 'next/router';
import {useState} from "react";
import {useForm} from 'react-hook-form';
import {yupResolver} from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import {userService, alertService} from '/services';
import _ from 'lodash';
import Swal from "sweetalert2";
import {parseStringToFloat, toUsNumber, truncateFloat} from "./Utils/calc";

function BtcSell({wallet, id, user, twofa, walletData, exchangePairInfo}) {
  let btcExchangeInfo = null;
  for( let i = 0; i < exchangePairInfo.length; i++ ){
    if(exchangePairInfo[i].pair_id === (id+'USD'))
      btcExchangeInfo = exchangePairInfo[i];
  }

  const router = useRouter();
  const [inputValue, setInputValue] = useState(0);
  const [receive, setReceive] = useState('0.00');
  const balance = parseStringToFloat(wallet.data.balance);
  const minimum = btcExchangeInfo?.sell_min * 1 ?? 0.001;
  const float = wallet.float * 1;
  const [ifNotValid, setIfNotValid] = useState(true);
  const unit = id === 'LTC' ? 'USDT' : 'USD';

  const handleInputChange = (event) => {
    let newValue = event.target.value;
    const decimalDigits = newValue.split(".");
    const isFloat = newValue.toString().includes(".");
    if (!isNaN(newValue)) {
      if (isFloat && decimalDigits[1].length >= float) {
        newValue = parseFloat(newValue).toFixed(float);
      }
      setInputValue(newValue);
    }
    debounceApiCall(user, id, newValue, balance);
  };

  const debounceApiCall = _.debounce((user, id, newValue, balance) => {
    setIfNotValid(true);
    if(newValue * 1 < minimum){
      setError('amount', {message: `Amount should be greater than ${minimum} ${id}`});
    }
    else{
      userService.runApi('cryptoPrice/', user)
        .then((res) => {
          const input = document.getElementById('amount');
          newValue = input.value;
          if(newValue * 1 < minimum){
            setError('amount', {message: `Amount should be greater than ${minimum} ${id}`});
          }
          else{
            const resCryptoCurrency = res.data.cryptocurrencies;
            const filteredData = resCryptoCurrency.filter((item) => item.pair.includes(id));
            const buy_price = filteredData[0].buy_price;
            let calculatedValue = parseFloat(newValue) * parseFloat(buy_price) * ( 1 - parseFloat(btcExchangeInfo.buy_fee_percent) / 100);
            calculatedValue > 0 ? setReceive(`` + calculatedValue.toFixed(2)) : setReceive('0.00');
            console.log('buy_price: ', buy_price, ', receive: ', calculatedValue);
            if (parseFloat(balance) < parseFloat(newValue)) {
              setError('amount', {message: `You don't have enough ${id} to sell this`});
              setIfNotValid(true);
              return;
            } else {
              setError('amount', null);
              setIfNotValid(false);
            }
            setIfNotValid(false);
          }
        })
        .catch(alertService.error);
    }
  }, 500); // debounce time in milliseconds

  const handleKeyDown = (event) => {
    if (event.key === '-' || event.key === '+') {
      event.preventDefault(); // prevent '-' or '+' from being entered
    }
    userService.PreventIncrement(event);
  }

  const validationSchema = Yup.object().shape({
    amount: Yup.string()
      .required('amount is required'),
  });

  const formOptions = {
    resolver: yupResolver(validationSchema), defaultValues: {
      email_address: user.email_address,
      auth_token: user.auth_token,
      type: 'sell',
      pair: id + `USD`,
      amount: inputValue,
    }
  };

  // get functions to build form with useForm() hook
  const {register, handleSubmit, formState, setError} = useForm(formOptions);
  const {errors} = formState;

  function onSubmit(formdata) {
    Swal.fire({
      title: `Do you really want to sell ${toUsNumber(inputValue)} ${id}?`,
      html: `You get ${toUsNumber(receive)} ${unit}}<br><em>The amount may vary slightly depending on the fluctuation.</em>`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, sell it",
      cancelButtonText: "No, cancel",
    }).then((result) => {
      if (result.isConfirmed) {
        userService.showLoader(true);
        return userService.runApi('cryptoExchange/', formdata)
          .then((res) => {
            userService.showLoader(false);
            if (res.data.result === "success") {
              Swal.fire({
                title: "Success",
                text: "Amount Exchanged Successfully",
                icon: "success",
              }).then(function (/*result*/) {
                router.reload();
              });
            } else if (res.data.result === "failed") {
              Swal.fire({
                title: "Error",
                text: res.data.error.errorMessage,
                icon: "error",
              }).then(function (result) {
              });
            }
          })
          .catch((res) => {
            userService.showLoader(false)
            Swal.fire({
              title: "Error",
              text: res.response.data.error.errorMessage,
              icon: "error",
            }).then(function (result) {
            });
          });
      } else {
      }
    })
  }

  return (
    <>
      <div className="container-fluid px-4">
        <div className="row pse-5 pt-5 pb-5">
          <div className="col-sm-11 mt-1">
            <h4 className="mb-2">
              <b>IMPORTANT NOTICE</b>
            </h4>
            <label className="">
              Final amount of {unit} you have to pay is subject to be changed according
              to {id}/{unit} price at the time your buying order is submitted and
              executed.{" "}
            </label>
          </div>
          <div className="col-sm-12 mt-4">
            <h4 className="mt-3">
              <b>AMOUNT YOU WANT TO SELL </b>
            </h4>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="mb-5">
                <input onKeyDown={handleKeyDown}
                       name="amount" step="0.000001"
                       {...register('amount')} className={`form-control ${ifNotValid ? 'is-invalid' : ''}`}
                       id="amount"
                       type="text"
                       value={inputValue}
                       onChange={handleInputChange}
                       placeholder={`Enter ` + wallet.title + ` Amount`}
                />
                <div className="invalid-feedback ms-3">{errors.amount?.message}</div>
                <div className="ms-3 mt-1">Available amount : {toUsNumber(truncateFloat(balance, float))} {id}</div>
              </div>
              <h4 className="mt-5">
                <b>YOU RECEIVE </b>
              </h4>
              <p className="amount-price amount-price-usd">
                {toUsNumber(receive)} <font style={{fontSize: 14}}>{unit}</font>{" "}
              </p>
              <button type="submit" className="size-xl button primary mt-4 col-sm-3"
                      disabled={formState.isSubmitting || ifNotValid}>
                SELL {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  )
}

export default BtcSell;
