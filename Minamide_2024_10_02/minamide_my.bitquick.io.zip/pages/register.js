import { useRouter } from 'next/router';
import Link from 'next/link'
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import YupPassword from 'yup-password'
YupPassword(Yup) // extend yup
import { userService, alertService } from '/services';
import countryList from '/lib/countryList';
import Swal from 'sweetalert2';
import Main from './layout/Main'
import {useState, useEffect, useRef} from "react";
import Cookies from 'js-cookie';
export default function register() {

  const router = useRouter();
  const [options, setOptions] = useState([]);
  const [refId, setRefId] = useState('');
  const [notset, setNotset] = useState('');
  const inputRef = useRef(null);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    const refIdd = Cookies.get(`AffRefId`);
    if (refIdd) {
      console.log(`The 'AffRefId' cookie is set with value: ${refIdd}`);
      setRefId(refIdd);
    } else {
      console.log("The 'AffRefId' cookie is not set");
      setNotset("The 'AffRefId' cookie is not set");
    }

    // Set focus
    if (inputRef.current) {
      inputRef.current.focus();
    }

    // Fetch Countries
    const fetchCountris = async () => {
      setOptions(await countryList());
    };
    if(!options.length)
      fetchCountris();
  }, [])

  const validationSchema = Yup.object().shape({
    first_name: userService.CommonValidation()
      .required('First Name is required').matches(
        /^([A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\s]*)$/gi,
        'First name can only contain Latin letters.'
      )
    ,
    last_name: userService.CommonValidation()
      .required('Last Name is required').matches(
        /^([A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\s]*)$/gi,
        'Last name can only contain Latin letters.'
      )
    ,
    email_address: userService.CommonValidation()
      .email('Please enter a valid email address')
      .required('Email is required')
    ,
    country: Yup.string()
      .required('Country is required')
    ,
    terms: Yup.bool()
      .oneOf([true] , 'Terms and conditions is required'),
    privacy: Yup.bool()
      .oneOf([true] , 'Privacy policy is required'),
    wallet_terms: Yup.bool()
      .oneOf([true] , 'Wallet Terms, Exchange Terms is required'),
    password: Yup.string()
      .required('No password provided.')
      .min(
        6,
        'password must contain 6 or more characters with at least one of each: uppercase, lowercase, number and special'
      )
      .max(
        60,
        'password cannot be longer than 60 characters'
      )
      .minLowercase(1, 'password must contain at least 1 lower case letter')
      .minUppercase(1, 'password must contain at least 1 upper case letter')
      .minNumbers(1, 'password must contain at least 1 number')
      .minSymbols(1, 'password must contain at least 1 special character'),
    retypePassword: Yup
      .string()
      .required('Please retype your password.')
      .oneOf([Yup.ref('password')], 'Your passwords do not match.')
  });
  const formOptions = { resolver: yupResolver(validationSchema) ,defaultValues: {
      affiliation:"BitQuick",

    }};

  // get functions to build form with useForm() hook
  const { register, handleSubmit, formState , setError } = useForm(formOptions);
  const { errors } = formState;

  function onSubmit(user) {
    user.user_check = 1;
    return userService.register(user)
      .then((res) => {

        const expiration = new Date().getTime() + 5 * 60 * 1000
        if(res.data.result === 'success'){
          Swal.fire({
            title: "Success",
            text: "Verification Code has been sent to your email address. Please check",
            icon: "success"
          }).then(function (result)
          {
            localStorage.setItem('beforeSignIn', JSON.stringify(user));
            router.push({
              pathname: '/verify-signup',
            });
            localStorage.setItem('verification-token', JSON.stringify({ res, expiration }));
          })
        }
        else if(res.data.result === "failed")
        {
          if(res.data.error.errorCode === 15){
            Swal.fire({
              title: "Notice",
              text: "You did not complete the previous signup process. Please complete the final step.",
              icon: "warning"
            }).then(function (result){
              userService.runApi(`resendSignupCode/`, user).then((d) => {
                router.push({
                  pathname: '/verify-signup',
                  query: res
                });
                localStorage.setItem('verification-token', JSON.stringify({ res, expiration }));
              })
            })
          }
          else{
            if(res.data.error.errorCode === 1)
              setError('first_name', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 2)
              setError('email_address', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 3)
              setError('email_address', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 4)
              setError('password', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 5)
              setError('password', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 6)
              setError('password', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 7)
              setError('password', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 8)
              setError('first_name', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 9)
              setError('first_name', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 10)
              setError('last_name', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 11)
              setError('last_name', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 12)
              setError('country', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 13)
              setError('country', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 14)
              setError('email_address', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 16)
              setError('password', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 17)
              setError('last_name', { message: res.data.error.errorMessage });

            if(res.data.error.errorCode === 18)
              setError('email_address', { message: res.data.error.errorMessage });
          }
        }
      })
      .catch(alertService.error);
  }
  return (
    <Main page="SIGN IN">
      {notset || refId ?
        <section className="height-con">
          <div className="container relative">
            <div className="crow login-main">
              <div className="col-sm-10 col-md-8 m-auto col-frm">
                <div className="main-frm signup-frm">
                  <h1 className="mt-4 pt-4">SIGN UP</h1>
                  <div className={`${isMobile ? "p-2" : "p-4"}`}>
                    <form className="row sign-up-fm" onSubmit={handleSubmit(onSubmit)}>
                      <div className="col-md-6 mb-4">
                        <label htmlFor="inputEmail4" className="form-label" style={{ color:"#1962A6" }}>
                          First Name
                        </label>
                        <input
                          type="text"
                          name="first_name"

                          {...register('first_name')} className={`input m w-input ${errors.first_name ? 'is-invalid' : ''}`}
                          id="inputEmail4"
                          placeholder="First Name"
                        />
                        <div className="invalid-feedback">{errors.first_name?.message}</div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <label htmlFor="inputPassword4" className="form-label" style={{ color:"#1962A6" }}>
                          Last Name
                        </label>
                        <input
                          type="text"
                          name="last_name"

                          {...register('last_name')} className={`input m w-input ${errors.last_name ? 'is-invalid' : ''}`}
                          id="inputPassword4"
                          placeholder="Last Name"
                        />
                        <input
                          type="hidden"
                          name="ref_id"
                          {...register('ref_id')} value={`${refId}`} className={`input m w-input ${errors.ref_id ? 'is-invalid' : ''}`}

                        />
                        <div className="invalid-feedback">{errors.last_name?.message}</div>
                      </div>
                      <div className="col-md-12 mb-4">
                        <label htmlFor="inputPassword4" className="form-label" style={{ color:"#1962A6" }}>
                          Email Address
                        </label>
                        <input
                          type="text"
                          name="email_address"
                          ref={inputRef}
                          {...register('email_address')} className={`input m w-input ${errors.email_address ? 'is-invalid' : ''}`}
                          id="inputPassword4"
                          placeholder="Email Address"
                        />
                        <div className="invalid-feedback">{errors.email_address?.message}</div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <label htmlFor="inputEmail4" className="form-label" style={{ color:"#1962A6" }}>
                          Password
                        </label>
                        <input
                          type="password"
                          name="password"

                          {...register('password')} className={`input m w-input ${errors.password ? 'is-invalid' : ''}`}
                          id="inputEmail4"
                          placeholder="Password"
                        />
                        <div className="invalid-feedback">{errors.password?.message}</div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <label htmlFor="inputPassword4" className="form-label" style={{ color:"#1962A6" }}>
                          Confirm Password
                        </label>
                        <input
                          type="password"
                          name="retypePassword"

                          {...register('retypePassword')} className={`input m w-input ${errors.retypePassword ? 'is-invalid' : ''}`}
                          id="inputPassword4"
                          placeholder="Confirm Password"
                        />
                        <div className="invalid-feedback">{errors.retypePassword?.message}</div>
                      </div>
                      <div className="col-md-12 mb-4">
                        <label htmlFor="inputState" className="form-label" style={{ color:"#1962A6" }}>
                          Country
                        </label>
                        <select
                          id="inputState"
                          name="country"
                          style={{ backgroundColor: "#393838", color:"#1962A6"}}
                          {...register('country')} className={`form-control ${errors.country ? 'is-invalid' : ''}`}
                          defaultValue=""
                        >
                          <option value="">Select Country</option>
                          {options.map(option=>(
                            <option key={option.label} value={option.label}>{option.label}</option>
                          ))}
                        </select>
                        <div className="invalid-feedback">{errors.country?.message}</div>
                      </div>
                      <div className="col-md-8 m-auto mb-4">
                        <div className="form-check mb-3 real-redio">
                          <input
                            name="terms"
                            {...register('terms')} className={`form-check-input ${errors.terms ? 'is-invalid' : ''}`}
                            type="checkbox"
                            id="flexcheckboxDefault1"
                            defaultChecked=""
                            value="1"
                          />
                          <label
                            className="form-check-label"
                            htmlFor="flexcheckboxDefault1" style={{ color:"#032D69" }}
                          >
                            I agree with <a className="font-800 text-white text-decoration-underline" href="https://www.bitquick.io/terms-and-conditions/" target="_blank" ><b>Term &amp; Conditions</b></a>
                          </label>
                          <div className="invalid-feedback">{errors.terms?.message}</div>
                        </div>
                        <div className="form-check mb-3 real-redio">
                          <input

                            type="checkbox"
                            name="privacy"
                            {...register('privacy')} className={`form-check-input ${errors.privacy ? 'is-invalid' : ''}`}
                            id="flexcheckboxDefault2"
                            value="1"
                          />
                          <label
                            className="form-check-label"
                            htmlFor="flexcheckboxDefault2" style={{ color:"#032D69" }}
                          >
                            I agree with <a className="font-800 text-white text-decoration-underline" href="https://www.bitquick.io/privacy-policy/" target="_blank" ><b>Privacy Policy</b></a>
                          </label>
                          <div className="invalid-feedback">{errors.privacy?.message}</div>
                        </div>
                        <div className="form-check real-redio">
                          <input
                            name="wallet_terms"
                            {...register('wallet_terms')} className={`form-check-input ${errors.wallet_terms ? 'is-invalid' : ''}`}
                            type="checkbox"

                            id="flexcheckboxDefault3"
                            value="1"
                          />
                          <label
                            className="form-check-label"
                            htmlFor="flexcheckboxDefault3" style={{ color:"#032D69" }}
                          >
                            I agree with <a className="font-800 text-white text-decoration-underline" href="https://www.bitquick.io/wallet-terms/" target="_blank" ><b>Wallet Terms,</b></a><a className="font-800 text-white text-decoration-underline" href="https://www.bitquick.io/exchange-terms/" target="_blank" ><b> Exchange Terms</b></a>
                          </label>
                          <div className="invalid-feedback">{errors.wallet_terms?.message}</div>
                        </div>
                      </div>
                      <div className="mb-4 text-center">
                        <button disabled={formState.isSubmitting}   className="btn cstm-submit py-2 w-100"
                                style={{ backgroundColor:"#10b981", color:"#fff" }}>
                          {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                          <font>SIGN UP</font>
                        </button>
                      </div>
                      <div className="mb-2 text-center">
                        <font className="user" style={{ color:"#032D69" }}>Already a member ?</font> &nbsp;
                        <Link href="/" className="font-800 text-decoration-underline" style={{ color:"white", fontSize:"12px;" }}>
                          SIGN IN
                        </Link>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="sign-bg">
            <div className="bg-img">
              {/*<img src="/assets/img/bg.png" width="100%" style={{ opacity:0.7 }} alt="background"/>*/}
            </div>
          </div>
        </section> : `Loading`}

    </Main>

  )
}
