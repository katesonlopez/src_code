<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Transaction extends Model
{
	use SoftDeletes;

	protected $primaryKey = 'orderNo';
	public $incrementing = false;

	protected $fillable = [
		'orderNo',
		'partner_id',
		'email_address',
		'card_holder_name',
		'amount',
		'fee',
		'fee_percent',
		'product_name',
		'username',
		'service_type',
		'status',
		'email_sent',
		'partner_domain',
	];

	// Define the relationship with the Partner model
	public function partner()
	{
		return $this->belongsTo(Partner::class);
	}
}
