<?php
namespace App\Library;
use DateTime;
use DateTimeZone;
use Exception;

class DateUtil
{
  /**
   * @throws Exception
   */
  public static function convertToUTC($dateString): string
  {
    $date = new DateTime($dateString);
    $date->setTimezone(new DateTimeZone('UTC'));
    return $date->format('Y-m-d H:i:s');
  }

	public static function formatDateTime($dateTimeString) {
		try {
			// Check the format of the date-time string and create a DateTime object
			if (strpos($dateTimeString, 'T') !== false) {
				// ISO 8601 format
				$dateTime = new DateTime($dateTimeString);
			} else {
				// Other format
				$dateTime = new DateTime($dateTimeString);
			}

			// Format the date and time separately
			$date = $dateTime->format('Y-m-d');
			$time = $dateTime->format('H:i:s');

			// Construct the HTML output
			return "<span class='simple-date'>{$date}</span><br/><sub class='simple-time'>{$time}</sub>";
		} catch (Exception $e) {
			// Handle the exception if the date-time string is not valid
			return "<span>Invalid date-time</span>";
		}
	}
}
