<?php
require_once '../includes/authentication.php';

/**
 * Start to call api
 **/
// Process AJAX request
$requestBody = json_decode(file_get_contents('php://input'), true);

$response = array(
  'result' => 'failed',
  'error' => ['errorMessage' => '']);

if (isset($requestBody['action']) && $requestBody['action'] == 'checkAuth') {
  try{
    // Check request parameters
    $action = $requestBody['action'] ?? null;
    $jwt = $requestBody['jwt'] ?? null;

    // Check jwt validation <=> Check if logged in
    $emailAddress = checkAuthentication( $jwt );
    $response['result'] = 'success';
    $response['emailAddress'] = $emailAddress;
  }
  catch(Exception $e){
    $response['error']['errorMessage'] = $e->getMessage();
  }
}

echo json_encode($response);