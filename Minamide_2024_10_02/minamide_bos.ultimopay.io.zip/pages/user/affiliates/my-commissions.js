import { useState, useEffect } from "react";
import { useRouter } from 'next/router';
import { userService/*, alertService*/ } from '/services';
import withAuth from '/hooks/withAuth';
import UserLayout from '/pages/user/layout/UserLayout'
import DataTable from '/components/DataTable';
import {maskEmail} from "../../../components/Utils/calc";

const page = () => {
  const router = useRouter();
  const [user, setUserData] = useState(null)
  const [userdata, setUserrData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [kycData, setKycData] = useState([]);
  const [reportData, setReportData] = useState([])
  const [approvedTotal, setApprovedTotal] = useState(0)
  const [pendingTotal, setPendingTotal] = useState(0)
  const [totalCost, setTotalCost] = useState(0)
  const col = [
    {
      Header: 'Date/Time',
      accessor: 'Date',
    },
    {
      Header: 'USER',
      accessor: 'OrderID',
    },
    {
      Header: 'COMMISSION',
      accessor: 'Commission',
    },
    {
      Header: 'AMOUNT',
      accessor: 'TotalCost',
    },
    {
      Header: 'PRODUCT',
      accessor: 'ProductID',
    },
    {
      Header: 'APPROVAL STATUS',
      accessor: 'Status',
    },
    {
      Header: 'PAYOUT STATUS',
      accessor: 'PaidStatus',
    },
  ];

  useEffect(() => {
    async function fetchData() {
      const y = localStorage.getItem('user');
      const userser = JSON.parse(y);
      const user = userser.res.data.signinResponse;
      setUserData(user);
      await getUserInfo(user );
      getUserStatus(user);
      getAffiliateReport(user);
    }

    fetchData();
  }, [router]);

  const getUserStatus = (userrr ) => {
    delete userrr.expires_in;
    delete userrr.wallet;

    userService.getUserStatus(userrr , 'both').then((d) => {
      setKycData(d.data);
    }).catch((d) => {
      console.log(d);
    });
  };

  const getAffiliateReport = (userParam) => {
    delete userParam.expires_in;
    delete userParam.wallet;
    userParam.affiliate_name = userParam.email_address;
    userService.runApi(`getAffiliateReport/` , userParam).then((d) => {
      /*
      * Pending Payout Commission
        ---> Apprve status [Approved] and Payout Statis [Unpaid]

        Pending Approval Commission
        ---> Apprve status [Pending]

        Toal Paid Commission
        ---> Payout Statis [Paid]
      * */
      console.log(d);
      let orders = d.data.apiResponse;
      orders = orders.map(record => ({
        ...record,
        OrderID: maskEmail(record.OrderID)
      }));

      setReportData(orders);

      let at = 0; // Approved total (where (PaidStatus is 'none' or 'UNPAID') while Status is 'APPROVED')
      let pt = 0; // Pending total (where Status is 'PENDING')
      let tc = 0; // Total paid (where PaidStatus is 'PAID')

      orders.forEach((item) => {
        if ((item.PaidStatus === 'none' || item.PaidStatus === 'UNPAID') && item.Status === 'APPROVED') {
          at += item.Commission;
        }

        if (item.Status === 'PENDING') {
          pt += item.Commission;
        }

        if (item.PaidStatus === 'PAID') {
          tc += item.Commission;
        }
      });

      setApprovedTotal(at);
      setPendingTotal(pt);
      setTotalCost(tc);
      setIsLoading(false);
    }).catch((d) => {
      console.log(d);
    })
  }

  const getUserInfo = (userParam) => {
    delete userParam.expires_in;
    delete userParam.wallet;
    setUserrData(false);
    userService.runApi(`userInfo/` , userParam).then((d) => {
      const resd = d.data.userInfoResponse;
      setUserrData(resd);
    }).catch((d) => {
      console.log(d);
    })
  }

  return (
    <UserLayout>
      {user && userdata && kycData ? (
        <main>
          <div className="container-fluid px-4">
            <div className='mt-4'>
              <div className="card">
                <div className="card-header">MY COMMISSIONS</div>
                <div className="card-body">
                  <table className="table table-borderless">
                    <tbody>
                      <tr>
                        <th className='border-0'>Pending payout commission:</th>
                        <td className='border-0'>{approvedTotal.toFixed(2)} USD</td>
                      </tr>
                      <tr>
                        <th className='border-0'>Pending approval commission:</th>
                        <td className='border-0'>{pendingTotal.toFixed(2)} USD</td>
                      </tr>
                      <tr>
                        <th className='border-0'>Total paid commission:</th>
                        <td className='border-0'>{totalCost.toFixed(2)} USD</td>
                      </tr>
                    </tbody>
                  </table>

                  <div className="table-responsive mt-3">
                    {isLoading ?  <p>Loading...</p> :
                      <DataTable data={reportData} col={col} />
                    }
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      ): (
        <p>Loading...</p>
      )}
    </UserLayout>
  )
}

export default withAuth(page);
