<?php
//05620010100133108,4284719007177821
$cardnum = (isset($_GET['cardnum']))?trim($_GET['cardnum']):'';
//$cardnum = "4284714014793975";
$req_body  = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:jdb=\"http://jdbinhouse.local.net/\">";
$req_body .= "<soapenv:Header/>";
$req_body .= "<soapenv:Body>";
$req_body .= "<jdb:GetDebitCheckBalance>";
$req_body .= "<jdb:card_no>" . $cardnum . "</jdb:card_no>";
$req_body .= "</jdb:GetDebitCheckBalance>";
$req_body .= "</soapenv:Body>";
$req_body .= "</soapenv:Envelope>";
//$req_formated_body = sprintf($req_body, $cardnum);

echo $req_body . "<br/>";

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://172.21.22.203:7867/jdbcardws.asmx?wsdl%0A',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => $req_body,
  CURLOPT_HTTPHEADER => array(
    'Content-Type: text/xml'
  ),
));

$response2 = curl_exec($curl);

curl_close($curl);
//echo "<br/>caocnsdsadf<br/>";
//echo $response2;


//$xml = simplexml_load_file('./jdbsoapres.xml');
$doc = new DOMDocument();
//$doc->load('./jdbsoapres.xml');
$doc->loadXML($response2);
$balance_node = $doc->getElementsByTagName('AVL_BALANCE');
$tblCardErrCode = $doc->getElementsByTagName('ERR_CODE');
$tblCardErrDesc = $doc->getElementsByTagName('ERR_DESC');
if ($balance_node->length==0) {
	echo "<br/>balance not found !";
} else {
	$balance = $balance_node->item(0)->nodeValue;
	echo "<br/>balance = " . $balance;
}

if ($tblCardErrCode->length>0) {
	$errCode = $tblCardErrCode->item(0)->nodeValue;
	echo "<br/>Error Code = " . $errCode;
}

if ($tblCardErrDesc->length>0) {
	$errDesc = $tblCardErrDesc->item(0)->nodeValue;
	echo "<br/>Error Desc = " . $errDesc;
}




?>