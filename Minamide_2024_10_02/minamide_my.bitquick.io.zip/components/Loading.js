// Loading.js

const Loading = () => {
  return (
    <div className="d-flex w-100 h-100 justify-content-center align-items-center">
      <div className="vertical-middle">
        BitQuick Loading...
      </div>
    </div>
  );
};

export default Loading;
