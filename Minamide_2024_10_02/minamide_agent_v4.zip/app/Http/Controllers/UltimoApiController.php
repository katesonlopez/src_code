<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UltimoApiController extends Controller
{
  public function showReqIssueCardApiTestPage()
  {
    return view('xapiserver.reqIssueCardApi');
  }
}
