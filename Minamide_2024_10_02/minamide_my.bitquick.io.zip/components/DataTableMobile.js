import React, { useMemo, useState } from 'react';
import { useTable, useSortBy, useGlobalFilter, usePagination } from 'react-table';

function DataTableMobile({ data , col }) {
  const [filterInput, setFilterInput] = useState('');

  data = toMobileData( data );
  console.log(data);

  const columns = useMemo(
    () => col,
    []
  );

  const tableData = useMemo(() => data, [data]);

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,
    state,
    setGlobalFilter,
    gotoPage,
    nextPage,
    previousPage,
    canNextPage,
    canPreviousPage,
    pageOptions,
    pageCount,
    setPageSize,
  } = useTable(
    {
      columns,
      data: tableData,
      initialState: { pageIndex: 0, pageSize: 10 },
    },
    useGlobalFilter,
    useSortBy,
    usePagination
  );

  const { globalFilter, pageIndex, pageSize } = state;

  const handleFilterChange = (e) => {
    const value = e.target.value || '';
    setGlobalFilter(value);
    setFilterInput(value);
  };

  function toMobileData( tableData ){
    return tableData.map(item => {
      const data = `
      <table>
        <tr>
            <td class="border-0 font-9" colspan="2">${item.Date}</td>
        </tr>
        <tr>
            <td class="border-0 font-9 text-break-keep-all">${item.ProductID}</td>
            <td class="border-0 font-9">${item.Commission} USD</td>
        </tr>
        <tr>
            <td class="border-0 font-9" colspan="2">${item.OrderID}</td>
        </tr>
        <tr>
            <td class="border-0 font-9">APPROVAL STATUS</td>
            <td class="border-0 font-9">${item.Status}</td>
        </tr>
        <tr>
            <td class="border-0 font-9">PAYOUT STATUS</td>
            <td class="border-0 font-9">${item.PaidStatus}</td>
        </tr>
      </table>
    `;
      return { Data: data.trim() };
    });
  }

  return (
    <>
      <table {...getTableProps()} className='mytable1'>
        {/*<thead>
        {headerGroups.map((headerGroup) => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map((column) => (
              <th
              >
                {column.render('Header')}
              </th>
            ))}
          </tr>
        ))}
        </thead>*/}
        <tbody {...getTableBodyProps()}>
        {page.map((row, rowIndex) => {
          prepareRow(row);
          return (
            <tr {...row.getRowProps()} key={rowIndex}>
              {row.cells.map((cell, cellIndex) => (
                <td {...cell.getCellProps()} key={cellIndex}>
                  <div dangerouslySetInnerHTML={{ __html: cell.value }} />
                </td>
              ))}
            </tr>
          );
        })}
        </tbody>
      </table>
      <div align="center" className="mt-2">
        <div className="pagination" style={{display:'block'}}>
          <button className="none-border-btn" onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
            {'<<'}
          </button>{' '}
          <button className="none-border-btn" onClick={() => previousPage()} disabled={!canPreviousPage}>
            {'<'}
          </button>{' '}
          <button className="none-border-btn" onClick={() => nextPage()} disabled={!canNextPage}>
            {'>'}
          </button>{' '}
          <button className="none-border-btn" onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
            {'>>'}
          </button>{' '}
        </div>
        <div className="mt-0">
          Page{' '}
          <strong>
            {pageIndex + 1} of {pageOptions.length}
          </strong>{' '}
        </div>
      </div>
    </>
  );
}

export default DataTableMobile;
