

<?php $__env->startSection('content'); ?>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <h2 class="text-success text-center mb-3">Payment Successful</h2>
      <div class="card">
        <div class="card-header">Payment Information</div>
        <div class="card-body">
          <p><strong>Order No:</strong> <?php echo e($orderNo); ?></p>
          <p><strong>Product Description:</strong> <?php echo e($productDescription); ?></p>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Minamide\minamide_api.kaiserpayment.com\resources\views/pages/confirmation.blade.php ENDPATH**/ ?>