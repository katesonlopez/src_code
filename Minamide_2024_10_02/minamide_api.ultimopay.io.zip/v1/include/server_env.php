<?php

const COGNITO_URL = 'https://cognito-idp.us-east-1.amazonaws.com/';

/**
    GRAPHQL_URL can be one of:
 *      https://vakotrade-demo.cryptosrvc.com/graphql/
 *      https://vakotrade.cryptosrvc-dev.com/graphql/
 *      https://vakotrade-plusqo-uat.cryptosrvc.com/graphql/
 **/
const GRAPHQL_URL = 'https://vakotrade-demo.cryptosrvc.com/graphql/';