<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FileDetail extends Model
{
  protected $fillable = [
    'file_id',
    'user_id',
    'amount',
    'currency',
    'comment',
    'result',
    'reason'
  ];

  public function file(): BelongsTo
  {
    return $this->belongsTo('App\File');
  }
}
