
let g_fileDatatable = null;
let g_siteUrl = base_url;

$(document).ready(function(){
  "use strict"

  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });

  g_fileDatatable = initDatatable('file_list_table');

  $("#upload").click(function(){
    checkCsvFileValidation();
  });


  $("#uploadConfirm").click(function(){
    uploadCsvFile();
  });

  getWalletBalance();
})

function initDatatable( tableId ){
  return $("#" + tableId).DataTable({
    "processing": true,
    "serverSide": true,
    ajax: {
      url: base_url + '/getFileList',
      "type": "POST",
    },
    responsive: true,
    dom: '<"top"<"actions action-btns"B><"action-filters"lf>><"clear">rt<"bottom"<"actions">p>',
    oLanguage: {
      sLengthMenu: "_MENU_",
      sSearch: "search"
    },
    aLengthMenu: [[4, 10, 15, 20], [4, 10, 15, 20]],
    bInfo: false,
    ordering: false,
    autoWidth: false,
    pageLength: 4,
    length: true,
    searchable: true,
    initComplete: function (settings, json) {
      $("#" + tableId).css('width', '');
    },

    "createdRow": function (row, data, index) {
      $(row).find('.detail-view-action').on('click', function (e) {
        getFileDetails($(this).attr('detailed_id'));
      });
    }
  });
}

function uploadCsvFile(){
  $("#uploadConfirm").attr('disabled', true);

  let url = g_siteUrl + '/upload/csvFile';
  let fd = new FormData();
  let files = $('#csvFile')[0].files[0];
  fd.append('csvFile', files);
  fd.append('merchant', $("#merchant").val());
  $.ajax({
    url: url,
    type: 'POST',
    data: fd,
    cache: false,
    contentType: false,
    processData: false,
    enctype: 'multipart/form-data',
    success: function(response){
      if(response * 1 > 0){
        closeModal('confirmDialog');
        g_fileDatatable.ajax.reload(null, false);
        getFileDetails( response, true );
      }
      else{
        sweetAlert('Failed to upload csv file.', 'This file not uploaded. Try again, please', 'error');
      }
      $("#uploadConfirm").removeAttr('disabled');
    },
    error: function (e){
      $("#uploadConfirm").removeAttr('disabled');
    }
  });
}

function checkCsvFileValidation(){
  $('#upload').attr('disabled', true);
  if($('#csvFile')[0].files[0]){
    // creating FileReader
    let totalUsdtAmount = 0;
    let totalUsdAmount = 0;
    let reader = new FileReader();

    // getting File instance
    let file = $('#csvFile')[0].files[0];

    // start reading
    reader.readAsText(file);

    // assigning handler
    reader.onloadend = function(evt) {
      if( evt.target.result == null ) {
        sweetAlert('Wrong file format', 'This file is corrupted or has wrong format. Please check file format.', 'warning');
        $('#upload').removeAttr('disabled');
        return;
      }
      let lines = evt.target.result.split(/\r?\n/);

      // Check file id validation
      let fileId = lines[0].split(/,/)[0];
      if( !fileId || fileId.trim().length === 0 ){
        sweetAlert('File id is required.', 'This file must contain unique file id.', 'warning');
      }
      else{
        $.ajax({
          url: g_siteUrl + '/upload/checkCsvFile',
          type: 'POST',
          data: {
            dupCheckFileId: fileId,
          },
          success: function(response){
            if(response * 1 === 0){
              // Check file content validation
              lines.forEach(function (line) {
                let itemArray = line.split(/,/);
                if( itemArray[1] == null || itemArray[1].trim().length === 0 ||
                  itemArray[2] == null || itemArray[2].trim().length === 0 ||
                  (itemArray[2].toUpperCase() !== 'USDT' && itemArray[2].toUpperCase() !== 'USD')){
                }
                else{
                  if(parseFloat(itemArray[1]) && itemArray[2].toUpperCase() === 'USDT') {
                    totalUsdtAmount += (itemArray[1] * 1);
                  }
                  if(parseFloat(itemArray[1]) && itemArray[2].toUpperCase() === 'USD') {
                    totalUsdAmount += (itemArray[1] * 1);
                  }
                }
              });

              if( totalUsdtAmount > parseFloat($("#balanceUsdt").text().trim())){
                sweetAlert('Insufficient USDT balance.', 'This agent USDT balance is insufficient.', 'warning');
              }
              else if( totalUsdAmount > parseFloat($("#balance_usd").text().trim())){
                sweetAlert('Insufficient USD balance.', 'This agent USD balance is insufficient.', 'warning');
              }
              else{
                $("#filename").text(file.name);
                $("#totalAmountUsdt").text(totalUsdtAmount);
                $("#totalAmountUsd").text(totalUsdAmount);
                $("#selectedMerchant").text($("#merchant").val());
                $("#do_modal_confirmDialog").trigger('click');
              }
            }
            else{
              sweetAlert('Already proceeded old file.', 'This file has been proceed already before.', 'error');
            }

            $('#upload').removeAttr('disabled');
          },
          error: function (){
            $('#upload').removeAttr('disabled');
          }
        });
      }
    };
  }
  else {
    $('#upload').removeAttr('disabled');
    sweetAlert('Select a csv file.', 'file not uploaded. select a csv file to be upload', 'warning');
  }
}

function getFileSummery(fileId, detailId){
  $.ajax({
    url: g_siteUrl + '/upload/getFileSummery',
    type: 'POST',
    data: {
      fileId: fileId,
      detailId: detailId,
    },
    success: function(fileSummery){
      $('#detailModalSuccessCount').text(fileSummery.success);
      $('#detailModalFailCount').text(fileSummery.fail);
    },
    error: function(){
      sweetAlert('Login needed', 'Can not get balances. Please re-login', "error", function (){
        window.location.href = g_siteUrl;
      });
    }
  });
}

function getFileDetails(fileId, autoStartCorrectBalance = false){

  let statusPending = '<span class="badge badge-info badge-pill"><span class="spinner-border spinner-border-sm text-primary" role="status"></span> Pending</span>';
  let statusFail = '<span class="badge badge-danger badge-pill"><i class="feather icon-x-circle"></i> Fail</span>';
  let statusFailRollback = '<span class="badge badge-warning badge-pill"><i class="feather icon-rotate-ccw"></i> Fail Rollback</span>';
  let statusSuccess = '<span class="badge badge-success badge-pill"><i class="feather icon-check-circle"></i> Success</span>';

  let detailTable = $('#file_detail');
  let detailModalTitle = $('#detailModalName');
  detailTable.html('');
  detailModalTitle.text('Balance correction details view');
  getFileSummery( fileId, null );
  $.ajax({
    url: g_siteUrl + '/upload/getFileDetails',
    type: 'POST',
    data: {
      fileId: fileId,
    },
    success: function(detailsList){
      // show details
      for( let i = 0; i < detailsList.length; i++ ){

        let status = '';
        let action = '';
        if( detailsList[i].result === 'fail' ) {
          action = '';/*'<button onclick="balanceCorrection('+ detailsList[i].id +')" type="button" class="btn btn-flat-warning waves-effect waves-light balCorBtn_'+ detailsList[i].id +'">\
                      <i class="feather icon-refresh-ccw"></i> Retry\
                    </button>';*/
          status = statusFail;
        }
        else if( detailsList[i].result === 'fail_rollback' ) {
          status = statusFail + statusFailRollback;
          action = '';/*'<button onclick="rollback(' + detailsList[i].id + ')" type="button" class="btn btn-flat-warning waves-effect waves-light balCorBtn_' + detailsList[i].id + '">\
                                        <i class="feather icon-rotate-ccw"></i> Retry Rollback\
                                      </button>';*/
        }
        else if( detailsList[i].result === 'success' ) {
          status = statusSuccess;
        }
        else if( detailsList[i].result === 'pending' ) {
          let disabled = '';
          if( autoStartCorrectBalance )
            disabled = ' disabled ';
          action = '';/*'<button '+ disabled +'onclick="balanceCorrection('+ detailsList[i].id +')" type="button" class="btn btn-flat-warning waves-effect waves-light balCorBtn_'+ detailsList[i].id +'">\
                      <i class="feather icon-refresh-ccw"></i> Retry\
                    </button>';*/
          status = statusPending;
        }

        let row = '<tr>\
        <td>'+ (i + 1) +'</td>\
        <td>'+ detailsList[i].user_id +'</td>\
        <td>'+ detailsList[i].amount +'</td>\
        <td>'+ detailsList[i].currency +'</td>\
        <td class="status_'+ detailsList[i].id +'">'+ status +'</td>\
        <td>'+ action + '</td>\
        <td>'+ (detailsList[i].reason == null ? '' : detailsList[i].reason) + '</td>\
        </tr>';
        let html = detailTable.html() + row;
        detailTable.html(html);
      }

      showModal('detailDialog');

      // start auto correct balance
      if( autoStartCorrectBalance) {
        let dlgCloseBtn = $('#detailDialog .closeBtn');
        dlgCloseBtn.attr('disabled', true);
        dlgCloseBtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Close');
        detailModalTitle.text('Balance correction started...');

        let correctBalanceForUser = function (){
          if( detailsList.length > 0 ){
            let i = 0;
            if( detailsList[i].result === 'pending' ) {
              $('#balCorBtn_'+ detailsList[i].id).attr('disabled', true);
              $.ajax({
                url: g_siteUrl + '/upload/balanceCorrection',
                type: 'POST',
                data: {
                  detailId: detailsList[i].id,
                },
                success: function (balanceCorrectionResult) {
                  let statusTd = $('.status_' + balanceCorrectionResult.id);
                  if (balanceCorrectionResult.result === 'success') {
                    statusTd.html(statusSuccess);
                    statusTd.next().html('');
                    statusTd.next().next().html('');
                  }
                  else if (balanceCorrectionResult.result === 'fail_rollback') {
                    statusTd.html(statusFail);
                    statusTd.append(statusFailRollback);
                    statusTd.next().html(''/*'<button onclick="rollback(' + balanceCorrectionResult.id + ')" type="button" class="btn btn-flat-warning waves-effect waves-light balCorBtn_' + balanceCorrectionResult.id + '">\
                                        <i class="feather icon-rotate-ccw"></i> Retry Rollback\
                                      </button>'*/);
                    statusTd.next().next().html(balanceCorrectionResult.reason);
                  }
                  else {
                    statusTd.html(statusFail);
                    statusTd.next().html(/*'<button onclick="balanceCorrection(' + balanceCorrectionResult.id + ')" type="button" class="btn btn-flat-warning waves-effect waves-light balCorBtn_' + balanceCorrectionResult.id + '">\
                                        <i class="feather icon-refresh-ccw"></i> Retry\
                                      </button>'*/);
                    statusTd.next().next().html(balanceCorrectionResult.reason);
                  }

                  detailsList.splice(i, 1);
                  correctBalanceForUser();
                },
                error: function (xhr, status, error) {
                  let statusTd = $('.status_' + detailsList[i].id);
                  statusTd.html(statusFail);
                  statusTd.next().html(''/*'<button onclick="balanceCorrection(' + detailsList[i].id + ')" type="button" class="btn btn-flat-warning waves-effect waves-light balCorBtn_' + detailsList[i].id + '">\
                                        <i class="feather icon-refresh-ccw"></i> Retry\
                                      </button>'*/);
                  statusTd.next().next().html(error);

                  detailsList.splice(i, 1);
                  correctBalanceForUser();
                }
              });
            }
          }
          else{
            correctBalanceForAgent();
          }
        };

        let correctBalanceForAgent = function(){
          // process agent balance
          $.ajax({
            url: g_siteUrl + '/upload/balanceCorrectionAgent',
            type: 'POST',
            data: {
              fileId: fileId,
            },
            success: function () {
              getFileSummery(fileId, null);
              dlgCloseBtn.removeAttr('disabled');
              dlgCloseBtn.html('Close');
              detailModalTitle.text('Balance correction has been completed!');
              g_fileDatatable.ajax.reload(null, false);
              getWalletBalance();
            },
            error: function () {
              getFileSummery(fileId, null);
              dlgCloseBtn.removeAttr('disabled');
              dlgCloseBtn.html('Close');
              detailModalTitle.text('Balance correction has been completed!');
              g_fileDatatable.ajax.reload(null, false);
              getWalletBalance();
            }
          });
        }

        correctBalanceForUser();
      }
    },
    error: function(){
      sweetAlert('Login needed', 'Can not get balances. Please re-login', "error", function (){
        window.location.href = g_siteUrl;
      });
    }
  });
}

function getWalletBalance(){
  $('.balanceUsdt-load').show();
  $('.balanceUsd-load').show();
  $.ajax({
    url: g_siteUrl + '/upload/getWalletBalance',
    type: 'POST',
    data: {
    },
    success: function(wallet){
      $('#balanceUsdt').text(wallet.USDT);
      $('#balance_usd').text(wallet.USD);
      $('.balanceUsdt-load').hide();
      $('.balanceUsd-load').hide();
      if( wallet.status !== 'success'){
        if( wallet.status === 'Unauthorized'){
          sweetAlert('Login needed', 'Can not get balances. Please re-login', "error", function (){
            window.location.href = g_siteUrl;
          });
        }
      }
    },
    error:function (){
      $('.balanceUsdt-load').hide();
      $('.balanceUsd-load').hide();
    }
  });
}

function balanceCorrection( balCorId ){
  let statusFailRollback = '<span class="badge badge-warning badge-pill"><i class="feather icon-rotate-ccw"></i> Fail Rollback</span>';
  let statusFail = '<span class="badge badge-danger badge-pill"><i class="feather icon-x-circle"></i> Fail</span>';
  let statusSuccess = '<span class="badge badge-success badge-pill"><i class="feather icon-check-circle"></i> Success</span>';

  let detailModalTitle = $('#detailModalName');
  let dlgCloseBtn = $('#detailDialog .closeBtn');
  let balCorBtn = $('.balCorBtn_' + balCorId);
  balCorBtn.attr('disabled', true);
  dlgCloseBtn.attr('disabled', true);
  dlgCloseBtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Close');
  detailModalTitle.text('Balance correction started...');

  $.ajax({
    url: g_siteUrl + '/upload/balanceCorrection',
    type: 'POST',
    data: {
      detailId: balCorId,
    },
    success: function (balanceCorrectionResult) {
      let statusTd = $('.status_' + balanceCorrectionResult.id);
      if( balanceCorrectionResult.result === 'success'){
        statusTd.html(statusSuccess);
        statusTd.next().html('');
      }
      else if( balanceCorrectionResult.result === 'fail_rollback' ) {
        statusTd.html(statusFail + statusFailRollback);
        statusTd.next().html('<button onclick="rollback(' + balanceCorrectionResult.id + ')" type="button" class="btn btn-flat-warning waves-effect waves-light balCorBtn_' + balanceCorrectionResult.id + '">\
                                        <i class="feather icon-rotate-ccw"></i> Retry Rollback\
                                      </button>');
      }
      else{
        statusTd.html(statusFail);
        statusTd.next().html('<button onclick="balanceCorrection('+ balanceCorrectionResult.id +')" type="button" class="btn btn-flat-warning waves-effect waves-light balCorBtn_'+ balanceCorrectionResult.id +'">\
                                        <i class="feather icon-refresh-ccw"></i> Retry\
                                      </button>');
      }

      dlgCloseBtn.removeAttr('disabled');
      dlgCloseBtn.html('Close');
      detailModalTitle.text('Balance correction has been finished!');
      g_fileDatatable.ajax.reload(null, false);

      getFileSummery( null, balCorId );
      getWalletBalance();
    },
    error: function(){
      let statusTd = $('.status_' + balCorId);
      statusTd.html(statusFail);
      statusTd.next().html('<button onclick="balanceCorrection('+ balCorId +')" type="button" class="btn btn-flat-warning waves-effect waves-light balCorBtn_'+ balCorId +'">\
                                        <i class="feather icon-refresh-ccw"></i> Retry\
                                      </button>');

      dlgCloseBtn.removeAttr('disabled');
      dlgCloseBtn.html('Close');
      detailModalTitle.text('Balance correction has been finished!');
      getWalletBalance();
    }
  });
}

function rollback( balCorId ){
  let statusFail = '<span class="badge badge-danger badge-pill"><i class="feather icon-x-circle"></i> Fail</span>';
  let statusFailRollback = '<span class="badge badge-warning badge-pill"><i class="feather icon-rotate-ccw"></i> Fail Rollback</span>';

  let detailModalTitle = $('#detailModalName');
  let dlgCloseBtn = $('#detailDialog .closeBtn');
  let balCorBtn = $('.balCorBtn_' + balCorId);
  balCorBtn.attr('disabled', true);
  dlgCloseBtn.attr('disabled', true);
  dlgCloseBtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Close');
  detailModalTitle.text('Retrying rollback...');

  $.ajax({
    url: g_siteUrl + '/upload/retryRollback',
    type: 'POST',
    data: {
      detailId: balCorId,
    },
    success: function( resp ){
      let statusTd = $('.status_' + balCorId);

      if( resp.result === 'success'){
        statusTd.html(statusFail);
        statusTd.next().html('<button onclick="balanceCorrection('+ balCorId +')" type="button" class="btn btn-flat-warning waves-effect waves-light balCorBtn_'+ balCorId +'">\
                                        <i class="feather icon-refresh-ccw"></i> Retry\
                                      </button>');
        g_fileDatatable.ajax.reload(null, false);
        getFileSummery( null, balCorId );
        getWalletBalance();
      }
      else{
        balCorBtn.removeAttr('disabled');
      }

      dlgCloseBtn.removeAttr('disabled');
      dlgCloseBtn.html('Close');
      detailModalTitle.text('Retrying rollback has been finished!');
    },
    error:function (){
      balCorBtn.removeAttr('disabled');
      dlgCloseBtn.removeAttr('disabled');
      dlgCloseBtn.html('Close');
      detailModalTitle.text('Retrying rollback has been finished!');
    }
  });
}

function showModal( modalId ){
  $('#do_modal_' + modalId).trigger('click');
}

function closeModal( modalId ){
  $("#" + modalId + " .close").trigger('click');
}

function sweetAlert(title, msg, type="error", cb = null){
  Swal.fire({
    title: title,
    text: msg,
    type: type,
    confirmButtonClass: 'btn btn-primary',
    buttonsStyling: false,
    allowOutsideClick: false,
  }).then(function (result) {
    if (result.value) {
      if( cb )
        cb.call();
    }
  });
}
