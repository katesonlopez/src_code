<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
  function getallheaders()
  {
    if (!is_array($_SERVER)) {
      return array();
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
      if (substr($name, 0, 5) == 'HTTP_') {
        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
      }
    }
    return $headers;
  }
}

function _log($email, $line) {
  if ($email == "") {
    $fh2 = fopen(dirname(__FILE__) . "/log/update_profile.log" , 'a');
  } else {
    $fh2 = fopen(dirname(__FILE__) . "/log/" . $email . ".log" , 'a');
  }
  $fline = date('[Ymd H:i:s] ') . $line."\n";
  fwrite($fh2, $fline);
  fclose($fh2);
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_once '../include/dbconfig.php';
  $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
  if (mysqli_connect_errno() != 0) {
    header('Content-Type: application/json');
    http_response_code(500);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
    echo json_encode($ret_rs);
    die();
  } else {
    _log("", "ket noi thanh cong");
    mysqli_query($dbhandle, "set names utf8;");
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
  $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
  $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
  $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
  $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret4 = 'climbpot api access key';
  $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
  $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
  $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
  $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
  $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
  $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
  $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
  $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
  $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
  $apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
  $found = 0;
  $coin = 'USDT';
  $sandbox = 0;
  $partner = "";
  $allowed_deposit_currency_arr = array('USDT');
  $req_api_key = "";
  $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

  foreach (getallheaders() as $name => $value) {
    if ($name == 'Authorization') {
      $req_api_key = trim($value);
      $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
      $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
      if (mysqli_num_rows($partner_rs) > 0) {
        while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
          $cur_api_key = "Bearer " . $row_partner['api_key'];
          if ($req_api_key == $cur_api_key) {
            $req_partner['partner'] = trim($row_partner['partner']);
            $req_partner['api_key'] = trim($row_partner['api_key']);
            $req_partner['website'] = trim($row_partner['website']);
            $selected_api_key = $req_api_key;
            break;
          }
        }
      } else {
        _log("", "not found in db");
      }
    }
  }

  function generateRandomString($length, $bitmask) {
    $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $lowercase = 'abcdefghijklmnopqrstuvwxyz';
    $numbers = '0123456789';
    $characters = '';
    $characters .= $uppercase . $lowercase . $numbers;
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
      $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
  }

  function validateDate($date, $format = 'Y-m-d'){
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
  }

  function isValidPassword($password) {
    if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
      return FALSE;
    return TRUE;
  }

  if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!($data)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          _log("", 'Reached the maximum stack depth');
          break;
        case JSON_ERROR_STATE_MISMATCH:
          _log("", 'Incorrect discharges or mismatch mode');
          break;
        case JSON_ERROR_CTRL_CHAR:
          _log("", 'Incorrect control character');
          break;
        case JSON_ERROR_SYNTAX:
          _log("", 'Syntax error or JSON invalid');
          break;
        case JSON_ERROR_UTF8:
          _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
          break;
        default:
          _log("", 'Unknown error');
          break;
      }

      _log("", 'A non-empty request body is required.');
      header('Content-Type: application/json');
      http_response_code(400);
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
      echo json_encode($ret_rs);
      die();
    } else {
      unset($errors);
      $errors = array();

      //email_address
      if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
        $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
        $errors[] = $error_obj;
      } else {
        $email_address = mysqli_real_escape_string($dbhandle, trim($data['email_address']));
      }
      //auth_token
      if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
        $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
        $errors[] = $error_obj;
      } else {
        $private_key = mysqli_real_escape_string($dbhandle, trim($data['auth_token']));
      }

      $sql_check_jdb_profile = "SELECT 
          gender,
          name_romaji,
          marriage_status,
          occupation,
          nationality,
          date_of_birth,
          id_card_type,
          id_card_number,
          id_card_issued_dt,
          id_card_expired_dt,
          id_card_issuer,
          residence_address,
          district,
          province,
          postal_code,
          country,
          cellphone_country_code,
          cellphone_number,
          name_on_card
        FROM cryptocash_jdb_profile 
        WHERE email_address = '$email_address' 
          AND created_from='" . $req_partner['partner'] . "'";
      $rs_check_jdb_profile = mysqli_query($dbhandle, $sql_check_jdb_profile);
      if (mysqli_num_rows($rs_check_jdb_profile) == 0) {
        $profile_title = 0;
        $profile_id_number = '';
        $profile_id_issued_date = '';
        $profile_id_expiration_date = '';
        $profile_name = '';
        $profile_marriage_status = 0;
        $profile_occupation = '';
        $profile_nationality = '';
        $profile_birthday = '1900-01-01';
        $profile_id_type = '';
        $profile_id_number = '';
        $profile_id_issued_date = '1900-01-01';
        $profile_id_expiration_date = '1900-01-01';
        $profile_id_issuer = '';
        $profile_address = '';
        $profile_city = '';
        $profile_prefecture = '';
        $profile_postal_code = '';
        $profile_country = '';
        $profile_cellphone_country_code = '';
        $profile_cellphone_number = '';
        $profile_name_on_card = '';
      } else {
        while ($row_jdb_profile = mysqli_fetch_array($rs_check_jdb_profile, MYSQLI_ASSOC)) {
          $profile_title = intval($row_jdb_profile['gender']);
          $profile_name = trim($row_jdb_profile['name_romaji']);
          $profile_marriage_status = intval($row_jdb_profile['marriage_status']);
          $profile_occupation = trim($row_jdb_profile['occupation']);
          $profile_nationality = trim($row_jdb_profile['nationality']);
          $profile_birthday = $row_jdb_profile['date_of_birth'];
          $profile_id_type = trim($row_jdb_profile['id_card_type']);
          $profile_id_number = trim($row_jdb_profile['id_card_number']);
          $profile_id_issued_date = $row_jdb_profile['id_card_issued_dt'];
          $profile_id_expiration_date = $row_jdb_profile['id_card_expired_dt'];
          $profile_id_issuer = trim($row_jdb_profile['id_card_issuer']);
          $profile_address = trim($row_jdb_profile['residence_address']);
          $profile_city = trim($row_jdb_profile['district']);
          $profile_prefecture = trim($row_jdb_profile['province']);
          $profile_postal_code = trim($row_jdb_profile['postal_code']);
          $profile_country = trim($row_jdb_profile['country']);
          $profile_cellphone_country_code = trim($row_jdb_profile['cellphone_country_code']);
          $profile_cellphone_number = trim($row_jdb_profile['cellphone_number']);
          $profile_name_on_card = trim($row_jdb_profile['name_on_card']);
        }
      }

      $sql_check_jdb_debit_card = "SELECT 
            card_provider,
            acc_no,
            debit_card_num,
            card_design 
        FROM cryptocash_jdb_debit_card 
        WHERE email_address = '$email_address' 
          AND created_from='" . $req_partner['partner'] . "'";
      $rs_check_jdb_debit_card = mysqli_query($dbhandle, $sql_check_jdb_debit_card);
      if (mysqli_num_rows($rs_check_jdb_debit_card) == 0) {
        $debit_card_provider = '';
        $debit_account_number = '';
        $debit_card_number = '';
        $debit_card_design = '';
      } else {
        while ($row_jdb_debit_card = mysqli_fetch_array($rs_check_jdb_debit_card, MYSQLI_ASSOC)) {
          $debit_card_provider = trim($row_jdb_debit_card['card_provider']);
          $debit_account_number = trim($row_jdb_debit_card['acc_no']);
          $debit_card_number = trim($row_jdb_debit_card['debit_card_num']);
          $debit_card_design = trim($row_jdb_debit_card['card_design']);
        }
      }

      $sql_check_users_profile = "SELECT 
            given_name, 
            middle_name, 
            sur_name 
        FROM cryptocash_users_profile 
        WHERE email = '$email_address' 
          AND created_from='" . $req_partner['partner'] . "'";
      $rs_check_users_profile = mysqli_query($dbhandle, $sql_check_users_profile);
      if (mysqli_num_rows($rs_check_users_profile) == 0) {
        $users_profile_given_name = '';
        $users_profile_middle_name = '';
        $users_profile_sur_name = '';
      } else {
        while ($row_users_profile = mysqli_fetch_array($rs_check_users_profile, MYSQLI_ASSOC)) {
          $users_profile_given_name = trim($row_users_profile['given_name']);
          $users_profile_middle_name = trim($row_users_profile['middle_name']);
          $users_profile_sur_name = trim($row_users_profile['sur_name']);
        }
      }

      //title
      if ((!isset($data['profile']['title'])) || (empty($data['profile']['title']))) {
      } else {
        $profile_title = mysqli_real_escape_string($dbhandle, trim($data['profile']['title']));
      }

      //name (given_name)
      if ((!isset($data['profile']['given_name'])) || (empty($data['profile']['given_name']))) {
      } else {
        $users_profile_given_name = mysqli_real_escape_string($dbhandle, trim($data['profile']['given_name']));
      }

      //name (middle_name)
      if ((!isset($data['profile']['middle_name'])) || (empty($data['profile']['middle_name']))) {
      } else {
        $users_profile_middle_name = mysqli_real_escape_string($dbhandle, trim($data['profile']['middle_name']));
      }

      //name (sur_name)
      if ((!isset($data['profile']['sur_name'])) || (empty($data['profile']['sur_name']))) {
      } else {
        $users_profile_sur_name = mysqli_real_escape_string($dbhandle, trim($data['profile']['sur_name']));
      }

      //name (full name)
      if ((!isset($data['profile']['name'])) || (empty($data['profile']['name']))) {
      } else {
        $profile_name = mysqli_real_escape_string($dbhandle, trim($data['profile']['name']));
      }

      //marriage_status
      if ((!isset($data['profile']['marriage_status'])) || (empty($data['profile']['marriage_status']))) {
      } else {
        $profile_marriage_status = mysqli_real_escape_string($dbhandle, trim($data['profile']['marriage_status']));
      }

      //occupation
      if ((!isset($data['profile']['occupation'])) || (empty($data['profile']['occupation']))) {
      } else {
        $profile_occupation = mysqli_real_escape_string($dbhandle, trim($data['profile']['occupation']));
      }

      //nationality
      if ((!isset($data['profile']['nationality'])) || (empty($data['profile']['nationality']))) {
      } else {
        $profile_nationality = mysqli_real_escape_string($dbhandle, trim($data['profile']['nationality']));
      }

      //birthday
      if ((!isset($data['profile']['birthday'])) || (empty($data['profile']['birthday']))) {
      } else {
        if (strpos($data['profile']['birthday'], "/") !== false) {
          $data['profile']['birthday'] = str_replace("/", "-", $data['profile']['birthday']);
        }
        if (!validateDate($data['profile']['birthday'])) {
          if (!validateDate($data['profile']['birthday'], 'Y-n-j')) {
            $error_obj = array('errorCode' => 23, 'errorMessage' => "invalid date format of profile.birthday. Only accept 'YYYY/MM/DD' or 'YYYY-MM-DD'");
            $errors[] = $error_obj;
          }
        }
        $profile_birthday = mysqli_real_escape_string($dbhandle, trim($data['profile']['birthday']));
      }

      //id_type
      if ((!isset($data['profile']['id_type'])) || (empty($data['profile']['id_type']))) {
        if ($profile_id_type == "passport") {
          $data['profile']['id_type'] = 1;
        } else if ($profile_id_type == "driving_license") {
          $data['profile']['id_type'] = 2;
        } else {
          $data['profile']['id_type'] = 0;
        }
      } else {
        if (intval($data['profile']['id_type'])==1) {
          $db_id_type = "passport";
        } else if (intval($data['profile']['id_type'])==2) {
          $db_id_type = "driving_license";
        } else {
          $error_obj = array('errorCode' => 22, 'errorMessage' => 'unsupported profile.id_type. Only accept "1" (for passport), or "2" (for ID card, driving license)');
          $errors[] = $error_obj;
        }
        $profile_id_type = trim($db_id_type);
      }

      //id_number
      if ((!isset($data['profile']['id_number'])) || (empty($data['profile']['id_number']))) {
      } else {
        $profile_id_number =  mysqli_real_escape_string($dbhandle, trim($data['profile']['id_number']));
      }

      //id_issued_date
      if ((!isset($data['profile']['id_issued_date'])) || (empty($data['profile']['id_issued_date']))) {
      } else {
        if (strpos($data['profile']['id_issued_date'], "/") !== false) {
          $data['profile']['id_issued_date'] = str_replace("/", "-", $data['profile']['id_issued_date']);
        }
        if (!validateDate($data['profile']['id_issued_date'])) {
          if (!validateDate($data['profile']['id_issued_date'], 'Y-n-j')) {
            $error_obj = array('errorCode' => 24, 'errorMessage' => "invalid date format of profile.id_issued_date. Only accept 'YYYY/MM/DD' or 'YYYY-MM-DD'");
            $errors[] = $error_obj;
          }
        }
        $profile_id_issued_date = mysqli_real_escape_string($dbhandle, trim($data['profile']['id_issued_date']));
      }

      //id_expiration_date
      if ((!isset($data['profile']['id_expiration_date'])) || (empty($data['profile']['id_expiration_date']))) {
      } else {
        if (strpos($data['profile']['id_expiration_date'], "/") !== false) {
          $data['profile']['id_expiration_date'] = str_replace("/", "-", $data['profile']['id_expiration_date']);
        }
        if (!validateDate($data['profile']['id_expiration_date'])) {
          if (!validateDate($data['profile']['id_expiration_date'], 'Y-n-j')) {
            $error_obj = array('errorCode' => 24, 'errorMessage' => "invalid date format of profile.id_expiration_date. Only accept 'YYYY/MM/DD' or 'YYYY-MM-DD'");
            $errors[] = $error_obj;
          }
        }
        $profile_id_expiration_date = mysqli_real_escape_string($dbhandle, trim($data['profile']['id_expiration_date']));
      }

      //id_issuer
      if ((!isset($data['profile']['id_issuer'])) || (empty($data['profile']['id_issuer']))) {
      } else {
        $profile_id_issuer = mysqli_real_escape_string($dbhandle, trim($data['profile']['id_issuer']));
      }

      //address
      if ((!isset($data['profile']['address'])) || (empty($data['profile']['address']))) {
      } else {
        $profile_address = mysqli_real_escape_string($dbhandle, trim($data['profile']['address']));
      }

      //city
      if ((!isset($data['profile']['city'])) || (empty($data['profile']['city']))) {
      } else {
        $profile_city = mysqli_real_escape_string($dbhandle, trim($data['profile']['city']));
      }

      //prefecture
      if ((!isset($data['profile']['prefecture'])) || (empty($data['profile']['prefecture']))) {
      } else {
        $profile_prefecture = mysqli_real_escape_string($dbhandle, trim($data['profile']['prefecture']));
      }

      //postal_code
      if ((!isset($data['profile']['postal_code'])) || (empty($data['profile']['postal_code']))) {
      } else {
        $profile_postal_code = mysqli_real_escape_string($dbhandle, trim($data['profile']['postal_code']));
      }

      //country
      if ((!isset($data['profile']['country'])) || (empty($data['profile']['country']))) {
      } else {
        $profile_country = mysqli_real_escape_string($dbhandle, trim($data['profile']['country']));
      }

      //cellphone_country_code
      if ((!isset($data['profile']['cellphone_country_code'])) || (empty($data['profile']['cellphone_country_code']))) {
      } else {
        $profile_cellphone_country_code = mysqli_real_escape_string($dbhandle, trim($data['profile']['cellphone_country_code']));
      }

      //cellphone_number
      if ((!isset($data['profile']['cellphone_number'])) || (empty($data['profile']['cellphone_number']))) {
      } else {
        $profile_cellphone_number = mysqli_real_escape_string($dbhandle, trim($data['profile']['cellphone_number']));
      }

      //name_on_card
      if ((!isset($data['profile']['name_on_card'])) || (empty($data['profile']['name_on_card']))) {
      } else {
        $profile_name_on_card = mysqli_real_escape_string($dbhandle, strtoupper(trim($data['profile']['name_on_card'])));
      }

      //card_provider
      if ((!isset($data['profile']['card_provider'])) || (empty($data['profile']['card_provider']))) {
        if ($debit_card_provider == "visa") {
          $data['profile']['card_provider'] = 1;
        } else if ($debit_card_provider == "unionpay") {
          $data['profile']['card_provider'] = 2;
        } else {
          $data['profile']['card_provider'] = 0;
        }
      } else {
        if (intval($data['profile']['card_provider'])==1) {
          $debit_card_provider = "visa";
        } else if (intval($data['profile']['card_provider'])==2) {
          $debit_card_provider = "unionpay";
        } else {
          $error_obj = array('errorCode' => 22, 'errorMessage' => 'unsupported profile.card_provider. Only accept "1" (for visa), or "2" (for unionpay)');
          $errors[] = $error_obj;
        }
      }

      //account_number
      if ((!isset($data['profile']['account_number'])) || (empty($data['profile']['account_number']))) {
      } else {
        $debit_account_number = mysqli_real_escape_string($dbhandle, trim($data['profile']['account_number']));
      }

      //card_number
      if ((!isset($data['profile']['card_number'])) || (empty($data['profile']['card_number']))) {
      } else {
        $debit_card_number = mysqli_real_escape_string($dbhandle, trim($data['profile']['card_number']));
      }

      //card_design
      if ((!isset($data['profile']['card_design'])) || (empty($data['profile']['card_design']))) {
        $debit_card_design = mysqli_real_escape_string($dbhandle, $req_partner['partner']);
      } else {
        $debit_card_design = mysqli_real_escape_string($dbhandle, trim($data['profile']['card_design']));
      }

      if (count($errors) == 0) {
        $errors_sub = array();
        require_once '../include/common.php';
        _log($email_address, "update profile started...");
        $allow_access_api = 0;
        $my_db_private_key = '';
        $my_db_auth_token = '';
        $my_db_wallet_auth_token = '';
        $my_db_sigin_dt = '';
        $my_db_token_refresh_dt = '';
        $my_db_shift_user_id = '';
        $my_db_shift_client_user_id = '';
        $sql_check_signin = "select 
            a.*, b.shift_user_id, b.shift_client_user_id 
          from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b 
          where a.email_address = '$email_address' 
            AND a.merchant='" . $req_partner['partner'] . "' 
            AND a.email_address = b.shift_email_address";
        $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
        if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
          $allow_access_api = 1;
          while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
            $my_db_auth_token = trim($row_signin['auth_token']);
            $my_db_wallet_auth_token = trim($row_signin['wallet_auth_token']);
            $my_db_sigin_dt = $row_signin['signin_dt'];
            $my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
            $my_db_private_key = trim($row_signin['private_key']);
            $my_db_shift_user_id = trim($row_signin['shift_user_id']);
            $my_db_shift_client_user_id = trim($row_signin['shift_client_user_id']);
          }
        }

        if ($allow_access_api == 1) {
          if ($private_key != $my_db_private_key) {
            @mysqli_close($dbhandle);
            header('Content-Type: application/json');
            http_response_code(500);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 26, 'errorMessage' => 'Unauthorized.');
            echo json_encode($ret_rs);
            die();
          } else {
            $unique_pid = '';
            $sql_check_jdb_profile = "SELECT 
                status, profile_id 
              FROM cryptocash_jdb_profile 
              WHERE email_address = '$email_address' 
                AND created_from='" . $req_partner['partner'] . "'";
            $rs_check_jdb_profile = mysqli_query($dbhandle, $sql_check_jdb_profile);
            if (mysqli_num_rows($rs_check_jdb_profile) == 0) { //add new
              _log($email_address, "try add profile...");
              $unique_pid = generateRandomString(20, 0);
              $added_dt = date('Y-m-d H:i:s');
              $sql_add_jdb_profile = "INSERT INTO 
                `cryptocash_jdb_profile` 
                    (`profile_id`,
                     `gender`,
                     `name_kanji_kana`,
                     `name_romaji`,
                     `marriage_status`,
                     `occupation`,
                     `country`,
                     `nationality`,
                     `date_of_birth`,
                     `place_of_birth`,
                     `id_card_number`,
                     `id_card_issued_dt`,
                     `id_card_expired_dt`,
                     `id_card_issuer`,
                     `id_card_type`,
                     `residence_address`,
                     `district`,
                     `province`,
                     `postal_code`,
                     `home_telephone_country_code`,
                     `home_telephone_number`,
                     `cellphone_country_code`,
                     `cellphone_number`,
                     `consent_name`,
                     `email_address`,
                     `added_dt`,
                     `application_deny_message`,
                     `name_on_card`,
                     `created_from`) 
                  VALUES 
                      ('$unique_pid',
                       '$profile_title',
                       '',
                       '$profile_name',
                       '$profile_marriage_status',
                       '$profile_occupation',
                       '$profile_country',
                       '$profile_nationality',
                       '$profile_birthday',
                       '$profile_id_issuer',
                       '$profile_id_number',
                       '$profile_id_issued_date',
                       '$profile_id_expiration_date',
                       '$profile_id_issuer',
                       '$profile_id_type',
                       '$profile_address',
                       '$profile_city',
                       '$profile_prefecture',
                       '$profile_postal_code',
                       '',
                       '',
                       '$profile_cellphone_country_code',
                       '$profile_cellphone_number',
                       '',
                       '$email_address',
                       '$added_dt',
                       '',
                       '$profile_name_on_card',
                       '" . $req_partner['partner'] . "')";
              mysqli_query($dbhandle, $sql_add_jdb_profile);
              if (mysqli_affected_rows($dbhandle) > 0) {
                $debit_card_created_dt = date('Y-m-d H:i:s');
                $sql_add_debit_card = "INSERT INTO 
                    cryptocash_jdb_debit_card 
                        (profile_id,
                         email_address,
                         created_dt,
                         updated_dt,
                         acc_no,
                         debit_card_num,
                         card_design,
                         card_provider,
                         created_from) 
                    VALUES 
                         ('$unique_pid',
                          '$email_address',
                          '$debit_card_created_dt',
                          '$debit_card_created_dt',
                          '$debit_account_number',
                          '$debit_card_number',
                          '$debit_card_design',
                          '$debit_card_provider',
                          '" . $req_partner['partner'] . "')";
                mysqli_query($dbhandle, $sql_add_debit_card);
                if (mysqli_affected_rows($dbhandle) > 0) {
                  $shift_full_name = $users_profile_given_name . " " . $users_profile_sur_name;
                  $update_shift_profile_sql = "UPDATE 
                        cryptocash_users_profile 
                    SET 
                        shift_update_dt='$added_dt',
                        given_name='$users_profile_given_name',
                        middle_name='$users_profile_middle_name',
                        sur_name='$users_profile_sur_name',
                        shift_full_name='$shift_full_name',
                        `country` = '$profile_country' 
                    WHERE email='$email_address' 
                      AND created_from='" . $req_partner['partner'] . "' LIMIT 1";
                  mysqli_query($dbhandle, $update_shift_profile_sql);
                  @mysqli_close($dbhandle);
                  header('Content-Type: application/json');
                  $ret_rs['result'] = 'success';
                  $ret_profile_arr = array();
                  $ret_profile_arr['email_address'] = $email_address;
                  $ret_profile_arr['title'] = $profile_title;
                  $ret_profile_arr['given_name'] = $users_profile_given_name;
                  $ret_profile_arr['middle_name'] = $users_profile_middle_name;
                  $ret_profile_arr['sur_name'] = $users_profile_sur_name;
                  $ret_profile_arr['name'] = $profile_name;
                  $ret_profile_arr['marriage_status'] = $profile_marriage_status;
                  $ret_profile_arr['occupation'] = $profile_occupation;
                  $ret_profile_arr['nationality'] = $profile_nationality;
                  $ret_profile_arr['birthday'] = $profile_birthday;
                  $ret_profile_arr['id_type'] = $data['profile']['id_type'];
                  $ret_profile_arr['id_number'] = $profile_id_number;
                  $ret_profile_arr['id_issued_date'] = $profile_id_issued_date;
                  $ret_profile_arr['id_expiration_date'] = $profile_id_expiration_date;
                  $ret_profile_arr['id_issuer'] = $profile_id_issuer;
                  $ret_profile_arr['address'] = $profile_address;
                  $ret_profile_arr['city'] = $profile_city;
                  $ret_profile_arr['prefecture'] = $profile_prefecture;
                  $ret_profile_arr['postal_code'] = $profile_postal_code;
                  $ret_profile_arr['country'] = $profile_country;
                  $ret_profile_arr['profile_cellphone_country_code'] = $profile_cellphone_country_code;
                  $ret_profile_arr['cellphone_number'] = $profile_cellphone_number;
                  $ret_profile_arr['name_on_card'] = $profile_name_on_card;
                  $ret_profile_arr['card_provider'] = $data['profile']['card_provider'];
                  $ret_profile_arr['account_number'] = $debit_account_number;
                  $ret_profile_arr['card_number'] = $debit_card_number;
                  $ret_profile_arr['card_design'] = $debit_card_design;
                  $ret_rs['updateProfileResponse'] = $ret_profile_arr;
                  echo json_encode($ret_rs);
                  die();
                } else {
                  _log($email_address, "FAILED : " . $sql_add_debit_card);
                  _log($email_address, ":: insert to jdb_debit_card FAILED:: " . $sql_add_debit_card);
                }
              } else {
                _log($email_address, ":: insert to jdb_profile FAILED:: " . $sql_add_jdb_profile);
                $data['msg'] = 'proc_ng2';
                $data['msg_ex'] = 'Profile update failed. Please contact administrator for help.';
              }
            } else { //update it
              _log($email_address, "try update profile...");
              $profile_status = -1;
              $update_dt = date('Y-m-d H:i:s');
              while ($row_jdb_profile = mysqli_fetch_array($rs_check_jdb_profile, MYSQLI_ASSOC)) {
                $unique_pid = trim($row_jdb_profile['profile_id']);
                $profile_status = intval($row_jdb_profile['status']);
              }
              if ($unique_pid != '') {
                $sql_update_jdb_profile = "UPDATE 
                        `cryptocash_jdb_profile` 
                    SET 
                        `gender` = '$profile_title',
                        `name_romaji` = '$profile_name',
                        `marriage_status` = '$profile_marriage_status',
                        `occupation` = '$profile_occupation',
                        `country` = '$profile_country',
                        `nationality` = '$profile_nationality',
                        `date_of_birth` = '$profile_birthday',
                        `place_of_birth` = '$profile_id_issuer',
                        `id_card_number` = '$profile_id_number',
                        `id_card_issued_dt` = '$profile_id_issued_date',
                        `id_card_expired_dt` = '$profile_id_expiration_date',
                        `id_card_issuer` = '$profile_id_issuer',
                        `id_card_type` = '$profile_id_type',
                        `residence_address` = '$profile_address',
                        `district` = '$profile_city',
                        `province` = '$profile_prefecture',
                        `postal_code` = '$profile_postal_code',
                        `cellphone_country_code` = '$profile_cellphone_country_code',
                        `cellphone_number` = '$profile_cellphone_number',
                        `update_dt` = '$update_dt',
                        `name_on_card` = '$profile_name_on_card'  
                    WHERE `profile_id` = '$unique_pid' 
                      AND created_from='" . $req_partner['partner'] . "'";
                if (mysqli_query($dbhandle, $sql_update_jdb_profile)) {
                  $sql_update_debit_card = "UPDATE 
                        cryptocash_jdb_debit_card 
                    SET 
                        `acc_no` = '$debit_account_number',
                        `debit_card_num` = '$debit_card_number',
                        `card_design` = '$debit_card_design',
                        `card_provider` = '$debit_card_provider' 
                    WHERE `profile_id` = '$unique_pid' 
                      AND created_from='" . $req_partner['partner'] . "'";
                  mysqli_query($dbhandle, $sql_update_debit_card);
                  if (mysqli_query($dbhandle, $sql_update_debit_card)) {
                    $shift_full_name = $users_profile_given_name . " " . $users_profile_sur_name;
                    $update_shift_profile_sql = "UPDATE 
                            cryptocash_users_profile 
                        SET 
                            shift_update_dt='$update_dt',
                            kyc_upload_dt = NULL,
                            given_name='$users_profile_given_name',
                            middle_name='$users_profile_middle_name',
                            sur_name='$users_profile_sur_name',
                            shift_full_name='$shift_full_name',
                            `country` = '$profile_country' 
                        WHERE email='$email_address' LIMIT 1";
                    mysqli_query($dbhandle, $update_shift_profile_sql);
                    @mysqli_close($dbhandle);
                    header('Content-Type: application/json');
                    $ret_rs['result'] = 'success';
                    $ret_profile_arr = array();
                    $ret_profile_arr['email_address'] = $email_address;
                    $ret_profile_arr['title'] = $profile_title;
                    $ret_profile_arr['given_name'] = $users_profile_given_name;
                    $ret_profile_arr['middle_name'] = $users_profile_middle_name;
                    $ret_profile_arr['sur_name'] = $users_profile_sur_name;
                    $ret_profile_arr['name'] = $profile_name;
                    $ret_profile_arr['marriage_status'] = $profile_marriage_status;
                    $ret_profile_arr['occupation'] = $profile_occupation;
                    $ret_profile_arr['nationality'] = $profile_nationality;
                    $ret_profile_arr['birthday'] = $profile_birthday;
                    $ret_profile_arr['id_type'] = $data['profile']['id_type'];
                    $ret_profile_arr['id_number'] = $profile_id_number;
                    $ret_profile_arr['id_issued_date'] = $profile_id_issued_date;
                    $ret_profile_arr['id_expiration_date'] = $profile_id_expiration_date;
                    $ret_profile_arr['id_issuer'] = $profile_id_issuer;
                    $ret_profile_arr['address'] = $profile_address;
                    $ret_profile_arr['city'] = $profile_city;
                    $ret_profile_arr['prefecture'] = $profile_prefecture;
                    $ret_profile_arr['postal_code'] = $profile_postal_code;
                    $ret_profile_arr['country'] = $profile_country;
                    $ret_profile_arr['profile_cellphone_country_code'] = $profile_cellphone_country_code;
                    $ret_profile_arr['cellphone_number'] = $profile_cellphone_number;
                    $ret_profile_arr['name_on_card'] = $profile_name_on_card;
                    $ret_profile_arr['card_provider'] = $data['profile']['card_provider'];
                    $ret_profile_arr['account_number'] = $debit_account_number;
                    $ret_profile_arr['card_number'] = $debit_card_number;
                    $ret_profile_arr['card_design'] = $debit_card_design;
                    $ret_rs['updateProfileResponse'] = $ret_profile_arr;
                    echo json_encode($ret_rs);
                    die();
                  } else {
                    _log($email_address, "FAILED : " . $sql_update_debit_card);
                    _log($email_address, ":: update to jdb_debit_card FAILED:: " . $sql_update_debit_card);
                  }
                } else {
                  _log($email_address, "update failed :: " . $sql_update_jdb_profile);
                  @mysqli_close($dbhandle);
                  header('Content-Type: application/json');
                  http_response_code(500);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'error occurred. please contact administrator for help.');
                  echo json_encode($ret_rs);
                  die();
                }
              } else  {
                _log($email_address, "unique_pid is null");
                @mysqli_close($dbhandle);
                header('Content-Type: application/json');
                http_response_code(500);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'error occurred. please contact administrator for help.');
                echo json_encode($ret_rs);
                die();
              }
            }
          }
        } else {
          @mysqli_close($dbhandle);
          header('Content-Type: application/json');
          http_response_code(500);
          $ret_rs['result'] = 'failed';
          $ret_rs['error'] = array('errorCode' => 27, 'errorMessage' => 'you must sign in to use this API.');
          echo json_encode($ret_rs);
          die();
        }
      } else {
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = $errors;
        header('Content-Type: application/json');
        echo json_encode($ret_rs);
        die();
      }
    }
  } else {
    header('HTTP/1.0 403 Forbidden');
  }
} else {
  http_response_code(405);
  die();
}
?>
