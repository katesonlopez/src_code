<?php

require_once("../include/cognito.php");
require_once("../include/graphQL_api.php");

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
  function getallheaders(): array
  {
    if (!is_array($_SERVER)) {
      return array();
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
      if (str_starts_with($name, 'HTTP_')) {
        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
      }
    }
    return $headers;
  }
}

function _log($email, $line): void
{
  if ($email == "") {
    $fh2 = fopen(dirname(__FILE__) . "/log/debug.log" , 'a');
  } else {
    $fh2 = fopen(dirname(__FILE__) . "/log/" . $email . ".log" , 'a');
  }
  $fline = date('[Ymd H:i:s] ') . $line."\n";
  fwrite($fh2, $fline);
  fclose($fh2);
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_once '../include/dbconfig.php';
  $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
  if (mysqli_connect_errno() != 0) {
	_log("", "ket noi that bai roi");
    header('Content-Type: application/json');
    http_response_code(500);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
    echo json_encode($ret_rs);
    die();
  } else {
    _log("", "ket noi thanh cong");
    mysqli_query($dbhandle, "set names utf8;");
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
  $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
  $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
  $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
  $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret4 = 'climbpot api access key';
  $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
  $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
  $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
  $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
  $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
  $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
  $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
  $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
  $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
  $found = 0;
  $coin = 'USDT';
  $sandbox = 0;
  $partner = "";
  $req_api_key = "";
  $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

  foreach (getAllHeaders() as $name => $value) {
    if ($name == 'Authorization') {
      $req_api_key = trim($value);
      $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
      $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
      if (mysqli_num_rows($partner_rs) > 0) {
        while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
          $cur_api_key = "Bearer " . $row_partner['api_key'];
          $supported_partners[] = strtoupper(trim($row_partner['partner']));
          if ($req_api_key == $cur_api_key) {
            $req_partner['partner'] = trim($row_partner['partner']);
            $req_partner['api_key'] = trim($row_partner['api_key']);
            $req_partner['website'] = trim($row_partner['website']);
            $selected_api_key = $req_api_key;
          }
        }
      } else {
        _log("", "not found in db");
      }
    }
  }
  @mysqli_close($dbhandle);

  function isValidPassword($password): bool
  {
    if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
      return FALSE;
    return TRUE;
  }

  function generateRandomString($length): string
  {
    $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $lowercase = 'abcdefghijklmnopqrstuvwxyz';
    $numbers = '0123456789';
    $special  = '_.-';
    $characters = '';
    $characters .= $uppercase . $lowercase . $numbers . $special;
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
      $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
  }

  //old code here...
  _log("", 'agent-tool-test@ruru.be: '.json_encode($req_partner));
  if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!($data)) {
      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          _log("", 'Reached the maximum stack depth');
          break;
        case JSON_ERROR_STATE_MISMATCH:
          _log("", 'Incorrect discharges or mismatch mode');
          break;
        case JSON_ERROR_CTRL_CHAR:
          _log("", 'Incorrect control character');
          break;
        case JSON_ERROR_SYNTAX:
          _log("", 'Syntax error or JSON invalid');
          break;
        case JSON_ERROR_UTF8:
          _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
          break;
        default:
          _log("", 'Unknown error');
          break;
      }

      _log("", 'A non-empty request body is required.');
      header('Content-Type: application/json');
      http_response_code(400);
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
      echo json_encode($ret_rs);
      die();

    } else {
      unset($errors);
      $errors = array();

      //email
      if (empty($data['email_address'])) {
        $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
        $errors[] = $error_obj;
      }

      //password
      if (empty($data['password'])) {
        $error_obj = array('errorCode' => 3, 'errorMessage' => 'password parameter is required.');
        $errors[] = $error_obj;
      }

      // user_check
      $reg_user_check = trim($data['user_check'] ?? '');
      if ($reg_user_check == '1') {
        //check user exists
        $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
        if (mysqli_connect_errno() == 0) {
          mysqli_query($dbhandle, "set names utf8;");
          $sql_users_profile = "SELECT created_from FROM cryptocash_users_profile WHERE email = '" . strtolower(trim($data['email_address'])) . "'";
          _log("", $sql_users_profile);
          $rs_users_profile = mysqli_query($dbhandle, $sql_users_profile);
          if (mysqli_num_rows($rs_users_profile) > 0) {
            $user_check_err = true;
            while ($row_users_profile = mysqli_fetch_array($rs_users_profile, MYSQLI_ASSOC)) {
              if (($row_users_profile['created_from'] ?? '') == $req_partner['partner']) {
                $user_check_err = false;
                break;
              }
            }
            if ($user_check_err) {
              $error_obj = array('errorCode' => 8, 'errorMessage' => 'That email address cannot be used with this service.');
              $errors[] = $error_obj;
            }
          }
          @mysqli_close($dbhandle);
        } else {
          @mysqli_close($dbhandle);
          header('Content-Type: application/json');
          http_response_code(500);
          $ret_rs['result'] = 'failed';
          $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
          echo json_encode($ret_rs);
          die();
        }
      }


      if (count($errors) == 0) {
        $errors_sub = array();

        require_once '../include/common.php';
		if ($req_partner['partner'] != 'ULTIMOPAY') {
			require_once('../classes/PostAffiliatePro/PapApi.class.php');
		} else if ($req_partner['partner'] != 'ULTIMOPAYMENT') {
			require_once('../classes/PostAffiliatePro/PapApi.class.php');
		} else if ($req_partner['partner'] != 'ULTIMOPAY_DASHBOARD') {
			require_once('../classes/PostAffiliatePro/PapApi.class.php');
		} else if ($req_partner['partner'] != 'BOS') {
			require_once('../classes/PostAffiliatePro/xexon/PapApi.class.php');
		} else if ($req_partner['partner'] != 'XEXON') {
			require_once('../classes/PostAffiliatePro/xexon/PapApi.class.php');
		}
        

        ////////////////////////////////////////////////////
        function PapLogin($_pap_url, $_username, $_password, $_type){
          try {
            if ($_type == "merchant") {
              $_merchant_session = new Pap_Api_Session($_pap_url);
              if(!$_merchant_session->login($_username, $_password)) {
                return null;
              }
              return $_merchant_session;
            } else if ($_type == "affiliate") {
              $_aff_session = new Pap_Api_Session($_pap_url);
              if(!$_aff_session->login($_username,$_password, Pap_Api_Session::AFFILIATE)) {
                return null;
              }
              return $_aff_session;
            }
          } catch (Exception $exception){
            return null;
          }
        }

        function PapUserCheck($_username, $_merchant_session): array
        {
          $affiliate_user = array('userid' => '', 'refid' => '', 'error' => '');
          $pap_user_check_request = new Pap_Api_AffiliatesGrid($_merchant_session);

          //Filtering affiliate with username
          $pap_user_check_request->addFilter('username', Gpf_Data_Filter::EQUALS, $_username);

          // sets limit to 30 rows, offset to 0 (first row starts)
          $pap_user_check_request->setLimit(0, 30);

          // sets columns, use it only if you want retrieve other as default columns
          $pap_user_check_request->addParam('columns', new Gpf_Rpc_Array(array(array('id'), array('refid'), array('userid'),
            array('username'), array('firstname'), array('lastname'), array('rstatus'), array('parentuserid'),
            array('dateinserted'), array('salesCount'), array('clicksRaw'), array('clicksUnique'))));

          // send request
          try {
            $pap_user_check_request->sendNow();

            // request was successful, get the grid result
            $grid = $pap_user_check_request->getGrid();

            // get recordset from the grid
            $pap_user_check_recordset = $grid->getRecordset();

            if (!empty($pap_user_check_recordset)) {
              foreach($pap_user_check_recordset as $rec) {
                if ((trim($rec->get('userid')) != '')  && (trim($rec->get('refid')) != '')){
                  $affiliate_user['userid'] = $rec->get('userid');
                  $affiliate_user['refid'] = $rec->get('refid');
                  break;
                }
              }
            }
          } catch(Exception $e) {
            $affiliate_user['error'] = $e->getMessage();
            return $affiliate_user;
          }

          return $affiliate_user;
        }

        function PapCreateUser($_pap_url, $_username, $_first_name, $_last_name, $_password, $_visitor_id, $_merchant_session) {
          $affiliate_user = array('userid' => '', 'refid' => '', 'error' => '');

          if (!empty($_merchant_session)) {
            $affiliate = new Pap_Api_Affiliate($_merchant_session);
            $affiliate->setUsername($_username);
            $affiliate->setFirstname($_first_name);
            $affiliate->setLastname($_last_name);
            $affiliate->setNotificationEmail($_username);
            $affiliate->setPassword($_password);

            try {
              if ($affiliate->add()) {
                $affiliate_user['userid'] = $affiliate->getUserid();
                $affiliate_user['refid'] = $affiliate->getRefid();
              } else {
                $affiliate_user['error'] = "Cannot save affiliate: ".$affiliate->getMessage();
              }
            } catch (Exception $e) {
              $affiliate_user['error'] = $_username . "::Error while communicating with PAP: ".$e->getMessage();
              return $affiliate_user;
            }

          } else {
            $affiliate_user['error'] = $_username . "::failed to login as merchant !";
          }

          return $affiliate_user;
        }

        $allowed_currency_arr = array('BTC', 'USDT', 'BUSD', 'USDC', 'USD', 'SOL', 'BCH', 'ETH', 'LTC', 'XRP');
        $allowed_shift_currency_arr = array('BTC', 'USDT', 'BUSD', 'USDC', 'USD', 'SOL', 'BCH', 'ETH', 'LTC', 'XRP');

        //receive POST params
        $reg_email_address = strtolower(trim($data['email_address']));
        $reg_password = trim($data['password']);

        if (empty($data['two_fa_code'])) {
          $reg_facode = "";
        } else {
          $reg_facode = $data['two_fa_code'];
        }

        _log($reg_email_address, "sign in started...");

        $post_data = array();
        $post_data['username'] = strtolower($reg_email_address);
        $post_data['password'] = $reg_password;
        $post_data['exchange'] = "PLUSQO";
        $db_add_cnt = 0;

        //first time login to ping
        $shift_user_sub_id = '';
        $shift_auth_token = '';
        $shift_auth_refresh_token = '';
        $shift_token_expires_in = 0;
        $merchants_has_signed_in = '';
        $shift_token_type = '';
        $merchant = '';

        $need_retry_login_call = 0;
        $login_first_res = array( 'result'=>'failed', 'message'=>'', 'data'=>null );
        $login_first_res = _cognito_signIn($reg_email_address, $reg_password);
        if ($login_first_res['result'] == 'success') {
          if (!isset($login_first_res['data']['AuthenticationResult'])) {
            $need_retry_login_call = 1;
          } else {
            $shift_user_sub_id = $login_first_res['data']['user_id'];
            $shift_auth_token =  $login_first_res['data']['AuthenticationResult']['AccessToken'];
            $shift_auth_refresh_token =  $login_first_res['data']['AuthenticationResult']['RefreshToken'];
            $shift_token_expires_in =  $login_first_res['data']['AuthenticationResult']['ExpiresIn'];
            $shift_token_type = $login_first_res['data']['AuthenticationResult']['TokenType'];
            _log($reg_email_address, "first time login : shift_user_sub_id = " . $shift_user_sub_id . ", shift_auth_token = " . $shift_auth_token);
          }
        } else {
          if (str_contains(strtolower($login_first_res['message']), "incorrect username or password")) {
            _log($reg_email_address, $login_first_res['message']);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'invalid credentials.');
            header('Content-Type: application/json');
            echo json_encode($ret_rs);
            die();
          } else if (str_contains(strtolower($login_first_res['message']), "user does not exist")) {
            _log($reg_email_address, $login_first_res['message']);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'invalid credentials.');
            header('Content-Type: application/json');
            echo json_encode($ret_rs);
            die();
          } else if (str_contains(strtolower($login_first_res['message']), "invalid credentials")) {
            _log($reg_email_address, $login_first_res['message']);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'invalid credentials.');
            header('Content-Type: application/json');
            echo json_encode($ret_rs);
            die();
          } else if (str_contains(strtolower($login_first_res['message']), "could not connect to PLUSQO")) {
            _log($reg_email_address, $login_first_res['result']['message']);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'system is under maintenance.');
            header('Content-Type: application/json');
            echo json_encode($ret_rs);
            die();
          } else if (str_contains(strtolower($login_first_res['message']), "2fa required")) {
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => '2FA code is required.');
            header('Content-Type: application/json');
            echo json_encode($ret_rs);
            die();
          } else if (str_contains(strtolower($login_first_res['message']), "2fa code invalid")) {
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'invalid 2FA code.');
            header('Content-Type: application/json');
            echo json_encode($ret_rs);
            die();
          } else if (str_contains(strtolower($login_first_res['message']), "user is not confirmed")) {
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'user is not confirmed.');
            header('Content-Type: application/json');
            echo json_encode($ret_rs);
            die();
          } else {
            _log($reg_email_address, $login_first_res['message']);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'system is under maintenance.');
            header('Content-Type: application/json');
            echo json_encode($ret_rs);
            die();
          }
        }

        if ($need_retry_login_call == 1) {
          _log($reg_email_address, "first time FAILED, retry second time...");
          ////////////////////////////////////////////////////////////
          //second time login
          sleep(3);
          $login_res = _cognito_signIn($reg_email_address, $reg_password);
          if (['result'] == 'success') {
            $shift_user_sub_id = $login_res['data']['user_id'];
            $shift_auth_token =  $login_res['data']['AuthenticationResult']['AccessToken'];
            $shift_auth_refresh_token =  $login_res['data']['AuthenticationResult']['RefreshToken'];
            $shift_token_expires_in =  $login_res['data']['AuthenticationResult']['ExpiresIn'];
            $shift_token_type = $login_res['data']['AuthenticationResult']['TokenType'];
            _log($reg_email_address, "first time login : shift_user_sub_id = " . $shift_user_sub_id . ", shift_auth_token = " . $shift_auth_token);
          } else {
            if (str_contains(strtolower($login_res['message']), "incorrect username or password")) {
              _log($reg_email_address, $login_res['result']['message']);
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'invalid credentials.');
              header('Content-Type: application/json');
              echo json_encode($ret_rs);
              die();
            } else if (str_contains(strtolower($login_res['message']), "user does not exist")) {
              _log($reg_email_address, $login_res['result']['message']);
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'invalid credentials.');
              header('Content-Type: application/json');
              echo json_encode($ret_rs);
              die();
            } else if (str_contains(strtolower($login_res['message']), "invalid credentials")) {
              _log($reg_email_address, $login_res['result']['message']);
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'invalid credentials.');
              header('Content-Type: application/json');
              echo json_encode($ret_rs);
              die();
            } else if (str_contains(strtolower($login_res['message']), "could not connect to PLUSQO")) {
              _log($reg_email_address, $login_res['result']['message']);
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'system is under maintenance.');
              header('Content-Type: application/json');
              echo json_encode($ret_rs);
              die();
            } else if (str_contains(strtolower($login_res['message']), "2fa required")) {
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => '2FA code is required.');
              header('Content-Type: application/json');
              echo json_encode($ret_rs);
              die();
            } else if (str_contains(strtolower($login_res['message']), "2fa code invalid")) {
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'invalid 2FA code.');
              header('Content-Type: application/json');
              echo json_encode($ret_rs);
              die();
            } else if (str_contains(strtolower($login_res['message']), "user is not confirmed")) {
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'user is not confirmed.');
              header('Content-Type: application/json');
              echo json_encode($ret_rs);
              die();
            } else {
              _log($reg_email_address, $login_res['message']);
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'system is under maintenance.');
              header('Content-Type: application/json');
              echo json_encode($ret_rs);
              die();
            }
          }
          ///////////////////////////////////////////////////////////
        }

        if (($shift_user_sub_id != '') && ($shift_auth_token != '')) {
          $authorization_value = "Bearer " . trim($shift_auth_token);
          $is_checkin_ok = 0;
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
          $auth_checkin_query = '{"query":"mutation {\n  checkin\n}","variables":{}}';
          $tmp_auth_dto_arr = array();
          unset($auth_checkin_res);
          $auth_checkin_res = api_call('/api/v4/auth_check_in', 0, $auth_checkin_query , $tmp_auth_dto_arr, $authorization_value);
          if (($auth_checkin_res['http_code'] == "200") || ($auth_checkin_res['http_code'] == "200 OK")) {
            if ((isset($auth_checkin_res['result']['data'])) && ($auth_checkin_res['result']['data']['checkin'] === true)) {
              $is_checkin_ok = 1;
              _log($reg_email_address, "checkIn API OK quy");
            } else {
              _log($reg_email_address, "checkIn API failed (2)");
            }
          } else {
            _log($reg_email_address, "checkIn API failed");
          }
          sleep(3);

          $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
          if (mysqli_connect_errno() == 0) {
            mysqli_query($dbhandle, "set names utf8;");

            //check debit_card exists
            if ($req_partner['partner'] == "BOS") {
              $sql_check_debit_card = "select * from cryptocash_jdb_debit_card where email_address = '$reg_email_address' and created_from='" . $req_partner['partner'] . "' limit 1";
              $rs_check_debit_card = mysqli_query($dbhandle, $sql_check_debit_card);
              if (mysqli_num_rows($rs_check_debit_card) <= 0) {
                $sql_check_debit_card_ultimopay = "select * from cryptocash_jdb_debit_card where email_address = '$reg_email_address' and created_from='ULTIMOPAY' limit 1";
                $rs_check_debit_card_ultimopay = mysqli_query($dbhandle, $sql_check_debit_card_ultimopay);
                if (mysqli_num_rows($rs_check_debit_card_ultimopay) > 0) {
                  while ($row_check_debit_card_ultimopay = mysqli_fetch_array($rs_check_debit_card_ultimopay, MYSQLI_ASSOC)) {
                    $debit_card_ultimopay_debit_card_id = (is_null($row_check_debit_card_ultimopay['debit_card_id']))?'':$row_check_debit_card_ultimopay['debit_card_id'];
                    $debit_card_ultimopay_acc_no = (is_null($row_check_debit_card_ultimopay['acc_no']))?'':$row_check_debit_card_ultimopay['acc_no'];
                    $debit_card_ultimopay_debit_card_num = (is_null($row_check_debit_card_ultimopay['debit_card_num']))?'':$row_check_debit_card_ultimopay['debit_card_num'];
                    $debit_card_ultimopay_debit_card_name = (is_null($row_check_debit_card_ultimopay['debit_card_name']))?'':$row_check_debit_card_ultimopay['debit_card_name'];
                    $debit_card_ultimopay_profile_id = (is_null($row_check_debit_card_ultimopay['profile_id']))?'':$row_check_debit_card_ultimopay['profile_id'];
                    $add_query = "";
                    if (is_null($row_check_debit_card_ultimopay['created_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_debit_card_ultimopay['created_dt'] . "',";
                    }
                    if (is_null($row_check_debit_card_ultimopay['updated_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_debit_card_ultimopay['updated_dt'] . "',";
                    }
                    $debit_card_ultimopay_status = (is_null($row_check_debit_card_ultimopay['status']))?'':$row_check_debit_card_ultimopay['status'];
                    $debit_card_ultimopay_invoice_id = (is_null($row_check_debit_card_ultimopay['invoice_id']))?'':$row_check_debit_card_ultimopay['invoice_id'];
                    $debit_card_ultimopay_has_paid_fee = (is_null($row_check_debit_card_ultimopay['has_paid_fee']))?'':$row_check_debit_card_ultimopay['has_paid_fee'];
                    $debit_card_ultimopay_payment_method = (is_null($row_check_debit_card_ultimopay['payment_method']))?'':$row_check_debit_card_ultimopay['payment_method'];
                    $debit_card_ultimopay_amount_fee_fiat = (is_null($row_check_debit_card_ultimopay['amount_fee_fiat']))?'':$row_check_debit_card_ultimopay['amount_fee_fiat'];
                    $debit_card_ultimopay_amount_fee_crypto = (is_null($row_check_debit_card_ultimopay['amount_fee_crypto']))?'':$row_check_debit_card_ultimopay['amount_fee_crypto'];
                    $debit_card_ultimopay_send_data_step_one = (is_null($row_check_debit_card_ultimopay['send_data_step_one']))?'':$row_check_debit_card_ultimopay['send_data_step_one'];
                    $debit_card_ultimopay_send_data_step_two = (is_null($row_check_debit_card_ultimopay['send_data_step_two']))?'':$row_check_debit_card_ultimopay['send_data_step_two'];
                    $debit_card_ultimopay_selfie_with_card_file = (is_null($row_check_debit_card_ultimopay['selfie_with_card_file']))?'':$row_check_debit_card_ultimopay['selfie_with_card_file'];
                    $debit_card_ultimopay_card_active_local_approved = (is_null($row_check_debit_card_ultimopay['card_active_local_approved']))?'':$row_check_debit_card_ultimopay['card_active_local_approved'];
                    $debit_card_ultimopay_has_sent_document_postal = (is_null($row_check_debit_card_ultimopay['has_sent_document_postal']))?'':$row_check_debit_card_ultimopay['has_sent_document_postal'];
                    $debit_card_ultimopay_activation_deny_message = (is_null($row_check_debit_card_ultimopay['activation_deny_message']))?'':$row_check_debit_card_ultimopay['activation_deny_message'];
                    $debit_card_ultimopay_card_issuance_deny_message = (is_null($row_check_debit_card_ultimopay['card_issuance_deny_message']))?'':$row_check_debit_card_ultimopay['card_issuance_deny_message'];
                    $debit_card_ultimopay_completion_show_cnt = (is_null($row_check_debit_card_ultimopay['completion_show_cnt']))?'':$row_check_debit_card_ultimopay['completion_show_cnt'];
                    $debit_card_ultimopay_secondary_address = (is_null($row_check_debit_card_ultimopay['secondary_address']))?'':$row_check_debit_card_ultimopay['secondary_address'];
                    $debit_card_ultimopay_secondary_country = (is_null($row_check_debit_card_ultimopay['secondary_country']))?'':$row_check_debit_card_ultimopay['secondary_country'];
                    $debit_card_ultimopay_secondary_district = (is_null($row_check_debit_card_ultimopay['secondary_district']))?'':$row_check_debit_card_ultimopay['secondary_district'];
                    $debit_card_ultimopay_secondary_province = (is_null($row_check_debit_card_ultimopay['secondary_province']))?'':$row_check_debit_card_ultimopay['secondary_province'];
                    $debit_card_ultimopay_secondary_postal_code = (is_null($row_check_debit_card_ultimopay['secondary_postal_code']))?'':$row_check_debit_card_ultimopay['secondary_postal_code'];
                    $debit_card_ultimopay_card_provider = (is_null($row_check_debit_card_ultimopay['card_provider']))?'':$row_check_debit_card_ultimopay['card_provider'];
                    $debit_card_ultimopay_card_selfie_uploaded = (is_null($row_check_debit_card_ultimopay['card_selfie_uploaded']))?'':$row_check_debit_card_ultimopay['card_selfie_uploaded'];
                  }
                  $sql_add_debit_card = "INSERT INTO cryptocash_jdb_debit_card (acc_no, debit_card_num, debit_card_name, profile_id, email_address, created_dt, updated_dt, status, invoice_id, has_paid_fee, payment_method, amount_fee_fiat, amount_fee_crypto, send_data_step_one, send_data_step_two, selfie_with_card_file, card_active_local_approved, has_sent_document_postal, activation_deny_message, card_issuance_deny_message, completion_show_cnt, secondary_address, secondary_country, secondary_district, secondary_province, secondary_postal_code, card_provider, card_selfie_uploaded, created_from) VALUES ('$debit_card_ultimopay_acc_no', '$debit_card_ultimopay_debit_card_num', '$debit_card_ultimopay_debit_card_name', '$debit_card_ultimopay_profile_id', '$reg_email_address'," . $add_query . "'$debit_card_ultimopay_status', '$debit_card_ultimopay_invoice_id', '$debit_card_ultimopay_has_paid_fee', '$debit_card_ultimopay_payment_method', '$debit_card_ultimopay_amount_fee_fiat', '$debit_card_ultimopay_amount_fee_crypto', '$debit_card_ultimopay_send_data_step_one', '$debit_card_ultimopay_send_data_step_two', '$debit_card_ultimopay_selfie_with_card_file', '$debit_card_ultimopay_card_active_local_approved', '$debit_card_ultimopay_has_sent_document_postal', '$debit_card_ultimopay_activation_deny_message', '$debit_card_ultimopay_card_issuance_deny_message', '$debit_card_ultimopay_completion_show_cnt', '$debit_card_ultimopay_secondary_address', '$debit_card_ultimopay_secondary_country', '$debit_card_ultimopay_secondary_district', '$debit_card_ultimopay_secondary_province', '$debit_card_ultimopay_secondary_postal_code', '$debit_card_ultimopay_card_provider', '$debit_card_ultimopay_card_selfie_uploaded', '" . $req_partner['partner'] . "')";
                  mysqli_query($dbhandle, $sql_add_debit_card);
                  if (mysqli_affected_rows($dbhandle) > 0) {
                    _log($reg_email_address, "insert new debit_card OK");
                  } else {
                    _log($reg_email_address, "insert new debit_card FAILED: " . $sql_add_debit_card);
                  }
                } else {
                  _log($reg_email_address, "no exists in debit_card of ultimopay");
                }
              } else {
                _log($reg_email_address, "already exists in debit_card, no need to add more");
              }

              $sql_check_jdb_profile = "select * from cryptocash_jdb_profile where email_address = '$reg_email_address' and created_from='" . $req_partner['partner'] . "' limit 1";
              $rs_check_jdb_profile = mysqli_query($dbhandle, $sql_check_jdb_profile);
              if (mysqli_num_rows($rs_check_jdb_profile) <= 0) {
                $sql_check_jdb_profile_ultimopay = "select * from cryptocash_jdb_profile where email_address = '$reg_email_address' and created_from='ULTIMOPAY' limit 1";
                $rs_check_jdb_profile_ultimopay = mysqli_query($dbhandle, $sql_check_jdb_profile_ultimopay);
                if (mysqli_num_rows($rs_check_jdb_profile_ultimopay) > 0) {
                  while ($row_check_jdb_profile_ultimopay = mysqli_fetch_array($rs_check_jdb_profile_ultimopay, MYSQLI_ASSOC)) {
                    $jdb_profile_ultimopay_profile_id = (is_null($row_check_jdb_profile_ultimopay['profile_id']))?'':$row_check_jdb_profile_ultimopay['profile_id'];
                    $jdb_profile_ultimopay_gender = (is_null($row_check_jdb_profile_ultimopay['gender']))?'':$row_check_jdb_profile_ultimopay['gender'];
                    $jdb_profile_ultimopay_name_kanji_kana = (is_null($row_check_jdb_profile_ultimopay['name_kanji_kana']))?'':$row_check_jdb_profile_ultimopay['name_kanji_kana'];
                    $jdb_profile_ultimopay_name_romaji = (is_null($row_check_jdb_profile_ultimopay['name_romaji']))?'':$row_check_jdb_profile_ultimopay['name_romaji'];
                    $jdb_profile_ultimopay_name_on_card = (is_null($row_check_jdb_profile_ultimopay['name_on_card']))?'':$row_check_jdb_profile_ultimopay['name_on_card'];
                    $jdb_profile_ultimopay_marriage_status = (is_null($row_check_jdb_profile_ultimopay['marriage_status']))?'':$row_check_jdb_profile_ultimopay['marriage_status'];
                    $jdb_profile_ultimopay_occupation = (is_null($row_check_jdb_profile_ultimopay['occupation']))?'':$row_check_jdb_profile_ultimopay['occupation'];
                    $jdb_profile_ultimopay_country = (is_null($row_check_jdb_profile_ultimopay['country']))?'':$row_check_jdb_profile_ultimopay['country'];
                    $jdb_profile_ultimopay_nationality = (is_null($row_check_jdb_profile_ultimopay['nationality']))?'':$row_check_jdb_profile_ultimopay['nationality'];
                    $jdb_profile_ultimopay_place_of_birth = (is_null($row_check_jdb_profile_ultimopay['place_of_birth']))?'':$row_check_jdb_profile_ultimopay['place_of_birth'];
                    $jdb_profile_ultimopay_id_card_number = (is_null($row_check_jdb_profile_ultimopay['id_card_number']))?'':$row_check_jdb_profile_ultimopay['id_card_number'];
                    $jdb_profile_ultimopay_id_card_issuer = (is_null($row_check_jdb_profile_ultimopay['id_card_issuer']))?'':$row_check_jdb_profile_ultimopay['id_card_issuer'];
                    $jdb_profile_ultimopay_id_card_type = (is_null($row_check_jdb_profile_ultimopay['id_card_type']))?'':$row_check_jdb_profile_ultimopay['id_card_type'];
                    $jdb_profile_ultimopay_residence_address = (is_null($row_check_jdb_profile_ultimopay['residence_address']))?'':$row_check_jdb_profile_ultimopay['residence_address'];
                    $jdb_profile_ultimopay_district = (is_null($row_check_jdb_profile_ultimopay['district']))?'':$row_check_jdb_profile_ultimopay['district'];
                    $jdb_profile_ultimopay_province = (is_null($row_check_jdb_profile_ultimopay['province']))?'':$row_check_jdb_profile_ultimopay['province'];
                    $jdb_profile_ultimopay_postal_code = (is_null($row_check_jdb_profile_ultimopay['postal_code']))?'':$row_check_jdb_profile_ultimopay['postal_code'];
                    $jdb_profile_ultimopay_home_telephone_country_code = (is_null($row_check_jdb_profile_ultimopay['home_telephone_country_code']))?'':$row_check_jdb_profile_ultimopay['home_telephone_country_code'];
                    $jdb_profile_ultimopay_home_telephone_number = (is_null($row_check_jdb_profile_ultimopay['home_telephone_number']))?'':$row_check_jdb_profile_ultimopay['home_telephone_number'];
                    $jdb_profile_ultimopay_cellphone_country_code = (is_null($row_check_jdb_profile_ultimopay['cellphone_country_code']))?'':$row_check_jdb_profile_ultimopay['cellphone_country_code'];
                    $jdb_profile_ultimopay_cellphone_number = (is_null($row_check_jdb_profile_ultimopay['cellphone_number']))?'':$row_check_jdb_profile_ultimopay['cellphone_number'];
                    $jdb_profile_ultimopay_consent_name = (is_null($row_check_jdb_profile_ultimopay['consent_name']))?'':$row_check_jdb_profile_ultimopay['consent_name'];
                    $add_query = "";
                    if (is_null($row_check_jdb_profile_ultimopay['date_of_birth'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_jdb_profile_ultimopay['date_of_birth'] . "',";
                    }
                    if (is_null($row_check_jdb_profile_ultimopay['id_card_issued_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_jdb_profile_ultimopay['id_card_issued_dt'] . "',";
                    }
                    if (is_null($row_check_jdb_profile_ultimopay['id_card_expired_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_jdb_profile_ultimopay['id_card_expired_dt'] . "',";
                    }
                    if (is_null($row_check_jdb_profile_ultimopay['consent_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_jdb_profile_ultimopay['consent_dt'] . "',";
                    }
                    if (is_null($row_check_jdb_profile_ultimopay['added_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_jdb_profile_ultimopay['added_dt'] . "',";
                    }
                    if (is_null($row_check_jdb_profile_ultimopay['update_dt'])) {
                      $add_query .= "NULL";
                    } else {
                      $add_query .= "'" . $row_check_jdb_profile_ultimopay['update_dt'] . "'";
                    }
                    $jdb_profile_ultimopay_passport_open_file = (is_null($row_check_jdb_profile_ultimopay['passport_open_file']))?'':$row_check_jdb_profile_ultimopay['passport_open_file'];
                    $jdb_profile_ultimopay_passport_selfie_file = (is_null($row_check_jdb_profile_ultimopay['passport_selfie_file']))?'':$row_check_jdb_profile_ultimopay['passport_selfie_file'];
                    $jdb_profile_ultimopay_id_card_front_file = (is_null($row_check_jdb_profile_ultimopay['id_card_front_file']))?'':$row_check_jdb_profile_ultimopay['id_card_front_file'];
                    $jdb_profile_ultimopay_id_card_back_file = (is_null($row_check_jdb_profile_ultimopay['id_card_back_file']))?'':$row_check_jdb_profile_ultimopay['id_card_back_file'];
                    $jdb_profile_ultimopay_id_card_selfie_file = (is_null($row_check_jdb_profile_ultimopay['id_card_selfie_file']))?'':$row_check_jdb_profile_ultimopay['id_card_selfie_file'];
                    $jdb_profile_ultimopay_status = (is_null($row_check_jdb_profile_ultimopay['status']))?'':$row_check_jdb_profile_ultimopay['status'];
                    $jdb_profile_ultimopay_admin_edit = (is_null($row_check_jdb_profile_ultimopay['admin_edit']))?'':$row_check_jdb_profile_ultimopay['admin_edit'];
                    $jdb_profile_ultimopay_application_deny_message = (is_null($row_check_jdb_profile_ultimopay['application_deny_message']))?'':$row_check_jdb_profile_ultimopay['application_deny_message'];
                    $jdb_profile_ultimopay_signature_one_filename = (is_null($row_check_jdb_profile_ultimopay['signature_one_filename']))?'':$row_check_jdb_profile_ultimopay['signature_one_filename'];
                    $jdb_profile_ultimopay_signature_two_filename = (is_null($row_check_jdb_profile_ultimopay['signature_two_filename']))?'':$row_check_jdb_profile_ultimopay['signature_two_filename'];
                    $jdb_profile_ultimopay_kyc_pdf_file_created = (is_null($row_check_jdb_profile_ultimopay['kyc_pdf_file_created']))?'':$row_check_jdb_profile_ultimopay['kyc_pdf_file_created'];
                  }
                  $sql_add_jdb_profile = "INSERT INTO cryptocash_jdb_profile (profile_id, gender, name_kanji_kana, name_romaji, name_on_card, marriage_status, occupation, country, nationality, place_of_birth, id_card_number, id_card_issuer, id_card_type, residence_address, district, province, postal_code, home_telephone_country_code, home_telephone_number, cellphone_country_code, cellphone_number, consent_name, email_address, passport_open_file, passport_selfie_file, id_card_front_file, id_card_back_file, id_card_selfie_file, status, admin_edit, application_deny_message, signature_one_filename, signature_two_filename, kyc_pdf_file_created, created_from, date_of_birth, id_card_issued_dt, id_card_expired_dt, consent_dt, added_dt, update_dt) VALUES ('$jdb_profile_ultimopay_profile_id', '$jdb_profile_ultimopay_gender', '$jdb_profile_ultimopay_name_kanji_kana', '$jdb_profile_ultimopay_name_romaji', '$jdb_profile_ultimopay_name_on_card', '$jdb_profile_ultimopay_marriage_status', '$jdb_profile_ultimopay_occupation', '$jdb_profile_ultimopay_country', '$jdb_profile_ultimopay_nationality', '$jdb_profile_ultimopay_place_of_birth', '$jdb_profile_ultimopay_id_card_number', '$jdb_profile_ultimopay_id_card_issuer', '$jdb_profile_ultimopay_id_card_type', '$jdb_profile_ultimopay_residence_address', '$jdb_profile_ultimopay_district', '$jdb_profile_ultimopay_province', '$jdb_profile_ultimopay_postal_code', '$jdb_profile_ultimopay_home_telephone_country_code', '$jdb_profile_ultimopay_home_telephone_number', '$jdb_profile_ultimopay_cellphone_country_code', '$jdb_profile_ultimopay_cellphone_number', '$jdb_profile_ultimopay_consent_name', '$reg_email_address', '$jdb_profile_ultimopay_passport_open_file', '$jdb_profile_ultimopay_passport_selfie_file', '$jdb_profile_ultimopay_id_card_front_file', '$jdb_profile_ultimopay_id_card_back_file', '$jdb_profile_ultimopay_id_card_selfie_file', '$jdb_profile_ultimopay_status', '$jdb_profile_ultimopay_admin_edit', '$jdb_profile_ultimopay_application_deny_message', '$jdb_profile_ultimopay_signature_one_filename', '$jdb_profile_ultimopay_signature_two_filename', '$jdb_profile_ultimopay_kyc_pdf_file_created', '" . $req_partner['partner'] . "'," . $add_query . ")";
                  mysqli_query($dbhandle, $sql_add_jdb_profile);
                  if (mysqli_affected_rows($dbhandle) > 0) {
                    _log($reg_email_address, "insert new jdb_profile OK");
                  } else {
                    _log($reg_email_address, "insert new jdb_profile FAILED: " . $sql_add_jdb_profile);
                  }
                } else {
                  _log($reg_email_address, "no exists in jdb_profile of ultimopay");
                }
              } else {
                _log($reg_email_address, "already exists in jdb_profile, no need to add more");
              }
            }

            //check there is data of my shift wallet?
            $shift_wallet_cnt = 0;
            $sql_check_shift_wallet = "select * from cryptocash_shift_wallet where shift_login_email='$reg_email_address'";
            $rs_check_shift_wallet = mysqli_query($dbhandle, $sql_check_shift_wallet);
            $shift_wallet_cnt = mysqli_num_rows($rs_check_shift_wallet);

            //check profile exists or not (add new if not exists)
            $has_shift_data = 0;
            $sql_check_profile = "select * from cryptocash_users_profile where email = '$reg_email_address' and created_from='" . $req_partner['partner'] . "' limit 1";
            $rs_check_profile = mysqli_query($dbhandle, $sql_check_profile);
            if (mysqli_num_rows($rs_check_profile) <= 0) {
              if ($req_partner['partner'] == "BOS") {
                $sql_check_profile_ultimopay = "select * from cryptocash_users_profile where email = '$reg_email_address' and created_from='ULTIMOPAY' limit 1";
                $rs_check_profile_ultimopay = mysqli_query($dbhandle, $sql_check_profile_ultimopay);
                if (mysqli_num_rows($rs_check_profile_ultimopay) > 0) {
                  while ($row_check_profile_ultimopay = mysqli_fetch_array($rs_check_profile_ultimopay, MYSQLI_ASSOC)) {
                    $profile_ultimopay_given_name = (is_null($row_check_profile_ultimopay['given_name']))?'':$row_check_profile_ultimopay['given_name'];
                    $profile_ultimopay_sur_name = (is_null($row_check_profile_ultimopay['sur_name']))?'':$row_check_profile_ultimopay['sur_name'];
                    $profile_ultimopay_middle_name = (is_null($row_check_profile_ultimopay['middle_name']))?'':$row_check_profile_ultimopay['middle_name'];
                    $profile_ultimopay_shift_full_name = (is_null($row_check_profile_ultimopay['shift_full_name']))?'':$row_check_profile_ultimopay['shift_full_name'];
                    $profile_ultimopay_country = (is_null($row_check_profile_ultimopay['country']))?'':$row_check_profile_ultimopay['country'];
                    $add_query = "";
                    if (is_null($row_check_profile_ultimopay['add_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_profile_ultimopay['add_dt'] . "',";
                    }
                    if (is_null($row_check_profile_ultimopay['shift_update_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_profile_ultimopay['shift_update_dt'] . "',";
                    }
                    if (is_null($row_check_profile_ultimopay['admin_update_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_profile_ultimopay['admin_update_dt'] . "',";
                    }
                    if (is_null($row_check_profile_ultimopay['admin_process_kyc_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_profile_ultimopay['admin_process_kyc_dt'] . "',";
                    }
                    if (is_null($row_check_profile_ultimopay['admin_process_card_activate_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_profile_ultimopay['admin_process_card_activate_dt'] . "',";
                    }
                    if (is_null($row_check_profile_ultimopay['admin_process_card_load_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_profile_ultimopay['admin_process_card_load_dt'] . "',";

                    }
                    if (is_null($row_check_profile_ultimopay['kyc_upload_dt'])) {
                      $add_query .= "NULL,";
                    } else {
                      $add_query .= "'" . $row_check_profile_ultimopay['kyc_upload_dt'] . "',";

                    }
                    $profile_ultimopay_pap_cookie = (is_null($row_check_profile_ultimopay['pap_cookie']))?'':$row_check_profile_ultimopay['pap_cookie'];
                    $profile_ultimopay_refid = (is_null($row_check_profile_ultimopay['refid']))?'':$row_check_profile_ultimopay['refid'];
                    $profile_ultimopay_parent_userid = (is_null($row_check_profile_ultimopay['parent_userid']))?'':$row_check_profile_ultimopay['parent_userid'];
                    $profile_ultimopay_token = (is_null($row_check_profile_ultimopay['token']))?'':$row_check_profile_ultimopay['token'];
                    $profile_ultimopay_affiliate_program_registered = (is_null($row_check_profile_ultimopay['affiliate_program_registered']))?'':$row_check_profile_ultimopay['affiliate_program_registered'];
                    $profile_ultimopay_admin_action = (is_null($row_check_profile_ultimopay['admin_action']))?'':$row_check_profile_ultimopay['admin_action'];
                    $profile_ultimopay_shift_user_group = (is_null($row_check_profile_ultimopay['shift_user_group']))?'':$row_check_profile_ultimopay['shift_user_group'];
                    $profile_ultimopay_merchants_has_signed_in = (is_null($row_check_profile_ultimopay['merchants_has_signed_in']))?'':$row_check_profile_ultimopay['merchants_has_signed_in'];
                    $profile_ultimopay_resend_signup_code_tm = (is_null($row_check_profile_ultimopay['resend_signup_code_tm']))?'':$row_check_profile_ultimopay['resend_signup_code_tm'];
                    $profile_ultimopay_resend_signup_code_cnt = (is_null($row_check_profile_ultimopay['resend_signup_code_cnt']))?'':$row_check_profile_ultimopay['resend_signup_code_cnt'];
                    $profile_ultimopay_affiliation = (is_null($row_check_profile_ultimopay['affiliation']))?'':$row_check_profile_ultimopay['affiliation'];
                  }
                  $sql_add_profile = "INSERT INTO cryptocash_users_profile (email, given_name, sur_name, middle_name, shift_full_name, country, add_dt, shift_update_dt, admin_update_dt, admin_process_kyc_dt, admin_process_card_activate_dt, admin_process_card_load_dt, kyc_upload_dt, pap_cookie, refid, parent_userid, token, affiliate_program_registered, admin_action, shift_user_group, created_from, merchants_has_signed_in, resend_signup_code_tm, resend_signup_code_cnt, affiliation) VALUES ('$reg_email_address', '$profile_ultimopay_given_name', '$profile_ultimopay_sur_name', '$profile_ultimopay_middle_name', '$profile_ultimopay_shift_full_name', '$profile_ultimopay_country', " . $add_query . "'$profile_ultimopay_pap_cookie', '$profile_ultimopay_refid', '$profile_ultimopay_parent_userid', '$profile_ultimopay_token', '$profile_ultimopay_affiliate_program_registered', '$profile_ultimopay_admin_action', '$profile_ultimopay_shift_user_group', '" . $req_partner['partner'] . "', '$profile_ultimopay_merchants_has_signed_in', '$profile_ultimopay_resend_signup_code_tm', '$profile_ultimopay_resend_signup_code_cnt', '$profile_ultimopay_affiliation')";
                } else {
                  $sql_add_profile = "INSERT INTO cryptocash_users_profile (email, created_from) VALUES ('$reg_email_address', '" . $req_partner['partner'] . "')";
                }
              } else {
                $sql_add_profile = "INSERT INTO cryptocash_users_profile (email, created_from) VALUES ('$reg_email_address', '" . $req_partner['partner'] . "')";
              }
              mysqli_query($dbhandle, $sql_add_profile);
              if (mysqli_affected_rows($dbhandle) > 0) {
                _log($reg_email_address, "insert new profile OK");
              } else {
                _log($reg_email_address, "insert new profile FAILED: " . $sql_add_profile);
                @mysqli_close($dbhandle);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #3.');
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
              }
            } else {
              _log($reg_email_address, "already exists in users_profile, no need to add more");
              $merchant_small_txt = strtolower($req_partner['partner']);
              $merchant_has_signed_in_arr = array();
              $merchant_has_signed_in_ex_arr = array();
              $merchant_has_signed_in_found = 0;
              $updated_merchant_signed_in = '';
              while ($row_check_profile = mysqli_fetch_array($rs_check_profile, MYSQLI_ASSOC)) {
                $merchants_has_signed_in = trim($row_check_profile['merchants_has_signed_in']);
                if ($merchants_has_signed_in != '') {
                  $merchant_has_signed_in_arr = explode("|", $merchants_has_signed_in);
                  if (count($merchant_has_signed_in_arr) > 0) {
                    for ($d=0; $d<count($merchant_has_signed_in_arr); $d++) {
                      $cur_merchants_signed_in = strtolower(trim($merchant_has_signed_in_arr[$d]));
                      if ($cur_merchants_signed_in != '') {
                        $merchant_has_signed_in_ex_arr[] = trim($merchant_has_signed_in_arr[$d]);
                        if ($merchant_small_txt == $cur_merchants_signed_in) {
                          $merchant_has_signed_in_found = 1;
                        }
                      }
                    }

                    if (count($merchant_has_signed_in_ex_arr) > 0) {
                      for ($e=0; $e<count($merchant_has_signed_in_ex_arr); $e++) {
                        $updated_merchant_signed_in = $updated_merchant_signed_in . $merchant_has_signed_in_ex_arr[$e] . " | ";
                      }
                    }

                    if ($merchant_has_signed_in_found == 0) {
                      $updated_merchant_signed_in = $updated_merchant_signed_in . $req_partner['partner'] . " | ";
                    }
                  }
                } else {
                  $updated_merchant_signed_in = $req_partner['partner'] . " | ";
                }
                // update user_profile table again (merchants_has_signed_in field)
                if ($updated_merchant_signed_in != '') {
_log($reg_email_address, 'merchants_has_signed_in: '.$updated_merchant_signed_in);
                  $sql_update_user_profile_ex = "UPDATE cryptocash_users_profile SET merchants_has_signed_in='$updated_merchant_signed_in' WHERE email='$reg_email_address' AND created_from='" . $req_partner['partner'] .  "' LIMIT 1";
                  mysqli_query($dbhandle, $sql_update_user_profile_ex);
                }
              }
            }

            // begin add 20230325 cryptocash_user_status k.o
            $sql_check_status = "select * from cryptocash_user_status where email_address = '$reg_email_address' and created_from='" . $req_partner['partner'] . "' limit 1";
            $rs_check_status = mysqli_query($dbhandle, $sql_check_status);
            if (mysqli_num_rows($rs_check_status) <= 0) {
              if ($req_partner['partner'] == "BOS") {
                $sql_user_info = "SELECT * from (SELECT a.email as shift_email, a.given_name, a.sur_name, a.middle_name, a.country as shift_country, a.add_dt as shift_add_dt, a.shift_update_dt, a.admin_update_dt, a.kyc_upload_dt, a.admin_action, a.admin_process_kyc_dt, a.admin_process_card_activate_dt, a.admin_process_card_load_dt, a.affiliation, a.created_from as created_from_one, b.*, c.debit_card_id, c.acc_no, c.debit_card_num, c.debit_card_name, c.status as card_status, c.has_paid_fee, c.payment_method, c.amount_fee_fiat, c.amount_fee_crypto, c.has_sent_document_postal, c.activation_deny_message, c.card_issuance_deny_message, c.secondary_address, c.secondary_country, c.secondary_district, c.secondary_province, c.secondary_postal_code, c.card_provider, c.selfie_with_card_file, c.send_data_step_one, c.send_data_step_two, c.card_active_local_approved, c.card_selfie_uploaded FROM cryptocash_users_profile a LEFT JOIN cryptocash_jdb_profile b ON ((a.email = b.email_address) AND (a.created_from = b.created_from)) LEFT JOIN cryptocash_jdb_debit_card c ON ((b.profile_id = c.profile_id) AND (b.created_from = c.created_from)) ORDER BY a.shift_update_dt DESC) AS dataset WHERE dataset.shift_email='$reg_email_address' AND dataset.created_from_one='ULTIMOPAY' ORDER BY dataset.shift_update_dt DESC LIMIT 1";
                _log($reg_email_address, $sql_user_info);
                $rs_user_info = mysqli_query($dbhandle, $sql_user_info);
                $cur_user_info = array();
                $my_profile_id = '';
                $has_paid_fee = '';
                $my_debit_card_id = '';
                $has_sent_document_postal = '';
                $my_card_status = '';
                $kyc_pdf_file_created = '';
                $card_selfie_uploaded = '';
                $selfie_with_card_file = '';
                $send_data_step_one = '';
                $card_active_local_approved = '';
                $send_data_step_two = '';
                $shift_country = '';
                $shift_email = '';
                $kyc_status = 0;
                $card_activation_status = 0;
                $card_status = 0;
                $payment_status = 0;
                $card_activation_file_url = null;
                $sql_add_datetime = null;

                while ($row_user_info = mysqli_fetch_array($rs_user_info, MYSQLI_ASSOC)) {

                  $cur_user_info['email_address'] = (is_null($row_user_info['email_address']))?'':$row_user_info['email_address'];
                  $shift_email = (is_null($row_user_info['shift_email']))?'':$row_user_info['shift_email'];
                  $cur_user_info['given_name'] = (is_null($row_user_info['given_name']))?'':$row_user_info['given_name'];
                  $cur_user_info['middle_name'] = (is_null($row_user_info['middle_name']))?'':$row_user_info['middle_name'];
                  $cur_user_info['sur_name'] = (is_null($row_user_info['sur_name']))?'':$row_user_info['sur_name'];
                  $cur_user_info['signup_datetime'] = (is_null($row_user_info['shift_add_dt']))?'':$row_user_info['shift_add_dt'];

                  if ($cur_user_info['signup_datetime'] != '') {
                    $shift_add_tm = strtotime($cur_user_info['signup_datetime']) - 32400; //change to UTC
                    $cur_user_info['signup_datetime'] = date('Y/m/d H:i:s', $shift_add_tm);
                  }

                  $cur_user_info['last_update_datetime'] = (is_null($row_user_info['shift_update_dt']))?'':$row_user_info['shift_update_dt'];
                  if ($cur_user_info['last_update_datetime'] != '') {
                    $shift_update_tm = strtotime($cur_user_info['last_update_datetime']) - 32400; //change to UTC
                    $cur_user_info['last_update_datetime'] = date('Y/m/d H:i:s', $shift_update_tm);
                  }

                  $cur_user_info['submit_kyc_document_datetime'] = (is_null($row_user_info['kyc_upload_dt']))?'':$row_user_info['kyc_upload_dt'];
                  if ($cur_user_info['submit_kyc_document_datetime'] != '') {
                    $kyc_upload_dt_tm = strtotime($cur_user_info['submit_kyc_document_datetime']) - 32400; //change to UTC
                    $cur_user_info['submit_kyc_document_datetime'] = date('Y/m/d H:i:s', $kyc_upload_dt_tm);
                  }
                  $cur_user_info['card_was_issued_datetime'] = (is_null($row_user_info['admin_process_kyc_dt']))?'':$row_user_info['admin_process_kyc_dt'];
                  if ($cur_user_info['card_was_issued_datetime'] != '') {
                    $admin_process_kyc_tm = strtotime($cur_user_info['card_was_issued_datetime']) - 32400; //change to UTC
                    $cur_user_info['card_was_issued_datetime'] = date('Y/m/d H:i:s', $admin_process_kyc_tm);
                  }
                  $cur_user_info['card_was_activated_datetime'] = (is_null($row_user_info['admin_process_card_activate_dt']))?'':$row_user_info['admin_process_card_activate_dt'];
                  if ($cur_user_info['card_was_activated_datetime'] != '') {
                    $admin_process_card_activate_tm = strtotime($cur_user_info['card_was_activated_datetime']) - 32400; //change to UTC
                    $cur_user_info['card_was_activated_datetime'] = date('Y/m/d H:i:s', $admin_process_card_activate_tm);
                  }

                  $shift_country = (is_null($row_user_info['shift_country']))?'':$row_user_info['shift_country'];
                  $cur_user_info['affiliation'] = (is_null($row_user_info['affiliation']))?'':$row_user_info['affiliation'];
                  $my_profile_id = (is_null($row_user_info['profile_id']))?'':$row_user_info['profile_id'];
                  $cur_user_info['title'] = (is_null($row_user_info['gender']))?'':$row_user_info['gender'];
                  if (intval($cur_user_info['title'])==1) {
                    $cur_user_info['title'] = "Mr.";
                  } else if (intval($cur_user_info['title'])==2) {
                    $cur_user_info['title'] = "Ms.";
                  }
                  $cur_user_info['name'] = (is_null($row_user_info['name_romaji']))?'':$row_user_info['name_romaji'];
                  $cur_user_info['card_emboss_name'] = (is_null($row_user_info['name_on_card']))?'':$row_user_info['name_on_card'];
                  $cur_user_info['marriage_status'] = (is_null($row_user_info['marriage_status']))?'':$row_user_info['marriage_status'];
                  if (intval($cur_user_info['marriage_status'])==1) {
                    $cur_user_info['marriage_status'] = "Single";
                  } else if (intval($cur_user_info['marriage_status'])==2) {
                    $cur_user_info['marriage_status'] = "Married";
                  }
                  $cur_user_info['occupation'] =  (is_null($row_user_info['occupation']))?'':$row_user_info['occupation'];
                  $cur_user_info['country'] = (is_null($row_user_info['country']))?'':$row_user_info['country'];
                  $cur_user_info['nationality'] = (is_null($row_user_info['nationality']))?'':$row_user_info['nationality'];
                  $cur_user_info['date_of_birth'] = (is_null($row_user_info['date_of_birth']))?'':$row_user_info['date_of_birth'];
                  if ($cur_user_info['date_of_birth'] != '') {
                    $cur_user_info['date_of_birth'] = str_replace("-","/",$cur_user_info['date_of_birth']);
                  }
                  $cur_user_info['place_of_birth'] = (is_null($row_user_info['place_of_birth']))?'':$row_user_info['place_of_birth'];
                  $cur_user_info['id_card_number'] = (is_null($row_user_info['id_card_number']))?'':$row_user_info['id_card_number'];
                  $cur_user_info['id_card_issued_date'] = (is_null($row_user_info['id_card_issued_dt']))?'':$row_user_info['id_card_issued_dt'];
                  if ($cur_user_info['id_card_issued_date'] != '') {
                    $cur_user_info['id_card_issued_date'] = str_replace("-","/",$cur_user_info['id_card_issued_date']);
                  }
                  $cur_user_info['id_card_expired_date'] =(is_null($row_user_info['id_card_expired_dt']))?'':$row_user_info['id_card_expired_dt'];
                  if ($cur_user_info['id_card_expired_date'] != '') {
                    $cur_user_info['id_card_expired_date'] = str_replace("-","/",$cur_user_info['id_card_expired_date']);
                  }
                  $cur_user_info['id_card_issuer'] = (is_null($row_user_info['id_card_issuer']))?'':$row_user_info['id_card_issuer'];
                  $cur_user_info['id_card_type'] = (is_null($row_user_info['id_card_type']))?'':$row_user_info['id_card_type'];
                  if ($cur_user_info['id_card_type'] == "passport") {
                    $cur_user_info['id_card_type'] = "Passport";
                  } else if ($cur_user_info['id_card_type'] == "driving_license") {
                    $cur_user_info['id_card_type'] = "ID card";
                  }
                  $cur_user_info['address'] = (is_null($row_user_info['residence_address']))?'':$row_user_info['residence_address'];
                  $cur_user_info['district'] = (is_null($row_user_info['district']))?'':$row_user_info['district'];
                  $cur_user_info['province'] = (is_null($row_user_info['province']))?'':$row_user_info['province'];
                  $cur_user_info['postal_code'] = (is_null($row_user_info['postal_code']))?'':$row_user_info['postal_code'];
                  $cur_user_info['cellphone_country_code'] = (is_null($row_user_info['cellphone_country_code']))?'':$row_user_info['cellphone_country_code'];
                  if (str_contains($cur_user_info['cellphone_country_code'], "_")) {
                    $cellphone_country_code_arr = explode("_", $cur_user_info['cellphone_country_code']);
                    if ($cellphone_country_code_arr[1] == "ca") {
                      $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
                    } else if ($cellphone_country_code_arr[1] == "44") {
                      $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0] . " 44";
                    } else if ($cellphone_country_code_arr[1] == "34") {
                      $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0] . " 34";
                    } else if ($cellphone_country_code_arr[1] == "97") {
                      $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0] . " 97";
                    } else if ($cellphone_country_code_arr[1] == "ca") {
                      $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
                    } else if ($cellphone_country_code_arr[1] == "kaz") {
                      $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
                    } else if ($cellphone_country_code_arr[1] == "swa") {
                      $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
                    } else if ($cellphone_country_code_arr[1] == "1") {
                      $cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
                    }
                  }
                  $cur_user_info['cellphone_number'] = (is_null($row_user_info['cellphone_number']))?'':$row_user_info['cellphone_number'];

                  $cur_user_info['profile_added_date'] = (is_null($row_user_info['added_dt']))?'':$row_user_info['added_dt'];
                  if ($cur_user_info['profile_added_date'] != '') {
                    $profile_added_tm = strtotime($cur_user_info['profile_added_date']) - 32400; //change to UTC
                    $cur_user_info['profile_added_date'] = date('Y/m/d H:i:s', $profile_added_tm);
                  }
                  $cur_user_info['profile_updated_date'] = (is_null($row_user_info['update_dt']))?'':$row_user_info['update_dt'];
                  if ($cur_user_info['profile_updated_date'] != '') {
                    $profile_updated_tm = strtotime($cur_user_info['profile_updated_date']) - 32400; //change to UTC
                    $cur_user_info['profile_updated_date'] = date('Y/m/d H:i:s', $profile_updated_tm);
                  }
                  $cur_user_info['profile_status'] = (is_null($row_user_info['status']))?'':$row_user_info['status'];
                  $cur_user_info['kyc_deny_message'] = (is_null($row_user_info['application_deny_message']))?'':$row_user_info['application_deny_message'];
                  $cur_user_info['kyc_deny_message'] = addslashes($cur_user_info['kyc_deny_message']);

                  $my_debit_card_id = (is_null($row_user_info['debit_card_id']))?'':$row_user_info['debit_card_id'];
                  $cur_user_info['bank_account_number'] = (is_null($row_user_info['acc_no']))?'':$row_user_info['acc_no'];
                  $cur_user_info['card_number'] =  (is_null($row_user_info['debit_card_num']))?'':$row_user_info['debit_card_num'];
                  $my_card_status =  (is_null($row_user_info['card_status']))?'':$row_user_info['card_status'];
                  $has_paid_fee =  (is_null($row_user_info['has_paid_fee']))?'':$row_user_info['has_paid_fee'];
                  $cur_user_info['payment_method'] = (is_null($row_user_info['payment_method']))?'':strtoupper($row_user_info['payment_method']);
                  $cur_user_info['amount_fee_fiat'] = (is_null($row_user_info['amount_fee_fiat']))?'':$row_user_info['amount_fee_fiat'];
                  $cur_user_info['amount_fee_crypto'] = (is_null($row_user_info['amount_fee_crypto']))?'':$row_user_info['amount_fee_crypto'];

                  $has_sent_document_postal = (is_null($row_user_info['has_sent_document_postal']))?'':$row_user_info['has_sent_document_postal'];
                  $cur_user_info['card_activation_deny_message'] = (is_null($row_user_info['activation_deny_message']))?'':$row_user_info['activation_deny_message'];
                  $cur_user_info['card_issuance_deny_message'] = (is_null($row_user_info['card_issuance_deny_message']))?'':$row_user_info['card_issuance_deny_message'];

                  if (($row_user_info['secondary_address'] != "") && ($row_user_info['secondary_district'] != "") && ($row_user_info['secondary_province'] != "") && ($row_user_info['secondary_country'] != "")) {
                    $cur_user_info['secondary_address'] = array('address' => $row_user_info['secondary_address'], 'district' => $row_user_info['secondary_district'], 'province' => $row_user_info['secondary_province'], 'postal_code' => $row_user_info['secondary_postal_code'], 'country' => $row_user_info['secondary_country']);
                  } else {
                    $cur_user_info['secondary_address'] = "";
                  }

                  $cur_user_info['card_provider'] = (is_null($row_user_info['card_provider']))?'':$row_user_info['card_provider'];
                  if ($cur_user_info['card_provider'] == "visa") {
                    $cur_user_info['card_provider'] = "VISA";
                  } else if ($cur_user_info['card_provider'] == "unionpay") {
                    $cur_user_info['card_provider'] = "UNIONPAY";
                  }
                  $selfie_with_card_file = (is_null($row_user_info['selfie_with_card_file']))?'':$row_user_info['selfie_with_card_file'];
                  $send_data_step_one = (is_null($row_user_info['send_data_step_one']))?'':$row_user_info['send_data_step_one'];
                  $send_data_step_two = (is_null($row_user_info['send_data_step_two']))?'':$row_user_info['send_data_step_two'];
                  $card_active_local_approved = (is_null($row_user_info['card_active_local_approved']))?'':$row_user_info['card_active_local_approved'];

                  $cur_user_info['kyc_file_url'] = '';
                  $kyc_pdf_file_created = (is_null($row_user_info['kyc_pdf_file_created']))?'':intval($row_user_info['kyc_pdf_file_created']);
                  if ($kyc_pdf_file_created == 1) {
                    $application_form_final_pdfex = '/var/www/dashboard.ultimopay.io/html/jdb/data/upload/application_final_signed_' . $my_profile_id . '.pdf';
                    $cur_user_info['kyc_file_url'] = 'https://dashboard.ultimopay.io/jdb/data/upload/application_final_signed_' . $my_profile_id . '.pdf';
                  }

                  if ($selfie_with_card_file) {
                    $card_activation_file_url = 'https://dashboard.ultimopay.io/jdb/data/upload/' . $selfie_with_card_file;
                  }

                  $cur_user_info['kyc_status'] = 'not yet';
                  if (intval($has_paid_fee) == 1) {
                    $cur_user_info['payment_status'] = 'done';
                  } else {
                    $cur_user_info['payment_status'] = 'not yet';
                  }
                  $card_selfie_uploaded = (is_null($row_user_info['card_selfie_uploaded']))?'':intval($row_user_info['card_selfie_uploaded']);
                  $cur_user_info['group'] = (is_null($row_user_info['created_from_one']))?'':$row_user_info['created_from_one'];

                  $cur_user_info['kyc_status'] = 'not yet';
                  $cur_user_info['card_activation_status'] = 'not yet';
                  $cur_user_info['card_status'] = 'not yet';
                  if (intval($my_card_status) == 1) {
                    $cur_user_info['kyc_status'] = 'approved';
                    $cur_user_info['card_activation_status'] = 'approved';
                    $cur_user_info['card_status'] = 'issued';
                  } else {
                    if (intval($cur_user_info['profile_status']) <= 0) {
                      if ($cur_user_info['kyc_deny_message'] != '') {
                        $cur_user_info['kyc_status'] = 'declined';
                      } else {
                        if ($kyc_pdf_file_created == 1) {
                          $cur_user_info['kyc_status'] = 'pending';
                        }
                      }
                    } else {
                      $cur_user_info['kyc_status'] = 'approved';
                      if ($selfie_with_card_file != '') {
                        if (file_exists("/var/www/dashboard.ultimopay.io/html/jdb/data/upload/" . $selfie_with_card_file)) {
                          if ($cur_user_info['card_activation_deny_message'] != '') {
                            $cur_user_info['card_activation_status'] = 'declined';
                          } else {
                            if (intval($card_active_local_approved) == 0) { //card active requests
                              $cur_user_info['card_activation_status'] = 'pending';
                            } else {
                              $cur_user_info['card_activation_status'] = 'issued';
                            }
                          }
                        }
                      }
                    }
                  }

                  if ($cur_user_info['payment_status'] == 'not yet') {
                    $payment_status = 0;
                  } else if ($cur_user_info['payment_status'] == 'done') {
                    $payment_status = 2;
                  }

                  if ($cur_user_info['card_activation_status'] == 'not yet') {
                    $card_activation_status = 0;
                  } else if ($cur_user_info['card_activation_status'] == 'pending') {
                    $card_activation_status = 1;
                  } else if ($cur_user_info['card_activation_status'] == 'approved') {
                    $card_activation_status = 2;
                  } else if ($cur_user_info['card_activation_status'] == 'declined') {
                    $card_activation_status = 9;
                  }

                  if ($cur_user_info['card_status'] == 'not yet') {
                    $card_status = 0;
                  } else if ($cur_user_info['card_status'] == 'processing') {
                    $card_status = 1;
                  } else if ($cur_user_info['card_status'] == 'issued') {
                    $card_status = 2;
                  }
                  if ($cur_user_info['kyc_status'] == 'not yet') {
                    $kyc_status = 0;
                  } else if ($cur_user_info['kyc_status'] == 'pending') {
                    $kyc_status = 1;
                  } else if ($cur_user_info['kyc_status'] == 'approved') {
                    $kyc_status = 2;
                  } else if ($cur_user_info['kyc_status'] == 'declined') {
                    $kyc_status = 9;
                  }

                  if ($cur_user_info['submit_kyc_document_datetime']) {
                    $admin_process_kyc_document_tm = strtotime($cur_user_info['submit_kyc_document_datetime']) + 32400; //change to UTC
                    $submit_kyc_document_datetime = date('Y/m/d H:i:s', $admin_process_kyc_document_tm);
                    $sql_add_datetime .= "'" . $submit_kyc_document_datetime . "',";
                  } else {
                    $sql_add_datetime = null;
                  }
                  if ($cur_user_info['card_was_activated_datetime']) {
                    $admin_process_card_activate_tm = strtotime($cur_user_info['card_was_activated_datetime']) + 32400; //change to UTC
                    $card_was_activated_datetime = date('Y/m/d H:i:s', $admin_process_card_activate_tm);
                    $sql_add_datetime .= "'" . $card_was_activated_datetime . "',";
                  } else {
                    $sql_add_datetime = null;
                  }
                  if ($cur_user_info['card_was_issued_datetime']) {
                    $admin_process_card_issued_tm = strtotime($cur_user_info['card_was_issued_datetime']) + 32400; //change to UTC
                    $card_was_issued_datetime = date('Y/m/d H:i:s', $admin_process_card_issued_tm);
                    $sql_add_datetime .= "'" . $card_was_issued_datetime . "',";
                  } else {
                    $sql_add_datetime = null;
                  }
                  //////////////////////////////////////////////////////////////////////////
                  _log($reg_email_address, $sql_add_datetime);
                }
                $sql_add_datetime = isset($sql_add_datetime) ? "'$sql_add_datetime'" : 'NULL';

                $sql_add_status = "
									INSERT INTO cryptocash_user_status (
										email_address, 
										kyc_status, 
										card_activation_status, 
										card_status, 
										payment_status, 
										kyc_file_url, 
										card_activation_file_url, 
										kyc_upload_dt, 
										card_activation_admin_dt, 
										card_issue_dt, 
										created_from
									) 
									VALUES (
										'$reg_email_address', 
										$kyc_status, 
										$card_activation_status, 
										$card_status, 
										$payment_status, 
										'" . $cur_user_info['kyc_file_url'] . "', 
										'$card_activation_file_url', 
										$sql_add_datetime, 
										$sql_add_datetime, 
										$sql_add_datetime, 
										'" . $req_partner['partner'] . "'
									)
								";
              } else {
                $sql_add_status = "INSERT INTO cryptocash_user_status (email_address, created_from) VALUES ('$reg_email_address', '" . $req_partner['partner'] . "')";
              }
              mysqli_query($dbhandle, $sql_add_status);
              if (mysqli_affected_rows($dbhandle) > 0) {
                _log($reg_email_address, "insert new status OK");
              } else {
                _log($reg_email_address, "insert new status FAILED: " . $sql_add_status);
                @mysqli_close($dbhandle);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #4.');
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
              }
            }
            // end add 20230325 cryptocash_user_status k.o

            //save user id from shift
            $sql_check_shift_user_ids = "select * from cryptocash_shift_user_ids where shift_email_address='$reg_email_address' limit 1";
            $rs_check_shift_user_ids = mysqli_query($dbhandle, $sql_check_shift_user_ids);
            if (mysqli_num_rows($rs_check_shift_user_ids) <= 0) {
              $sql_shift_user_id = "INSERT INTO cryptocash_shift_user_ids (shift_email_address, shift_user_sub_id) VALUES ('$reg_email_address', '$shift_user_sub_id')";
              mysqli_query($dbhandle, $sql_shift_user_id);
              if (mysqli_affected_rows($dbhandle) <= 0) {
                _log($reg_email_address, "failed to cryptocash_shift_user_ids !");
                @mysqli_close($dbhandle);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #5.');
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
              } else {
                _log($reg_email_address, "success added to cryptocash_shift_user_ids !");
              }
            } else {
              _log($reg_email_address, "already exists in cryptocash_shift_user_ids, no need to add more");
              $my_shift_user_sub_id = '';
              while ($row_check_shift_user_ids = mysqli_fetch_array($rs_check_shift_user_ids, MYSQLI_ASSOC)) {
                $my_shift_user_sub_id = trim($row_check_shift_user_ids['shift_user_sub_id']);
              }
              if (empty($my_shift_user_sub_id)) {
                _log($reg_email_address, "try update shift_user_sub_id to cryptocash_shift_user_ids...");
                $sql_update_shift_user_ids = "UPDATE cryptocash_shift_user_ids SET shift_user_sub_id='$shift_user_sub_id' WHERE shift_email_address='$reg_email_address' LIMIT 1";
                if (mysqli_query($dbhandle, $sql_update_shift_user_ids)) {
                  _log($reg_email_address, "success update shift_user_sub_id to cryptocash_shift_user_ids: " . $shift_user_sub_id);
                }
              }
            }

            $user_data = array();
            $user_data['shift_user_sub_id'] = $shift_user_sub_id;
            $user_data['email_address'] = $reg_email_address;
            $user_data['auth_token'] = $shift_auth_token;
            $user_data['auth_refresh_token'] = $shift_auth_refresh_token;
            $user_data['expires_in'] = $shift_token_expires_in;
            $user_data['token_type'] = $shift_token_type;

            $the_private_key = "";
            $sql_check_signin = "select * from cryptocash_merchant_user_signin where email_address = '$reg_email_address' and merchant='" . $req_partner['partner'] . "'";
            $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
            if (mysqli_num_rows($rs_check_signin) <= 0) {
              $the_private_key = generateRandomString(128);
              $sql_add_signin = "INSERT INTO cryptocash_merchant_user_signin (email_address, auth_token, auth_refresh_token, wallet_auth_token, wallet_auth_refresh_token, merchant, private_key) VALUES ('$reg_email_address', '" . $user_data['auth_token'] . "', '" . $user_data['auth_refresh_token'] . "', '', '', '" . $req_partner['partner'] . "', '$the_private_key')";
              mysqli_query($dbhandle, $sql_add_signin);
              if (mysqli_affected_rows($dbhandle) > 0) {
                _log($reg_email_address, "insert cryptocash_merchant_user_signin ok for " . $reg_email_address);
              } else {
                @mysqli_close($dbhandle);
                _log($reg_email_address, "insert cryptocash_merchant_user_signin failed:: " . $sql_add_signin);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #6.');
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
              }
            } else { //update
              $cur_auth_token = "";
              while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
                $cur_auth_token = trim($row_signin['auth_token']);
                $the_private_key = trim($row_signin['private_key']);
                if ($the_private_key == "") {
                  $the_private_key = generateRandomString(128);
                }
              }
              $update_signin_dt = date('Y-m-d H:i:s');
              $sql_update_signin = "UPDATE cryptocash_merchant_user_signin SET auth_token='" . $user_data['auth_token'] . "', auth_refresh_token='" . $user_data['auth_refresh_token'] . "', signin_dt='$update_signin_dt', token_refresh_dt = NULL, private_key='$the_private_key' WHERE email_address='$reg_email_address' AND merchant='" . $req_partner['partner'] . "' LIMIT 1";
              if (mysqli_query($dbhandle, $sql_update_signin)) {
                //if (mysqli_affected_rows($dbhandle) > 0) {
                _log($reg_email_address, "update cryptocash_merchant_user_signin ok for " . $reg_email_address);
              } else {
                _log($reg_email_address, "update cryptocash_merchant_user_signin failed:: " . $sql_update_signin);
                @mysqli_close($dbhandle);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #7.');
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
              }
            }

            //try to get account data (wallet address, balance)
            /////////////////////////////////////////////////////////////
            $shift_wallet_arr = array();
            $tmp_dto_arr = array();
            $accounts_res = _shift_getAccountBalance( $user_data['auth_token'] );
            if ($accounts_res['result'] == 'success' && isset($accounts_res['data']['data']['alias_get_accounts_balances'])) {
              if (is_array($accounts_res['data']['data']['alias_get_accounts_balances'])) {
                /////////////////////////////////////////////////////////
                $accounts_arr = $accounts_res['data']['data']['alias_get_accounts_balances'];
                if (count($accounts_arr) > 0) {
                  _log($reg_email_address, "getAccountBalance: ok vao roi");
                  $user_wallet_arr = array();
                  for ($coin_cnt=0; $coin_cnt<count($accounts_arr); $coin_cnt++) {
                    $cur_coin_stat = $accounts_arr[$coin_cnt];
                    unset($shift_wallet_obj);
                    $shift_wallet_obj = array('currency_id' => '', 'balance' => 0);
                    if ( !is_null($cur_coin_stat['currency_id'])) {
                      $shift_wallet_obj['id'] = strtoupper($cur_coin_stat['currency_id']);
                      $shift_wallet_obj['currency_id'] = strtoupper($cur_coin_stat['currency_id']);
                      $shift_wallet_obj['balance'] = format_coin(number_format($cur_coin_stat['total_balance'], 10, '.', ','));
                      if (in_array($shift_wallet_obj['currency_id'], $allowed_currency_arr)) {
                        $allowed_wallet_obj = array();
                        $allowed_wallet_obj = array('currency' => $shift_wallet_obj['currency_id'], 'balance' => $shift_wallet_obj['balance']);
                        $user_wallet_arr[] = $allowed_wallet_obj;
                      }

                      if (in_array($shift_wallet_obj['currency_id'], $allowed_shift_currency_arr)) {
                        $shift_wallet_arr[] = $shift_wallet_obj;
                      }
                    }
                  }
                  $user_data['wallet'] = $user_wallet_arr;
                  if (count($shift_wallet_arr) > 0) {
                    _log($reg_email_address, " vao toi day roi (1)...");
					_log($reg_email_address, json_encode($shift_wallet_arr, JSON_PRETTY_PRINT));
                    $shift_wallet_added_dt = date('Y-m-d H:i:s');
                    for ($s=0; $s<count($shift_wallet_arr); $s++) {
                      $cur_wallet = $shift_wallet_arr[$s];					  
                      if (isset($cur_wallet['id'])) {

                        //check if this currency exists
                        $sql_check_coin = "SELECT * FROM cryptocash_shift_wallet WHERE shift_login_email='$reg_email_address' AND shift_user_sub_id='$shift_user_sub_id' AND shift_account_currency='" . $cur_wallet['currency_id'] . "'";
                        $rs_check_coin = mysqli_query($dbhandle, $sql_check_coin);
                        if (mysqli_num_rows($rs_check_coin) <= 0) {
                          $numberAsString = $cur_wallet['balance'];
                          $numberAsString = str_replace(',', '', $numberAsString);
                          $numberAsString = rtrim($numberAsString, '0');
                          $numberAsString = preg_replace('/\s+/', '', $numberAsString);
                          $curWalletBalance = floatval($numberAsString);

                          $sql_save_shift_wallet = "INSERT INTO cryptocash_shift_wallet (shift_login_email, shift_user_sub_id, shift_account_currency, balance, added_dt, added_dt_tron, added_dt_binance) VALUES ('$reg_email_address', '$shift_user_sub_id', '" . $cur_wallet['currency_id'] . "', '" . $curWalletBalance . "', '$shift_wallet_added_dt', '$shift_wallet_added_dt', '$shift_wallet_added_dt')";

                          mysqli_query($dbhandle, $sql_save_shift_wallet);
                          if (mysqli_affected_rows($dbhandle) <= 0) {
                            _log($reg_email_address, "failed save to cryptocash_shift_wallet ! " . $cur_wallet['currency_id']);
                            @mysqli_close($dbhandle);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #8.');
                            header('Content-Type: application/json');
                            echo json_encode($ret_rs);
                            die();
                          }
                        } else {
						  $cur_balance_db = str_replace(',', '', $cur_wallet['balance']);
                          $sql_update_shift_wallet = "UPDATE cryptocash_shift_wallet SET balance='" . $cur_balance_db . "' WHERE shift_login_email='$reg_email_address' AND shift_user_sub_id='$shift_user_sub_id' AND shift_account_currency='" . $cur_wallet['currency_id'] . "' LIMIT 1";
						  _log($reg_email_address, "sql_update_shift_wallet" . $sql_update_shift_wallet);
                          mysqli_query($dbhandle, $sql_update_shift_wallet);
                        }
                      }
                    }
                  } else {
                    _log($reg_email_address, "error::shift_wallet_arr empty or shift_user_sub_id empty !!!");
                    @mysqli_close($dbhandle);
                    $ret_rs['result'] = 'failed';
                    $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #9.');
                    header('Content-Type: application/json');
                    echo json_encode($ret_rs);
                    die();
                  }
                } else {
                  _log($reg_email_address, "getAccountBalance error array empty");
                  @mysqli_close($dbhandle);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #10.');
                  header('Content-Type: application/json');
                  echo json_encode($ret_rs);
                  die();
                }
              } else {
                _log($reg_email_address, "getAccountBalance error not array");
                @mysqli_close($dbhandle);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #11.');
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
              }
            } else {
              //////////////////////////////////////////////////////////
              _log($reg_email_address, " failed getting wallet data, try adding default values...");
              for ($coin_cnt=0; $coin_cnt<count($allowed_currency_arr); $coin_cnt++) {
                $cur_coin = $allowed_currency_arr[$coin_cnt];
                unset($allowed_wallet_obj);
                $allowed_wallet_obj = array();
                $allowed_wallet_obj = array('currency' => strtoupper($cur_coin), 'balance' => format_coin(number_format(0, 10, '.', ',')));
                $user_wallet_arr[] = $allowed_wallet_obj;
              }
              $user_data['wallet'] = $user_wallet_arr;
              if (count($user_wallet_arr) > 0) {
                _log($reg_email_address, " vao toi day roi (2)...");
                $shift_wallet_added_dt = date('Y-m-d H:i:s');
                for ($s=0; $s<count($user_wallet_arr); $s++) {
                  $cur_wallet = $user_wallet_arr[$s];

                  //check if this currency exists
                  $sql_check_coin = "SELECT * FROM cryptocash_shift_wallet WHERE shift_login_email='$reg_email_address' AND shift_user_sub_id='$shift_user_sub_id' AND shift_account_currency='" . $cur_wallet['currency'] . "'";
                  $rs_check_coin = mysqli_query($dbhandle, $sql_check_coin);
                  if (mysqli_num_rows($rs_check_coin) <= 0) {
                    $sql_save_shift_wallet = "INSERT INTO cryptocash_shift_wallet (shift_login_email, shift_user_sub_id, shift_account_currency, balance, added_dt, added_dt_tron, added_dt_binance) VALUES ('$reg_email_address', '$shift_user_sub_id', '" . $cur_wallet['currency'] . "', '" . $cur_wallet['balance'] . "', '$shift_wallet_added_dt', '$shift_wallet_added_dt', '$shift_wallet_added_dt')";

                    mysqli_query($dbhandle, $sql_save_shift_wallet);
                    if (mysqli_affected_rows($dbhandle) <= 0) {
                      _log($reg_email_address, "failed save to cryptocash_shift_wallet ! " . $cur_wallet['currency_id']);
                      @mysqli_close($dbhandle);
                      $ret_rs['result'] = 'failed';
                      $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #8.');
                      header('Content-Type: application/json');
                      echo json_encode($ret_rs);
                      die();
                    }
                  } else {
                    $sql_update_shift_wallet = "UPDATE cryptocash_shift_wallet SET balance='" . $cur_wallet['balance'] . "' WHERE shift_login_email='$reg_email_address' AND shift_user_sub_id='$shift_user_sub_id' AND shift_account_currency='" . $cur_wallet['currency'] . "' LIMIT 1";
                    mysqli_query($dbhandle, $sql_update_shift_wallet);
                  }
                }
              } else {
                _log($reg_email_address, "error::shift_wallet_arr empty or shift_user_sub_id empty !!!");
                @mysqli_close($dbhandle);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #9.');
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
              }
            }

            @mysqli_close($dbhandle);
          } else {
            _log($reg_email_address, "could not connect db when add to cryptocash_users_profile !");
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #13.');
            header('Content-Type: application/json');
            echo json_encode($ret_rs);
            die();
          }

          //PostAffiliatePro
          $target_pap_merchant_username = "";
          $target_pap_merchant_password = "";
          $target_pap_merchant_url = "";
          if ($req_partner['partner'] == 'XEXON') {
            $target_pap_merchant_username = MERCHANT_USERNAME_XEXON;
            $target_pap_merchant_password = MERCHANT_PASSWORD_XEXON;
            $target_pap_merchant_url = PAP_URL_XEXON;
          } else if ($req_partner['partner'] == 'ULTIMOPAY') {
            $target_pap_merchant_username = MERCHANT_USERNAME;
            $target_pap_merchant_password = MERCHANT_PASSWORD;
            $target_pap_merchant_url = PAP_URL;
          } else if ($req_partner['partner'] == 'ULTIMOPAYMENT') {
            $target_pap_merchant_username = MERCHANT_USERNAME;
            $target_pap_merchant_password = MERCHANT_PASSWORD;
            $target_pap_merchant_url = PAP_URL;
          } else if ($req_partner['partner'] == 'BOS') {
            $target_pap_merchant_username = MERCHANT_USERNAME;
            $target_pap_merchant_password = MERCHANT_PASSWORD;
            $target_pap_merchant_url = PAP_URL;
          }
          if( strlen($target_pap_merchant_url) > 0) {
            $raw_pap_merchant_login_obj = PapLogin($target_pap_merchant_url, $target_pap_merchant_username, $target_pap_merchant_password, "merchant");
            if (!empty($raw_pap_merchant_login_obj)) {
              $pap_affiliate_obj = PapUserCheck($reg_email_address, $raw_pap_merchant_login_obj);
              if ($pap_affiliate_obj['userid'] == '') { //user does not exist, create it (no parent) !
                _log($reg_email_address, "postaffiliate a/c not found, try to create one...");
                $res_user = PapCreateUser($target_pap_merchant_url, $reg_email_address, $reg_email_address, $reg_email_address, $reg_password, "", $raw_pap_merchant_login_obj);
                if (($res_user['userid'] != '') && ($res_user['refid'] != '')) {
                  _log($reg_email_address, "successfully added affiliate : userid=" . $res_user['userid'] . " / refid=" . $res_user['refid']);
                } else {
                  _log('', $res_user['error']);
                }
              } else {
                _log($reg_email_address, "postaffiliate a/c existed, no need to create");
              }
            } else {
              _log($reg_email_address, "failed to login as merchant !");
            }
          }

          $ret_user_data = array();
          $ret_user_data['shift_user_sub_id'] = $user_data['shift_user_sub_id'];
          $ret_user_data['email_address'] = $user_data['email_address'];
          $ret_user_data['auth_token'] = $the_private_key;
          $ret_user_data['expires_in'] = $user_data['expires_in'];
          $ret_user_data['wallet'] = $user_data['wallet'];
          $ret_rs['result'] = 'success';
          $ret_rs['signinResponse'] = $ret_user_data;
          header('Content-Type: application/json');
          echo json_encode($ret_rs);
          die();
        } else {
          _log($reg_email_address, "all data returned empty !");
          $ret_rs['result'] = 'failed';
          $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'error occured. please contact administrator for help #14.');
          header('Content-Type: application/json');
          echo json_encode($ret_rs);
          die();
        }
      } else {
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = $errors[0];
        _log("", $ret_rs['error']['errorMessage']);
        header('Content-Type: application/json');
        echo json_encode($ret_rs);
        die();
      }
    }
  } else {
    header('HTTP/1.0 403 Forbidden');
  }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
  http_response_code(405);
  die();
}
