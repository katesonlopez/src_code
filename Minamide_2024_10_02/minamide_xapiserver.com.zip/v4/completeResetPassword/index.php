<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($line) {
    $fh2 = fopen(dirname(__FILE__) . "/log/debug.log" , 'a');
    $fline = date('[Ymd H:i:s] ') . $line."\n";
    fwrite($fh2, $fline);
    fclose($fh2);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../include/dbconfig.php';
    $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (mysqli_connect_errno() != 0) {
        header('Content-Type: application/json');
        http_response_code(500);
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
        echo json_encode($ret_rs);
        die();
    } else {
        _log("ket noi thanh cong");
        mysqli_query($dbhandle, "set names utf8;");
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
    $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
    $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
    $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
    $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
    $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
    $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
    $clientSecret4 = 'climbpot api access key';
    $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
    $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
    $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
    $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
    $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
    $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
    //$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
    $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
    $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
    $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
    $found = 0;
    $coin = 'USDT';
    $sandbox = 0;
    $partner = "";
    $req_api_key = "";
    $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
    foreach (getallheaders() as $name => $value) {
        if ($name == 'Authorization') {
            $req_api_key = trim($value);
            $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
            $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
            if (mysqli_num_rows($partner_rs) > 0) {
                while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
                    $cur_api_key = "Bearer " . $row_partner['api_key'];
                    if ($req_api_key == $cur_api_key) {
                        $req_partner['partner'] = trim($row_partner['partner']);
                        $req_partner['api_key'] = trim($row_partner['api_key']);
                        $req_partner['website'] = trim($row_partner['website']);
                        $selected_api_key = $req_api_key;
                        break;
                    }
                }
            } else {
                _log("not found in db");
            }
        }
    }
    @mysqli_close($dbhandle);


    function isValidPassword($password) {
        if (!preg_match_all('$\S*(?=\S{6,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
            return FALSE;
        return TRUE;
    }

    if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);

        if (!($data)) {

            switch (json_last_error()) {
                case JSON_ERROR_DEPTH:
                    _log('Reached the maximum stack depth');
                    break;
                case JSON_ERROR_STATE_MISMATCH:
                    _log('Incorrect discharges or mismatch mode');
                    break;
                case JSON_ERROR_CTRL_CHAR:
                    _log('Incorrect control character');
                    break;
                case JSON_ERROR_SYNTAX:
                    _log('Syntax error or JSON invalid');
                    break;
                case JSON_ERROR_UTF8:
                    _log('Invalid UTF-8 characters, possibly invalid encoding');
                    break;
                default:
                    _log('Unknown error');
                    break;
            }

            _log('A non-empty request body is required.');
            header('Content-Type: application/json');
            http_response_code(400);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
            echo json_encode($ret_rs);
            die();
        } else {
            unset($errors);
            $errors = array();

            //email
            if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
                $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
                $errors[] = $error_obj;
            }

            //verification code
            if ((!isset($data['verification_code'])) || (empty($data['verification_code']))) {

                $error_obj = array('errorCode' => 3, 'errorMessage' => 'verification_code parameter is required.');
                $errors[] = $error_obj;
            }

            //password
            if ((!isset($data['password'])) || (empty($data['password']))) {
                $error_obj = array('errorCode' => 4, 'errorMessage' => 'password parameter is required.');
                $errors[] = $error_obj;
            } else {
                if (strlen($data['password'])<6) {
                    $error_obj = array('errorCode' => 5, 'errorMessage' => 'password must have at least 6 characters');
                    $errors[] = $error_obj;
                } else {
                    if (strlen($data['password'])>60) {
                        $error_obj = array('errorCode' => 6, 'errorMessage' => 'password cannot be longer than 60 characters');
                        $errors[] = $error_obj;
                    } else {
                        if(!isValidPassword($data['password'])) {
                            $error_obj = array('errorCode' => 7, 'errorMessage' => 'password must have least 1 numeric character, 1 upper case character, 1 symbol character.');
                            $errors[] = $error_obj;
                        } else {


                            //TODO

                        }
                    }
                }
            }

            if (count($errors) == 0) {
                $errors_sub = array();
                //proceed to shift api
                require_once '../include/common.php';
                ////////////////////////////////////////////////////

                //receive POST params
                $reg_email_address = strtolower(trim($data['email_address']));
                $verification_code = trim($data['verification_code']);
                $the_pwd = trim($data['password']);
                _log("complete reset password started...");

                $post_data = array();
                $post_data['ClientId'] = $aws_cognito_app_client_id;
                $post_data['Username'] = $reg_email_address;
                $post_data['ConfirmationCode'] = $verification_code;
                $post_data['Password'] = $the_pwd;
                $post_data['exchange'] = "PLUSQO";

                $change_password_res = api_call('/authentication/user_authentication/completeForgotPassword', 0, '', $post_data, '');
                if (($change_password_res['http_code'] == "200") || ($change_password_res['http_code'] == "200 OK")) {

                    $complete_reset_password_response = array('email_address' => $reg_email_address,  'completeResetPassword' => true);
                    $ret_rs['result'] = 'success';
                    $ret_rs['resetPasswordResponse'] = $complete_reset_password_response;
                    header('Content-Type: application/json');
                    echo json_encode($ret_rs);
                    die();

                } else {
                    $_error_type = (!empty($change_password_res['result']['__type']))?$change_password_res['result']['__type']:'';
                    $_error_message = (!empty($change_password_res['result']['message']))?$change_password_res['result']['message']:'';
                    if (($_error_type == 'CodeMismatchException') || (strpos(strtolower($_error_message), "invalid verification code") !== false)) {
                        $ret_rs['result'] = 'failed';
                        $ret_rs['error'] = array('errorCode' => 8, 'errorMessage' => 'invalid verification code.');
                        header('Content-Type: application/json');
                        echo json_encode($ret_rs);
                        die();
                    } else if (($_error_type == 'InvalidPasswordException') || (strpos(strtolower($_error_message), "password does not conform to policy") !== false)) {
                        $ret_rs['result'] = 'failed';
                        $ret_rs['error'] = array('errorCode' => 9, 'errorMessage' => 'Password length must be between 6 and 60 characters, and contains at least 1 numeric character, 1 lowercase character, 1 uppercase character, and 1 symbol character');
                        header('Content-Type: application/json');
                        echo json_encode($ret_rs);
                        die();
                    } else {
                        $ret_rs['result'] = 'failed';
                        $ret_rs['error'] = array('errorCode' => 10, 'errorMessage' => 'unknown error occurred. please contact administrator for help');
                        header('Content-Type: application/json');
                        echo json_encode($ret_rs);
                        die();
                    }
                }
            } else {
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = $errors[0];
                _log($ret_rs['error']['errorMessage']);
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
            }
        }
    } else {
        header('HTTP/1.0 403 Forbidden');
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
    http_response_code(405);
    die();
}