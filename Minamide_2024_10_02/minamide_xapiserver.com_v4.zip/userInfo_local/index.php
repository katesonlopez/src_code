<?php
// Enable error logging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// CORS headers for all requests
header('Access-Control-Allow-Origin: http://localhost:8000');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, X-Requested-With, Authorization');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 3600'); // Cache for 1 hour

// Log request method for debugging
error_log("Request method: " . $_SERVER['REQUEST_METHOD']);

// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(200);  // Ensure HTTP 200 OK is returned
  exit();
}

// Set Content-Type header to JSON
header('Content-Type: application/json');

$response = [
    "result" => "success",
    "userInfoResponse" => [
        "email_address" => "agent-tool-test@ruru.be",
        "kyc_deny_message" => "dlfjsdjf sdfjd f fdlf dskf dfldskfklds fdsfkds fklds",
    ]
];

// Output the JSON response
echo json_encode($response);
exit;
