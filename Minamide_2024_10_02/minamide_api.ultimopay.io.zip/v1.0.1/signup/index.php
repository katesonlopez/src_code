<?php
mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				break;
			}
		}
	}

	function _log($line) {
		//global $fh;
		$fh2 = fopen("/var/www/api.ultimopay.io/v1/signup/log/signup.log" , 'a');
		$fline = date('[Ymd H:i:s] ') . $line."\n";
		fwrite($fh2, $fline);
		fclose($fh2);
		//echo date('[Ymd H:i:s] ').$line."\n";
		//@ob_flush(); 
		//flush();
	}

	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}


	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	_log("bat dau xu ly...");
	if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6)) {


		
		
		//$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);
		
		//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
		//echo "payment_id: " . $payment_id . "<br/>";
		$json = file_get_contents('php://input');
		$data = json_decode($json, true);
		
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					//$failed_rs['error'] = 'Reached the maximum stack depth';
					_log('Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					_log('Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					//$failed_rs['error'] = 'Incorrect control character';
					_log('Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					//$failed_rs['error'] = 'Syntax error or JSON invalid';
					_log('Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					_log('Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					//$failed_rs['error'] = 'Unknown error';
					_log('Unknown error');
					break;
			}
			
			//throw new Exception($error);
			//_log($failed_rs['error']);
			_log('A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			} else {
				if (!filter_var($data['email_address'], FILTER_VALIDATE_EMAIL)) {
					//echo "<br>invalid email format !";
					$error_obj = array('errorCode' => 3, 'errorMessage' => 'invalid email address format.');
					$errors[] = $error_obj;
				} else {
					//echo "<br>" . $email . " is valid !";
				}
			}
			
			//password
			if ((!isset($data['password'])) || (empty($data['password']))) {
				$error_obj = array('errorCode' => 4, 'errorMessage' => 'password parameter is required.');
				$errors[] = $error_obj;
			} else {
				if (strlen($data['password'])<6) {
					$error_obj = array('errorCode' => 5, 'errorMessage' => 'password must have at least 6 characters');
					$errors[] = $error_obj;
				} else {
					if (strlen($data['password'])>60) {
						$error_obj = array('errorCode' => 6, 'errorMessage' => 'password cannot be longer than 60 characters');
						$errors[] = $error_obj;
					} else {
						if(!isValidPassword($data['password'])) { 
							$error_obj = array('errorCode' => 7, 'errorMessage' => 'password must have least 1 numeric character, 1 upper case character, 1 symbol character.');
							$errors[] = $error_obj;
						} else {
							
							
							//TODO
							
						}
					}
				}
			}
			
			//first name
			if ((!isset($data['first_name'])) || (empty($data['first_name']))) {
				
				$error_obj = array('errorCode' => 8, 'errorMessage' => 'first_name parameter is required.');
				$errors[] = $error_obj;
			} else {
				//if(!preg_match("/[^[:alnum:]\#?!@$%^&*-_ ]/", $data['first_name']))  {
				if (preg_match("/^[a-zA-Z ]+$/", $data['first_name'])) {
					//echo "<br>" . $myname . " is a valid name";
				} else {
					$error_obj = array('errorCode' => 9, 'errorMessage' => 'first_name contains invalid characters.');
					$errors[] = $error_obj;
				}
			}
			//last name
			if ((!isset($data['last_name'])) || (empty($data['last_name']))) {
				
				$error_obj = array('errorCode' => 10, 'errorMessage' => 'last_name parameter is required.');
				$errors[] = $error_obj;
			} else {
				//if(!preg_match("/[^[:alnum:]\#?!@$%^&*-_ ]/", $data['last_name']))  {
				if (preg_match("/^[a-zA-Z ]+$/", $data['last_name'])) {
					//echo "<br>" . $myname . " is a valid name";
				} else {
					$error_obj = array('errorCode' => 11, 'errorMessage' => 'last_name contains invalid characters.');
					$errors[] = $error_obj;
				}
			}
			
			
			//country
			if ((!isset($data['country'])) || (empty($data['country']))) {
				
				$error_obj = array('errorCode' => 12, 'errorMessage' => 'country parameter is required.');
				$errors[] = $error_obj;
			} else {
				//if(!preg_match("/[^[:alnum:]\#?!@$%^&-_ ]/",$data['country']))  {
				//if (preg_match("/^[a-zA-Z0-9 ]+$/", $data['country'])) {
				//if (!preg_match ("/^[a-zA-Z0-9 \.+-\']*$/", $data['country']) ){  
				if (!preg_match ("/^[\'\+\-\w\s]*$/", $data['country']) ){  
					//echo "<br>" . $myname . " is a valid name";
					$error_obj = array('errorCode' => 13, 'errorMessage' => 'country contains invalid characters.');
					$errors[] = $error_obj;
				} else {
					
				}
			}
			
			
			if (count($errors) == 0) {
				
				$errors_sub = array();
				
				
				//proceed to shift api
				require_once '../include/common.php';
				require_once '../include/dbconfig.php';
				require_once('../classes/PostAffiliatePro/PapApi.class.php');
				
				////////////////////////////////////////////////////
				function PapLogin($_pap_url, $_username, $_password, $_type){    

					try {

						if ($_type == "merchant") {
							$_merchant_session = new Pap_Api_Session($_pap_url); 
							if(!$_merchant_session->login($_username, $_password)) {
								//die("Cannot login. Message: ".$_merchant_session->getMessage());
								//_log("Merchant Cannot login: ".$_merchant_session->getMessage());
								return;
							}
							return $_merchant_session;

						} else if ($_type == "affiliate") {
							$_aff_session = new Pap_Api_Session($_pap_url); 
							if(!$_aff_session->login($_username,$_password, Pap_Api_Session::AFFILIATE)) {
								//die("Cannot login. Message: ".$_aff_session->getMessage());
								//_log("Affiliate (" . $_username . ") Cannot login: ".$_aff_session->getMessage());
								return;        
								
							}
							return $_aff_session;
							
						}
						
					} catch (Exception $e){
						//die('Error: '.$e->getMessage());
						//_log('Error: '.$e->getMessage());
						return;
						
					}

				}

				function GetUserIdByRefId($_refid, $_merchant_session) {
					$affiliate_user = array('userid' => '', 'username' => '', 'refid' => '', 'error' => '');
					$pap_user_check_request = new Pap_Api_AffiliatesGrid($_merchant_session);
					//Filtering affiliate with refid
					$pap_user_check_request->addFilter('refid', Gpf_Data_Filter::EQUALS, $_refid);

					// sets limit to 30 rows, offset to 0 (first row starts)
					$pap_user_check_request->setLimit(0, 30);

					// sets columns, use it only if you want retrieve other as default columns
					$pap_user_check_request->addParam('columns', new Gpf_Rpc_Array(array(array('id'), array('refid'), array('userid'), 
					array('username'), array('firstname'), array('lastname'), array('rstatus'), array('parentuserid'),
					array('dateinserted'), array('salesCount'), array('clicksRaw'), array('clicksUnique'))));

					// send request
					try {
						$pap_user_check_request->sendNow();
						// request was successful, get the grid result
						$grid = $pap_user_check_request->getGrid();

						// get recordset from the grid
						$pap_user_check_recordset = $grid->getRecordset();	
						
						if (!empty($pap_user_check_recordset)) {
							foreach($pap_user_check_recordset as $rec) {
								if ((trim($rec->get('userid')) != '')  && (trim($rec->get('username')) != '')){
									$affiliate_user['userid'] = $rec->get('userid');
									$affiliate_user['refid'] = $rec->get('refid');
									$affiliate_user['username'] = $rec->get('username');
									break;
								}				
							}
						}
					} catch(Exception $e) {
						//die("API call error: ".$e->getMessage());
						//_log("GetUserIdByRefId::API call error: ".$e->getMessage());
						$affiliate_user['error'] = $e->getMessage();
						return $affiliate_user;
					}

					
					return $affiliate_user;
				}
				
				$affiliate_parent_user_id = "";
				$allow_countries = array("Abkhazia", "Cape Verde", "Cook Islands", "Ethiopia", "Artsakh", "Niue", "Pakistan", "Palestine", "Transnistria", "Serbia", "Somaliland", "South Ossetia", "Sri Lanka", "Syria", "Trinidad and Tobago", "Tunisia", "Venezuela", "Western Sahara", "Yemen", "Zimbabwe", "Iran", "Curacao");
				
				$country_arr = array('United States', 'Abkhazia', 'Afghanistan', 'Albania', 'Algeria', 'Andorra', 'Angola', 'Antigua and Barbuda', 'Argentina', 'Armenia', 'Artsakh', 'Australia', 'Austria', 'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bhutan', 'Bolivia', 'Bosnia and Herzegovina', 'Brazil', 'Brunei', 'Bulgaria', 'Burkina Faso', 'Burundi', 'Cabo Verde', 'Cambodia', 'Cameroon', 'Canada', 'Central African Republic', 'Chad', 'Chile', 'China', 'Colombia', 'Comoros', 'Congo', 'Cook Islands', 'Costa Rica', 'Cote d\'Ivoire', 'Croatia', 'Cuba', 'Curacao', 'Cyprus', 'Czech Republic', 'Denmark', 'Djibouti', 'Dominica', 'Dominican Republic', 'East Timor', 'Egypt', 'El Salvador', 'Equatorial Guinea', 'Eritrea', 'Estonia', 'Ethiopia', 'Fiji', 'Finland', 'France', 'Gabon', 'Gambia', 'Georgia', 'Germany', 'Ghana', 'Gibraltar', 'Greece', 'Grenada', 'Guatemala', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Honduras', 'Hong Kong', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iraq', 'Iran', 'Ireland', 'Israel', 'Italy', 'Jamaica', 'Japan', 'Jordan', 'Kazakhstan', 'Kenya', 'Kiribati', 'South Korea', 'Kosovo', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Latvia', 'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Macedonia', 'Madagascar', 'Malawi', 'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Mauritania', 'Mauritius', 'Mexico', 'Federated States of Micronesia', 'Moldova', 'Monaco', 'Mongolia', 'Montenegro', 'Mozambique', 'Myanmar', 'Namibia', 'Nauru', 'Nepal', 'Netherlands', 'New Zealand', 'Nicaragua', 'Niger', 'Nigeria', 'Niue', 'Norway', 'Oman', 'Pakistan', 'Palau', 'Palestine', 'Panama', 'Papua New Guinea', 'Paraguay', 'Peru', 'Philippines', 'Poland', 'Portugal', 'Qatar', 'Romania', 'Russia', 'Rwanda', 'Saint Kitts and Nevis', 'Saint Lucia', 'Saint Vincent and the Grenadines', 'Samoa', 'San Marino', 'Serbia', 'Sao Tome and Principe', 'Saudi Arabia', 'Senegal', 'Seychelles', 'Sierra Leone', 'Singapore', 'Slovakia', 'Slovenia', 'Solomon Islands', 'Somalia', 'Somaliland', 'South Africa', 'South Ossetia', 'Spain', 'Sri Lanka', 'Sudan', 'South Sudan', 'Suriname', 'Syria', 'Swaziland', 'Sweden', 'Switzerland', 'Taiwan', 'Tajikistan', 'Tanzania', 'Thailand', 'Togo', 'Tonga', 'Transnistria', 'Trinidad and Tobago', 'Tunisia', 'Turkey', 'Turkmenistan', 'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'Uruguay', 'Uzbekistan', 'Vanuatu', 'Vatican City', 'Venezuela', 'Vietnam', 'Yemen', 'Zambia', 'Zimbabwe', 'Western Sahara');
				
				
				//receive POST params
				$reg_email_address = trim($data['email_address']);
				$reg_password = trim($data['password']);
				$reg_first_name = trim($data['first_name']);
				$reg_last_name = trim($data['last_name']);
				$reg_country = trim($data['country']);
				$reg_country_shift = $reg_country;
				_log("sign up started...");
				_log($reg_email_address . " / ". $reg_password . " / " . $reg_first_name . " / " . $reg_last_name . " / " . $reg_country);
				if (!in_array($reg_country, $country_arr))  {
					$reg_country_shift = "Philippines";
				} else {
					if (strtoupper($reg_country) == "GIBRALTAR") {
						$reg_country_shift = "United Kingdom";
					}
					if (strtoupper($reg_country) == "HONG KONG") {
						$reg_country_shift = "China";
					}				
					if (in_array($reg_country, $allow_countries))  {
						$reg_country_shift = "Philippines";				
					}
				}
				
				$post_data = array();
				$post_data['username'] = $reg_email_address;
				$post_data['password'] = $reg_password;
				$post_data['exchange'] = "PLUSQO";
				
				//given name
				$given_name_arr = array();
				$given_name_arr['name'] = "custom:given_name";
				$given_name_arr['value'] = $reg_first_name;
				
				//surname
				$surname_arr = array();
				$surname_arr['name'] = "custom:surname";
				$surname_arr['value'] = $reg_last_name;
				
				//country
				$country_arr = array();
				$country_arr['name'] = "custom:country";
				$country_arr['value'] = $reg_country_shift;
				
				$attributes = array();
				$attributes[] = $given_name_arr;
				$attributes[] = $surname_arr;
				$attributes[] = $country_arr;
				
				$post_data['userAttributes'] = $attributes;
				
				$signup_res = api_call('/authentication/user_authentication/signUp', 0, '', $post_data, '');
				if (($signup_res['result']['message'] == "") &&  (!is_null($signup_res['result']['signUpResponse'])))   {	
				//if ( (isset($signup_res['result']['client_user_id'])) && (isset($signup_res['result']['username'])) && (isset($signup_res['result']['user_id'])) ) {
					
					/*
					$data['msg'] = 'proc_ok';
					$data['msg_ex'] = 'signup was successful';
					$data['email'] = $email;
					$data['given_name'] = $firstname;
					$data['sur_name'] = $lastname;
					$data['country'] = $country_shift;
					_log("email: " . $signup_res['result']['signUpResponse']['codeDeliveryDetails']['destination']);
					*/
					
					//PostAffiliatePro (SignUp)
					//sleep(1);				
					$raw_pap_merchant_login_obj = PapLogin(PAP_URL, MERCHANT_USERNAME, MERCHANT_PASSWORD, "merchant");
					if ((!is_null($raw_pap_merchant_login_obj)) && (!empty($raw_pap_merchant_login_obj))) {
						$affiliate = new Pap_Api_Affiliate($raw_pap_merchant_login_obj);
						$affiliate->setUsername($reg_email_address);
						$affiliate->setFirstname($reg_first_name);
						$affiliate->setLastname($reg_first_name);
						$affiliate->setNotificationEmail($reg_email_address);
						//if ($affiliate_parent_user_id != "") {
						//	$affiliate->setParentUserId($affiliate_parent_user_id);
						//}
						
						$affiliate->setPassword($reg_password);
						//$affiliate->setVisitorId($visitor_id);
						try {
							if ($affiliate->add()) {
								_log($reg_email_address . "::Affiliate saved successfuly id: " . $affiliate->getUserid() . " / refid: " . $affiliate->getRefid());
							} else {
								_log($reg_email_address . "::Cannot save affiliate: ".$affiliate->getMessage());
							}
						} catch (Exception $e) {
							_log("Error while communicating with PAP: ".$e->getMessage());
						}

					} else {
						_log($email . "::failed to login as merchant !");
					}
					
					//add data to users_profile		
					$shift_full_name = $reg_first_name . " " . $reg_last_name;
					$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
					if (mysqli_connect_errno() == 0) {
						mysqli_query($dbhandle, "set names utf8;");
						$sql_add_profile = "INSERT INTO cryptocash_users_profile (email, given_name, sur_name, shift_full_name, country, add_dt, pap_cookie, refid, parent_userid) VALUES ('$reg_email_address', '$reg_first_name', '$reg_last_name', '$shift_full_name', '$reg_country', NOW(), '', '', '')";
						_log($sql_add_profile);
						mysqli_query($dbhandle, $sql_add_profile);
						if (mysqli_affected_rows($dbhandle) <= 0) {
							
							_log($reg_email_address . ": insert cryptocash_users_profile failed");
						}
						
						@mysqli_close($dbhandle);
						
					} else {			
						_log($reg_email_address . "::could not connect db when add to cryptocash_users_profile !");
						
					}
					
					
					$signup_response = array('email_address' => $reg_email_address, 'signupConfirmed' => false);
					$ret_rs['result'] = 'success';
					$ret_rs['signupResponse'] = $signup_response;
					//$ret_rs['signupDateTime'] = $reg_email_address;
					header('Content-Type: application/json');
					echo json_encode($ret_rs);
					die();
					/////////////////////////////////////////////////////////////////////////////////////
					//old code add db
					
				} else {
					
					if ( strpos(strtolower($signup_res['result']['message']), "already exists") !== false ) {
						/*
						//$data['msg_ex'] = $signup_res['result']['message'];					
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 14, 'errorMessage' => 'An account with the given email address already exists.');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
						*/
						$post_data_ex = array();
						$post_data_ex['username'] = $reg_email_address;
						$post_data_ex['code'] = "12345678";
						$post_data_ex['exchange'] = "PLUSQO";
						///////////////////////////////////////////////////////
						$verify_res = api_call('/authentication/user_authentication/confirmSignUp', 0, '', $post_data_ex, '');
						if ($verify_res['result']['result'] === true) {
						//if (($verify_res['result']['message'] == "") &&  (!is_null($verify_res['result']['confirmSignUpResponse'])))   {	
						//if ( (isset($signup_res['result']['client_user_id'])) && (isset($signup_res['result']['username'])) && (isset($signup_res['result']['user_id'])) ) {
							_log("vao day ok...");
							_log("shift message : " . $verify_res['result']['message']);
							/*
							if (($verify_res['result']['message'] == "") &&  (!is_null($verify_res['result']['confirmSignUpResponse'])))   {
								$confirmed_signup_response = array('email_address' => $reg_email_address, 'signupConfirmed' => true);
								$ret_rs['result'] = 'success';
								$ret_rs['signupResponse'] = $confirmed_signup_response;
								//$ret_rs['signupDateTime'] = $reg_email_address;
								header('Content-Type: application/json');
								echo json_encode($ret_rs);
								die();
							}
							*/
							
						} else {
							_log("vao day NG...");
							_log("shift message : " . $verify_res['result']['message']);
							if (( strpos(strtolower($verify_res['result']['message']), "user cannot be confirmed") !== false ) || ( strpos(strtolower($verify_res['result']['message']), "current status is confirmed") !== false )) { //already been a confimed user
								//$data['msg_ex'] = $signup_res['result']['message'];					
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => 14, 'errorMessage' => 'An account with the given email address already exists. Please use another email address.');
								header('Content-Type: application/json');
								echo json_encode($ret_rs);
								die();
							} else {
								if (( strpos(strtolower($verify_res['result']['message']), "not found") !== false )) {
									/*
									$detailed_error_msg = 'Data not found for the email address: ' . $reg_email_address;
									$ret_rs['result'] = 'failed';
									$ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => $detailed_error_msg);
									header('Content-Type: application/json');
									echo json_encode($ret_rs);
									die();
									*/
								} else if (( strpos(strtolower($verify_res['result']['message']), "invalid verification code") !== false )) {
									
									$ret_rs['result'] = 'failed';
									$ret_rs['error'] = array('errorCode' => 15, 'errorMessage' => 'This account has not completed sign up yet.');
									header('Content-Type: application/json');
									echo json_encode($ret_rs);
									die();
								} else if (( strpos(strtolower($verify_res['result']['message']), "invalid code") !== false )) {
									$ret_rs['result'] = 'failed';
									$ret_rs['error'] = array('errorCode' => 15, 'errorMessage' => 'This account has not completed sign up yet.');
									header('Content-Type: application/json');
									echo json_encode($ret_rs);
									die();
								}
								
							}
							
							
						}
						
						///////////////////////////////////////////////////////
					} else {
						//$data['msg_ex'] = "Password must be 6 characters or more and combine numbers, lowercase letters, uppercase letters, and symbols.<br/>For example: abc1A#";
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 16, 'errorMessage' => 'Password length must be between 6 and 60 characters, and contains at least 1 numeric character, 1 lowercase character, 1 uppercase character, and 1 symbol character');
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					}
					
					//if (isset($signup_res['result']['message'])) {
					//	_log($signup_res['result']['message']);	
					//} else {
					//	_log($email . "::unknown shift error");	
					//}
					

				}
				
				/*
				////$visitor_id = isset($_POST['VisitorId'])?($_POST['VisitorId']):'';
				$visitor_id = isset($_POST['papCookie'])?($_POST['papCookie']):'';
				$refid = isset($_POST['UltimopayAffRefId'])?($_POST['UltimopayAffRefId']):'';
				$refid = trim($refid);
				_log("refid=" . $refid);
				
				$pap_visitorId = (isset($_COOKIE['PAPVisitorId']))?htmlentities($_COOKIE['PAPVisitorId'], 3, 'UTF-8'):"";
				
				_log($email . "::visitor_id = " . $visitor_id . " / pap_visitorId = " . $pap_visitorId);
				if ($visitor_id == '') {
					if ($pap_visitorId != '') {
						$visitor_id = $pap_visitorId;
						_log($email . "::replaced by pap_visitorId !");
					}
				}
				
				if (isset($_COOKIE['UltimopayAffRefId'])) {
					_log($_COOKIE['UltimopayAffRefId'] . " = " . $refid);
					$refid = $_COOKIE['UltimopayAffRefId'];
				}
				
				
				//PostAffiliatePro
				//fetch affiliate parent if have any
				$raw_pap_merchant_login_obj = PapLogin(PAP_URL, MERCHANT_USERNAME, MERCHANT_PASSWORD, "merchant");
				if ((!is_null($raw_pap_merchant_login_obj)) && (!empty($raw_pap_merchant_login_obj))) {
					$pap_affiliate_obj = GetUserIdByRefId($refid, $raw_pap_merchant_login_obj);
					if ($pap_affiliate_obj['userid'] == '') {
						_log("User with refid=" . $refid . " not found !");
					} else {
						_log("found userid = " . $pap_affiliate_obj['userid'] . " for refid=" . $refid);
						$affiliate_parent_user_id = $pap_affiliate_obj['userid'];
						//echo "found user: " . $pap_affiliate_obj['username'] . " with following information:<br/>===================================<br/>";
						//echo "userid: " .  $pap_affiliate_obj['userid'] . "<br/>"; 
						//echo "refid: " .  $pap_affiliate_obj['refid'] . "<br/>"; 
					}
					
				} else {
					_log($reg_email_address . "::failed to login as merchant ! Cannot get userid of parent affiliate !");
				}
				*/
				////////////////////////////////////////////////////

				
				
				/*
				//prepare data
				//OLD CODE HERE...
				//SELECT from_unixtime(updated_dt, '%Y-%m-%d %H:%i:%s') as updated_dt FROM `cryptocash_merchant_links` WHERE 1
				
				$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
				if (mysqli_connect_errno() == 0) {
					
					$sql_find_merchant_link = "SELECT * FROM cryptocash_merchant_links WHERE client_id = '" . trim($data['user_id']) . "' AND merchant='" . trim($data['merchant']) . "' AND status=1";
					_log($sql_find_merchant_link);
					$rs_find_merchant_link = mysqli_query($dbhandle, $sql_find_merchant_link);
					if (mysqli_num_rows($rs_find_merchant_link) > 0) {
						$current_linked_account = array('email_address' => '', 'merchant' => '', 'client_id' => '', 'linked_tm' => 0, 'unlinked_tm' => 0, 'status' => 0);
						//$db_merchant_rs = array('merchant' => '', 'user_id' => '', 'email_address' => '', 'balance' => '0.00000000', 'updated_dt' => '', 'last_action' => '', 'last_amount' => '0.00000000', 'status' => 0, 'coin' => '', 'api_call' => 0);
						$merchant_link_rs = array('merchant' => '', 'user_id' => '', 'balance' => '0.00000000');
						while ($row_find_merchant_link = mysqli_fetch_array($rs_find_merchant_link, MYSQLI_ASSOC)) {
							
							$current_linked_account['email_address'] = trim($row_find_merchant_link['email_address']);
							$current_linked_account['merchant'] = trim($row_find_merchant_link['merchant']);
							$current_linked_account['client_id'] = trim($row_find_merchant_link['client_id']);
							$current_linked_account['linked_tm'] = intval($row_find_merchant_link['linked_tm']);
							$current_linked_account['unlinked_tm'] = intval($row_find_merchant_link['unlinked_tm']);
							$current_linked_account['status'] = intval($row_find_merchant_link['status']);
							break;
						}
						
						if ($current_linked_account['email_address'] != '') {
							
							$sql_transaction_history = "SELECT * FROM cryptocash_merchant_transaction_history WHERE email_address='" . $current_linked_account['email_address'] . "' AND client_id='" . $current_linked_account['client_id'] . "' AND merchant='" . $current_linked_account['merchant'] . "' ORDER BY updated_tm DESC LIMIT 1";
							_log($sql_transaction_history);
							$rs_transaction_history = mysqli_query($dbhandle, $sql_transaction_history);
							if (mysqli_num_rows($rs_transaction_history) > 0) {
								$last_transaction_history_rs = array('txid' => '', 'email_address' => '', 'merchant' => '', 'client_id' => '', 'balance' => 0, 'updated_tm' => 0, 'last_action' => '', 'last_amount' => 0, 'coin' => '', 'api_call' => 0);
								while ($row_transaction_history = mysqli_fetch_array($rs_transaction_history, MYSQLI_ASSOC)) {
							
									$last_transaction_history_rs['txid'] = trim($row_transaction_history['txid']);
									$last_transaction_history_rs['email_address'] = trim($row_transaction_history['email_address']);
									$last_transaction_history_rs['merchant'] = trim($row_transaction_history['merchant']);
									$last_transaction_history_rs['client_id'] = trim($row_transaction_history['client_id']);
									$last_transaction_history_rs['balance'] = $row_transaction_history['balance'];
									$last_transaction_history_rs['updated_tm'] = intval($row_transaction_history['updated_tm']);
									$last_transaction_history_rs['last_action'] = trim($row_transaction_history['last_action']);
									$last_transaction_history_rs['last_amount'] = $row_transaction_history['last_amount'];
									$last_transaction_history_rs['coin'] = trim($row_transaction_history['coint']);
									$last_transaction_history_rs['api_call'] = intval($row_transaction_history['api_call']);
									
								}
								if ($last_transaction_history_rs['txid'] != '') {
									$clean_amount = trim($handled_amount_final);
									$clean_action = trim($data['content']['action']);
									$uuid = common_uuid();
									$old_balance = $last_transaction_history_rs['balance'];
									$new_balance = '0.00000000';
									if ($clean_action == 'plus') {
										$new_balance = $old_balance + $clean_amount;
									} else if ($action == 'minus') { 
										$new_balance = $old_balance - $clean_amount;
										if ($new_balance < 0) {
											@mysqli_close($dbhandle);
											_log($data['user_id'] . " new balance is minus !");
											//@fclose($fh);
											$failed_rs['error'] = 'cannot subtract amount bigger than current balance ' . $old_balance;
											header('Content-Type: application/json');
											echo json_encode($failed_rs);
											die();
										}
									}
									$new_balance_final = number_format($new_balance, 8, '.', '');
									_log("new_balance = " . $new_balance_final);
									$updated_tm = time();
									
									$sql_add_tx = "INSERT INTO cryptocash_merchant_transaction_history (txid, email_address, merchant, client_id, balance, updated_tm, last_action, last_amount, coin, api_call) VALUES ('$uuid', '" . $current_linked_account['email_address'] . "', '" . $current_linked_account['merchant'] . "', '" . $current_linked_account['client_id'] . "', '" . $new_balance_final . "', '$updated_tm', '$clean_action', '$clean_amount', '', 1)";
									_log($sql_add_tx);
									mysqli_query($dbhandle, $sql_add_tx);
									if (mysqli_affected_rows($dbhandle) <= 0) {
										_log("failed to insert db !");
										@mysqli_close($dbhandle);
										$failed_rs['error'] = 'unknown system error, contact adminnistrator for help';
										header('Content-Type: application/json');
										echo json_encode($failed_rs);
										die();
									} else {
										$success_rs = array();
										$success_rs['user_id'] = $current_linked_account['client_id'];
										$success_rs['merchant'] = $current_linked_account['merchant'];
										$success_rs['balance_old'] = $old_balance;
										$success_rs['balance_new'] = $new_balance_final;
										@mysqli_close($dbhandle);
										header('Content-Type: application/json');
										echo json_encode($success_rs);
										die();
										
									}
										
									
								} else {
									//todo
								}
								
							} else {
								$clean_amount = trim($handled_amount_final);
								$clean_action = trim($data['content']['action']);
								$uuid = common_uuid();
								$old_balance = 0;
								$new_balance = '0.00000000';
								if ($clean_action == 'plus') {
									$new_balance = $old_balance + $clean_amount;
								} else if ($action == 'minus') { 
									$new_balance = $old_balance - $clean_amount;
									if ($new_balance < 0) {
										@mysqli_close($dbhandle);
										_log($data['user_id'] . " new balance is minus !");
										//@fclose($fh);
										$failed_rs['error'] = 'cannot subtract amount bigger than current balance ' . $old_balance;
										header('Content-Type: application/json');
										echo json_encode($failed_rs);
										die();
									}
								}
								$new_balance_final = number_format($new_balance, 8, '.', '');
								_log("new_balance = " . $new_balance_final);
								$updated_tm = time();
								
								$sql_add_tx = "INSERT INTO cryptocash_merchant_transaction_history (txid, email_address, merchant, client_id, balance, updated_tm, last_action, last_amount, coin, api_call) VALUES ('$uuid', '" . $current_linked_account['email_address'] . "', '" . $current_linked_account['merchant'] . "', '" . $current_linked_account['client_id'] . "', '" . $new_balance_final . "', '$updated_tm', '$clean_action', '$clean_amount', '', 1)";
								_log($sql_add_tx);
								mysqli_query($dbhandle, $sql_add_tx);
								if (mysqli_affected_rows($dbhandle) <= 0) {
									_log("failed to insert db !");
									@mysqli_close($dbhandle);
									$failed_rs['error'] = 'unknown system error, contact adminnistrator for help';
									header('Content-Type: application/json');
									echo json_encode($failed_rs);
									die();
								} else {
									$success_rs = array();
									$success_rs['user_id'] = $current_linked_account['client_id'];
									$success_rs['merchant'] = $current_linked_account['merchant'];
									$success_rs['balance_old'] = $old_balance;
									$success_rs['balance_new'] = $new_balance_final;
									@mysqli_close($dbhandle);
									header('Content-Type: application/json');
									echo json_encode($success_rs);
									die();
									
								}
							}
								
							
						} else {
							//todo
						}
						
					} else {
						@mysqli_close($dbhandle);
						_log('user_id ' . trim($data['user_id']) . ' is being disconnected');
						$failed_rs['error'] = 'user_id ' . trim($data['user_id']) . ' is being disconnected';
						header('Content-Type: application/json');
						echo json_encode($failed_rs);
						die();
					}
					
					
				} else {
					_log($data['user_id'] . ":: db connect error");				
					$failed_rs['error'] = 'unknown error occured';
					header('Content-Type: application/json');
					echo json_encode($failed_rs);
					die();
				}
				
				*/
				
			} else {
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors[0];
				_log($ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
				
			
		}

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>