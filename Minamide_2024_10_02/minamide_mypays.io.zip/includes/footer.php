<?php
require_once "common.php";
$baseUrl = getBaseUrl();
?>
<div class="footer bg-primary p-3 text-right text-white">
  Copyright@ 2024
</div>
</body>
</html>
