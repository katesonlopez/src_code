<?php

namespace App\includes\JDB_UAT\api;

use App\includes\JDB_UAT\ActionRequest;
use App\includes\JDB_UAT\SecurityData;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Log;
use Jose\Component\Checker\InvalidClaimException;
use Jose\Component\Checker\MissingMandatoryClaimException;
use Webpatser\Uuid\Uuid;

class Payment extends ActionRequest
{
  /**
   * @throws Exception
   */
  public function Execute($amount = 0): string
  {
    $crypto_amount = $amount * 0.94;
    $crypto_amount = bcdiv($crypto_amount, 1, 6);
    $amount = ceil($amount * 100) / 100;
    $amount_text = ceil($amount * 100);
    $len = strlen((string)$amount_text);
    for ($i = 0; $i < (12 - $len); $i++) {
      # code...
      $amount_text = "0" . $amount_text;

    }
    $now = Carbon::now();
    $orderNo = $now->getPreciseTimestamp(3);
    $app_url = env("APP_URL");
    $request = [
      "apiRequest" => [
        "requestMessageID" => Uuid::generate()->string,
        "requestDateTime" => $now->utc()->format("Y-m-d\TH:i:s.v\Z"),
        "language" => "en-US"
      ],
      "officeId" => "000002105010108",
      "orderNo" => $orderNo,
      "productDescription" => "For buying $crypto_amount USDT",
      "paymentType" => "CC",
      "paymentCategory" => "ECOM",
      "storeCardDetails" => [
        "storeCardFlag" => "N",
        "storedCardUniqueID" => Uuid::generate()->string
      ],
      "installmentPaymentDetails" => [
        "ippFlag" => "N",
        "installmentPeriod" => 0,
        "interestType" => null
      ],
      "mcpFlag" => "N",
      "request3dsFlag" => "N",
      "transactionAmount" => [
        "amountText" => $amount_text,
        "currencyCode" => "USD",
        "decimalPlaces" => 2,
        "amount" => $amount
      ],
      "notificationURLs" => [
        "confirmationURL" => "$app_url/payment-confirmation",
        "failedURL" => "$app_url/payment-failed",
        "cancellationURL" => "$app_url/payment-cancellation",
        "backendURL" => "$app_url/payment-backend"
      ],

      "customFieldList" => [
        [
          "fieldName" => "TestField",
          "fieldValue" => "This is test"
        ]
      ]
    ];
    $stringRequest = json_encode($request);
    $response = $this->client->post("api/1.0/Payment/prePaymentUI", [
      "headers" => [
        "Accept" => "application/json",
        "apiKey" => SecurityData::$AccessToken,
        "Content-Type" => "application/json; charset=utf-8"
      ],
      "body" => $stringRequest
    ]);

    return $response->getBody()->getContents();
  }

  /**
   * @throws Exception
   * $requestParam['amount']
   * $requestParam['productName']
   * $requestParam['host']
   * $requestParam['feePercent']
   * $requestParam['email']
   * $requestParam['name']
   * $requestParam['card_number']
   * $requestParam['card_expiry']
   * $requestParam['cvv_code']
   */
  public function ExecuteNonUI($requestParam): string
  {
    try {
      // Prepare basic information
      $amount = ceil($requestParam['amount'] * 100) / 100;
      $feeAmount = $amount * $requestParam['feePercent'] / 100;
      $amount_text = ceil($amount * 100);
      $len = strlen((string)$amount_text);
      for ($i = 0; $i < (12 - $len); $i++) {
        $amount_text = "0" . $amount_text;
      }

      $orderNo = $requestParam['orderNo'];
      $now = Carbon::now();

      // Prepare URLs
      $baseUrl = env('KAISER_BACKEND');

      $request = [
        "apiRequest" => [
          "requestMessageID" => Uuid::generate()->string,
          "requestDateTime" => $now->utc()->format("Y-m-d\TH:i:s.v\Z"),
          "language" => "en-US"
        ],
        "officeId" => "000002105010090",
        "orderNo" => $orderNo,
        "productDescription" => $requestParam['productName'],
        "paymentType" => "CC",
        "paymentCategory" => "ECOM",
        "creditCardDetails" => [
          "cardNumber" => $requestParam['card_number'],
          "cardExpiryMMYY" => $requestParam['card_expiry'],
          "cvvCode" => $requestParam['cvv_code'],
          "payerName" => $requestParam['name'] ?? null,
        ],
        "storeCardDetails" => [
          "storeCardFlag" => "N",
          "storedCardUniqueID" => Uuid::generate()->string
        ],
        "installmentPaymentDetails" => [
          "ippFlag" => "N",
          "installmentPeriod" => 0,
          "interestType" => null
        ],
        "mcpFlag" => "N",
        "request3dsFlag" => "N",
        "transactionAmount" => [
          "amountText" => $amount_text,
          "currencyCode" => "USD",
          "decimalPlaces" => 2,
          "amount" => $amount
        ],
        "notificationURLs" => [
          "confirmationURL" => "$baseUrl/kaiser-payment-confirmation",
          "failedURL" => "$baseUrl/kaiser-payment-failed",
          "cancellationURL" => "$baseUrl/kaiser-payment-cancellation",
          "backendURL" => "$baseUrl/kaiser-payment-backend"
        ],
        "customFieldList" => [
          [
            "fieldName" => "fee",
            "fieldValue" => $feeAmount
          ],
          [
            "fieldName" => "feePercent",
            "fieldValue" => $requestParam['feePercent']
          ],
          [
            "fieldName" => "partner",
            "fieldValue" => $requestParam['host']
          ]
        ]
      ];

      // Include "email" and "name" field if it is provided and not empty
      if ($requestParam['email'] !== null && $requestParam['email'] !== '') {
        $request['customFieldList'][] = [
          "fieldName" => "email",
          "fieldValue" => $requestParam['email']
        ];
      }

      if ($requestParam['name'] !== null && $requestParam['name'] !== '') {
        $request['customFieldList'][] = [
          "fieldName" => "name",
          "fieldValue" => $requestParam['name']
        ];
      }

      $url = ActionRequest::getPaymentEndpoint() . "api/1.0/Payment/NonUi";
      $headers = [
        "Content-Type: application/json; charset=utf-8",
        "apiKey: " . SecurityData::$AccessToken,
      ];

      $body = json_encode($request);
      // Initialize cURL session
      $ch = curl_init($url);

      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
      Log::info("nonUI request: $body");

      // Execute cURL request and get response
      $response = curl_exec($ch);
      Log::info( "nonUI response: $response" );

      // Check for cURL errors
      if (curl_errno($ch)) {
        throw new Exception('Request Error: ' . curl_error($ch));
      }

      /*// Get HTTP status code
      $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);*/

      // Close cURL session
      curl_close($ch);

      return $response;
    } catch (Exception $e) {
      // Handle the exception
      return json_encode([
        "error" => true,
        "message" => $e->getMessage()
      ]);
    }
  }

  /**
   * @throws Exception
   */
  public function ExecuteJose($amount = 0, $productName = "", $host = "", $feePercent = 0, $email = null, $name = null): string
  {
    // Prepare basic information
    $amount = ceil($amount * 100) / 100;
    $feeAmount = $amount * $feePercent / 100;
    $amount_text = ceil($amount * 100);
    $len = strlen((string)$amount_text);
    for ($i = 0; $i < (12 - $len); $i++) {
      $amount_text = "0" . $amount_text;
    }
    $now = Carbon::now();
    $orderNo = $now->getPreciseTimestamp(3);

    // Prepare urls
    $baseUrl = env('KAISER_BACKEND');

    $request = [
      "apiRequest" => [
        "requestMessageID" => Uuid::generate()->string,
        "requestDateTime" => $now->utc()->format("Y-m-d\TH:i:s.v\Z"),
        "language" => "en-US"
      ],
      "officeId" => "000002105010090",
      "orderNo" => $orderNo,
      "productDescription" => $productName,
      "paymentType" => "CC",
      "paymentCategory" => "ECOM",
      "mcpFlag" => "N",
      "request3dsFlag" => "N",
      "transactionAmount" => [
        "amountText" => $amount_text,
        "currencyCode" => "USD",
        "decimalPlaces" => 2,
        "amount" => $amount
      ],
      "notificationURLs" => [
        "confirmationURL" => "$baseUrl/kaiser-payment-confirmation",
        "failedURL" => "$baseUrl/kaiser-payment-failed",
        "cancellationURL" => "$baseUrl/kaiser-payment-cancellation",
        "backendURL" => "$baseUrl/kaiser-payment-backend"
      ],
      "customFieldList" => [
        [
          "fieldName" => "fee",
          "fieldValue" => $feeAmount
        ],
        [
          "fieldName" => "feePercent",
          "fieldValue" => $feePercent
        ],
        [
          "fieldName" => "partner",
          "fieldValue" => $host
        ]
      ]
    ];

    // Include "email" and "name" field if it is provided and not empty
    if ($email !== null && $email !== '') {
      $request['customFieldList'][] = [
        "fieldName" => "email",
        "fieldValue" => $email
      ];
    }

    if ($name !== null && $name !== '') {
      $request['customFieldList'][] = [
        "fieldName" => "name",
        "fieldValue" => $name
      ];
    }

    $url = ActionRequest::getPaymentEndpoint() . "api/1.0/Payment/prePaymentUI";
    $headers = [
      "Content-Type: application/json; charset=utf-8",
      "apiKey: " . SecurityData::$AccessToken,
    ];
    $body = json_encode($request);
    $options = [
      'http' => [
        'header' => implode("\r\n", $headers),
        'method' => 'POST',
        'content' => $body,
      ],
    ];
    $context = stream_context_create($options);
    return file_get_contents($url, false, $context);
  }

  /**
   * @throws MissingMandatoryClaimException
   * @throws InvalidClaimException
   * @throws Exception
   */
  public function ExecuteJoseNonUI(): string
  {
    $now = Carbon::now();
    $orderNo = $now->getPreciseTimestamp(3);

    $request = [
      "apiRequest" => [
        "requestMessageID" => Uuid::generate()->string,
        "requestDateTime" => $now->utc()->format("Y-m-d\TH:i:s.v\Z"),
        "language" => "en-US",
      ],
      "officeId" => "000002105010090",
      "orderNo" => $orderNo,
      "productDescription" => "desc for {$orderNo}",
      "paymentType" => "CC",
      "paymentCategory" => "ECOM",
      "creditCardDetails" => [
        "cardNumber" => "4706860000002325",
        "cardExpiryMMYY" => "1225",
        "cvvCode" => "761",
        "payerName" => "Demo Sample"
      ],
      "storeCardDetails" => [
        "storeCardFlag" => "N",
        "storedCardUniqueID" => Uuid::generate()->string
      ],
      "installmentPaymentDetails" => [
        "ippFlag" => "N",
        "installmentPeriod" => 0,
        "interestType" => null
      ],
      "mcpFlag" => "N",
      "request3dsFlag" => "N",
      "transactionAmount" => [
        "amountText" => "000000100000",
        "currencyCode" => "THB",
        "decimalPlaces" => 2,
        "amount" => 1000
      ],
      "notificationURLs" => [
        "confirmationURL" => "https://example-confirmation.com",
        "failedURL" => "https://example-failed.com",
        "cancellationURL" => "https://example-cancellation.com",
        "backendURL" => "https://example-backend.com"
      ],
      "deviceDetails" => [
        "browserIp" => "1.0.0.1",
        "browser" => "Postman Browser",
        "browserUserAgent" => "PostmanRuntime/7.26.8 - not from header",
        "mobileDeviceFlag" => "N"
      ],
      "purchaseItems" => [
        [
          "purchaseItemType" => "ticket",
          "referenceNo" => "2322460376026",
          "purchaseItemDescription" => "Bundled insurance",
          "purchaseItemPrice" => [
            "amountText" => "000000100000",
            "currencyCode" => "THB",
            "decimalPlaces" => 2,
            "amount" => 1000
          ],
          "subMerchantID" => "string",
          "passengerSeqNo" => 1
        ]
      ],
      "customFieldList" => [
        [
          "fieldName" => "TestField",
          "fieldValue" => "This is test"
        ]
      ]
    ];

    $payload = [
      "request" => $request,
      "iss" => SecurityData::$AccessToken,
      "aud" => "PacoAudience",
      "CompanyApiKey" => SecurityData::$AccessToken,
      "iat" => $now->unix(),
      "nbf" => $now->unix(),
      "exp" => $now->addHour()->unix(),
    ];

    $stringPayload = json_encode($payload);
    $signingKey = $this->GetPrivateKey(SecurityData::$MerchantSigningPrivateKey);
    $encryptingKey = $this->GetPublicKey(SecurityData::$PacoEncryptionPublicKey);

    $body = $this->EncryptPayload($stringPayload, $signingKey, $encryptingKey);

    $response = $this->client->post("api/1.0/Payment/NonUi", [
      "headers" => [
        "Accept" => "application/jose",
        "CompanyApiKey" => SecurityData::$AccessToken,
        "Content-Type" => "application/jose; charset=utf-8"
      ],
      "body" => $body
    ]);

    $token = $response->getBody()->getContents();
    $decryptingKey = $this->GetPrivateKey(SecurityData::$MerchantDecryptionPrivateKey);
    $signatureVerificationKey = $this->GetPublicKey(SecurityData::$PacoSigningPublicKey);

    return $this->DecryptToken($token, $decryptingKey, $signatureVerificationKey);
  }
}
