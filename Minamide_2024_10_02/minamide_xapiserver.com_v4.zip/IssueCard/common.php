<?php
if (!defined('BASE_PATH')) {
  /*define("BASE_PATH", "D:\\xampp\\htdocs\\minamide\\xapiserver.com_v4");*/
  define("BASE_PATH", '/usr/share/nginx/xapiserver.com/v4');
}
if (!defined('SITE_PATH')) {
  /*define("SITE_PATH", "http://localhost/minamide/xapiserver.com_v4");*/
  define("SITE_PATH", 'https://xapiserver.com/v4');
}
