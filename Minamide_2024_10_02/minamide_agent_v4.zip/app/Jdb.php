<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;

class Jdb extends Model
{
  /**
   * @var string
   */
  public function __construct()
  {
    // Call the parent constructor
    parent::__construct();
  }

  /**=============      base api       ===============================================**/
  public static function getTransactions($uri, $orderIds = null): array
  {
    try {
      // Prepare the request data
      $now = Carbon::now();

      $data = [
        'apiRequest' => [
          'requestMessageID' => self::generateUuid(),
          'requestDateTime' => $now->utc()->format('Y-m-d\TH:i:s.v\Z'),
          'language' => 'en-US'
        ],
        'advSearchParams' => [
          'controllerInternalID' => null,
          'officeId' => [config('purchaseCheckToolSetting.jdbOfficeId')],
          'orderNo' => $orderIds ?? [],
          'invoiceNo2C2P' => null,
          'fromDate' => '1991-01-01T00:00:00',
          'toDate' => '2025-01-01T00:00:00',
          'amountFrom' => null,
          'amountTo' => null
        ]
      ];

      // Encode the request data as JSON
      $encodedData = json_encode($data);

      // Initialize cURL
      $curl = curl_init(config('purchaseCheckToolSetting.jdbServerUrl') . $uri);

      // Set cURL options
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
      curl_setopt($curl, CURLOPT_HTTPHEADER, [
        'apiKey: '.config('purchaseCheckToolSetting.jdbApiKey'),
        'Authorization: '.config('purchaseCheckToolSetting.jdbAuthorization'),
        'Content-Type: application/json; charset=utf-8'
      ]);
      curl_setopt($curl, CURLOPT_POSTFIELDS, $encodedData);

      // Execute the cURL request
      $response = curl_exec($curl);

      // Check for cURL errors
      if (curl_errno($curl)) {
        throw new \Exception('cURL error: ' . curl_error($curl));
      }

      // Close the cURL session
      curl_close($curl);

      // Decode the response
      $response = json_decode($response, true);

      // Log the response for debugging
      Log::info($response);

    } catch (\Throwable $th) {
      // Handle exceptions
      Log::error('Failed to get transactions: ' . $th->getMessage());
      $response = ['result' => 'failed'];
    }

    return $response;
  }

  public static function getOneTransaction($uri, $orderNo = null): array
  {
    try {
      // Initialize cURL with GET method
      $curl = curl_init(config('purchaseCheckToolSetting.jdbServerUrl') . $uri . "?orderNo=$orderNo");

      Log::info("url: ".config('purchaseCheckToolSetting.jdbServerUrl') . $uri . "?orderNo=$orderNo");
      // Set cURL options for a GET request
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($curl, CURLOPT_HTTPGET, true); // Use GET request instead of POST
      curl_setopt($curl, CURLOPT_HTTPHEADER, [
        'apiKey: ' . config('purchaseCheckToolSetting.jdbApiKey'),
        'Authorization: ' . config('purchaseCheckToolSetting.jdbAuthorization'),
        'Content-Type: application/json; charset=utf-8'
      ]);

      // Execute the cURL request
      $response = curl_exec($curl);

      // Check for cURL errors
      if (curl_errno($curl)) {
        throw new \Exception('cURL error: ' . curl_error($curl));
      }

      // Close the cURL session
      curl_close($curl);

      // Decode the response
      $response = json_decode($response, true);

      // Log the response for debugging
      Log::info($response);

    } catch (\Throwable $th) {
      // Handle exceptions
      Log::error('Failed to get transactions: ' . $th->getMessage());
      $response = ['result' => 'failed'];
    }

    return $response;
  }

  static function generateUuid(): string
  {
    // Generate 16 random bytes
    $data = random_bytes(16);

    // Set the version to 4 (UUIDv4)
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);

    // Convert bytes to UUID format
    return vsprintf(
      '%s%s-%s-%s-%s-%s%s%s',
      str_split(bin2hex($data), 4)
    );
  }
}
