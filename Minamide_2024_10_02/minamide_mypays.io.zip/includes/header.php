<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");

require_once "common.php";
$baseUrl = getBaseUrl();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MyPays</title>
  <link rel="shortcut icon" href="<?php echo $baseUrl; ?>assets/images/favicon.ico">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>assets/css/styles.css?ver=006">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>assets/css/font-awesome.min.css">
  <script src="<?php echo $baseUrl; ?>assets/js/jquery-3.3.1.min.js"></script>
  <script src="<?php echo $baseUrl; ?>assets/js/popper.min.js"></script>
  <script src="<?php echo $baseUrl; ?>assets/js/bootstrap.min.js"></script>
  <script src="<?php echo $baseUrl; ?>assets/js/common.js"></script>
</head>
<body class="">

<!-- Constant start -->
<input type="hidden" id="base_url" name="base_url" value="<?php echo $baseUrl; ?>">
<!-- Constant end -->

<!-- Menu start -->
<nav class="navbar navbar-expand-lg navbar-light bg-primary p-2">
  <a class="navbar-brand text-white username" href="<?php echo $baseUrl; ?>" style="display: none">
    <i class="fa fa-user-circle-o"></i>
    <span class="auth_username"></span>
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse pl-4" id="navbarNav">
    <ul class="navbar-nav authenticated" style="display: none">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo $baseUrl; ?>dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo $baseUrl; ?>pay_with_card.php"><i class="fa fa-credit-card-alt"></i> Pay with Card</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo $baseUrl; ?>pay_with_card_report.php"><i class="fa fa-list-alt"></i> Card Payments Report</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo $baseUrl; ?>logout.php"><i class="fa fa-sign-out"></i> Logout</a>
      </li>
    </ul>
    <ul class="navbar-nav unauthenticated">
      <li class="nav-item">
        <a class="nav-link" href="#">&nbsp</a>
      </li>
    </ul>
  </div>
</nav>
<!-- Menu end -->

<!-- Toast start -->
<div class="toast hide" data-delay="3000">
  <div class="toast-header">
    <strong class="mr-auto">Notification</strong>
    <small></small>
    <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <div class="toast-body mt-2">
  </div>
</div>
<!-- Toast end -->
