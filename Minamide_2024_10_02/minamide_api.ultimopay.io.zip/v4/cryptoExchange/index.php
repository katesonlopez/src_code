<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding("UTF-8");
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders')) {
  function getallheaders(){
    if (!is_array($_SERVER)) {
      return array();
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
      if (substr($name, 0, 5) == 'HTTP_') {
        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
      }
    }
    return $headers;
  }
}

function _log($email, $line)
{
  if ($email == "") {
    $fh2 = fopen("/var/www/api.ultimopay.io/v4/cryptoExchange/log/cryptoExchange.log" , 'a');
  } else {
    $fh2 = fopen("/var/www/api.ultimopay.io/v4/cryptoExchange/log/" . $email . ".log" , 'a');
  }
  $fline = date('[Ymd H:i:s] ') . $line."\n";
  fwrite($fh2, $fline);
  fclose($fh2);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_once '../include/dbconfig.php';
  $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
  if (mysqli_connect_errno() != 0) {
    header('Content-Type: application/json');
    http_response_code(500);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
    echo json_encode($ret_rs);
    die();
  } else {
    _log("", "ket noi thanh cong");
    mysqli_query($dbhandle, "set names utf8;");
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
  $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
  $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
  $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
  $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret4 = 'climbpot api access key';
  $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
  $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
  $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
  $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
  $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
  $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
  //$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
  $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
  $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
  $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
  $apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
  $found = 0;
  $coin = 'USDT';
  $sandbox = 0;
  $partner = "";
  $crypto_pair_arr = array('USDTUSD', 'BTCUSD', 'USDCUSD', 'BUSDUSDT', 'SOLUSD', 'BCHUSD', 'ETHUSD', 'LTCUSD', 'XRPUSD');
  $exchange_type_arr = array('buy', 'sell');
  $req_api_key = "";
  $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

  foreach (getallheaders() as $name => $value) {
    if ($name == 'Authorization') {
      $req_api_key = trim($value);
      $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
      $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
      if (mysqli_num_rows($partner_rs) > 0) {
        while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
          $cur_api_key = "Bearer " . $row_partner['api_key'];
          if ($req_api_key == $cur_api_key) {
            $req_partner['partner'] = trim($row_partner['partner']);
            $req_partner['api_key'] = trim($row_partner['api_key']);
            $req_partner['website'] = trim($row_partner['website']);
            $selected_api_key = $req_api_key;
            break;
          }
        }
      } else {
        _log("", "not found in db");
      }
    }
  }
  @mysqli_close($dbhandle);

  function isValidPassword($password)
  {
    if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
      return FALSE;
    return TRUE;
  }

  function uuid()
  {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
      mt_rand(0, 0xffff), mt_rand(0, 0xffff),
      mt_rand(0, 0xffff),
      mt_rand(0, 0x0fff) | 0x4000,
      mt_rand(0, 0x3fff) | 0x8000,
      mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
  }

  function decimal_notation($float)
  {
    $parts = explode('E', $float);

    if (count($parts) === 2) {
      $exp = abs(end($parts)) + strlen($parts[0]);
      $decimal = number_format($float, $exp);
      return rtrim($decimal, '.0');
    } else {
      return $float;
    }
  }

  function get_crypto_price($_crypto_pair, $_auth_token)
  {
    $crypto_price_info = array('buy_price' => '', 'sell_price' => '', 'error' => '', 'raw_error' => '');
    ///////////////////////////////////////////////////
    $tmp_dto_price_arr = array();
    $instruments_price_query = sprintf('{"query":"query ($instrument_id: String!, $is_active: ToggleSwitch) {\n  instruments(instrument_id: $instrument_id, is_active: $is_active) {\n    name\n    instrument_id\n    base_currency_id\n    quote_currency_id\n    price {\n      instrument_id\n      ask\n      bid\n      price_24h_change\n      ts\n    }\n  }\n}","variables":{"instrument_id":"%s"}}', $_crypto_pair);
    unset($instruments_price_res);
    $instruments_price_res = api_call('/api/v4/securities/statistics', 0, $instruments_price_query, $tmp_dto_price_arr, $_auth_token);
    $raw_res_body = json_encode($instruments_price_res);
    if (($instruments_price_res['http_code'] == "200") || ($instruments_price_res['http_code'] == "200 OK")) {
      if (is_array($instruments_price_res['result']['data']['instruments'])) {
        $target_instrument = $instruments_price_res['result']['data']['instruments'][0];
        if (!empty($target_instrument)) {
          if (!empty($target_instrument['price'])) {
            if ((!empty($target_instrument['price']['instrument_id'])) && (!empty($target_instrument['price']['bid'])) && (!empty($target_instrument['price']['ask']))) {
              if (strtoupper($target_instrument['price']['instrument_id']) == $_crypto_pair) {
                $crypto_price_info['buy_price'] = $target_instrument['price']['bid'];
                $crypto_price_info['sell_price'] = $target_instrument['price']['ask'];
              }
            } else {
              $crypto_price_info['error'] = 'data.instruments.price_bid_ask_are_empty';
              $crypto_price_info['raw_error'] = $raw_res_body;
            }
          } else {
            $crypto_price_info['error'] = 'data.instruments.price_is_empty';
            $crypto_price_info['raw_error'] = $raw_res_body;
          }
        } else {
          $crypto_price_info['error'] = 'data.instruments_array_is_empty';
          $crypto_price_info['raw_error'] = $raw_res_body;
        }
      } else {
        $crypto_price_info['error'] = 'data.instruments_is_not_array';
        $crypto_price_info['raw_error'] = $raw_res_body;
      }
    } else {
      $crypto_price_info['error'] = 'ng_http_response_code';
      $crypto_price_info['raw_error'] = $raw_res_body;
    }
    ///////////////////////////////////////////////////
    return $crypto_price_info;
  }

  function get_wallet_balance($currency_id, $_auth_token)
  {
    $wallet_balance_info = array('crypto_balance' => '', 'usd_balance' => '', 'error' => '');
    ///////////////////////////////////////////////////
    $tmp_dto_arr = array();
    $my_account_balances_query = '{
      "query": "{\\n  accounts_balances {\\n    currency_id\\n    total_balance\\n    exposed_balance\\n    currency {\\n      type\\n      precision\\n      payment_routes {\\n        crypto_network\\n        crypto_address_tag_type\\n      }\\n    }\\n    free_balance\\n    free_balance_USD: free_balance_quoted(quote_currency_id: \\"USD\\")\\n    free_balance_BTC: free_balance_quoted(quote_currency_id: \\"BTC\\")\\n    free_balance_ETH: free_balance_quoted(quote_currency_id: \\"ETH\\")\\n    free_balance_USDT: free_balance_quoted(quote_currency_id: \\"USDT\\")\\n    free_balance_USDC: free_balance_quoted(quote_currency_id: \\"USDC\\")\\n    free_balance_SOL: free_balance_quoted(quote_currency_id: \\"SOL\\")\\n    free_balance_BCH: free_balance_quoted(quote_currency_id: \\"BCH\\")\\n    free_balance_LTC: free_balance_quoted(quote_currency_id: \\"LTC\\")\\n    free_balance_XRP: free_balance_quoted(quote_currency_id: \\"XRP\\")\\n  }\\n}",
      "variables": {}
    }';
    unset($accounts_res);
    $accounts_res = api_call('/api/v4/accounts', 0, $my_account_balances_query, $tmp_dto_arr, $_auth_token);
    if (($accounts_res['http_code'] == "200") || ($accounts_res['http_code'] == "200 OK")) {
      if (!empty($accounts_res['result']['errors'])) {
        $wallet_balance_info['error'] = 'access_token_expired';
      } else {
        if (is_array($accounts_res['result']['data']['accounts_balances'])) {
          $accounts_arr = $accounts_res['result']['data']['accounts_balances'];
          if (count($accounts_arr) > 0) {
            $found_currency = 0;
            for ($coin_cnt = 0; $coin_cnt < count($accounts_arr); $coin_cnt++) {
              $cur_coin_stat = $accounts_arr[$coin_cnt];
              if (strtoupper($cur_coin_stat['currency_id']) == $currency_id) {
                if (isset($cur_coin_stat['total_balance'])) {
                  $wallet_balance_info['crypto_balance'] = $cur_coin_stat['total_balance'];
                }
              } else if (strtoupper($cur_coin_stat['currency_id']) == 'USD') {
                if (isset($cur_coin_stat['total_balance'])) {
                  $wallet_balance_info['usd_balance'] = $cur_coin_stat['total_balance'];
                }
              }
            }
          }
        } else {
          $wallet_balance_info['error'] = 'data.account_balances_is_empty';
        }
      }
    } else {
      $wallet_balance_info['error'] = 'ng_http_response_code';
    }
    ///////////////////////////////////////////////////
    return $wallet_balance_info;
  }

  if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!($data)) {

      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          _log("", 'Reached the maximum stack depth');
          break;
        case JSON_ERROR_STATE_MISMATCH:
          _log("", 'Incorrect discharges or mismatch mode');
          break;
        case JSON_ERROR_CTRL_CHAR:
          _log("", 'Incorrect control character');
          break;
        case JSON_ERROR_SYNTAX:
          _log("", 'Syntax error or JSON invalid');
          break;
        case JSON_ERROR_UTF8:
          _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
          break;
        default:
          _log("", 'Unknown error');
          break;
      }

      _log("", 'A non-empty request body is required.');
      header('Content-Type: application/json');
      http_response_code(400);
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
      echo json_encode($ret_rs);
      die();
    } else {
      unset($errors);
      $errors = array();

      //email
      if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
        $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
        $errors[] = $error_obj;
      }

      //auth_token
      if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
        $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
        $errors[] = $error_obj;
      }

      //type
      if ((!isset($data['type'])) || (empty($data['type']))) {
        $error_obj = array('errorCode' => 4, 'errorMessage' => 'type parameter is required.');
        $errors[] = $error_obj;
      } else {
        if (!in_array(strtolower($data['type']), $exchange_type_arr)) {
          $error_obj = array('errorCode' => 5, 'errorMessage' => "unsupported type. Only 'buy' or 'sell' are allowed.");
          $errors[] = $error_obj;
        }
      }

      //pair
      if ((!isset($data['pair'])) || (empty($data['pair']))) {
        $error_obj = array('errorCode' => 6, 'errorMessage' => 'pair parameter is required.');
        $errors[] = $error_obj;
      } else {
        if (!in_array(strtoupper($data['pair']), $crypto_pair_arr)) {
          $error_obj = array('errorCode' => 7, 'errorMessage' => 'unsupported pair.');
          $errors[] = $error_obj;
        }
      }

      if (count($errors) == 0) {
        $errors_sub = array();

        //proceed to shift api
        require_once '../include/common.php';
        require_once '../include/cognito.php';

        ////////////////////////////////////////////////////

        $allowed_shift_currency_arr = array('USDT', 'BTC', 'BUSD', 'USDC', 'USD', 'SOL', 'BCH', 'ETH', 'LTC', 'XRP');
        //receive POST params
        $reg_email_address = trim($data['email_address']);
        $private_key = trim($data['auth_token']);
        $type = trim(strtolower($data['type']));
        $pair = trim(strtoupper($data['pair']));
        $amount = trim($data['amount']);
        $currency = '';
        $pair2 = '';
        if ($pair == "USDTUSD") {
          $currency = 'USDT';
          $pair2 = $pair;
        } else if ($pair == "BUSDUSD") {
          $currency = 'BUSD';
          $pair2 = "BUSDUSDT";
        } else if ($pair == "BTCUSD") {
          $currency = 'BTC';
          $pair2 = $pair;
        } else if ($pair == "USDCUSD") {
          $currency = 'USDC';
          $pair2 = $pair;
        } else if ($pair == "SOLUSD") {
          $currency = 'SOL';
          $pair2 = $pair;
        } else if ($pair == "BCHUSD") {
          $currency = 'BCH';
          $pair2 = $pair;
        } else if ($pair == "ETHUSD") {
          $currency = 'ETH';
          $pair2 = $pair;
        } else if ($pair == "LTCUSD") {
          $currency = 'LTC';
          $pair2 = $pair;
        } else if ($pair == "XRPUSD") {
          $currency = 'XRP';
          $pair2 = $pair;
        }

        _log($reg_email_address, "crypto exchange started...");

        $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
        if (mysqli_connect_errno() == 0) {
          mysqli_query($dbhandle, "set names utf8;");
          $allow_access_api = 0;
          $my_db_private_key = '';
          $my_db_auth_token = '';
          $my_db_wallet_auth_token = '';
          $my_db_sigin_dt = '';
          $my_db_token_refresh_dt = '';
          $my_db_shift_user_id = '';
          $nonce = millitime();
          $usd_balance_before_order = 0;
          $usd_balance_after_order = 0;
          $crypto_balance_before_order = 0;
          $crypto_balance_after_order = 0;
          $sql_check_signin = "select a.*, b.shift_user_id from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b where a.email_address = '$reg_email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_email_address";
          $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
          if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
            $allow_access_api = 1;
            while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
              $my_db_auth_token = trim($row_signin['auth_token']);
              $my_db_wallet_auth_token = trim($row_signin['wallet_auth_token']);
              $my_db_sigin_dt = $row_signin['signin_dt'];
              $my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
              $my_db_private_key = trim($row_signin['private_key']);
              $my_db_shift_user_id = $row_signin['shift_user_id'];
            }
          }
          $authorization_value = "Bearer " . $my_db_auth_token;
          $shift_user_id = '';
          $sql_get_shift_user_id = "select * from cryptocash_shift_user_ids where shift_email_address='$reg_email_address' limit 1";
          $rs_get_shift_user_id = mysqli_query($dbhandle, $sql_get_shift_user_id);
          if (mysqli_num_rows($rs_get_shift_user_id) == 1) {
            while ($row_shift_user_id = mysqli_fetch_array($rs_get_shift_user_id, MYSQLI_ASSOC)) {
              $shift_user_id = $row_shift_user_id['shift_user_sub_id'];
            }
          }

          if ($allow_access_api == 1) {
            if ($private_key != $my_db_private_key) {
              @mysqli_close($dbhandle);
              header('Content-Type: application/json');
              http_response_code(500);
              $ret_rs['result'] = 'failed';
              $ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'Unauthorized.');
              echo json_encode($ret_rs);
              die();
            } else {
              /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
              //try getting wallet USD wallet balance before execution of order...
              ////////////////////////////////////////////////////////////////////////////
              $before_order_wallet_info = get_wallet_balance($currency, $authorization_value);
              if (($before_order_wallet_info['error'] == '') && ($before_order_wallet_info['crypto_balance'] !== '') && ($before_order_wallet_info['usd_balance'] !== '')) {
                $usd_balance_before_order = $before_order_wallet_info['usd_balance'];
                $crypto_balance_before_order = $before_order_wallet_info['crypto_balance'];
              } else {
                _log($reg_email_address, "get_wallet_balance (before order) error : " . $before_order_wallet_info['error']);
              }
              _log($reg_email_address, "usd_balance_before_order = " . $usd_balance_before_order);

              $buy_fee_percent = 3.0;
              $sell_fee_percent = 3.0;
              if( $req_partner['partner'] != 'BOS' ) {
                $get_fee_query = "SELECT * FROM `cryptocash_supported_exchange_pairs` WHERE `partner` = '" . $req_partner['partner'] . "' AND pair_id='$pair'";
                _log($reg_email_address, "check fee query = " . $get_fee_query);
                $get_fee_rs = mysqli_query($dbhandle, $get_fee_query);
                if (mysqli_num_rows($get_fee_rs) > 0) {
                  while ($row_fee = mysqli_fetch_array($get_fee_rs, MYSQLI_ASSOC)) {
                    $buy_fee_percent = (float)$row_fee['buy_fee_percent'];
                    $sell_fee_percent = (float)$row_fee['sell_fee_percent'];
                    _log($reg_email_address, "buy_fee_percent: " . $buy_fee_percent);
                    _log($reg_email_address, "sell_fee_percent: " . $sell_fee_percent);
                    break;
                  }
                } else {
                  _log("", "not found fee data in db");
                }
              }

              ///////////////////////////////////////////////////////////////////////////////////////////
              if ($currency == 'USDT' || $currency == 'USDC') {
                $securities_sell_price = 0;
                $securities_buy_price = 0;

                $crypto_price_data = get_crypto_price($pair2, $authorization_value);
                if (($crypto_price_data['error'] == '') && ($crypto_price_data['buy_price'] !== '') && ($crypto_price_data['sell_price'] !== '')) {
                  $securities_buy_price = $crypto_price_data['buy_price'];
                  $securities_sell_price = $crypto_price_data['sell_price'];
                } else {
                  _log($reg_email_address, "get_crypto_price error : " . $crypto_price_data['error'] . " / " . $crypto_price_data['raw_error']);
                  @mysqli_close($dbhandle);
                  header('Content-Type: application/json');
                  http_response_code(500);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'unknown error occurred. please contact administrator for help #1');
                  echo json_encode($ret_rs);
                  die();
                }

                $amount_flag = 0;
                if ($type == "sell") {
                  _log($reg_email_address, "usd_balance_before_sell = " . $usd_balance_before_order . ", sell amount = " . $amount);
                  if ($crypto_balance_before_order >= $amount) {
                    $amount_flag = 1;
                  }
                } else if ($type == "buy") {
                  $feePercent = 1 + $sell_fee_percent / 100;
                  $needed_usd_amount = $amount * $securities_sell_price * $feePercent;
                  _log($reg_email_address, "usd_balance_before_buy = " . $usd_balance_before_order . ", buy amount = " . $amount);
                  if ($usd_balance_before_order >= $needed_usd_amount) {
                    $amount_flag = 1;
                  }
                }

                if ($amount_flag == 1) {
                  $dec_configurator_key = '';
                  _log($reg_email_address, "try call get_configurator_key api...");
                  $plusqo_configurator_info_res = get_configurator_key($reg_email_address, $my_db_auth_token, 'plusqo_backoffice_key_salt_v4', 'plusqo_backoffice_ec_key_v4');
                  if (($plusqo_configurator_info_res['http_code'] == "200") || ($plusqo_configurator_info_res['http_code'] == "200 OK")) {
                    _log($reg_email_address, "call get_configurator_key api success.");
                    if (!empty($plusqo_configurator_info_res['result']['target_key_value'])) {
                      $dec_configurator_key = trim($plusqo_configurator_info_res['result']['target_key_value']);
                      _log($reg_email_address, "::get dec_configurator_key success : " . $dec_configurator_key);
                    }
                  } else {
                    _log($reg_email_address, "call dec_configurator_key api failed.");
                  }

                  if ($dec_configurator_key == '') {
                    _log($reg_email_address, "failed logging by Configurator Account (get dec_configurator_key failed)! try use default value...");
                    $dec_configurator_key = BACKOFFICE_ADMIN_PWD;
                  }

                  _log($reg_email_address, "try logging in by Configurator Account...");
                  $configurator_access_token = '';
                  $admin_auth_res = _cognito_getAdminAuthToken();
                  _log($reg_email_address, $admin_auth_res);

                  $configurator_access_token = '';
                  if ($admin_auth_res['data'] != null) {
                    _log($reg_email_address, "Access Token (Backoffice) = " . $admin_auth_res['data']);
                    $configurator_access_token = trim($admin_auth_res['data']);
                    $configurator_auth_value = "Bearer " . $configurator_access_token;
                    if ($configurator_access_token != '') {
                      _log($reg_email_address, "::Configurator Account logged in successful. Try execute balancecorrection...");
                      $final_usd_amount = 0;
                      if ($type == "sell") {
                        $feePercent = 1 - $buy_fee_percent / 100.0;
                        $received_amount_usd = $amount * $securities_buy_price * $feePercent;
                        $received_amount_usd = format_fiat(number_format($received_amount_usd, 10, '.', ''), 3);
                        $added_currency_id = "USD";
                        $create_account_transaction_comment = 'Sell ' . $amount . ' ' . $currency;
                        $create_account_transaction_debit_query = sprintf('{"query":"mutation ($items: [RecordTransactionItem!]!) {\\n  create_account_transaction(items: $items) {\\n    parent_transaction_id\\n    account_transactions {\\n      account_transaction_id\\n      type\\n      amount\\n    }\\n  }\\n}","variables":{"items":[{"user_id":"%s","currency_id":"%s","type":"debit","transaction_class":"payment","amount":%s,"comment":"%s"}]}}',
                          $shift_user_id, $currency, $amount, $create_account_transaction_comment);

                        $create_account_transaction_credit_query = sprintf('{"query":"mutation ($items: [RecordTransactionItem!]!) {\\n  create_account_transaction(items: $items) {\\n    parent_transaction_id\\n    account_transactions {\\n      account_transaction_id\\n      type\\n      amount\\n    }\\n  }\\n}","variables":{"items":[{"user_id":"%s","currency_id":"%s","type":"credit","transaction_class":"payment","amount":%s,"comment":"%s"}]}}',
                          $shift_user_id, $added_currency_id, $received_amount_usd, $create_account_transaction_comment);

                        $final_usd_amount = $received_amount_usd;
                      } else if ($type == "buy") {
                        $feePercent = 1 + $sell_fee_percent / 100.0;
                        $pay_amount_usd = $amount * $securities_sell_price * $feePercent;
                        $pay_amount_usd = format_fiat(number_format($pay_amount_usd, 10, '.', ''), 3);
                        $deduction_currency_id = "USD";
                        $create_account_transaction_comment = 'Buy ' . $amount . ' ' . $currency;
                        $create_account_transaction_debit_query = sprintf('{"query":"mutation ($items: [RecordTransactionItem!]!) {\\n  create_account_transaction(items: $items) {\\n    parent_transaction_id\\n    account_transactions {\\n      account_transaction_id\\n      type\\n      amount\\n    }\\n  }\\n}","variables":{"items":[{"user_id":"%s","currency_id":"%s","type":"debit","transaction_class":"payment","amount":%s,"comment":"%s"}]}}',
                          $shift_user_id, $deduction_currency_id, $pay_amount_usd, $create_account_transaction_comment);

                        $create_account_transaction_credit_query = sprintf('{"query":"mutation ($items: [RecordTransactionItem!]!) {\\n  create_account_transaction(items: $items) {\\n    parent_transaction_id\\n    account_transactions {\\n      account_transaction_id\\n      type\\n      amount\\n    }\\n  }\\n}","variables":{"items":[{"user_id":"%s","currency_id":"%s","type":"credit","transaction_class":"payment","amount":%s,"comment":"%s"}]}}',
                          $shift_user_id, $currency, $amount, $create_account_transaction_comment);

                        $final_usd_amount = $pay_amount_usd;
                      }

                      unset($create_account_transaction_debit_res);
                      _log($reg_email_address, $create_account_transaction_debit_query);
                      $tmp_dto_debit_arr = array();
                      $create_account_transaction_debit_res = api_call(
                        '/api/v4/create_account_transaction',
                        0,
                        $create_account_transaction_debit_query,
                        $tmp_dto_debit_arr,
                        $configurator_auth_value);
                      if (($create_account_transaction_debit_res['http_code'] == "200") || ($create_account_transaction_debit_res['http_code'] == "200 OK")) {
                        if (!empty($create_account_transaction_debit_res['result']['errors'])) {
                          _log($reg_email_address, "balancecorrection execution(1) failed : " . $create_account_transaction_debit_res['result']['errors'][0]['message']);
                          @mysqli_close($dbhandle);
                          header('Content-Type: application/json');
                          http_response_code(500);
                          $ret_rs['result'] = 'failed';
                          $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #2.');
                          echo json_encode($ret_rs);
                          die();
                        } else {
                          _log($reg_email_address, "executed balancecorrection(1) successful. Try execute balancecorrection(2)...");
                          unset($create_account_transaction_credit_res);
                          _log($reg_email_address, $create_account_transaction_credit_query);
                          $tmp_dto_credit_arr = array();
                          $create_account_transaction_credit_res = api_call('/api/v4/create_account_transaction', 0, $create_account_transaction_credit_query, $tmp_dto_credit_arr, $configurator_auth_value);
                          if (($create_account_transaction_credit_res['http_code'] == "200") || ($create_account_transaction_credit_res['http_code'] == "200 OK")) {
                            if (!empty($create_account_transaction_credit_res['result']['errors'])) {
                              _log($reg_email_address, "balancecorrection execution(2) failed : " . $create_account_transaction_credit_res['result']['errors'][0]['message']);
                              @mysqli_close($dbhandle);
                              header('Content-Type: application/json');
                              http_response_code(500);
                              $ret_rs['result'] = 'failed';
                              $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #3.');
                              echo json_encode($ret_rs);
                              die();
                            } else {
                              _log($reg_email_address, "executed balancecorrection(2) successful.");
                              $tx_history_date = date('Y/m/d H:i:s');
                              $sql_add_tx_history = "INSERT INTO cryptocash_exchange_history (id, email_address, currency, type, amount, usd_amount, status, date, tx_id, created_from) VALUES (null, '$reg_email_address', '$currency', '$type', '$amount','$final_usd_amount', 'completely_filled', '$tx_history_date', '', '" . $req_partner['partner'] . "')";
                              if (mysqli_query($dbhandle, $sql_add_tx_history)) {
                                $exchange_res = array('email_address' => $reg_email_address, 'id' => '');
                                $exchange_res_details = array();
                                $exchange_res_details['type'] = $type;
                                $exchange_res_details['pair'] = $pair;
                                $exchange_res_details['currency'] = $currency;
                                $exchange_res_details['amount'] = $amount;
                                $exchange_res_details['status'] = "success";
                                if ($type == "sell") {
                                  $exchange_res_details['received_amount'] = abs($final_usd_amount);
                                } else if ($type == "buy") {
                                  $exchange_res_details['paid_amount'] = abs($final_usd_amount);
                                }
                                $tx_history_date_utc = strtotime($tx_history_date) - 32400; //change to UTC
                                $exchange_res_details['created_dt'] = date('Y/m/d H:i:s', $tx_history_date_utc);

                                $exchange_res['details'] = $exchange_res_details;
                                ////////////////////////////////////////////////////////

                                @mysqli_close($dbhandle);
                                $ret_rs['result'] = 'success';
                                $ret_rs['exchange_response'] = $exchange_res;
                                header('Content-Type: application/json');
                                echo json_encode($ret_rs);
                                die();
                              } else {
                                _log($reg_email_address, $sql_add_tx_history);
                              }
                            }
                          } else {
                            _log($reg_email_address, "balancecorrection execution(2) failed: not 200 ok");
                            @mysqli_close($dbhandle);
                            header('Content-Type: application/json');
                            http_response_code(500);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #4.');
                            echo json_encode($ret_rs);
                            die();
                          }
                        }
                      } else {
                        _log($reg_email_address, "balancecorrection execution(1) failed: not 200 ok");
                        @mysqli_close($dbhandle);
                        header('Content-Type: application/json');
                        http_response_code(500);
                        $ret_rs['result'] = 'failed';
                        $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #5.');
                        echo json_encode($ret_rs);
                        die();
                      }
                    } else {
                      _log($reg_email_address, "failed to get Backoffice Access Token");
                      @mysqli_close($dbhandle);
                      header('Content-Type: application/json');
                      http_response_code(500);
                      $ret_rs['result'] = 'failed';
                      $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #6.');
                      echo json_encode($ret_rs);
                      die();
                    }
                  } else {
                    @mysqli_close($dbhandle);
                    header('Content-Type: application/json');
                    http_response_code(500);
                    $ret_rs['result'] = 'failed';
                    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #7.');
                    echo json_encode($ret_rs);
                    die();
                  }
                } else {
                  @mysqli_close($dbhandle);
                  header('Content-Type: application/json');
                  http_response_code(500);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => 8, 'errorMessage' => 'Insufficiency balance to execute this order.');
                  echo json_encode($ret_rs);
                  die();
                }
              } else {
                $tmp_dto_create_order_arr = array();
                $create_order_query = sprintf('{"query":"mutation ($instrument_id: String!, $type: OrderType!, $price: Float, $side: OrderSide!, $time_in_force: OrderTimeInForce!, $quantity: Float!, $expires_at: String, $quantity_mode: OrderQuantityMode) {\\n  create_order(instrument_id: $instrument_id, type: $type, price: $price, side: $side, time_in_force: $time_in_force, quantity: $quantity, expires_at: $expires_at, quantity_mode: $quantity_mode) {\\n    order_id\\n    type\\n    side\\n    status\\n    price\\n    quantity\\n    executed_quantity\\n    remaining_quantity\\n    quantity_mode\\n    instrument_id\\n    message\\n    updated_at\\n    created_at\\n    expires_at\\n  }\\n}","variables":{"instrument_id":"%s","type":"market","price":null,"side":"%s","time_in_force":"ioc","quantity":%s,"quantity_mode":"base"}}', $pair2, $type, $amount);
                _log($reg_email_address, $create_order_query);
                unset($create_order_res);
                $create_order_res = api_call(
                  '/api/v4/create_order/',
                  0,
                  $create_order_query,
                  $tmp_dto_create_order_arr,
                  $authorization_value);
                _log($reg_email_address, json_encode($create_order_res));
                if (($create_order_res['http_code'] == "200") || ($create_order_res['http_code'] == "200 OK")) {
                  if (!empty($create_order_res['result']['errors'])) {
                    _log($reg_email_address, "::/api/v4/create_order/ failed : " . $create_order_res['result']['errors'][0]['message']);
                    @mysqli_close($dbhandle);
                    header('Content-Type: application/json');
                    http_response_code(500);
                    $ret_rs['result'] = 'failed';
                    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #8.');
                    echo json_encode($ret_rs);
                    die();
                  } else {
                    $res_order_id = (!empty($create_order_res['result']['data']['create_order']['order_id'])) ? $create_order_res['result']['data']['create_order']['order_id'] : '';
                    $res_order_status = (!empty($create_order_res['result']['data']['create_order']['status'])) ? $create_order_res['result']['data']['create_order']['status'] : '';
                    $res_order_quantity = (!empty($create_order_res['result']['data']['create_order']['quantity'])) ? $create_order_res['result']['data']['create_order']['quantity'] : '';
                    $res_order_side = (!empty($create_order_res['result']['data']['create_order']['side'])) ? $create_order_res['result']['data']['create_order']['side'] : '';
                    $res_order_instrument_id = (!empty($create_order_res['result']['data']['create_order']['instrument_id'])) ? strtoupper($create_order_res['result']['data']['create_order']['instrument_id']) : '';
                    $res_order_created_at = (!empty($create_order_res['result']['data']['create_order']['created_at'])) ? $create_order_res['result']['data']['create_order']['created_at'] : '';
                    _log($reg_email_address, "create_order OK : " . $res_order_side . "/" . $res_order_id . "/status: " . $res_order_status . "/ quantity: " . $res_order_quantity);
                    sleep(2);
                    $after_order_wallet_info = get_wallet_balance($currency, $authorization_value);
                    if (($after_order_wallet_info['error'] == '') && ($after_order_wallet_info['crypto_balance'] !== '') && ($after_order_wallet_info['usd_balance'] !== '')) {
                      $usd_balance_after_order = $after_order_wallet_info['usd_balance'];
                      $crypto_balance_after_order = $after_order_wallet_info['crypto_balance'];
                    } else {
                      _log($reg_email_address, "get_wallet_balance (ater order) error: " . $after_order_wallet_info['error']);
                    }
                    _log($reg_email_address, "usd_balance_after_order = " . $usd_balance_after_order);

                    $exchange_res = array('email_address' => $reg_email_address, 'id' => $res_order_id);
                    $exchange_res_details = array();
                    $used_currency = "";
                    if ($pair == 'BTCUSD') {
                      $used_currency = "BTC";
                    } else if ($pair == 'USDTUSD') {
                      $used_currency = "USDT";
                    } else if ($pair == 'USDCUSD') {
                      $used_currency = "USDC";
                    } else if ($pair == 'SOLUSD') {
                      $used_currency = "SOL";
                    } else if ($pair == 'BCHUSD') {
                      $used_currency = "BCH";
                    } else if ($pair == 'ETHUSD') {
                      $used_currency = "ETH";
                    } else if ($pair == 'LTCUSD') {
                      $used_currency = "LTC";
                    } else if ($pair == 'XRPUSD') {
                      $used_currency = "XRP";
                    }

                    $exchange_res_details['type'] = strtolower($res_order_side);
                    $exchange_res_details['pair'] = $res_order_instrument_id;
                    $coin_type = '';
                    if ($exchange_res_details['pair'] == 'BTCUSD') {
                      $coin_type = "BTC";
                    } else if ($exchange_res_details['pair'] == 'USDTUSD') {
                      $coin_type = "USDT";
                    } else if ($exchange_res_details['pair'] == 'USDCUSD') {
                      $coin_type = "USDC";
                    } else if ($exchange_res_details['pair'] == 'SOLUSD') {
                      $coin_type = "SOL";
                    } else if ($exchange_res_details['pair'] == 'BCHUSD') {
                      $coin_type = "BCH";
                    } else if ($exchange_res_details['pair'] == 'ETHUSD') {
                      $coin_type = "ETH";
                    } else if ($exchange_res_details['pair'] == 'LTCUSD') {
                      $coin_type = "LTC";
                    } else if ($exchange_res_details['pair'] == 'XRPUSD') {
                      $coin_type = "XRP";
                    }
                    $exchange_res_details['currency'] = $coin_type;
                    $exchange_res_details['amount'] = $amount;
                    $exchange_res_details['status'] = "completed";
                    if ($type == "sell") {
                      $diff_wallet_usd_amount = abs($usd_balance_after_order - $usd_balance_before_order);
                      $exchange_res_details['received_amount'] = $diff_wallet_usd_amount;
                    } else if ($type == "buy") {
                      $diff_wallet_usd_amount = abs($usd_balance_before_order - $usd_balance_after_order);
                      $exchange_res_details['paid_amount'] = $diff_wallet_usd_amount;
                    }

                    //save to db
                    if ($res_order_created_at != '') {
                      $tx_history_date = str_replace("-", "/", $res_order_created_at);
                    } else {
                      $tx_history_date = date('Y/m/d H:i:s');
                    }

                    $sql_add_tx_history = "
                      INSERT INTO cryptocash_exchange_history 
                      (
                          id, 
                          email_address, 
                          currency, 
                          type, 
                          amount, 
                          usd_amount, 
                          status, 
                          date, 
                          tx_id, 
                          created_from, 
                          shift_order_id
                      ) 
                      VALUES 
                      (
                          null, 
                          '$reg_email_address', 
                          '$currency', 
                          '$type', 
                          '$amount', 
                          '$diff_wallet_usd_amount', 
                          'completely_filled', 
                          '$tx_history_date', 
                          '', 
                          '" . $req_partner['partner'] . "', 
                          '$res_order_id'
                      )";
                    _log($reg_email_address, $sql_add_tx_history);
                    mysqli_query($dbhandle, $sql_add_tx_history);
                    if (mysqli_affected_rows($dbhandle) <= 0) {
                      _log($reg_email_address, "add to cryptocash_exchange_history failed");
                    }

                    $exchange_res['details'] = $exchange_res_details;
                    @mysqli_close($dbhandle);
                    $ret_rs['result'] = 'success';
                    $ret_rs['exchange_response'] = $exchange_res;
                    header('Content-Type: application/json');
                    echo json_encode($ret_rs);
                    die();
                  }
                } else {
                  _log($reg_email_address, "::/api/v4/create_order/ failed: not 200 ok");
                  @mysqli_close($dbhandle);
                  header('Content-Type: application/json');
                  http_response_code(500);
                  $ret_rs['result'] = 'failed';
                  $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'Unknown error occurred. please contact administrator for help #9.');
                  echo json_encode($ret_rs);
                  die();
                }
              }
            }
          } else {
            @mysqli_close($dbhandle);
            header('Content-Type: application/json');
            http_response_code(500);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 10, 'errorMessage' => 'you must sign in to use this API.');
            echo json_encode($ret_rs);
            die();
          }
        } else {
          //_log($reg_email_address, "could not connect db !");
          //@mysqli_close($dbhandle);
          header('Content-Type: application/json');
          http_response_code(500);
          $ret_rs['result'] = 'failed';
          $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'system is under maintenance.');
          echo json_encode($ret_rs);
          die();
        }
      } else {
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = $errors[0];
        _log("", $ret_rs['error']['errorMessage']);
        header('Content-Type: application/json');
        echo json_encode($ret_rs);
        die();
      }
    }
  } else {
    header('HTTP/1.0 403 Forbidden');
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
  http_response_code(405);
  die();
}
