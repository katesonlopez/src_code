<?php global $baseUrl;
include 'includes/header.php';
?>
<script>
  $(document).ready(function() {
    logout();
  });
</script>
<?php include 'includes/footer.php'; ?>
