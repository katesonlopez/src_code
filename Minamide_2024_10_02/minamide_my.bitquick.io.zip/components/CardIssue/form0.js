import {useState} from "react";

function Form0({ user, userdata, form0, countryOptions, onNextClick, isMobile, memberCard }) {

    const [isLoading, setIsLoading] = useState(false);

    function onSubmitAction(event) {
        event.preventDefault();
        setIsLoading(true);
        onNextClick(user, 1);
    }

    return (
      <>
          <div className="row justify-content-center">
              <div className="col-md-8">
                  <form className="row g-3" onSubmit={onSubmitAction} encType="multipart/form-data">
                      <div className="card">
                          <div className="card-header no-color">
                              <h3 className="mt-2 text-center text-white font-800"> BITQUICK MEMBER CARD</h3>
                          </div>
                          <div className="card-body light-bg-color mb-2 text-center">
                              <div className="col-sm-12">
                                  <div className="m-3 font-14">
                                      Please follow the next steps after receiving the Member Card directly from the BitQuick team
                                  </div>
                                  <button
                                    type="submit"
                                    className="button primary mt-4 mb-3 offset-sm-3 col-12 col-sm-6"
                                    disabled={isLoading}>
                                      <i className="bi bi-chevron-right right"></i> NEXT
                                      {isLoading && <span className="spinner-border spinner-border-sm ml-1"></span>}
                                  </button>
                              </div>
                          </div>
                      </div>
                  </form>
              </div>
          </div>
      </>
    )
}

export { Form0 };
