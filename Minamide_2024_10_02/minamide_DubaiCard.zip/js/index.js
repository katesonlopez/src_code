$(document).ready(function() {
  // Initialize components
  initComponents();

  // Initialize wallet list
  initCryptoWallets(false);

  // Hide zero crypto event handler
  $('#hideZeroBalancesCheckbox').change(function () {
    clearCryptoWallets();
    initCryptoWallets($('#hideZeroBalancesCheckbox').is(':checked'), $('.wallet-filter').val());
  });

  // Keyword event handler
  $('.wallet-filter').on('input', function(event) {
    event.preventDefault(); // Prevent the default action (e.g., form submission)
    clearCryptoWallets();
    initCryptoWallets($('#hideZeroBalancesCheckbox').is(':checked'), $('.wallet-filter').val());
  });

  // Keyword event handler
  $('.btn-clear').on('click', function(event) {
    event.preventDefault(); // Prevent the default action (e.g., form submission)
    $('.wallet-filter').val('');
    clearCryptoWallets();
    initCryptoWallets($('#hideZeroBalancesCheckbox').is(':checked'), '');
  });

  // Calculate total
  updateTotalUsd(calculateTotalBalanceUSD(CRYPTOS));
});

function initCryptoWallets(hideZero, keywords = ''){
  // Sort the CRYPTOS array based on the 'order' property
  CRYPTOS.sort((a, b) => a.order - b.order);
  let filteredCrypto = CRYPTOS;

  // Filter out zero currencies when it is necessary.
  if( hideZero )
    filteredCrypto = CRYPTOS.filter(crypto => crypto.balance > 0);

  // Filters according keywords
  if( keywords.trim().length > 0 ) {
    const keywordArray = keywords.toLowerCase().split(' ');

    // Create a fuzzy search instance
    const fuse = new Fuse(filteredCrypto, {
      keys: ['title','unit'],
      includeScore: true,
      threshold: 0.1 // Adjust this threshold based on desired fuzziness
    });

    // Filter cryptocurrencies based on whether their title matches any of the keywords
    filteredCrypto = keywordArray.reduce((acc, keyword) => {
      const results = fuse.search(keyword);
      const matches = results.map(result => result.item);
      return [...new Set([...acc, ...matches])]; // Merge results and remove duplicates
    }, []);
  }

  updateTotalUsd(calculateTotalBalanceUSD(filteredCrypto));

  // Iterate through the sorted CRYPTOS array
  filteredCrypto.forEach(function(crypto) {
    // Create the main currency menu item
    let cryptoItem = `
      <li class="list-group-item d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
          <img src="assets/images/currency/${crypto.icon}" alt="${crypto.title}" width="40" height="40" class="mr-3">
          <div class="">
            <strong class="${crypto.unit.toLowerCase()}-color">${crypto.title}</strong><br>
            <small>${(crypto.price.toFixed(2)*1).toLocaleString()} <small>USD</small></small>
          </div>
        </div>
        <div class="d-flex align-items-center">
          <div class="pr-2 pr-md-4 text-end">
            <strong><span class="amount">${(crypto.balance.toFixed(crypto.float)*1).toLocaleString()}</span> ${crypto.unit}</strong><br>
            <small class="float-right">${((crypto.balance * crypto.price).toFixed(2)*1).toLocaleString()}<small> USD</small></small>
          </div>
          <div class="dropdown">
            <i class="bi bi-list dropdown-toggle fs-x-large pointer" data-toggle="dropdown"></i>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="#">Buy</a></li>
              <li><a class="dropdown-item" href="#">Sell</a></li>
              <li><a class="dropdown-item" href="#">Deposit</a></li>
              <li><a class="dropdown-item" href="#">Withdraw</a></li>
            </ul>
          </div>
        </div>
      </li>`;

    // Append the generated menu item to the currencyMenu list
    $('.my-wallets').append(cryptoItem);
  });
}

function clearCryptoWallets(){
  $('.my-wallets').html('');
}

function calculateTotalBalanceUSD(cryptos) {
  return cryptos.reduce((total, crypto) => {
    // Calculate value in USD if the unit is not 'USD'
    const valueInUSD = crypto.balance * crypto.price;
    return total + valueInUSD;
  }, 0);
}

function updateTotalUsd(total){
  $('#amount-total-usd').text((total.toFixed(2) * 1).toLocaleString());
}