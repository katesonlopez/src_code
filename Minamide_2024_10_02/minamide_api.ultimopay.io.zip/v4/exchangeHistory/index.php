<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	//$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$partner = "";
	$crypto_pair_arr = array('USDTUSD', 'BTCUSD');
	
	
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_freelancer) {
				$found = 7;
				$coin = 'USDT';
				break;			
			} else if ($value == $apikey_bos) {
				$found = 8;
				$coin = 'USDT';
				$partner = "BOS";
				break;
			}
		}
	}

	function _log($email, $line) {
		
		//global $fh;
		if ($email == "") {
			$fh2 = fopen("/var/www/api.ultimopay.io/v1/exchangeHistory/log/exchange_history.log" , 'a');
		} else {
			$fh2 = fopen("/var/www/api.ultimopay.io/v1/exchangeHistory/log/" . $email . ".log" , 'a');
		}		
		$fline = date('[Ymd H:i:s] ') . $line."\n";
		fwrite($fh2, $fline);
		fclose($fh2);
		//echo date('[Ymd H:i:s] ').$line."\n";
		//@ob_flush(); 
		//flush();
		
	}

	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}


	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	//_log("bat dau xu ly...");
	if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6) || ($found==7) || ($found==8)) {


		
		
		//$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);
		
		//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
		//echo "payment_id: " . $payment_id . "<br/>";
		$json = file_get_contents('php://input');
		$data = json_decode($json, true);
		
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					//$failed_rs['error'] = 'Reached the maximum stack depth';
					_log("", 'Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					_log("", 'Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					//$failed_rs['error'] = 'Incorrect control character';
					_log("", 'Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					//$failed_rs['error'] = 'Syntax error or JSON invalid';
					_log("", 'Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					//$failed_rs['error'] = 'Unknown error';
					_log("", 'Unknown error');
					break;
			}
			
			//throw new Exception($error);
			//_log($failed_rs['error']);
			_log("", 'A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			}
			
			
			//auth_token
			if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
				$error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
				$errors[] = $error_obj;
			}
			
						
			if (count($errors) == 0) {
				
				$errors_sub = array();
				
				
				//proceed to shift api
				require_once '../include/common.php';
				require_once '../include/dbconfig.php';
				
				////////////////////////////////////////////////////
				
				//$allowed_currency_arr = array('USDT');
				$allowed_shift_currency_arr = array('USDT', 'BTC', 'USD');
				//receive POST params
				$reg_email_address = trim($data['email_address']);
				//$auth_token = trim($data['auth_token']);
				$private_key = trim($data['auth_token']);
				$tx_history_ret_arr = array();
								
				_log($reg_email_address, "get card load history started...");
				
				//$post_data = array();
				//$post_data['exchange'] = "PLUSQO";
				//$post_data['refreshToken'] = $auth_refresh_token;
								
				//$refresh_token_res = api_call('/authentication/user_authentication/refreshAccessToken', 0, '', $post_data, '');
				//if ($refresh_token_res['result']['result'] == 'success') {
					
					//$signin_user_data = array();
					
					$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
					if (mysqli_connect_errno() == 0) {
						mysqli_query($dbhandle, "set names utf8;");
						$allow_access_api = 0;
						
						$my_db_private_key = '';
						$my_db_auth_token = '';
						$my_db_wallet_auth_token = '';
						$my_db_sigin_dt = '';
						$my_db_token_refresh_dt = '';
						$my_db_shift_user_id = '';
						$authorization_value = '';
						$sql_check_signin = "select a.*, b.shift_user_id from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b where a.email_address = '$reg_email_address' AND a.merchant='$partner' AND a.email_address = b.shift_email_address";
						_log($reg_email_address, $sql_check_signin);
						$rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
						if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
							$allow_access_api = 1;
							while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
								$my_db_auth_token = trim($row_signin['auth_token']);
								$my_db_wallet_auth_token = trim($row_signin['wallet_auth_token']);
								$my_db_sigin_dt = $row_signin['signin_dt'];
								$my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
								$my_db_private_key = trim($row_signin['private_key']);
								$my_db_shift_user_id = $row_signin['shift_user_id'];
								$authorization_value = "Bearer " . $my_db_auth_token;
								
							}
						}
						//@mysqli_close($dbhandle);
						
						if ($allow_access_api == 1) {
							
							if ($private_key != $my_db_private_key) {
								@mysqli_close($dbhandle);
								header('Content-Type: application/json');
								http_response_code(500);
								$ret_rs['result'] = 'failed';
								$ret_rs['error'] = array('errorCode' => 5, 'errorMessage' => 'Unauthorized.');
								echo json_encode($ret_rs);
								die();
							} else {
								/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
								_log($reg_email_address, "vao sell roi bay ?");
								$tx_history_post_data = array();
								$tx_history_res = api_call('/trade/orders/closed', 0, $tx_history_post_data, '', $authorization_value);
								if (is_array($tx_history_res['result']['items'])) {
									if (count($tx_history_res['result']['items']) > 0) {
										_log($cur_username . "::/trade/orders/closed: ok vao roi");		
										_log($cur_username . ":: total exchange cnt = " . count($tx_history_res['result']['items']));								
										for ($tx_cnt=0; $tx_cnt<count($tx_history_res['result']['items']); $tx_cnt++) {	
											$cur_tx = $tx_history_res['result']['items'][$tx_cnt];
											_log($cur_tx['side'] . " / " . $cur_tx['type'] . " / " . $cur_tx['id'] . " / " . $cur_tx['status']);
											
											//if (($cur_tx['type'] == 'market') && ($cur_tx['instrument_id'] == 'BTCUSD')) {
											if ($cur_tx['type'] == 'market') {
												_log("du ma may !");
												unset($tx_item);
												$tx_item = array();
												$tx_item[] = date('Y/m/d H:i:s', ($cur_tx['open_time'] / 1000) - 32400);
												$found_instrument = 0;
												if ($cur_tx['instrument_id'] == 'BTCUSD') {
													$tx_item[] = 'BTC';
													$found_instrument = 1;
												} else if ($cur_tx['instrument_id'] == 'USDTUSD') {
													$tx_item[] = 'USDT';
													$found_instrument = 1;
												}
												
												if ($found_instrument == 1) {
													//////////////////////////////////////////////////////
													$buy_total_usd_paid = 0;
													$buy_total_usd_beforetax_paid = 0;
													$buy_total_usd_aftertax_paid = 0;
													
													
													$net_receive_usd_amount = 0;
													$gross_receive_usd_amount = 0;
													$shift_trading_commission_amount = 0;
													if (($cur_tx['status'] == 'completely_filled') || ($cur_tx['status'] == 'partially_filled')) {
														_log("choi suong lam ! " . $cur_tx['status']);
														//////////////////////////////////////////////////////////////
														if ((is_array($cur_tx['transactions'])) && (count($cur_tx['transactions']) > 0)){									
														//if (!empty($cur_tx['transactions'])) {
															_log("right here !!!");
															//_log("transactions total = " . count($cur_tx['transactions']));
															//iterate transactions of this order
															foreach ($cur_tx['transactions'] as $order_tx_k => $order_tx_v) {
																//_log($order_tx_k);
																$cur_tx_type = '';
																$cur_tx_currency = '';
																$cur_tx_conversion_currency = '';
																$cur_tx_amount = '';
																foreach ($order_tx_v as $order_tx_k2 => $order_tx_v2) {
																	//_log($order_tx_k2 . " = " . $order_tx_v2);
																	if (trim($order_tx_k2) == 'type') {
																		$cur_tx_type = trim($order_tx_v2);
																	}
																	if (trim($order_tx_k2) == 'conversion_currency') {
																		$cur_tx_conversion_currency = trim(strtoupper($order_tx_v2));
																	}
																	if (trim($order_tx_k2) == 'currency') {
																		$cur_tx_currency = trim(strtoupper($order_tx_v2));
																	}
																	if (trim($order_tx_k2) == 'amount') {
																		$cur_tx_amount = $order_tx_v2;
																	}
																}
																if (($cur_tx_type == 'Execution') && ($cur_tx_currency == 'USD') && ($cur_tx_conversion_currency == 'USD')) {
																	$gross_receive_usd_amount = $cur_tx_amount;
																	$buy_total_usd_beforetax_paid = abs($cur_tx_amount);
																}										
																if (($cur_tx_type == 'TradingCommission') && ($cur_tx_currency == 'USD') && ($cur_tx_conversion_currency == 'USD')) {
																	$shift_trading_commission_amount = abs($cur_tx_amount);
																}
															}										
														}
														if ($cur_tx['side'] == 'sell') {
															if ($gross_receive_usd_amount > 0) {
																$net_receive_usd_amount = $gross_receive_usd_amount - $shift_trading_commission_amount;
															}
															_log("SELL:: " . $net_receive_usd_amount . " / " . $gross_receive_usd_amount . " / " . $shift_trading_commission_amount);
														} else if ($cur_tx['side'] == 'buy'){
															if ($buy_total_usd_beforetax_paid > 0) {
																$buy_total_usd_aftertax_paid = $buy_total_usd_beforetax_paid + $shift_trading_commission_amount;
															}
															_log("SELL:: " . $buy_total_usd_beforetax_paid . " / " . $buy_total_usd_aftertax_paid . " / " . $shift_trading_commission_amount);
														}
														
														$buy_total_usd_aftertax_paid = format_fiat(number_format($buy_total_usd_aftertax_paid, 10, '.', ','), 2);
														
														$net_receive_usd_amount = format_fiat(number_format($net_receive_usd_amount, 10, '.', ','), 2);
														$gross_receive_usd_amount = format_fiat(number_format($gross_receive_usd_amount, 10, '.', ','), 2);
														//_log($net_receive_usd_amount . " / " . $gross_receive_usd_amount);
														//$shift_trading_commission_amount = format_fiat(number_format($shift_trading_commission_amount, 10, '.', ','), 2);
														if ($cur_tx['side'] == 'sell') {
															$coin_type = "";
															if ($cur_tx['instrument_id'] == 'BTCUSD') {
																$coin_type = "BTC";
															} else if ($cur_tx['instrument_id'] == 'USDTUSD') {
																$coin_type = "USDT";
															}
															
															$tx_item[] = 'Sell';
															$tx_item[] = 'Sell ' . decimal_notation($cur_tx['quantity']) . ' ' . $coin_type .'<br/>(Received ' . $net_receive_usd_amount . ' USD)';		
														} else if ($cur_tx['side'] == 'buy'){
															$coin_type = "";
															if ($cur_tx['instrument_id'] == 'BTCUSD') {
																$coin_type = "BTC";
															} else if ($cur_tx['instrument_id'] == 'USDTUSD') {
																$coin_type = "USDT";
															}
															$tx_item[] = 'Buy';
															$tx_item[] = 'Buy ' . decimal_notation($cur_tx['quantity']) . ' ' . $coin_type . '<br/>(Paid ' . $buy_total_usd_aftertax_paid . ' USD)';		
														}
														$tx_item[] = "<span style=\"font-weight: 900\">COMPLETED</span>";
														//////////////////////////////////////////////////////////////
													} else {
														
														if ($cur_tx['status'] == 'rejected') {
															if ($cur_tx['side'] == 'sell') {
																$tx_item[] = 'Sell';
																$tx_item[] = 'Sell ' . decimal_notation($cur_tx['quantity']) . ' ' . $coin_type . '<br/>(Received ' . $net_receive_usd_amount . ' USD)';		
															} else if ($cur_tx['side'] == 'buy'){
																$tx_item[] = 'Buy';
																$tx_item[] = 'Buy ' . decimal_notation($cur_tx['quantity']) . ' ' . $coin_type . '<br/>(Paid ' . $buy_total_usd_aftertax_paid . ' USD)';	
															}
															$tx_item[] = "<span style=\"padding: 3px 3px; background-color: red; color: #fff; font-weight: 900; \">FAILED</span>";
														}
													}
													$tx_history_ret_arr[] = $tx_item;
													//////////////////////////////////////////////////////
												} else {
													//////////////////////////////////////////////////////
													
													//////////////////////////////////////////////////////
												}
												
												
												
												
												
												
												
											}
										}
									} else {
										_log($cur_username . "::/trade/orders/closed ERROR: is EMPTY");
									}
									
								} else {
									_log($cur_username . "::/trade/orders/closed ERROR: is not array");
								}
								/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							}
							
							
							
						} else {
							@mysqli_close($dbhandle);
							header('Content-Type: application/json');
							http_response_code(500);
							$ret_rs['result'] = 'failed';
							$ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'you must sign in to use this API.');
							echo json_encode($ret_rs);
							die();
						}
						
						
					} else {			
						//_log($reg_email_address, "could not connect db !");
						@mysqli_close($dbhandle);
						header('Content-Type: application/json');
						http_response_code(500);
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'system is under maintenance.');
						echo json_encode($ret_rs);
						die();
						
					}
					
					
					//header('Content-Type: application/json');
					//echo json_encode($ret_rs);
					//die();
					@mysqli_close($dbhandle);
					$ret_rs['result'] = 'success';
					//$ret_rs['email_address'] = $reg_email_address;
					$ret_rs['exchangeHistoryResponse'] = $tx_history_ret_arr;					
					header('Content-Type: application/json');
					echo json_encode($ret_rs);
					die();
					
					
					
				//} else {
				//	_log($reg_email_address . " : " . $refresh_token_res['result']['message']);
				//	$ret_rs['result'] = 'failed';
				//	$ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'failed to refresh auth_token');
				//	header('Content-Type: application/json');
				//	echo json_encode($ret_rs);
				//	die();
				//}
				
				
			} else {
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors[0];
				_log("", $ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
				
			
		}

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>