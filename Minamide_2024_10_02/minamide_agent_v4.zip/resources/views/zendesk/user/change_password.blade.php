@extends('layouts.app')

@section('content')
    <div class="container d-flex justify-content-center align-items-center flex-column" style="min-height: 50vh;">
      @if (session('success'))
        <div class="alert alert-success w-50">
          {{ session('success') }}
        </div>
      @endif
      @if (session('error'))
        <div class="alert alert-danger w-50">
          {{ session('error') }}
        </div>
      @endif
        <h1>Change Password</h1>
        <form action="{{ route('zendesk.password.change') }}" method="POST" class="w-50">
            @csrf
          <div class="mb-3">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" class="form-control form-control-sm rounded" placeholder="Email" required value="{{ old('email', $userData['email'] ?? '') }}">
            @error('email')
            <div class="text-danger">{{ $message }}</div>
            @enderror
          </div>
            <label for="password">New Password:</label>
            <div class="mb-3">
                <input type="password" id="new_password" name="new_password" class="form-control form-control-sm rounded" placeholder="New Password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-sm btn-block rounded-pill">Change Password</button>
        </form>
    </div>
@endsection

