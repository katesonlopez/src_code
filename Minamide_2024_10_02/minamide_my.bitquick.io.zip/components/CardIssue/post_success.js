import { useRouter } from 'next/router';
import { userService } from '/services';
import Swal from 'sweetalert2';
import { useEffect, useState } from 'react';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import Loading from "../Loading";

function PostSuccess({ user, form2, userdata, form1, onNextClick, isMobile, memberCard }) {
  const [profile, setProfile] = useState([]);
  const [status, setStatus] = useState([]);

  const router = useRouter();

  useEffect(() => {
    userService.runApi('userInfo/', user).then((res) => {
      console.log('userInfo', res.data.userInfoResponse);
      setProfile(res.data.userInfoResponse);
      userService.runApi('updateUserStatus/', user).then((res) => {
        console.log('updateUserStatus', res.data.updateStatusResponse);
        setStatus(res.data.updateStatusResponse);
      });
    });
  }, [memberCard, user]);

  const validationSchema = Yup.object().shape({
    member_confirm1: Yup.string().required('Member card number is required'),
    member_confirm2: Yup.string()
      .required('Confirmation code is required')
      .test('is-7878', 'Confirmation code is not valid, please contact the administrator', (value) => value === '7878'),
    member_confirm0: Yup.bool().oneOf([true], 'Accurate check is required'),
  });

  const formOptions = {
    resolver: yupResolver(validationSchema),
    defaultValues: {},
    mode: 'onBlur',
  };

  const { register, handleSubmit, formState } = useForm(formOptions);
  const { errors, isSubmitting } = formState;

  function onSubmit(form) {
    user.member_card = 1;

    return userService
      .runApi('payCardFee/', user)
      .then((res) => {
        if (res.data.result === 'success' || res.data.error.errorCode * 1 === 9/*means This user account has been already paid card fee.*/) {
          console.log(res);
          user.status['kyc_status'] = 2;
          user.status['payment_status'] = 2;
          user.status['card_activation_status'] = 1;

          userService
            .runApi('updateUserStatus/', user)
            .then((res) => {
              if (res.data.result === 'success') {
                router.reload();
              }
            })
            .catch((res) => {
              Swal.fire({
                title: 'Error',
                text: res.response.data.error.errorMessage,
                icon: 'error',
              });
            });
        }
      })
      .catch((res) => {
        Swal.fire({
          title: 'Error',
          text: res.response.data.error.errorMessage,
          icon: 'error',
        });
      });
  }

  function resetDoc() {
    Swal.fire({
      title: 'Are you sure?',
      text: 'This action will reset your activation process.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, reset it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true,
    }).then((result) => {
      if (result.isConfirmed) {
        user.status = {};
        user.status.card_activation_status = '0';

        if (memberCard === 1) user.member_card = 1;

        userService.runApi('updateUserStatus/', user).then(() => {
          router.reload();
        });
      }
    });
  }

  return (
    <>
      {status.kyc_status ? (
        <div className="col-md-9 mx-auto mt-4">
          <div className="card mx-auto">
            <div className="card-header no-color">
              <h3 className="mt-2 text-center text-white font-800">
                {memberCard === 0 ? 'Your Card Activation Request is Under Review' : 'BITQUICK MEMBER CARD'}
              </h3>
            </div>
            <div className="card-body p-4 light-bg-color m-2">
              {memberCard === 0 ? (
                <>
                  <p className="card-text">
                    We will inform you the result via email, or here in your dashboard. Please keep following our updates.
                  </p>
                  <div className="d-flex justify-content-between mt-3 mb-3">
                    <a className="button primary" target="_blank" rel="noopener noreferrer" href={userdata.card_activation_file_url}>
                      Check Your Activation Image
                    </a>
                    <a className="button primary" href="#" onClick={resetDoc}>
                      Reset Your activation Process
                    </a>
                  </div>
                  <p className="card-text">
                    <strong>About PIN Code:</strong>
                    <br />
                    The PIN code is enclosed in the same envelope as the card. Please open the bag binding of the enclosed
                    documents and check.
                  </p>
                  <p className="card-text mt-2">
                    <strong>Notes:</strong>
                    <br />
                    Do not disclose your PIN code to anyone. Do not write down the PIN code on your card. It may be used if the
                    card is lost. If you do not know your PIN code, it can be reissued.
                  </p>
                  <hr />
                  <p className="card-text">
                    <strong>Activate Your {memberCard === 0 ? 'Debit' : 'Member'} Card</strong>
                    <br />
                    Please note that reissuance will incur a fee and may take time.
                  </p>
                </>
              ) : (
                (status.kyc_status*1 === 2 && status.payment_status*1 === 2 && status.card_activation_status*1 === 1) ? (
                    <>
                      <label className="text-left p-2">
                        <p className="card-text">Congratulations!</p>
                        <p className="card-text mt-2">Your application for the BitQuick Member Card has been completed.</p>
                        <p className="card-text">Please wait while your card is activated.</p>
                        <p className="card-text font-800 mt-3">
                          <b>
                            It will be available for use within approximately 2-3 business days.
                          </b>
                        </p>
                      </label>
                      <div className='d-flex justify-content-between'>
                        <div className="loading-container">
                          <div className="loading loading-dark"></div>
                          <div className="loading-text dark-color">Please<br/>Wait</div>
                        </div>
                      </div>
                    </>
                  ):
                  (
                    <>
                      <>
                        <div>
                          <div>
                            <dl>
                              <dt>Select card provider</dt>
                              <dd>{profile.card_provider}</dd>

                              <dt>Title</dt>
                              <dd>{profile.title}</dd>

                              <dt>Name (Alphabet)</dt>
                              <dd>{profile.name}</dd>

                              <dt>Marriage status</dt>
                              <dd>{profile.marriage_status}</dd>

                              <dt>Occupation</dt>
                              <dd>{profile.occupation}</dd>

                              <dt>Nationality</dt>
                              <dd>{profile.nationality}</dd>

                              <dt>Birthday</dt>
                              <dd>{profile.date_of_birth}</dd>

                              <dt>ID Card type (ID Card must be valid for at least 6 months)</dt>
                              <dd>{profile.id_card_type}</dd>

                              <dt>ID Number</dt>
                              <dd>{profile.id_card_number}</dd>

                              <dt>ID issued date</dt>
                              <dd>{profile.id_card_issued_date}</dd>

                              <dt>ID expiration date</dt>
                              <dd>{profile.id_card_expired_date}</dd>

                              <dt>ID Issuer</dt>
                              <dd>{profile.id_card_issuer}</dd>

                              <dt>Address (english)</dt>
                              <dd>{profile.address}</dd>

                              <dt>City/Municipality</dt>
                              <dd>{profile.district}</dd>

                              <dt>Prefecture</dt>
                              <dd>{profile.province}</dd>

                              <dt>Postal code</dt>
                              <dd>{profile.postal_code}</dd>

                              <dt>Country</dt>
                              <dd>{profile.country}</dd>

                              <dt>Cellphone number (country code)</dt>
                              <dd>{profile.cellphone_country_code}</dd>

                              <dt>Cellphone number</dt>
                              <dd>{profile.cellphone_number}</dd>
                            </dl>
                          </div>
                          <img
                            className="img-fluid file-upload-image photo-frame"
                            src={status.card_activation_file_url}
                            alt="card activation image"
                          />

                          <div className="form-group row mt-4">
                            <h3 className="font-800">
                              <u>Operations by the BitQuick team</u>
                            </h3>
                          </div>

                          <form className="row g-3 mt-2" onSubmit={handleSubmit(onSubmit)}>
                            <div className="col-md-12">
                              <div className="form-check">
                                <input
                                  name="member_confirm0"
                                  {...register('member_confirm0')}
                                  className={`form-check-input ${errors.member_confirm0 ? 'is-invalid' : ''}`}
                                  value="1"
                                  type="checkbox"
                                  id="member_confirm0"
                                />
                                <label className="form-check-label" htmlFor="member_confirm0">
                                  The text on the ID card in the selfie is accurately legible
                                </label>
                                <div className="invalid-feedback">{errors.member_confirm0?.message}</div>
                              </div>
                            </div>

                            <div className="col-md-12">
                              <label htmlFor="member_confirm1" className="form-label">
                                Card Number for this member card
                              </label>
                              <input
                                type="text"
                                name="member_confirm1"
                                {...register('member_confirm1')}
                                className={`form-control ${errors.member_confirm1 ? 'is-invalid' : ''}`}
                                id="member_confirm1"
                                placeholder="Card Number for this member card"
                              />
                              <div className="invalid-feedback">{errors.member_confirm1?.message}</div>
                            </div>

                            <div className="col-md-12">
                              <label htmlFor="member_confirm2" className="form-label">
                                Confirmation Code
                              </label>
                              <input
                                type="text"
                                name="member_confirm2"
                                {...register('member_confirm2')}
                                className={`form-control ${errors.member_confirm2 ? 'is-invalid' : ''}`}
                                id="member_confirm2"
                                placeholder="Confirmation Code"
                              />
                              <div className="invalid-feedback">{errors.member_confirm2?.message}</div>
                            </div>

                            <div className="offset-sm-3 col-12 col-sm-6">
                              <button type="submit" className="button primary size-xl mt-3" disabled={isSubmitting}>
                                <i className="bi bi-chevron-right right"></i> Confirm and go Next
                                {isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                              </button>
                            </div>
                          </form>
                        </div>
                      </>
                    </>
                  )
              )}
            </div>
          </div>
        </div>
      ) : (
        <Loading />
        )}
    </>
  );
}

export { PostSuccess };
