@extends('layouts.app')

@section('content')

    <div class="container d-flex justify-content-center align-items-center flex-column" style="min-height: 50vh;">
        @if (session('success'))
            <div class="alert alert-success w-50">
                {{ session('success') }}
            </div>
        @endif
        @if (session('error'))
          <div class="alert alert-danger w-50">
            {{ session('error') }}
          </div>
        @endif
        <h1>Log In</h1>
        <form action="{{ route('zendesk.login.submit') }}" method="POST" class="w-50">
            @csrf
            <div class="mb-3">
                <input type="email" name="email" class="form-control form-control-sm rounded" placeholder="Email" required>
            </div>
            <div class="mb-3">
                <input type="password" name="password" class="form-control form-control-sm rounded" placeholder="Password" required>
            </div>
            <div class="mb-3 form-check">
                <input type="checkbox" name="redirect_to_admin" class="form-check-input" id="redirectCheckbox">
                <label class="form-check-label" for="redirectCheckbox">Redirect to admin page after login</label>
            </div>
            @if(isset($brand_id) && isset($locale_id) && isset($return_to))
              <input type="hidden" name="brand_id" value="{{ $brand_id }}">
              <input type="hidden" name="locale_id" value="{{ $locale_id }}">
              <input type="hidden" name="return_to" value="{{ $return_to }}">
            @endif
          <button type="submit" class="btn btn-primary btn-sm btn-long rounded-pill">Login</button>
        </form>
    </div>
@endsection

