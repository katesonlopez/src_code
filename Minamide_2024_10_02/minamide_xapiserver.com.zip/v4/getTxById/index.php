<?php
mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
	
	if ($email == "") {
		$fh2 = fopen(dirname(__FILE__) . "/log/get_tx_by_id.log" , 'a');
	} else {
		$fh2 = fopen(dirname(__FILE__) . "/log/" . $email . ".log" , 'a');
	}		
	$fline = date('[Ymd H:i:s] ') . $line."\n";
	fwrite($fh2, $fline);
	fclose($fh2);
	//echo date('[Ymd H:i:s] ').$line."\n";
	//@ob_flush(); 
	//flush();
}

	
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		_log("", "ket noi thanh cong");
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$allowed_deposit_currency_arr = array('USDT');
	$allowed_set_money_type_arr = array('IN', 'OUT', 'DEPOSIT', 'WITHDRAW');
	$dbhandle = NULL;
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			/*
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				break;
			} else if ($value == $apikey_freelancer) {
				$found = 7;
				$coin = 'USDT';
				break;
			}
			*/
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
					
				}
			} else {
				_log("", "not found in db");
			}
		}
	}
	@mysqli_close($dbhandle);

	


	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}


	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	//_log("bat dau xu ly...");
	//if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6) || ($found==7)) {
	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {


		
		
		//$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);
		
		//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
		//echo "payment_id: " . $payment_id . "<br/>";
		$json = file_get_contents('php://input');
		$data = json_decode($json, true);
		
		if (!($data)) {
			
			switch (json_last_error()) {
				case JSON_ERROR_DEPTH:
					//$failed_rs['error'] = 'Reached the maximum stack depth';
					_log("", 'Reached the maximum stack depth');
					break;
				case JSON_ERROR_STATE_MISMATCH:
					//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
					_log("", 'Incorrect discharges or mismatch mode');
					break;
				case JSON_ERROR_CTRL_CHAR:
					//$failed_rs['error'] = 'Incorrect control character';
					_log("", 'Incorrect control character');
					break;
				case JSON_ERROR_SYNTAX:
					//$failed_rs['error'] = 'Syntax error or JSON invalid';
					_log("", 'Syntax error or JSON invalid');
					break;
				case JSON_ERROR_UTF8:
					//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
					_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
					break;
				default:
					//$failed_rs['error'] = 'Unknown error';
					_log("", 'Unknown error');
					break;
			}
			
			//throw new Exception($error);
			//_log($failed_rs['error']);
			_log("", 'A non-empty request body is required.');
			header('Content-Type: application/json');
			http_response_code(400);
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
			echo json_encode($ret_rs);
			die();
			
		} else {
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			}
			
			//txid
			if ((!isset($data['txid'])) || (empty($data['txid']))) {
				$error_obj = array('errorCode' => 3, 'errorMessage' => 'txid parameter is required.');
				$errors[] = $error_obj;
			}	
			
			/*
			//type
			if ((!isset($data['type'])) || (empty($data['type']))) {
				$error_obj = array('errorCode' => 4, 'errorMessage' => 'type parameter is required.');
				$errors[] = $error_obj;
			} else {
				if (!in_array(strtoupper($data['type']), $allowed_set_money_type_arr)) {
					$error_obj = array('errorCode' => 5, 'errorMessage' => 'unsupported type.');
					$errors[] = $error_obj;
				}
			}
			*/			
			
			
			if (count($errors) == 0) {
				
				
				//proceed to shift api
				require_once '../include/common.php';
				require_once '../include/dbconfig.php';
				
				function connectdb() {
					global $dbhandle;
					$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
					if (mysqli_connect_errno() == 0) {
						//if ($is_first_time == 1) {
							mysqli_query($dbhandle, "set names utf8;");				
						//}
						return 1;
					} else {
						return 0;
					}
				}
				
				function update_tx($_in_tx_id, $_in_email, $_in_tx_division, $_in_merchant, $_in_status, $_in_error_code, $_in_error_message) {
					global $dbhandle;
					if (connectdb() == 1) {
						$sql_update_tx = "UPDATE cryptocash_merchant_user_transaction SET status=$_in_status, error_code='$_in_error_code', error_message='$_in_error_message' WHERE email_address='$_in_email' AND txid='$_in_tx_id' AND tx_division='$_in_tx_division' AND merchant='$_in_merchant' AND status=0 LIMIT 1";
						mysqli_query($dbhandle, $sql_update_tx);
						if (mysqli_affected_rows($dbhandle) == 1) {
							return 1;
						} else {
							return 0;
						}
						@mysqli_close($dbhandle);
						
					} else {
						return 0;
					}
				}
				
				////////////////////////////////////////////////////
				
				//$allowed_currency_arr = array('USDT');
				$allowed_shift_currency_arr = array('USDT', 'BTC', 'USD');
				//receive POST params
				$reg_email_address = trim($data['email_address']);				
				$txid = trim($data['txid']);				
				//$set_money_type = strtolower(trim($data['type']));
				
				//_log("set money started...");
				//_log($reg_email_address . " / ". $amount);
				
				
				
				if (connectdb() == 1) {
					//mysqli_query($dbhandle, "set names utf8;");
					$allow_access_api = 0;
					$merchant = '';
					////$merchant = ($found==6)?'LUCKY8':'';
					//if (($found == 6) || ($found == 7)) {
					//	$merchant = 'UltimoCasino';
					//}
					
					
					/////////////////////////////////////////////////////////////////////////
					$sql_tx = "SELECT * FROM cryptocash_merchant_user_transaction WHERE email_address='$reg_email_address' AND txid='$txid' AND merchant='" . $req_partner['partner'] . "' ORDER BY created_dt DESC";
					$rs_tx = mysqli_query($dbhandle, $sql_tx);
					if (mysqli_num_rows($rs_tx) == 0) {
						@mysqli_close($dbhandle);						
						$ret_rs['email_address'] = $reg_email_address;
						$ret_rs['result'] = 'failed';
						$ret_rs['error'] = array('txid' => $txid, 'errorCode' => 4, 'errorMessage' => 'not found.');						
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					} else {
						$req_tm = time();
						$tx_arr = array();
						while ($row_tx = mysqli_fetch_array($rs_tx, MYSQLI_ASSOC)) {
							unset($cur_tx_line);
							$cur_tx_line = array();							
							
							$cur_tx_id = trim($row_tx['txid']);
							$cur_tx_division = trim($row_tx['tx_division']);							
							$cur_amount = $row_tx['amount'];
							$cur_currency = $row_tx['currency'];
							$cur_created_dt = $row_tx['created_dt'];
							$cur_created_tm = strtotime($cur_created_dt);
							$cur_status = intval($row_tx['status']);
							$cur_error_code = intval($row_tx['error_code']);
							$cur_error_message = trim($row_tx['error_message']);
							
							$cur_time_utc = $cur_created_tm - 32400;
							$cur_y_utc = date('Y', $cur_time_utc);
							$cur_m_utc = date('m', $cur_time_utc);	
							$cur_d_utc = date('d', $cur_time_utc);
							$cur_giophutgiay_utc = date('H:i:s', $cur_time_utc);
							$cur_tx_added_dt_utc =  $cur_y_utc . "-" . $cur_m_utc . "-" . $cur_d_utc . "T" . $cur_giophutgiay_utc . "Z";
							
							if ($cur_status == 1) {
								$cur_tx_line['result'] = 'success';
								$cur_tx_line['txid'] = $cur_tx_id;
								$cur_tx_line['type'] = $cur_tx_division;															
								$cur_tx_line['amount'] = $cur_amount;
								$cur_tx_line['currency'] = $cur_currency;
								$cur_tx_line['time'] = $cur_tx_added_dt_utc;								
							} else if ($cur_status == 2) {
								$cur_tx_line['result'] = 'failed';
								$cur_tx_line['errorCode'] = $cur_error_code;
								$cur_tx_line['errorMessage'] = $cur_error_message;
								$cur_tx_line['txid'] = $cur_tx_id;
								$cur_tx_line['type'] = $cur_tx_division;
								$cur_tx_line['amount'] = $cur_amount;
								$cur_tx_line['currency'] = $cur_currency;
								$cur_tx_line['time'] = $cur_tx_added_dt_utc;
							} else if ($cur_status == 0) {
								if ($req_tm - $cur_created_tm < 61) {
									$cur_tx_line['result'] = 'being proccessed';
									//$cur_tx_line['errorCode'] = $cur_error_code;
									$cur_tx_line['message'] = 'This transaction is being processed.';
									$cur_tx_line['txid'] = $cur_tx_id;
									$cur_tx_line['type'] = $cur_tx_division;
									$cur_tx_line['amount'] = $cur_amount;
									$cur_tx_line['currency'] = $cur_currency;
									$cur_tx_line['time'] = $cur_tx_added_dt_utc;
								} else {
									$cur_tx_line['result'] = 'failed';
									$cur_tx_line['errorCode'] = 99;
									$cur_tx_line['message'] = 'Error occurred while processing this transaction. Please contact administrator for help.';
									$cur_tx_line['txid'] = $cur_tx_id;
									$cur_tx_line['type'] = $cur_tx_division;
									$cur_tx_line['amount'] = $cur_amount;
									$cur_tx_line['currency'] = $cur_currency;
									$cur_tx_line['time'] = $cur_tx_added_dt_utc;
								}
							}
							$tx_arr[] = $cur_tx_line;
						}
						@mysqli_close($dbhandle);						
						$ret_rs['email_address'] = $reg_email_address;
						$ret_rs['txResponse'] = $tx_arr;						
						header('Content-Type: application/json');
						echo json_encode($ret_rs);
						die();
					}
					
					/////////////////////////////////////////////////////////////////////////
						
					
					//@mysqli_close($dbhandle);
					
					
					
				} else {
					
					_log($reg_email_address, "ERROR: could not connect db outside (" . $reg_email_address . ")");
					$error_code = 5;
					$error_message = 'error occurred. please contact administrator for help.';
					$ret_rs['result'] = 'failed';
					$ret_rs['email_address'] = $reg_email_address;
					$ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);								
					header('Content-Type: application/json');
					http_response_code(500);								
					echo json_encode($ret_rs);
					die();
					
				}
				
			} else {
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = $errors[0];
				_log("", $ret_rs['error']['errorMessage']);	
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
				
			
		}

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>