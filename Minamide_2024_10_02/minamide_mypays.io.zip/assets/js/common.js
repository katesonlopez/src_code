let BASE_URL = '';
let API_URL = '';

const DECIMAL_POINTS = {
  'BTC': 8,
  'USDT': 6,
  'USD': 2
};
const DEFAULT_DECIMAL_POINTS = 6;
const USD_DECIMAL_POINTS = 2;

const REPORT_TYPE = {
  'ALL': 0,
  'DEPOSIT': 1,
  'WITHDRAW': 2,
  'EXCHANGE': 3,
};

$(document).ready(function() {
  BASE_URL = $('#base_url').val();
  API_URL = $('#base_url').val() + 'extAPIs/';

  // Function to show toast
  window.showToast = function(message) {
    $('.toast-body').text(message);
    $('.toast').toast('show');
  }

  // Disable button with spinner and text
  window.disableWithSpinner = function(id, label){
    $('#' + id + ' .spinner-anim').show();
    $('#' + id + ' .spinner-text').text(label);
    $('#' + id).attr('disabled', true);
  }

  // Enable button with spinner and text
  window.enableWithSpinner = function(id, label){
    $('#' + id + ' .spinner-anim').hide();
    $('#' + id + ' .spinner-text').text(label);
    $('#' + id).removeAttr('disabled');
  }
});

function setCookie(name, value, seconds) {
  const date = new Date();
  date.setTime(date.getTime() + (seconds * 1000));
  const expires = "expires=" + date.toUTCString();
  document.cookie = name + "=" + value + ";" + expires + ";path=/";
}

function getCookie(name) {
  let cookieArr = document.cookie.split(";");

  for (let i = 0; i < cookieArr.length; i++) {
    let cookiePair = cookieArr[i].split("=");

    // Remove whitespace at the beginning of the cookie name and compare it with the given name
    if (name === cookiePair[0].trim()) {
      return decodeURIComponent(cookiePair[1]);
    }
  }

  // Return null if not found
  return null;
}

function formatNumberWithCommas(number) {
  let [integerPart, decimalPart] = number.toString().split('.');
  integerPart = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return decimalPart ? `${integerPart}.${decimalPart}` : integerPart;
}

function removeCommaFromNumber(number){
  return number.replace(/,/g, '');
}

function reportStatusBadge(status){
  if( status.toLowerCase() === 'rejected')
    return '<span class="badge badge-warning">REJECTED</span>'
  if( status.toLowerCase() === 'completed')
    return '<span class="badge badge-success">COMPLETED</span>'
  if( status.toLowerCase() === 'new')
    return '<span class="badge badge-info">NEW</span>'
  if( status.toLowerCase() === 'pending')
    return '<span class="badge badge-primary">PENDING</span>'
  if( status.toLowerCase() === 'failed')
    return '<span class="badge badge-danger">FAILED</span>'
}

function isMobileView() {
  return window.innerWidth <= 768;
}

function logout(){
  localStorage.clear();
  window.location.href = BASE_URL;
}