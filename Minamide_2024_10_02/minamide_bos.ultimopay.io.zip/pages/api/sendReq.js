import Axios from 'axios';
import fetch from 'node-fetch';
import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();
Axios.create({
    baseURL: `${publicRuntimeConfig.apiUrl}`,
    headers: {
        Accept: '*/*',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${publicRuntimeConfig.apitoken}`,
    },
});

export default async (req, res) => {
    try {
        let reqBody = JSON.parse(req.body);
        let sendBody = { ...reqBody };

        let headers = {
            Accept: '*/*',
            'Content-Type': 'application/json',
        };

        let responseData;

        const response = await fetch(process.env.NEXT_PUBLIC_API_URL + '?uri=' + reqBody.url, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(sendBody),
        });

        if (response.ok) {
            responseData = await response.json();
            res.status(200).json({ data: responseData, data2: response });
        } else {
            res.status(500).json({ error: 'Network response was not ok', data: response });
        }
    } catch (error) {
        // Handle errors
        res.status(500).json({ error: 'Internal Server Error', data: error.message });
    }
};
