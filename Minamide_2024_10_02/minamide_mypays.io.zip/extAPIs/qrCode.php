<?php
require '../vendor/autoload.php';

use Endroid\QrCode\QrCode;
use Endroid\QrCode\ErrorCorrectionLevel;

// Get wallet address from query string
$walletAddress = isset($_GET['address']) ? $_GET['address'] : '';

// Generate QR code
$qrCode = new QrCode($walletAddress);
$qrCode->setErrorCorrectionLevel(new ErrorCorrectionLevel(ErrorCorrectionLevel::LOW)); // Use predefined constants
$qrCode->setSize(300);
$qrCode->setMargin(10);

// Output the QR code image
header('Content-Type: image/png');
echo $qrCode->writeString();
