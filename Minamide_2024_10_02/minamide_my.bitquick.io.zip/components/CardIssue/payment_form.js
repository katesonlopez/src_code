import {useRouter} from 'next/router';
import {useState, useEffect, useCallback} from "react";
import {userService, alertService} from '/services';
import {useForm} from 'react-hook-form';
import {yupResolver} from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import Swal from "sweetalert2";
import Loading from "../Loading";
import {toUsNumber, truncateFloat} from "../Utils/calc";
import Link from "next/link";

function PaymentForm({user, form2, userdata, form1, onNextClick, isMobile, memberCard}) {
  const router = useRouter();
  const [cost, setCost] = useState('...');
  const [float, setFloat] = useState(2);
  const [fee, setFee] = useState(0);
  const [balance, setBalance] = useState('...');
  const [wallet, setWalletData] = useState(null)
  const [input, setInput] = useState('USD')
  const [ifNotValid, setIfNotValid] = useState(false);
  const [enoughBalance, setEnoughBalance] = useState(false);
  const [cryptoPairs, setCryptoPairs] = useState( null );
  const [currencyError, setCurrencyError] = useState( '' );

  useEffect(() => {
    const fetchFeeWallet = async () => {
      try {
        const[
          feeResponse,
          walletResponse,
          cryptoPairResponse] = await Promise.all([
          userService.runApi("getAmountFee/", { partner: "BITQUICK" }),
          userService.walletBalance(user),
          userService.runApi('cryptoPrice/', user)
        ]);
        // handle fee response
        const costFromApi = feeResponse.data.response.card_issue_fee * 1;
        setFee(costFromApi);

        // handle wallet response
        const wallets = walletResponse.data.wallet;
        const order = userService.getCurrencyOrder()
        wallets.sort((a, b) => order.indexOf(a.currency) - order.indexOf(b.currency));
        wallets.forEach(item => item.balance = parseFloat(item.balance.replace(",", "")));

        const bal = {
          "USDT": {
            bal: truncateFloat(wallets[0].balance,6),
            float: 6
          },
          "BTC": {
            bal: truncateFloat(wallets[1].balance, 8),
            float: 8
          },
          "USD": {
            bal: truncateFloat(wallets[2].balance, 2),
            float: 2
          },
          "USDC": {
            bal: truncateFloat(wallets[3].balance, 2),
            float: 2
          },
        }
        setWalletData(bal);

        // handle crypto pair response
        const cPairs = cryptoPairResponse.data.cryptocurrencies;
        setCryptoPairs( cPairs );
      } catch (error) {
        console.error("Error fetching fee:", error);
      }
    };
    fetchFeeWallet().then(r => {});
  }, []);

  const validationSchema = Yup.object().shape({
    currency: Yup.string().nullable()
      .required('Pay solution is required'),
  });

  const handleInputChange = (event) => {
    setEnoughBalance(false);
    const id = event.target.value;
    setInput(event.target.value);
    getBalance(id, wallet);
  };

  useEffect(() => {
    if (cryptoPairs && wallet) {
      getBalance(input, wallet);
    }
  }, [fee, cryptoPairs, wallet]);

  const getBalance = (id, wallet) => {
    setCost('...');
    setBalance('...');

    const filteredData = cryptoPairs.filter((item) => item.pair.includes(id));
    let buy_price = filteredData[0].buy_price;
    if( id === 'USD' )
      buy_price = 1;
    const calculatedValue = parseFloat(fee) / parseFloat(buy_price);
    (calculatedValue > 0 && id !== 'USD') ? setCost(truncateFloat(calculatedValue, wallet[id].float)) : setCost(truncateFloat(fee, wallet[id].float));
    setCost(() => {
      if (calculatedValue > 0 && id !== 'USD')
        return truncateFloat(calculatedValue, wallet[id].float);
      else
        return fee;
    });
    setBalance(wallet[id].bal);

    console.log(truncateFloat(wallet[id].bal, wallet[id].float), truncateFloat(calculatedValue, wallet[id].float));
    setFloat(wallet[id].float);
    if (truncateFloat(wallet[id].bal, wallet[id].float)*1 < truncateFloat(calculatedValue, wallet[id].float)*1) {
      setError('currency', { message: `You don't have enough ${id} to buy this` });
      setCurrencyError(`You don't have enough ${id} to buy this`);
      setIfNotValid(true);
    } else {
      setError('currency', null);
      setCurrencyError('');
      setIfNotValid(false);
    }
  };

  const formOptions = {
    resolver: yupResolver(validationSchema), defaultValues: {
      email_address: user.email_address,
      auth_token: user.auth_token,
      amount: cost
    },
    mode: 'onBlur',
    criteriaMode: 'all'
  };

  // get functions to build form with useForm() hook
  const {
    register,
    handleSubmit,
    formState,
    setError,
    setValue
  } = useForm(formOptions);

  const { errors } = formState;

  useEffect(() => {
    if (cost * 1 > balance * 1)
      setEnoughBalance(false);
    else
      setEnoughBalance(true);
  }, [cost, balance])

  function onSubmit(user) {
    return Swal.fire({
      title: 'Are you sure?',
      text: 'Do you really want to pay?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Pay!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        user.amount = cost;

        // Member card case
        if( memberCard === 1 )
          user.member_card = 1;

        return userService.runApi("payCardFee/", user)
          .then((res) => {
            if (res.data.result === "success") {
              router.reload();
            } else {
              Swal.fire({
                title: "Error",
                text: res.data.error.errorMessage,
                icon: "error",
              }).then(function (result) {
              });
            }
          })
          .catch((res) => {
            Swal.fire({
              title: "Error",
              text: res.response.data.error.errorMessage,
              icon: "error",
            }).then(function (result) {
            });
          });
      }
    })
  }

  return (
    <>
      {user && wallet && fee !== 0 ? (
        <>
          <div className="col-md-12 mt-5">
            <label>
              Your KYC has been approved. Please pay the card issuance fee of ${fee}.
            </label>
          </div>
          <hr/>
          <div className="col-sm-12">
            <form className="row g-3" onSubmit={handleSubmit(onSubmit)} encType="multipart/form-data">
              <div className="col-md-12">
                <div className='row'>
                  <div className='col-12'>
                    <label htmlFor="inputState" className="form-label">
                      Pay Solution
                    </label>
                  </div>
                  <div className='col-12 ps-5'>
                    <select id="currency" name="currency"
                            {...register('currency')}
                            onChange={handleInputChange}
                            value={input}
                            className={`form-control ${ifNotValid ? 'is-invalid' : ''}`}>
                      <option value="USD">USD</option>
                      <option value="USDT">USDT</option>
                      {/*<option value="USDC">USDC</option>
                      <option value="BUSD">BUSD</option>*/}
                      <option value="BTC">BTC</option>
                    </select>
                    <div className="invalid-feedback">{currencyError}</div>
                    {currencyError && input !== 'USD' && (
                      <>
                        <span className="text-white me-1">Deposit</span>
                        <Link className="text-white font-800 text-decoration-underline" href={`/user/deposit/${input}`}>
                          Here
                        </Link>
                      </>
                    )}
                  </div>
                </div>
              </div>
              <div className="col-md-12">
                <div className='row'>
                  <div className='col-12'>
                    <label htmlFor="inputState" className="form-label">
                      Pay Amount
                    </label>
                  </div>
                  <div className='col-12 ps-5'>
                    <h6>{toUsNumber(truncateFloat(cost, float))} {input}</h6>
                    <input type='hidden' {...register('amount')} value={cost}/>
                    <p>Your balance : {toUsNumber(truncateFloat(balance, float))} {input} </p>
                  </div>
                </div>
              </div>
              <div className="col-12">
                <div className="row">
                  <div className="col-md-6 m-auto nav nav-tabs" id="myTab" role="tablist">
                    <button type="submit" className="button primary mt-2 w-100 size-xl"
                            {...(formState.isSubmitting || !enoughBalance ? {disabled: true} : {})}>
                      Pay Now
                      {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </>) : (
        <Loading/>
      )}
    </>
  )
}

export {PaymentForm};
