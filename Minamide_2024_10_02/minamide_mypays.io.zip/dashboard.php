<?php
global $baseUrl;
include 'includes/header.php';
?>
<!-- Necessary js start-->
<script src="<?php echo $baseUrl; ?>assets/js/auth.js"></script>
<!-- Necessary js end -->

<!-- Container start -->
<div class="main-content container d-flex justify-content-center">
  <div class="col-md-6 col-lg-6">
    <h3 class="text-center mt-4 mb-4">MyPays Wallet</h3>
    <div class="card blue-boarder mb-4">
      <!-- Start total balance to USD -->
      <div class="card-header bg-primary-opacity">
        <div class="panel-list">
          <div class="panel-list-left font-weight-bold fs-6">
            Wallet total balance
          </div>
          <div class="panel-list-right">
            $<span id="total_usd_balance" class="fs-6 font-weight-bold">0.00</span>
          </div>
        </div>
      </div>
      <!-- End total balance to USD -->
      <div class="card-body">
        <!-- Start BTC balance -->
        <div class="panel-list">
          <div class="panel-list-left fs-6">
            <div>
              <img class="mt-2 mr-2" width="30px" height="auto" src="<?php echo $baseUrl.'assets/images/BTC.png'; ?>" alt="BTC"/>
            </div>
            <div class="panel-list-vert">
              <div class="font-weight-bold fs-6">
                BTC
              </div>
              <div class="fs-8 text-dark">
                $<span id="BTC_usd_price" class="fs-8 text-dark">0.00000</span>
              </div>
            </div>
          </div>
          <div class="panel-list-right">
            <div class="panel-list-vert">
              <div class="font-weight-bold fs-6 text-right">
                <span id="BTC_balance">0.000000</span>
              </div>
              <div class="fs-8 text-dark text-right">
                $<span id="BTC_usd_balance" class="fs-8 text-dark">0.00000</span>
              </div>
            </div>
            <div class="panel-list-vert text-right ml-2 mt-2">
              <div class="dropdown">
                <button class="btn dropdown-toggle bg-primary-opacity" type="button" id="dropdownMenuButtonBTC" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                </button>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButtonBTC">
                  <a class="dropdown-item dropdown-menu-right" href="<?php echo $baseUrl; ?>deposit.php?id=BTC">Deposit</a>
                  <a class="dropdown-item dropdown-menu-right" href="<?php echo $baseUrl; ?>report.php?id=BTC">Report</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End BTC balance -->

        <hr/>

        <!-- Start USDT balance -->
        <div class="panel-list mt-4">
          <div class="panel-list-left fs-6">
            <div>
              <img class="mt-2 mr-2" width="30px" height="auto" src="<?php echo $baseUrl.'assets/images/USDT.png'; ?>" alt="BTC"/>
            </div>
            <div class="panel-list-vert">
              <div class="font-weight-bold fs-6">
                USDT
              </div>
              <div class="fs-8 text-dark">
                $<span id="USDT_usd_price" class="fs-8 text-dark">0.00000</span>
              </div>
            </div>
          </div>
          <div class="panel-list-right">
            <div class="panel-list-vert">
              <div class="font-weight-bold fs-6 text-right">
                <span id="USDT_balance">0.000000</span>
              </div>
              <div class="fs-8 text-dark text-right">
                $<span id="USDT_usd_balance" class="fs-8 text-dark">0.00000</span>
              </div>
            </div>
            <div class="panel-list-vert text-right ml-2 mt-2">
              <div class="dropdown">
                <button class="btn dropdown-toggle bg-primary-opacity" type="button" id="dropdownMenuButtonUSDT" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                </button>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButtonUSDT">
                  <a class="dropdown-item dropdown-menu-right" href="<?php echo $baseUrl; ?>deposit.php?id=USDT">Deposit</a>
                  <a class="dropdown-item dropdown-menu-right" href="<?php echo $baseUrl; ?>report.php?id=USDT">Report</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End USDT balance -->
      </div>
    </div>
  </div>
</div>
<!-- Container end -->

<script>
  $(document).ready(function() {

    // Load balances from local storage
    let user = JSON.parse(localStorage.getItem("user"));

    // Update balances
    user.wallet.forEach(wallet => {
      let id = wallet.currency;
      let decimalPoint = DECIMAL_POINTS[id] || DEFAULT_DECIMAL_POINTS;
      let balance = parseFloat(removeCommaFromNumber(wallet.balance)).toFixed(decimalPoint);
      $('#' + id + '_balance').html(formatNumberWithCommas(balance));
    });

    // Get wallet balance via API and update UIs
    updateBalances();

    // Get currency prices via API and update UIs
    updatePrices();
  });

  // Get wallet balance via API and update UIs
  function updateBalances() {
    const jwt = localStorage.getItem('jwt');
    const auth_token = localStorage.getItem('auth_token');

    $.ajax({
      url: API_URL + 'ultimoApi.php',
      type: 'POST',
      data: JSON.stringify({
        action: 'walletBalance',
        jwt: jwt,
        auth_token: auth_token
      }),
      contentType: 'application/json',
      success: function(response) {
        if (response.result === 'success') {
          // Load balances from local storage and update it with wallet balance
          let user = JSON.parse(localStorage.getItem("user"));
          user.wallet = response.wallet;
          localStorage.setItem('user', JSON.stringify(user));

          // Update balances
          response.wallet.forEach(wallet => {
            let id = wallet.currency;
            let decimalPoint = DECIMAL_POINTS[id] || DEFAULT_DECIMAL_POINTS;
            let balance = parseFloat(removeCommaFromNumber(wallet.balance)).toFixed(decimalPoint);
            $('#' + id + '_balance').html(formatNumberWithCommas(balance));
          });
        } else {
          showToast(response.error.errorMessage);
          console.log(response.error.errorMessage);
        }
      },
      error: function(error) {
        console.log('An error occurred:', error);
      }
    });
  }

  // Get currency prices via API and update UIs
  function updatePrices() {
    const jwt = localStorage.getItem('jwt');
    const auth_token = localStorage.getItem('auth_token');

    $.ajax({
      url: API_URL + 'ultimoApi.php',
      type: 'POST',
      data: JSON.stringify({
        action: 'cryptoPrice',
        jwt: jwt,
        auth_token: auth_token
      }),
      contentType: 'application/json',
      success: function(response) {
        if (response.result === 'success') {
          // Load balances from local storage and update it with wallet balance
          let user = JSON.parse(localStorage.getItem("user"));
          let totalPriceUSD = 0;

          // Update prices
          response.cryptocurrencies.forEach(price => {
            let id = price.pair.slice(0, -3);
            if( id === 'BTC' || id === 'USDT'){
              let walletItem = user.wallet.find(currency => currency.currency === id);
              let usdPrice = removeCommaFromNumber(walletItem.balance) * 1 * price.buy_price;
              totalPriceUSD += usdPrice;
              $('#' + id + '_usd_price').html(formatNumberWithCommas((price.buy_price * 1).toFixed(USD_DECIMAL_POINTS)));
              $('#' + id + '_usd_balance').html(formatNumberWithCommas(usdPrice.toFixed(USD_DECIMAL_POINTS)));
            }
          });

          $('#total_usd_balance').html(formatNumberWithCommas(totalPriceUSD.toFixed(USD_DECIMAL_POINTS)));
        } else {
          showToast(response.error.errorMessage);
          console.log(response.error.errorMessage);
        }
      },
      error: function(error) {
        console.log('An error occurred:', error);
      }
    });
  }
</script>
<?php include 'includes/footer.php'; ?>
