<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: text/html; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, X-Requested-With, Authorization');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 3600');
mb_internal_encoding("UTF-8");
date_default_timezone_set('Asia/Tokyo');
ini_set('memory_limit', '50M');

//$GET_SIGNED_HASH_URL = 'http://192.168.8.46/minamide/dashboard.xexon.io/SignedHash/';
$GET_SIGNED_HASH_URL = 'http://172.21.22.203:5001/api/card/v1/generateSignature/';
//$AUTH_URL = 'http://192.168.8.46:80/minamide/dashboard.xexon.io/xeson_response_check?cmd=auth';
$AUTH_URL = 'http://172.21.22.203:5001/api/card/v1/authentication';
//$CARD_TRANSACTION_URL = 'http://192.168.8.46:80/minamide/dashboard.xexon.io/xeson_response_check?cmd=transaction';
$CARD_TRANSACTION_URL = 'http://172.21.22.203:5001/api/card/v1/cardTransaction';
$SECRET_ID = 'rHmGxfRZbAs8YhUG8omAh3k08qnMdKUx2B4iEJZ2n2wSmsr8vRjzMQEjNZFu3m0ZPP0lsJwonzNGlr';
$AUTH_USER_ID = 'JDBCARD';
$requestMethod = "POST";
$result = '';

//================= 1st, authentication ======================================================
$requestId = generateUniqueRandomString();
$cardNo = $_GET['cardnum'];
$fromDate = isset($_GET['fromDate']) ? $_GET['fromDate'] : null;
$toDate = isset($_GET['toDate']) ? $_GET['toDate'] : null;
if( $fromDate == null )
    $fromDate = '01-JAN-2000';
if( $toDate == null )
    $toDate = date('d-M-Y', strtotime('now'));

// 1st, authentication
$requestData = [
    'requestId' => $requestId,
    'userId' => $AUTH_USER_ID,
    'secretId'=>$SECRET_ID
];
$jsonRequestData = json_encode( $requestData );
$requestHeaders = [
    "Content-Type: application/json",
    "SignedHash: ".generateHash($jsonRequestData)
];

// execute curl command
$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => $AUTH_URL,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => $requestMethod,
    CURLOPT_POSTFIELDS => $jsonRequestData,
    CURLOPT_HTTPHEADER => $requestHeaders,
));
$response = curl_exec($curl);
$error = curl_error($curl);
$errorDetails = getCurlErrorResponse( $error );
curl_close($curl);

if ( $error ) {
    $result .= '<br/>';
    $result .= '<br/>'.'Error Code = '.$errorDetails['Error Code'];
    $result .= '<br/>'.'Error Desc = '.$errorDetails['Error Desc'];
    echo $result;
    return;
}

$AUTH_TOKEN = '';
if ($response) {
    $responseData = json_decode($response, true);
    if( !isset($responseData['data']) ||
        !isset($responseData['data'][0]['tokenType']) ||
        $responseData['data'][0]['tokenType'] != 'Bearer' ||
        !isset($responseData['data'][0]['token']) ||
        strlen($responseData['data'][0]['token']) == 0 ){
        $result .= '<br/>';
        $result .= '<br/>'.'Error Code = 81';
        $result .= '<br/>'.'Error Desc = Token from JDB is invalid';
        echo $response;
        echo $result;
        return;
    }
    else {
        $AUTH_TOKEN = $responseData['data'][0]['tokenType'] . ' ' . $responseData['data'][0]['token'];
    }
}
//================= 2nd, get card balanceget card transactions ========================================

$requestData = [
    'requestId' => $requestId,
    'cardNo' => $cardNo,
    'fromDate' => $fromDate,
    'toDate' => $toDate
];
$jsonRequestData = json_encode( $requestData );
$requestHeaders = [
    "Content-Type: application/json",
    'Authorization: ' . $AUTH_TOKEN,
    'SignedHash: '.generateHash($jsonRequestData)
];

// execute curl command
$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => $CARD_TRANSACTION_URL,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => $requestMethod,
    CURLOPT_POSTFIELDS => $jsonRequestData,
    CURLOPT_HTTPHEADER => $requestHeaders,
));
$response = curl_exec($curl);
$error = curl_error($curl);
$errorDetails = getCurlErrorResponse( $error );
curl_close($curl);

if ( $error ) {
    $result .= '<br/>';
    $result .= '<br/>'.'Error Code = '.$errorDetails['Error Code'];
    $result .= '<br/>'.'Error Desc = '.$errorDetails['Error Desc'];
    echo $result;
    return;
}

if ( $response ) {
    $responseData = json_decode($response, true);
    if( !isset($responseData['success']) ||
        !isset($responseData['message'])){
        $result .= '<br/>';
        $result .= '<br/>'.'Error Code = 82';
        $result .= '<br/>'.'Error Desc = Response from JDB for cardTransaction is invalid';
        echo $result;
        return;
    }

    if(!$responseData['success']){
        echo $responseData['message'];
        return;
    }
    else {
        $result .= '';
        foreach ($responseData['data'] as $transaction) {
            $result .= '<br/>TXN_DATE_TIME = ' . $transaction['txnDate'];
            $result .= '<br/>CARD_NO = ' . $transaction['cardNo'];
            $result .= '<br/>AC_NO = ' . $transaction['accountNo'];
            $result .= '<br/>TRN_REF_NO = ' . $transaction['trnRefNo'];
            $result .= '<br/>AC_ENTRY_SR_NO = ' . $transaction['srNo'];
            $result .= '<br/>DESCTRIPTION = ' . $transaction['description'];
            $result .= '<br/>TRN_CODE = ' . $transaction['trnCode'];
            $result .= '<br/>AUTH_STAT = ' . $transaction['authstat'];
            $result .= '<br/>DR_AMOUNT = ' . $transaction['drAmount'];
            $result .= '<br/>CR_AMOUNT = ' . $transaction['crAmount'];
            $result .= '<br/>END_BAL = ' . $transaction['endBal'];
            $result .= '<br/>USER_ID = ' . $transaction['userId'];
        }
        echo $result;
    }
}

function getCurlErrorResponse( $error ){
    $result = array();
    $result['Error Code'] = $error;
    switch ($error){
        case 1:
            $result['Error Desc'] = 'Unsupported protocol';
            break;
        case 3:
            $result['Error Desc'] = 'Malformed URL';
            break;
        case 6:
            $result['Error Desc'] = "Could not resolve host";
            break;
        case 7:
            $result['Error Desc'] = 'Couldn not connect to host';
            break;
        case 9:
            $result['Error Desc'] = 'Remote access denied or authentication failure';
            break;
        case 18:
            $result['Error Desc'] = 'Partial file';
            break;
        case 22:
            $result['Error Desc'] = 'HTTP page not found';
            break;
        case 28:
            $result['Error Desc'] = 'Operation timeout';
            break;
        case 35:
            $result['Error Desc'] = 'SSL/TLS handshake failed';
            break;
        case 47:
            $result['Error Desc'] = 'Too many redirects';
            break;
        case 51:
            $result['Error Desc'] = 'Proxy authentication required';
            break;
        case 52:
            $result['Error Desc'] = 'Empty response from server';
            break;
        case 56:
            $result['Error Desc'] = 'Failure with receiving network data';
            break;
        case 58:
            $result['Error Desc'] = 'SSL certificate problem';
            break;
        default:
            $result['Error Desc'] = 'Unknown error';
            break;
    }
    return $result;
}

function generateHash($originalString)
{
    $SECRET_KEY = '2BUedUhCZEv6taCknNpkE7c0K/XQUM4XTflTDZtP7xJvTNz5suTLvqZ92x1Iv0tzSEO/rHmGxfRZbAs8YhUG8omAh3k08qnMdKUx2B4iEJZ2n2wSmsr8';

    try {
        $encodedHash = hash_hmac('sha256', $originalString, $SECRET_KEY, true);

        return bytesToHex($encodedHash);
    } catch (Exception $e) {
        echo 'An error occurred: ' . $e->getMessage();
    }

    return null;
}

function bytesToHex($hash)
{
    $hexString = '';

    for ($i = 0; $i < strlen($hash); $i++) {
        $hex = dechex(ord($hash[$i]));

        if (strlen($hex) === 1) {
            $hexString .= '0';
        }

        $hexString .= $hex;
    }

    return $hexString;
}

function generateUniqueRandomString($length = 20) {
    $characters = '0123456789';
    $charactersLength = strlen($characters);
    $randomString = '';

    // Generate a random string with a timestamp and a random suffix
    $randomString .= time(); // Current timestamp
    for ($i = 0; $i < $length - 10; $i++) {
        $randomString .= $characters[mt_rand(0, $charactersLength - 1)];
    }

    return $randomString;
}

function isIPPortAvailable($ip, $port) {
    $connection = @fsockopen($ip, $port, $errno, $errstr, 1);

    if ($connection) {
        fclose($connection);
        return true; // IP address and port are available
    } else {
        return false; // IP address and port are not available
    }
}
