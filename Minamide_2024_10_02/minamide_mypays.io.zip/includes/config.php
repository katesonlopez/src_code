<?php
/**
 * Database configuration
 **/
// const DB_HOST = '138.201.224.107';
const DB_HOST = '127.0.0.1';
const DB_USER = 'root';
// const DB_PASS = 'FyR@9876!pQr';
const DB_PASS = '';
const DB_NAME = 'mypays.io';

/**
 * JWT Secret Key
**/
const JWT_SECRET = 'F6ED6A29C44789F4F91DCD7A95E1C';

/**
 * API calls
 **/
const ULTIMO_API_KEY = 'hTSdZwR2wJOPYrOz0EzlxU9YsSs9J0uw4c2y5qu6a9G1EaeHbE1F1QbbRGQresz4fnzM3QhKmHkx7KV6I3qi5nyCMGLG9kFu7n7007PrxQ7MGYgs5qATyLlwZftiHWL5';
const ULTIMO_API_URL = 'https://xapiserver.com/v4/';

const KAISER_API_KEY = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MTgsIm5hbWUiOiJNWVBBWVMiLCJkb21haW4iOiJNWVBBWVMuSU8iLCJmZWUiOiI4Iiwic2VydmljZV90eXBlIjoiUFJPRCIsImV4cCI6NDg3NzMxNjYxN30.a9o4OGMW2XfNE76xUCzL5-cImhyUSvqwHxxVmzUOQ3k';
const KAISER_API_URL = 'https://api.kaiserpayment.com/api/';