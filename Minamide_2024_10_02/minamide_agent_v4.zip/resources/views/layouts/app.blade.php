<!DOCTYPE html>
<html>
<head>
    <title>Zendesk Test App</title>
    <!-- Add Bootstrap CSS link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header>
    <!-- Your header content here -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="{{ route('zendesk.admin') }}">Zendesk Test App</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    @auth
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('zendesk.admin') }}">Admin</a>
                    </li>
                    @endauth
                    @guest
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('zendesk.signup.form') }}">Sign Up</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('zendesk.login') }}">Login</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="{{ route('zendesk.kaiser.1') }}">Kaiser-1</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="{{ route('zendesk.kaiser.2') }}">Kaiser-2</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="{{ route('zendesk.kaiser.3') }}">Kaiser-3</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="{{ route('zendesk.kaiser.4') }}">Kaiser-4</a>
                    </li>
                    @endguest
                    @auth
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('zendesk.logout') }}">Logout</a>
                    </li>
                    @endauth
                </ul>
            </div>
        </div>
    </nav>
</header>

<main>
    <div class="container mt-4">
        @yield('content')
    </div>
</main>

<footer class="bg-light p-3 mt-4">
    <!-- Your footer content here -->
</footer>

<!-- Add Bootstrap JS and Popper.js (required for some Bootstrap components) -->
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
