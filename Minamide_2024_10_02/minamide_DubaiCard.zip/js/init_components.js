function initComponents(){
  // Toggle sidebar visibility
  $('.menu-toggle').on('click', function() {
    $('.sidebar').toggle();
  });

  // Toggle submenu
  $('.toggle-submenu').on('click', function() {
    $(this).toggleClass('rotate-90');
    $(this).closest('.menu-item').find('.submenu').slideToggle();
  });
}