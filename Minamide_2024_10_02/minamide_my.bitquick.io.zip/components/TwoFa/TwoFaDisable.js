import { useRouter } from 'next/router';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { userService, alertService } from '/services';
import Swal from 'sweetalert2';
import QRCode from 'qrcode.react';
import { useState, useEffect } from "react";
import Loading from "../Loading";

function TwoFaDisable({user}) {
  const router = useRouter();
  const [twofaKey, setTwofaKeyData] = useState(null);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    async function fetchData() {
      get2FASecretKey(user);
    }
    fetchData();
  }, [router]);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const validationSchema = Yup.object().shape({
    two_fa_code: Yup.string()
      .required('2FA is required'),
    password: Yup.string()
      .required('Password is required'),
  });
  const formOptions = { resolver: yupResolver(validationSchema) ,defaultValues: {
      email_address:user.email_address,
      auth_token:user.auth_token,
      type:1,
    }};

  // get functions to build form with useForm() hook
  const { register, handleSubmit, formState , setError } = useForm(formOptions);
  const { errors } = formState;

  function onSubmit(user) {
    return userService.set2FA(user)
      .then((res) => {
        if(res.data.result === 'success')
        {
          Swal.fire({
            title: "Success",
            text: "Your 2-FA has been enabled successfully",
            icon: "success"
          }).then(function (result)
          {
            router.push({
              pathname: '/user/2fa',
            });
          })
        }
        else
        {
          Swal.fire({
            title: "Error",
            text: res.data.error.errorMessage,
            icon: "error"
          }).then(function (result)
          {})
        }
      })
      .catch((ress) => {
        const res =  ress.response;
        if(res.data.result === "failed")
        {
          if(res.data.error.errorCode === 11)
          {
            setError('two_fa_code', { message: res.data.error.errorMessage });
          }
          if(res.data.error.errorCode === 12)
          {
            setError('password', { message: 'Invalid password' });
          }
        }
        else
        {
          Swal.fire({
            title: "Error",
            text: res.data.error.errorMessage,
            icon: "error"
          }).then(function (result)
          {})
        }
      });
  }

  const get2FASecretKey = (user) => {
    userService.get2FASecretKey(user).then((d) => {
      setTwofaKeyData(d.data.two_fa_secret_key);
    })
  }
  return (
    <>
      {twofaKey ? (
        <div className={`container-fluid ${isMobile ? "pe-2 ps-2" : "pe-4 ps-4"}`}>
          <form className="row g-3" onSubmit={handleSubmit(onSubmit)}>
            <div className={`row ${isMobile ? "pe-1 ps-1" : "pe-4 ps-4"} pt-5 pb-0 d-flex align-items-stretch`}>
              <div className="col-sm-6">
                <h1 className="mt-3 font-800 text-white">
                  <b>2-Factor Authentication is
                    <small
                      style={{ top: '-1px', fontSize: '1rem', marginLeft: '10px', filter: 'opacity(0.5)' }}
                      className="alert alert-secondary p-0 px-2">OFF
                    </small>
                  </b>
                </h1>
              </div>
              <div className="col-sm-6 p-3">
                <h6 className="line-height-1p5">
                  You can secure your account better by
                  enabling 2-Factor authentication via Google
                  Authenticator app.
                  <br /> For Android: <b><a target="_blank" href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2">click here to install</a></b>
                  <br /> For iOS: <b><a target="_blank" href="https://apps.apple.com/us/app/google-authenticator/id388497605">click here to install</a></b>{" "}
                </h6>
              </div>
              <div className="col-md-6 mb-3">
                <div className="fact p-4 text-center">
                  <div className="qr-code-area">
                    <QRCode value={`otpauth://totp/${user.email_address}?secret=${twofaKey}&issuer=BitQuick`} />
                  </div>
                  <h5 className="mt-2 text-white">{twofaKey} </h5>
                  <p className="text-start mb-0 mt-1">
                    Use your Google Authenticator App
                    to scan the QR code or enter the
                    authenticator key shown{" "}
                  </p>
                </div>
              </div>
              <div className="col-md-6 mb-3">
                <div className="fact p-4">
                  <h6 className="mb-4 fw-bold ">
                    Enter the code from your Google
                    Authenticator App and your login
                    password{" "}
                  </h6>
                  <div className="col-md-12">
                    <label htmlFor="inputPassword1" className="form-label">
                      Enter the code from your Google Authenticator App
                    </label>
                    <input
                      type="text"
                      name='two_fa_code'
                      {...register('two_fa_code')} className={`form-control ${errors.two_fa_code ? 'is-invalid' : ''}`}
                      id="inputPassword1"
                      placeholder="Enter the code from your Google Authenticator App"
                    />
                    <div className="invalid-feedback">{errors.two_fa_code?.message}</div>
                  </div>
                  <div className="col-md-12 mb-2 mt-4">
                    <label htmlFor="inputPassword4" className="form-label">
                      Your login password
                    </label>
                    <input
                      type="password"
                      name='password'
                      {...register('password')} className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                      id="inputPassword4"
                      placeholder="Enter Your login password"
                    />
                    <div className="invalid-feedback">{errors.password?.message}</div>
                  </div>
                </div>
              </div>
              <div className="col-md-12 mt-2">
                <div className="fact p-4">
                  <p className="mb-2">
                    By default, 2-Factor Authentication will be turned ON for
                    Withdrawals and Login.{" "}
                  </p>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="d-flex align-items-center">
                        <div
                          style={{ border: '2px solid rgb(173 231 255)', borderRadius: '50%' }}
                          className="text-center me-3">
                          <img src="/assets/img/check.png" width="30px" />
                        </div>
                        <div className="">
                          Withdrawals <br />
                        </div>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="d-flex align-items-center">
                        <div className="text-center me-3"
                             style={{ border: '2px solid rgb(173 231 255)', borderRadius: '50%' }}>
                          <img src="/assets/img/check.png" width="30px" />
                        </div>
                        <div className="">Login to your account </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-sm-12 mb-3">
              <div className="col-12">
                <div className="row">
                  <div className="col-md-6 m-auto">
                    <button type="submit" className="button primary size-xl mb-2 w-100" disabled={formState.isSubmitting}>
                      Enable 2-FA
                      {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      ): (
        <Loading />
      )}
    </>
  )
}

export {TwoFaDisable} ;
