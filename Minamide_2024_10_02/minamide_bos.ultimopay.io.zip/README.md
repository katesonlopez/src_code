# bos.ultimopay.io

This is a starter template for [Learn Next.js](https://nextjs.org/learn).

```yaml
node.js: 16.17.1
php: 7.2.34
```

```bash
$ npm i --legacy-peer-deps

$ npm run dev
```
