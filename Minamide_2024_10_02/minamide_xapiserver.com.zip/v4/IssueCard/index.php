<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, x-csrf-token, X-Auth-Token, X-Requested-With, Authorization');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 3600');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

/**
 * =======================================================================
 * Define constants
 * =======================================================================
**/

const ACTION_KYC_UPLOAD = 0;
const TODO_ADD_KYC = 0;
const TODO_UPDATE_KYC = 1;

/**
 * =======================================================================
 * Utility functions
 * =======================================================================
**/
// Save logs
function _log($email, $line): void {
  if ($email == "") {
    $logFilePath = dirname(__FILE__) . '/log/IssueCard.log';
  } else {
    $logFilePath = dirname(__FILE__) . '/log/' . $email . '.log';
  }
  $fh = fopen($logFilePath, 'a');
  $fLine = date('[Ymd H:i:s] ') . $line . "\n";
  if( $fh ) {
    fwrite($fh, $fLine);
    fclose($fh);
  }
}

// Get All Headers
if (!function_exists('getAllHeaders')) {
  function getAllHeaders(): array {
    if (!is_array($_SERVER)) {
      return array();
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
      if (substr($name, 0, 5) == 'HTTP_') {
        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
      }
    }
    return $headers;
  }
}

// Utility function
function generateRandomString($length): string
{
  $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $lowercase = 'abcdefghijklmnopqrstuvwxyz';
  $numbers = '0123456789';
  $characters = $uppercase . $lowercase . $numbers;
  $charactersLength = strlen($characters);
  $randomString = '';
  for ($i = 0; $i < $length; $i++) {
    $randomString .= $characters[rand(0, $charactersLength - 1)];
  }
  return $randomString;
}

// Check parameter validation
function validateProfileParams($params): array
{
  $errors = [];

  // Validate `email_address` parameter
  if (isset($params['email_address'])) {
    $email = $params['email_address'];

    // Check if the email is valid
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $errors[] = "Invalid email format for `email_address`.";
    }
  } else {
    $errors[] = "Missing `email_address` parameter.";
  }

  // Validate `profile` parameters
  if (isset($params['profile'])) {
    $profile = $params['profile'];

    // Required fields and validation rules
    $requiredProfileFields = [
      'gender' => '/^[0-9]+$/', // Numeric string
      'full_name' => '/^[a-zA-Z ]+$/', // Alphabets and spaces
      'marriage_status' => '/^[0-9]+$/', // Numeric string
      'occupation' => '/^[a-zA-Z ]+$/', // Alphabets and spaces
      'country' => '/^[a-zA-Z ]+$/', // Alphabets and spaces
      'nationality' => '/^[a-zA-Z ]+$/', // Alphabets and spaces
      'date_of_birth' => '/^\d{4}-\d{2}-\d{2}$/', // Date format YYYY-MM-DD
      'place_of_birth' => '/^[a-zA-Z ]+$/', // Alphabets and spaces
      'id_card_number' => '/^[a-zA-Z0-9]+$/', // Alphanumeric
      'id_card_issued_dt' => '/^\d{4}-\d{2}-\d{2}$/', // Date format YYYY-MM-DD
      'id_card_expired_dt' => '/^\d{4}-\d{2}-\d{2}$/', // Date format YYYY-MM-DD
      'id_card_issuer' => '/^[a-zA-Z ]+$/', // Alphabets and spaces
      'id_card_type' => '/^(passport|driving_license)$/', // Specific set of values
      'residence_address' => '/^.+$/', // Non-empty string
      'district' => '/^.+$/', // Non-empty string
      'province' => '/^.+$/', // Non-empty string
      'postal_code' => '/^[0-9]+$/', // Numeric string
      'cellphone_country_code' => '/^\+\d{1,3}$/', // International dialing code format
      'cellphone_number' => '/^\d+$/', // Numeric string
      'name_on_card' => '/^[A-Z ]+$/', // Uppercase alphabets and spaces
      'card_provider' => '/^(visa|unionpay)$/', // Specific set of values
    ];

    foreach ($requiredProfileFields as $field => $regex) {
      if (!isset($profile[$field])) {
        $errors[] = "Missing `$field` in `profile`.";
      } elseif (!preg_match($regex, $profile[$field])) {
        $errors[] = "Invalid value for `$field` in `profile`.";
      }
    }
  } else {
    $errors[] = "Missing `profile` section.";
  }

  // Validate `image` parameters
  if (isset($params['image'])) {
    $imgUrl = $params['image'];

    // Required fields and validation rules
    if( $params['profile']['id_card_type'] == 'passport')
      $requiredImgUrlFields = [
        'passport_open_file',
        'passport_selfie_file',
      ];
    else
      $requiredImgUrlFields = [
        'id_card_front_file',
        'id_card_back_file',
        'id_card_selfie_file',
      ];

    foreach ($requiredImgUrlFields as $field) {
      if (!isset($imgUrl[$field])) {
        $errors[] = "Missing `$field` in `image`.";
      } elseif (!filter_var($imgUrl[$field], FILTER_VALIDATE_URL)) {
        $errors[] = "Invalid value for `$field` in `image`.";
      }
    }
  } else {
    $errors[] = "Missing `image` section.";
  }

  return $errors;
}

// Load and populate the HTML template
function loadHtmlTemplate($templateFile, $data = null): string {
  if ($data)
    extract($data); // Extract data array to variables
  ob_start(); // Start output buffering
  include $templateFile; // Include the template file
  return ob_get_clean(); // Return the buffered content
}

function sendPostRequestCurl($url, $postData): string
{
  // Initialize cURL session
  $ch = curl_init($url);

  // Set cURL options
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData)); // Encode data to x-www-form-urlencoded format
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

  // Execute cURL request
  $response = curl_exec($ch);

  // Check for cURL errors
  if (curl_errno($ch)) {
    return 'Error:' . curl_error($ch);
  }

  // Close cURL session
  curl_close($ch);
  return $response;
}

/**
 * =======================================================================
 * Start API work
 * =======================================================================
**/
// 1. Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type, Authorization');
  http_response_code(200);
  exit();
}

// 2. Check if post method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  die();
}

mb_internal_encoding("UTF-8");
date_default_timezone_set('Asia/Tokyo');

// 3. Define global variables
$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
$ret_rs = [
  'result' => '',
  'code' => 200
];
$htmlContent = '';

// 4. Connect to database
require_once('common.php');
require_once '../include/dbconfig.php';
$dbHandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
if (mysqli_connect_errno() != 0) {
  http_response_code(500);
  $ret_rs['result'] = 'failed';
  $ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'System can not connect to data storage.');
  echo json_encode($ret_rs);
  die();
} else {
  mysqli_query($dbHandle, "set names utf8;");
}

// 5. Check authorization header
foreach (getAllHeaders() as $name => $value) {
  if ($name == 'Authorization' || $name == 'authorization') {
    $req_api_key = trim($value);
    $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
    $partner_rs = mysqli_query($dbHandle, $get_partner_sql);
    if (@mysqli_num_rows($partner_rs) > 0) {
      while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
        $cur_api_key = trim("Bearer " . $row_partner['api_key']);
        if ($req_api_key == $cur_api_key) {
          $req_partner['partner'] = trim($row_partner['partner']);
          $req_partner['api_key'] = trim($row_partner['api_key']);
          $req_partner['website'] = trim($row_partner['website']);
          _log("", "partner: ".$req_partner['partner']);
          _log("", "api_key: ".$req_partner['api_key']);
          _log("", "website: ".$req_partner['website']);
          break;
        }
      }
    } else {
      @mysqli_close($dbHandle);
      http_response_code(403);
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 51, 'errorMessage' => 'Can not check API key.');
      echo json_encode($ret_rs);
      die();
    }
  }
}

if (($req_partner['partner'] == '') || ($req_partner['api_key'] == '') || ($req_partner['website'] == '')){
  @mysqli_close($dbHandle);
  http_response_code(403);
  $ret_rs['result'] = 'failed';
  $ret_rs['error'] = array('errorCode' => 52, 'errorMessage' => 'Invalid API key.'.json_encode($req_partner));
  echo json_encode($ret_rs);
  die();
}
$partner_name = $req_partner['partner'];
$partner_api_key = $req_partner['api_key'];
$partner_site = $req_partner['website'];

// 6. Fetch input parameters
$json = file_get_contents('php://input');
$params = json_decode($json, true);
if (!$params) {
  switch (json_last_error()) {
    case JSON_ERROR_DEPTH:
      _log("", 'Reached the maximum stack depth');
      break;
    case JSON_ERROR_STATE_MISMATCH:
      _log("", 'Incorrect discharges or mismatch mode');
      break;
    case JSON_ERROR_CTRL_CHAR:
      _log("", 'Incorrect control character');
      break;
    case JSON_ERROR_SYNTAX:
      _log("", 'Syntax error or JSON invalid');
      break;
    case JSON_ERROR_UTF8:
      _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
      break;
    default:
      _log("", 'Unknown error');
      break;
  }

  @mysqli_close($dbHandle);
  http_response_code(400);
  $ret_rs['result'] = 'failed';
  $ret_rs['error'] = array('errorCode' => 61, 'errorMessage' => 'A non-empty request body is required.');
  echo json_encode($ret_rs);
  die();
}

$requestAction = $params['action'] ?? ACTION_KYC_UPLOAD;
$email_address = $params['email_address'] ?? null;
$profile = $params['profile'] ?? null;
$image = $params['image'] ?? null;
$auth_token = $params['auth_token'] ?? null;

// 7. Check if user signed up and signed in before
$allow_access_api = 0;
$my_db_private_key = '';
$sql_check_sign_in = "SELECT a.*, b.* 
    FROM cryptocash_merchant_user_signin a, cryptocash_shift_wallet b 
    WHERE a.email_address = '$email_address' 
      AND a.merchant='$partner_name' 
      AND a.email_address = b.shift_login_email";
_log($email_address, $sql_check_sign_in);
$rs_check_sign_in = mysqli_query($dbHandle, $sql_check_sign_in);
if (mysqli_num_rows($rs_check_sign_in) > 0) {
  $allow_access_api = 1;
  while ($row_sign_in = mysqli_fetch_array($rs_check_sign_in, MYSQLI_ASSOC)) {
    $my_db_private_key = trim($row_sign_in['private_key']);
  }
}
if( $allow_access_api == 0 ){
  @mysqli_close($dbHandle);
  header('Content-Type: application/json');
  http_response_code(403);
  $ret_rs['result'] = 'failed';
  $ret_rs['error'] = array('errorCode' => 71, 'errorMessage' => 'you must sign in to use this API.');
  echo json_encode($ret_rs);
  die();
}
if ($auth_token != $my_db_private_key) {
  @mysqli_close($dbHandle);
  header('Content-Type: application/json');
  http_response_code(403);
  $ret_rs['result'] = 'failed';
  $ret_rs['error'] = array('errorCode' => 72, 'errorMessage' => 'Unauthorized.');
  echo json_encode($ret_rs);
  die();
}

// 8. Check if the user has been completed issuing a card, is pending KYC verification, or is pending activation,
$old_kyc_status = 0;
$old_card_activation_status = 0;
$old_card_status = 0;
$old_payment_status = 0;
$errorMsg = '';
$sql_check_user_status =
  "SELECT * FROM cryptocash_user_status WHERE email_address = '$email_address' AND created_from='$partner_name'";
$rs_check_user_status = mysqli_query($dbHandle, $sql_check_user_status);
if (@mysqli_num_rows($rs_check_user_status) > 0) {
  while ($row_user_status = mysqli_fetch_array($rs_check_user_status, MYSQLI_ASSOC)) {
    $old_kyc_status = (int)trim($row_user_status['kyc_status']);
    $old_card_activation_status = (int)trim($row_user_status['card_activation_status']);
    $old_card_status = (int)trim($row_user_status['card_status']);
    $old_payment_status = (int)trim($row_user_status['payment_status']);
  }
  if( $old_kyc_status == 1 ){
    $errorMsg = 'You are in under review KYC status for issue the debit card. You will receive your results within 24 hours';
  }
  else if( $old_kyc_status == 2 ){
    if( $old_payment_status == 2 ){
      if( $old_card_activation_status == 2 ) {
        if( $old_card_status == 2 ){
          $errorMsg = 'Your KYC has been approved. You already have a card.';
        }
        else{
          $errorMsg = 'Your KYC has been approved. Please contact to administrator.';
        }
      }
      else if( $old_card_activation_status == 1 ) {
        $errorMsg = 'Your KYC has been approved. Your card activation documents are currently under review. Please wait 2-3 days for the review process to be completed.';
      }
      else if( $old_card_activation_status == 9 ) {
        $errorMsg = 'Your KYC has been approved. But unfortunately, your card activation documents have not been approved. Please review the requirements and resubmit the necessary documents for further review.';
      }
      else {
        $errorMsg = 'Your KYC has been approved. Create your card. Your Debit Card is now on production. Expect the card delivered to your postal address in 10-15 days.';
      }
    }
    else {
      $errorMsg = 'Your KYC already has been approved. Please pay the card issuance fee.';
    }
  }

  if( $errorMsg != '' ){
    @mysqli_close($dbHandle);
    header('Content-Type: application/json');
    http_response_code(500);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 81, 'errorMessage' => $errorMsg);
    echo json_encode($ret_rs);
    die();
  }
}
else{
  $sql_add_user_status = "INSERT INTO `cryptocash_user_status` 
    (`email_address`, `kyc_status`, `card_activation_status`, `card_status`, `payment_status`, `created_from`)
    VALUES ('$email_address', 0, 0, 0, 0, '$partner_name');";
  _log($email_address, $sql_add_user_status);
  mysqli_query($dbHandle, $sql_add_user_status);
  if (mysqli_affected_rows($dbHandle) <= 0){
    @mysqli_close($dbHandle);
    http_response_code(400);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 82, 'errorMessage' => 'You must register on this system, first');
    echo json_encode($ret_rs);
    die();
  }
}

// 9. Check if all parameters are valid.
$parameter_check_result = validateProfileParams($params);
if (count($parameter_check_result) > 0) {
  @mysqli_close($dbHandle);
  http_response_code(400);
  $ret_rs['result'] = 'failed';
  $ret_rs['error'] = array('errorCode' => 91, 'errorMessage' => 'Some parameters are missing.', 'errorData' => $parameter_check_result);
  echo json_encode($ret_rs);
  die();
}

// 10. Preparing parameters to store database
$gender = $params['profile']['gender'];
$name_romaji = $params['profile']['full_name'];
$marriage_status = $params['profile']['marriage_status'];
$occupation = $params['profile']['occupation'];
$country = $params['profile']['country'];
$nationality = $params['profile']['nationality'];
$date_of_birth = $params['profile']['date_of_birth'];
$place_of_birth = $params['profile']['place_of_birth'];
$id_card_number = $params['profile']['id_card_number'];
$id_card_issued_dt = $params['profile']['id_card_issued_dt'];
$id_card_expired_dt = $params['profile']['id_card_expired_dt'];
$id_card_issuer = $params['profile']['id_card_issuer'];
$id_card_type = $params['profile']['id_card_type'];
$residence_address = $params['profile']['residence_address'];
$district = $params['profile']['district'];
$province = $params['profile']['province'];
$postal_code = $params['profile']['postal_code'];
$cellphone_country_code = $params['profile']['cellphone_country_code'];
$cellphone_number = $params['profile']['cellphone_number'];
$name_on_card = $params['profile']['name_on_card'];
$card_provider = $params['profile']['card_provider'];
$card_design = 'ultimo';
$unique_pid = generateRandomString(20);
$added_dt = date('Y-m-d H:i:s');
$update_dt = date('Y-m-d H:i:s');

$givenName = '';
$surname = '';
$middleName = '';
$nameParts = explode(' ', trim($name_romaji));
$nameCount = count($nameParts);
if ($nameCount > 0) {
  $givenName = $nameParts[0];
  $surname = $nameParts[$nameCount - 1];
  $middleName = $nameCount > 2 ? implode(' ', array_slice($nameParts, 1, $nameCount - 2)) : '';
}

// 11. Check what to do
$toDoAction = TODO_ADD_KYC;
$toDoSql = "SELECT * FROM `cryptocash_jdb_profile` WHERE `email_address` = '$email_address' AND `created_from`='$partner_name'";
$rs_toDo = mysqli_query($dbHandle, $toDoSql);
if (@mysqli_num_rows($rs_toDo) > 0) {
  $toDoAction = TODO_UPDATE_KYC;
}

// 12. Insert a new profile or update an existing profile.
if( $toDoAction == TODO_ADD_KYC ){
  $removeSql = "DELETE FROM `cryptocash_jdb_profile` WHERE `email_address` = '$email_address' AND `created_from`='$partner_name'";
  mysqli_query($dbHandle, $removeSql);

  $unique_pid = generateRandomString(20);
  $added_dt = date('Y-m-d H:i:s');
  $sql_add_profile = "
    INSERT INTO `cryptocash_jdb_profile` 
        (`profile_id`, `gender`, `name_kanji_kana`, `name_romaji`, `marriage_status`, `occupation`, `country`,
         `nationality`, `date_of_birth`, `place_of_birth`, `id_card_number`, `id_card_issued_dt`, `id_card_expired_dt`,
         `id_card_issuer`, `id_card_type`,`residence_address`, `district`, `province`, `postal_code`,
         `home_telephone_country_code`, `home_telephone_number`, `cellphone_country_code`, `cellphone_number`, `consent_name`,
         `email_address`, `added_dt`, `application_deny_message`, `name_on_card`, `created_from`) 
    VALUES 
        ('$unique_pid', '$gender', '', '$name_romaji', '$marriage_status', '$occupation', '$country',
         '$nationality', '$date_of_birth', '$place_of_birth', '$id_card_number', '$id_card_issued_dt', '$id_card_expired_dt',
         '$id_card_issuer', '$id_card_type', '$residence_address', '$district', '$province', '$postal_code',
         '', '', '$cellphone_country_code', '$cellphone_number', '',
         '$email_address', '$added_dt', '', '$name_on_card', '$partner_name')";
  mysqli_query($dbHandle, $sql_add_profile);
  if (mysqli_affected_rows($dbHandle) > 0) {
    // Remove if exists.
    $removeSql = "DELETE FROM `cryptocash_jdb_debit_card` WHERE `email_address` = '$email_address' AND `created_from`='$partner_name'";
    mysqli_query($dbHandle, $removeSql);

    $debit_card_created_dt = date('Y-m-d H:i:s');
    $sql_add_debit_card = " INSERT INTO cryptocash_jdb_debit_card 
            (profile_id, email_address, created_dt, updated_dt, acc_no, debit_card_num,
             card_design, card_provider, created_from) 
        VALUES 
             ('$unique_pid', '$email_address', '$debit_card_created_dt', '$debit_card_created_dt',
              '', '', '$card_design', '$card_provider', '$partner_name')";
    mysqli_query($dbHandle, $sql_add_debit_card);
    if (mysqli_affected_rows($dbHandle) > 0) {
      // Remove if exists.
      $removeSql = "DELETE FROM `cryptocash_users_profile` WHERE `email` = '$email_address' AND `created_from`='$partner_name'";
      mysqli_query($dbHandle, $removeSql);

      $sql_add_user_profile = " INSERT INTO cryptocash_users_profile 
            (email, given_name, middle_name, sur_name, 
             shift_full_name, country, shift_update_dt, created_from) 
        VALUES 
             ('$email_address', '$givenName', '$middleName', '$surname',
              '$name_romaji', '$country', '$added_dt', '$partner_name')";
      mysqli_query($dbHandle, $sql_add_user_profile);
      if (mysqli_affected_rows($dbHandle) <= 0) {
        $ret_rs['code'] = 500;
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = array('errorCode' => 121, 'errorMessage' => "Can not add user profile: $sql_add_user_profile");
      }
    } else {
      $ret_rs['code'] = 500;
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 122, 'errorMessage' => "Can not add jdb debit card: $sql_add_debit_card");
    }
  } else {
    $ret_rs['code'] = 500;
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 123, 'errorMessage' => "Can not add jdb profile: $sql_add_profile");
  }
}
else {
  $sql_update_profile = "UPDATE `cryptocash_jdb_profile` 
    SET 
        `gender` = '$gender', `name_romaji` = '$name_romaji', `marriage_status` = '$marriage_status',
        `occupation` = '$occupation', `country` = '$country', `nationality` = '$nationality',
        `date_of_birth` = '$date_of_birth', `place_of_birth` = '$place_of_birth', `id_card_number` = '$id_card_number',
        `id_card_issued_dt` = '$id_card_issued_dt', `id_card_expired_dt` = '$id_card_expired_dt', `id_card_issuer` = '$id_card_issuer',
        `id_card_type` = '$id_card_type', `residence_address` = '$residence_address', `district` = '$district',
        `province` = '$province', `postal_code` = '$postal_code', `cellphone_country_code` = '$cellphone_country_code',
        `cellphone_number` = '$cellphone_number', `update_dt` = '$update_dt', `name_on_card` = '$name_on_card'  
    WHERE `email_address` = '$email_address' AND created_from='$partner_name'";
  if (mysqli_query($dbHandle, $sql_update_profile)) {
    $sql_update_debit_card = "UPDATE cryptocash_jdb_debit_card 
      SET 
          `acc_no` = '',
          `debit_card_num` = '',
          `card_design` = '$card_design',
          `card_provider` = '$card_provider' 
      WHERE `email_address` = '$email_address' AND created_from='$partner_name'";
    if (mysqli_query($dbHandle, $sql_update_debit_card)) {
      $update_shift_profile_sql = "UPDATE cryptocash_users_profile 
        SET 
            shift_update_dt='$update_dt', kyc_upload_dt = NULL, given_name='$givenName',
            middle_name='$middleName', sur_name='$surname', shift_full_name='$name_romaji',
            `country` = '$country' 
        WHERE email='$email_address' AND created_from='$partner_name'";
      if(!mysqli_query($dbHandle, $update_shift_profile_sql)){
        $ret_rs['code'] = 500;
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = array('errorCode' => 124, 'errorMessage' => "Can not update user profile: $update_shift_profile_sql");
      }
    } else {
      $ret_rs['code'] = 500;
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 125, 'errorMessage' => "Can not update debit card: $sql_update_debit_card");
    }
  } else {
    $ret_rs['code'] = 500;
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 126, 'errorMessage' => "Can not update debit card: $sql_update_profile");
  }
}

// 13. Generate KYC PDF file
$profileUrl = SITE_PATH."/IssueCard/profile.php";
$profilePostData = [
  'profile_title' => $gender,
  'name_on_card' => $name_on_card,
  'profile_name_romaji' => $name_romaji,
  'profile_marriage_status' => $marriage_status,
  'occupation_final' => $occupation,
  'profile_nationality' => $nationality,
  'profile_country' => $country,
  'profile_birthday' => str_replace('-', '/', $date_of_birth),
  'profile_id_number' => $id_card_number,
  'profile_id_issue_date' => str_replace('-', '/', $id_card_issued_dt),
  'profile_id_issuer' => $id_card_issuer,
  'profile_id_card_expiration_date' => str_replace('-', '/', $id_card_expired_dt),
  'profile_address' => $residence_address,
  'profile_city' => $district,
  'profile_province' => $province,
  'profile_zipcode' => $postal_code,
  'profile_cellphone_country_code' => $cellphone_country_code,
  'profile_cellphone_number' => $cellphone_number,
  'email_address' => $email_address,
  'id_card_type' => $id_card_type,
  'card_provider_selection' => $card_provider,
];
$response = sendPostRequestCurl($profileUrl, $profilePostData);
$resp_profile = json_decode($response, true);
if( $resp_profile['msg'] != 'proc_ok'){
  $ret_rs['resp'] = $response;
  $ret_rs['result'] = 'failed';
  $ret_rs['code'] = 500;
}
else{
  $htmlBindingData = [
    'profileData' => $params,
    'pdfData' => json_decode($response, true),
    'apiKey' => $partner_api_key,
    'auth_token' => $auth_token,
  ];
  $htmlContent = loadHtmlTemplate('templates/template_card_issue.php', $htmlBindingData);
}

// 14. Send final response.
@mysqli_close($dbHandle);
header('Content-Type: application/json');
http_response_code($ret_rs['code']);
if( $ret_rs['result'] != 'failed' && strlen(trim($htmlContent)) > 0 ) {
  $encodedHtml = base64_encode($htmlContent);
  $ret_rs['challengeHtml'] = $encodedHtml;
  $ret_rs['result'] = 'success';
}
echo json_encode($ret_rs);
