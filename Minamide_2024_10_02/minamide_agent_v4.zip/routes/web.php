<?php

use App\Http\Controllers\CheckPurchaseToolController;
use App\Http\Controllers\LanguageController;
// zendesk
use App\Http\Controllers\UltimoApiController;
use App\Http\Controllers\ZendeskController;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
    // Route Dashboards

Route::any('/', 'AuthenticationController@login');
Route::post('/login', 'DashboardController@login');

// Route Authentication Pages
Route::get('/login', 'AuthenticationController@login')->name('login');
//Route::get('/auth-register', 'AuthenticationController@register')->name('register.form');
//Route::post('/post-register', 'AuthController@register')->name('register.post');;
Route::get('/auth-forgot-password', 'AuthenticationController@forgot_password');
Route::get('/auth-reset-password', 'AuthenticationController@reset_password');
Route::get('/auth-lock-screen', 'AuthenticationController@lock_screen');

//Auth::routes();

// Route url
Route::middleware([])->group(function () {

    Route::post('/upload/csvFile', 'DashboardController@upload');
    Route::post('/upload/retryRollback', 'DashboardController@retryRollback');
    Route::post('/upload/checkCsvFile', 'DashboardController@checkCsvFile');
    Route::post('/upload/getFileDetails', 'DashboardController@getFileDetails');
    Route::post('/upload/balanceCorrection', 'DashboardController@balanceCorrection');
    Route::post('/upload/balanceCorrectionAgent', 'DashboardController@balanceCorrectionAgent');
    Route::post('/upload/getFileSummery', 'DashboardController@getFileSummery');
    Route::post('/upload/getWalletBalance', 'DashboardController@getWalletBalance');
    Route::get('/home', 'DashboardController@home')->name('home');
    Route::get('/myPaysIo', 'DashboardController@myPaysIo')->name('myPaysIo');
    Route::post('/getFileList', 'DashboardController@getFileList')->name('getFileList');

    // Route Components
    Route::get('/sk-layout-2-columns', 'StaterkitController@columns_2');
    Route::get('/sk-layout-fixed-navbar', 'StaterkitController@fixed_navbar');
    Route::get('/sk-layout-floating-navbar', 'StaterkitController@floating_navbar');
    Route::get('/sk-layout-fixed', 'StaterkitController@fixed_layout');

    // acess controller
    Route::get('/access-control', 'AccessController@index');
    Route::get('/access-control/{roles}', 'AccessController@roles');
    Route::get('/modern-admin', 'AccessController@home')->middleware('permissions:approve-post');
    // locale Route
    Route::get('lang/{locale}',[LanguageController::class,'swap']);
});



Route::get('/zendesk', [ZendeskController::class, 'redirectToAdmin']);


Route::get('/zendesk/admin', [ZendeskController::class, 'index'])->name('zendesk.admin');

// Signup
Route::get('/zendesk/signup', [ZendeskController::class, 'showSignupForm'])->name('zendesk.signup.form');
Route::post('/zendesk/signup', [ZendeskController::class, 'signup'])->name('zendesk.signup.submit');

// Login
Route::get('/zendesk/login', [ZendeskController::class, 'showLoginForm'])->name('zendesk.login');
Route::post('/zendesk/login', [ZendeskController::class, 'login'])->name('zendesk.login.submit');
Route::get('/zendesk/logout', [ZendeskController::class, 'logout'])->name('zendesk.logout');
Route::get('/zendesk/kaiser-1', [ZendeskController::class, 'callKaiser1'])->name('zendesk.kaiser.1');
Route::get('/zendesk/kaiser-2', [ZendeskController::class, 'callKaiser2'])->name('zendesk.kaiser.2');
Route::get('/zendesk/kaiser-3', [ZendeskController::class, 'callKaiser3'])->name('zendesk.kaiser.3');
Route::get('/zendesk/kaiser-4', [ZendeskController::class, 'callKaiser4'])->name('zendesk.kaiser.4');

// Admin Profile Update
Route::get('/zendesk/admin/profile/update', [ZendeskController::class, 'showUpdateProfileForm'])->name('zendesk.admin.profile.form');
Route::post('/zendesk/admin/profile/update', [ZendeskController::class, 'updateProfile'])->name('zendesk.admin.update');

// Change Password
Route::get('/zendesk/change-password', [ZendeskController::class, 'showChangePasswordForm'])->name('zendesk.password.form');
Route::post('/zendesk/change-password', [ZendeskController::class, 'changePassword'])->name('zendesk.password.change');

// Ultimo API test url
Route::get('/xapiserver/reqCardIssue', [UltimoApiController::class, 'showReqIssueCardApiTestPage'])->name('xapiserver.reqIssueCardApi');
Route::post('/xapiserver/callIssueCardApi', [UltimoApiController::class, 'callIssueCardApi'])->name('xapiserver.callIssueCardApi');

// Payment Check Tool
Route::get('/purchaseChecker', [CheckPurchaseToolController::class, 'home'])->name('purchaseChecker.home');
Route::get('/purchaseChecker/home', [CheckPurchaseToolController::class, 'home'])->name('purchaseChecker.home');
Route::get('/purchaseChecker/checkTxID', [CheckPurchaseToolController::class, 'checkTxID'])->name('purchaseChecker.checkTxID');
Route::get('/purchaseChecker/setting', [CheckPurchaseToolController::class, 'setting'])->name('purchaseChecker.setting');

Route::get('/purchaseChecker/partner', [CheckPurchaseToolController::class, 'partner']);
Route::get('/purchaseChecker/partners', [CheckPurchaseToolController::class, 'partners']);
Route::post('/purchaseChecker/partner', [CheckPurchaseToolController::class, 'savePartner']);
Route::delete('/purchaseChecker/partner', [CheckPurchaseToolController::class, 'removePartner']);

Route::post('/purchaseChecker/shiftSignIn', [CheckPurchaseToolController::class, 'shiftSignIn']);
Route::post('/purchaseChecker/getShiftTransactions', [CheckPurchaseToolController::class, 'getShiftTransactions']);
Route::post('/purchaseChecker/getLocalData', [CheckPurchaseToolController::class, 'getLocalData']);
Route::post('/purchaseChecker/getJdbData', [CheckPurchaseToolController::class, 'getJdbData']);
Route::post('/purchaseChecker/getOneJdbData', [CheckPurchaseToolController::class, 'getOneJdbData']);
Route::post('/purchaseChecker/getShiftTransactionDetails', [CheckPurchaseToolController::class, 'getShiftTransactionDetails']);
Route::post('/purchaseChecker/getFireBlocksData', [CheckPurchaseToolController::class, 'getFireBlocksData']);
