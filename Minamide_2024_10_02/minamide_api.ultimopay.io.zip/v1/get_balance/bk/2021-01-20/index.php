<?php
mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}
$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
$found = 0;
foreach (getAllHeaders() as $name => $value) {
    //echo "$name: $value\n";
	if ($name == 'Authorization') {
		if ($value == $apikey) {
			$found=1;
			break;
		}
	}
}

if ($found==1) {
	$failed_rs = array('result' => 'failed', 'error' => 'invalid data');
	
	//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
	//echo "payment_id: " . $payment_id . "<br/>";
	$json = file_get_contents('php://input');
	$data = json_decode($json, true);
	
	if (!($data)) {
		switch (json_last_error()) {
			case JSON_ERROR_DEPTH:
				$failed_rs['error'] = 'Reached the maximum stack depth';
				break;
			case JSON_ERROR_STATE_MISMATCH:
				$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
				break;
			case JSON_ERROR_CTRL_CHAR:
				$failed_rs['error'] = 'Incorrect control character';
				break;
			case JSON_ERROR_SYNTAX:
				$failed_rs['error'] = 'Syntax error or JSON invalid';
				break;
			case JSON_ERROR_UTF8:
				$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
				break;
			default:
				$failed_rs['error'] = 'Unknown error';
		}

		//throw new Exception($error);
		
	} else {
		$errors = array();
		if ((!isset($data['requested_crypto_currency'])) || (empty($data['requested_crypto_currency']))) {
			$errors[] = 'requested_crypto_currency is empty';
		} else {
			if (trim($data['requested_crypto_currency']) != 'USDT') {
				$errors[] = 'requested_crypto_currency must be USDT';
			}
		}
		
		if ((!isset($data['fiat_total_amount_to_pay'])) || (empty($data['fiat_total_amount_to_pay']))) {
			$errors[] = 'fiat_total_amount_to_pay is empty';			
		} 
		
		if ((!isset($data['fiat_total_amount_to_pay']['amount'])) || (empty($data['fiat_total_amount_to_pay']['amount']))) {
			$errors[] = 'invalid fiat_total_amount_to_pay data: amount is empty';			
		} else {
			if (floatval($data['fiat_total_amount_to_pay']['amount']) == 0) {
				$errors[] = 'invalid fiat_total_amount_to_pay data: amount must be a number and greater than zero';
			}
			
			if (floatval($data['fiat_total_amount_to_pay']['amount']) < 50) {
				$errors[] = 'invalid fiat_total_amount_to_pay data: amount must be at least 50';
			}
			
			if (floatval($data['fiat_total_amount_to_pay']['amount']) > 20000) {
				$errors[] = 'invalid fiat_total_amount_to_pay data: amount cannot exceed 20000';
			}
		}
		
		if ((!isset($data['fiat_total_amount_to_pay']['currency'])) || (empty($data['fiat_total_amount_to_pay']['currency']))) {
			$errors[] = 'invalid fiat_total_amount_to_pay data: currency is empty';			
		} else {
			if (trim($data['fiat_total_amount_to_pay']['currency']) != 'USD') {
				$errors[] = 'invalid fiat_total_amount_to_pay data: currency must be USD';	
			}			
		}
		
		if ((!isset($data['usdt_wallet_address'])) || (empty($data['usdt_wallet_address']))) {
			$errors[] = 'usdt_wallet_address is empty';			
		} 
		
		if ((!isset($data['user_agent'])) || (empty($data['user_agent']))) {
			$errors[] = 'user_agent is empty';			
		} 
		
		if ((!isset($data['ip'])) || (empty($data['ip']))) {
			$errors[] = 'ip is empty';			
		} 
		
		if ((!isset($data['accept_language'])) || (empty($data['accept_language']))) {
			$errors[] = 'accept_language is empty';			
		} 
		
		if ((!isset($data['partner'])) || (empty($data['partner']))) {
			$errors[] = 'partner is empty';			
		} else {
			if (trim($data['partner']) != 'YOUSCASINO') {
				$errors[] = 'partner must be YOUSCASINO';
			}
		}
		
		if (count($errors) == 0) {
			require '../include/dbconfig.php';
			require '../include/common.php';
			
			$fh = @fopen("/var/www/api.xbuy.io/v1/get_payment_id/transaction.log" , 'a');

			function _log($line) {
				global $fh;
				$fline = date('[Ymd H:i:s] ') . $line."\n";
				fwrite($fh, $fline);
				//echo date('[Ymd H:i:s] ').$line."\n";
				//@ob_flush(); 
				//flush();
			}
			$email = 'xbuy_user_' . uniqid() . '@xbuy.io';
			$app_end_user_id = common_uuid();
			$payment_id = common_uuid();
			$success_rs = array();
			$success_rs['payment_id'] = $payment_id;
			$fiat_total_amount_to_pay_arr = array();
			$fiat_total_amount_to_pay_arr['amount'] = $data['fiat_total_amount_to_pay']['amount'];
			$fiat_total_amount_to_pay_arr['currency'] = $data['fiat_total_amount_to_pay']['currency'];
			$success_rs['fiat_total_amount_to_pay'] = $fiat_total_amount_to_pay_arr;
			$success_rs['usdt_wallet_address'] = $data['usdt_wallet_address'];
			$success_rs['user_agent'] = $data['user_agent'];
			$success_rs['ip'] = $data['ip'];
			$success_rs['accept_language'] = $data['accept_language'];
			$success_rs['partner'] = $data['partner'];
			
			
			$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
			if (mysqli_connect_errno() == 0) {
				mysqli_query($dbhandle, "set names utf8;");
				//add to payment
				$fiat_amount_db = mysqli_real_escape_string($dbhandle, $data['fiat_total_amount_to_pay']['amount']);
				$fiat_currency_db = "USD";
				$usdt_wallet_address_db = mysqli_real_escape_string($dbhandle, $data['usdt_wallet_address']);
				$user_agent_db = mysqli_real_escape_string($dbhandle, $data['user_agent']);
				$ip_address_db = mysqli_real_escape_string($dbhandle, $data['ip']);
				$accept_language_db = mysqli_real_escape_string($dbhandle, $data['accept_language']);
				
				$cur_time = time();
				$created_dt_db = date('Y-m-d H:i:s', $cur_time);
				$sql  = "INSERT INTO youscasino_generated_payment (payment_id, created_tm, created_dt, fiat_amount, fiat_currency, usdt_wallet_address, user_agent, ip_address, accept_language, app_end_user_id, email, crypto_currency) VALUES ('$payment_id', $cur_time, '$created_dt_db', ";
				$sql .= "'$fiat_amount_db', 'USD', '$usdt_wallet_address_db', '$user_agent_db', '$ip_address_db', '$accept_language_db', '$app_end_user_id', '$email', 'USDT')";
				_log($sql);
				@fclose($fh);
				if (!mysqli_query($dbhandle, $sql)) {
					@mysqli_close($dbhandle);
					$failed_rs['error'] = 'cannot insert, please contact xbuy.io administrator';
					header('Content-Type: application/json');
					echo json_encode($failed_rs);
					die();
					
				} else {
					header('Content-Type: application/json');
					echo json_encode($success_rs);
					die();
				}
				
			} else {
				$failed_rs['error'] = 'cannnot connect db, please contact xbuy.io administrator';
				header('Content-Type: application/json');
				echo json_encode($failed_rs);
				die();
			}
			
			
			
		} else {
			$failed_rs['error'] = $errors[0];
			header('Content-Type: application/json');
			echo json_encode($failed_rs);
			die();
		}
			
		
	}

} else {
	header('HTTP/1.0 403 Forbidden');
}
?>