<?php
//define("DB_HOST", '95.216.23.251');
//define("DB_USERNAME", 'ultimopay003');
//define("DB_PASSWORD", 'c6XNCs72Bsd39w4T');
//define("DB_NAME", 'ultimopay.io');

define("DB_HOST", 'localhost');
define("DB_USERNAME", 'root');
define("DB_PASSWORD", '');
define("DB_NAME", 'ultimopay.io');

define("DB_HOST_XEXON", '95.216.23.251');
define("DB_USERNAME_XEXON", 'xexon001');
define("DB_PASSWORD_XEXON", 'tRLG8LPrKUtQAkdT');
define("DB_NAME_XEXON", 'cryptocash.com');
?>
