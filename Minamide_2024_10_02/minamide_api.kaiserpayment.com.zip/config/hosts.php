<?php
return [
  'localhost',
  'api.kaiserpayment.com',
  'dashboard.xexon.io'
];
