<!-- Admin Update Modal -->
<div class="modal fade" id="apiKeyModal" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="apiKeyLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-success">
        <h5 class="modal-title" id="apiKeyLabel">API KEY<span class="update-partner-apikey"></span></h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="modal-api-key" style="word-break: break-all;"></div>
      </div>
    </div>
  </div>
</div>


