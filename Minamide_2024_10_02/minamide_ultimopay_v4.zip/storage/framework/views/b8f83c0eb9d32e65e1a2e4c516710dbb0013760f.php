<!-- BEGIN: Footer-->
<?php if($configData["mainLayoutType"] == 'horizontal' && isset($configData["mainLayoutType"])): ?>
<footer
    class="footer <?php echo e($configData['footerType']); ?> <?php echo e(($configData['footerType']=== 'footer-hidden') ? 'd-none':''); ?> footer-light navbar-shadow">
    <?php else: ?>
    <footer
        class="footer <?php echo e($configData['footerType']); ?>  <?php echo e(($configData['footerType']=== 'footer-hidden') ? 'd-none':''); ?> footer-light">
        <?php endif; ?>
        <p class="clearfix blue-grey lighten-2 mb-0"><span
                class="float-md-left d-block d-md-inline-block mt-25">Ultimopay &copy; 2022<a
                    class="text-bold-800 grey darken-2" href="#"
                    target="_blank"></a>All rights Reserved</span><span
                class="float-md-right d-none d-md-block">Made with<img style="width: 60px; margin-left:5px"src="images/logo/ultimo-logo-footer.png"/></span>
            <button class="btn btn-primary btn-icon scroll-top" type="button"><i
                    class="feather icon-arrow-up"></i></button>
        </p>
    </footer>
    <!-- END: Footer--><?php /**PATH D:\Minamide\minamide_ultimopay_v4\resources\views/panels/footer.blade.php ENDPATH**/ ?>