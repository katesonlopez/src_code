<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

ini_set('memory_limit','100M');

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
  function getallheaders()
  {
    if (!is_array($_SERVER)) {
      return array();
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
      if (substr($name, 0, 5) == 'HTTP_') {
        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
      }
    }
    return $headers;
  }
}

function decimal_notation($float) {
  $parts = explode('E', $float);

  if(count($parts) === 2){
    $exp = abs(end($parts)) + strlen($parts[0]);
    $decimal = number_format($float, $exp);
    return rtrim($decimal, '.0');
  }
  else{
    return $float;
  }
}

function _log($email, $line) {

  //global $fh;
  if ($email == "") {
    $fh2 = fopen("/var/www/api.ultimopay.io/v4/getReport/log/get_report.log" , 'a');
  } else {
    $fh2 = fopen("/var/www/api.ultimopay.io/v4/getReport/log/" . $email . ".log" , 'a');
  }
  $fline = date('[Ymd H:i:s] ') . $line."\n";
  fwrite($fh2, $fline);
  fclose($fh2);
}

$people = array("kakizaki50en2@gmail.com", "minamide@optlynx.com");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_once '../include/dbconfig.php';
  $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
  if (mysqli_connect_errno() != 0) {

    header('Content-Type: application/json');
    http_response_code(500);
    $ret_rs['result'] = 'failed';
    $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
    echo json_encode($ret_rs);
    die();
  } else {
    _log("", "ket noi thanh cong");
    mysqli_query($dbhandle, "set names utf8;");
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
  $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
  $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
  $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
  $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
  $clientSecret4 = 'climbpot api access key';
  $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
  $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
  $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
  $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
  $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
  $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
  //$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
  $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
  $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
  $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
  $apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
  $found = 0;
  $coin = 'USDT';
  $sandbox = 0;
  $partner = "";
  $allowed_deposit_currency_arr = array('USDT');
  $req_api_key = "";
  $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

  foreach (getallheaders() as $name => $value) {

    if ($name == 'Authorization') {

      $req_api_key = trim($value);
      $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
      $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
      if (mysqli_num_rows($partner_rs) > 0) {
        while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
          $cur_api_key = "Bearer " . $row_partner['api_key'];
          if ($req_api_key == $cur_api_key) {
            $req_partner['partner'] = trim($row_partner['partner']);
            $req_partner['api_key'] = trim($row_partner['api_key']);
            $req_partner['website'] = trim($row_partner['website']);
            $selected_api_key = $req_api_key;
            break;
          }
        }
      } else {
        _log("", "not found in db");
      }
    }
  }

  function generateRandomString($length, $bitmask) {
    $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $lowercase = 'abcdefghijklmnopqrstuvwxyz';
    $numbers = '0123456789';
    $characters = '';
    $characters .= $uppercase . $lowercase . $numbers;
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
      $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
  }

  function validateDate($date, $format = 'Y-m-d'){
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
  }

  function isValidPassword($password) {
    if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
      return FALSE;
    return TRUE;
  }

  function get_wallet_transaction_history($_auth_token) {
    global $email_address;
    global $api_graphql_host;
    global $api_host;
    $wallet_transaction_histor_arr = array();
    $wallet_transaction_history_info = array('error' => '', 'raw_error' => '', 'http_code' => '');
    ///////////////////////////////////////////////////
    $tmp_dto_transaction_history_arr = array();
    $wallet_transaction_history_query = '{"query":"query (\n    $type: PaymentType,\n    $currency_id: String,\n    $dateRange: DateRangeInput,\n    $pager: PagerInput,\n    $status: [PaymentStatus!]) {\n        payments (\n            type: $type,\n            currency_id: $currency_id,\n            dateRange: $dateRange,\n            pager: $pager,\n            status: $status\n        ) {\n            payment_id,\n            currency_id,\n            amount,\n            type,\n            crypto_transaction_id,\n            crypto_address,\n            crypto_address_tag_type,\n            crypto_address_tag_value,\n            crypto_network,\n            approval_status,\n            fiat_bank_name,\n            fiat_bank_address,\n            fiat_bank_bic,\n            fiat_routing_number,\n            fiat_reference,\n            fiat_notes,\n            fiat_beneficiary_name,\n            fiat_beneficiary_account_number,\n            fiat_beneficiary_address_line_1,\n            fiat_beneficiary_address_line_2,\n            status,\n            message,\n            error_message,\n            created_at,\n            updated_at \n        }\n    }","variables":{"pager":{"offset":0,"limit":10000}}}';
    unset($wallet_transaction_history_res);
    _log($email_address, "chuan bi ....");
    $wallet_transaction_history_res = api_call('/api/v4/wallet/transaction/history', 0, $wallet_transaction_history_query , $tmp_dto_transaction_history_arr, $_auth_token);
    _log($email_address, "chuan bi xong :");
    $raw_res_body = json_encode($wallet_transaction_history_res);
    _log($email_address, "chuan bi ke tiep : " . $raw_res_body);
    if (($wallet_transaction_history_res['http_code'] == "200") || ($wallet_transaction_history_res['http_code'] == "200 OK")) {
      if (is_array($wallet_transaction_history_res['result']['data']['payments'])) {
        _log($email_address, "phat hien array " . count($wallet_transaction_history_res['result']['data']['payments']));

        for ($tx_cnt=0; $tx_cnt<count($wallet_transaction_history_res['result']['data']['payments']); $tx_cnt++) {
          unset($target_tx);
          $target_tx = $wallet_transaction_history_res['result']['data']['payments'][$tx_cnt];
          if (isset($target_tx)) {

            if (  (isset($target_tx['payment_id'])) && (isset($target_tx['currency_id'])) && (isset($target_tx['type']))  && (isset($target_tx['amount']))  ) {
              //_log($email_address, "vao item so " .  $tx_cnt);
              $shift_tx_obj = array('payment_id' => '', 'status' => '', 'type' => '', 'currency' => '', 'address' => '', 'amount' => '', 'crypto_transaction_id' => '', 'created_date' => '', 'crypto_network' => '');

              //payment_id
              $shift_tx_obj['payment_id'] = trim($target_tx['payment_id']);

              //status
              if (isset($target_tx['status'])) {
                $shift_tx_obj['status'] = trim($target_tx['status']);
              }

              //type
              $shift_tx_obj['type'] = trim($target_tx['type']);

              //currency_id
              $shift_tx_obj['currency'] = strtoupper(trim($target_tx['currency_id']));

              //crypto_address
              $shift_tx_obj['address'] = trim($target_tx['crypto_address']);

              //amount
              $shift_tx_obj['amount'] = trim($target_tx['amount']);

              //crypto_transaction_id
              _log($email_address, "target_tx['crypto_transaction_id'] " . $target_tx['crypto_transaction_id']);
              if (!is_null($target_tx['crypto_transaction_id'])) {
                $shift_tx_obj['crypto_transaction_id'] = trim($target_tx['crypto_transaction_id']);
              }

              //crypto_network
              if (isset($target_tx['crypto_network'])) {
                $shift_tx_obj['crypto_network'] = trim($target_tx['crypto_network']);
              }

              //created_at
              if (!empty($target_tx['created_at'])) {
                $shift_tx_obj['created_date'] = str_replace("-","/", $target_tx['created_at']);
              }

              //updated_at
              if (!empty($target_tx['updated_at'])) {
                $shift_tx_obj['updated_date'] = str_replace("-","/", $target_tx['updated_at']);
              }

              $wallet_transaction_histor_arr[] = $shift_tx_obj;

            } else {
              _log($email_address, "api call /api/v4/wallet/transaction/history ERROR: all fields are empty");
            }

          } else {
            _log($email_address, "api call /api/v4/wallet/transaction/history ERROR: target_tx is empty");
          }
        }
        $wallet_transaction_history_info['wallet_transction_history_list'] = $wallet_transaction_histor_arr;

      } else {
        _log($email_address, "api call /api/v4/wallet/transaction/history ERROR: is not array");
        $wallet_transaction_history_info['error'] = 'data.payments_is_not_array';
        $wallet_transaction_history_info['raw_error'] = $raw_res_body;
      }
    } else {
      $wallet_transaction_history_info['error'] = 'ng_http_response_code';
      $wallet_transaction_history_info['raw_error'] = $raw_res_body;
      $wallet_transaction_history_info['http_code'] = $wallet_transaction_history_res['http_code'];
    }
    ///////////////////////////////////////////////////
    return $wallet_transaction_history_info;
  }

  function get_my_closed_orders($_auth_token) {
    global $db_order_id_arr;
    global $email_address;
    global $api_graphql_host;
    global $api_host;
    $my_closed_orders_arr = array();
    $my_closed_orders_info = array('error' => '', 'raw_error' => '', 'http_code' => '');
    ///////////////////////////////////////////////////
    $tmp_dto_my_closed_orders_arr = array();
    $my_closed_orders_query = '{"query":"query ($instrument_id: String, $status: [OrderStatus!], $side: OrderSide, $pager: PagerInput, $dateRange: DateRangeInput) {\\n  closed_orders(instrument_id: $instrument_id, status: $status, side: $side, pager: $pager, dateRange: $dateRange) {\\n    order_id\\n    type\\n    side\\n    status\\n    price\\n    quantity\\n    executed_quantity\\n    remaining_quantity\\n    quantity_mode\\n    instrument_id\\n    message\\n    updated_at\\n    created_at\\n    expires_at\\n  }\\n}","variables":{"pager":{"offset":0,"limit":10000}}}';
    unset($my_closed_orders_res);
    _log($email_address, "chuan bi (closed orders)....");
    $my_closed_orders_res = api_call('/api/v4/trade/orders/closed/', 0, $my_closed_orders_query , $tmp_dto_my_closed_orders_arr, $_auth_token);
    _log($email_address, "chuan bi xong (closed orders) :");
    $raw_res_body = json_encode($my_closed_orders_res);
    _log($email_address, "chuan bi ke tiep (closed orders) : " . $raw_res_body);
    _log($email_address, "db_order_id_arr = " . json_encode($db_order_id_arr));
    if (($my_closed_orders_res['http_code'] == "200") || ($my_closed_orders_res['http_code'] == "200 OK")) {
      if (is_array($my_closed_orders_res['result']['data']['closed_orders'])) {
        _log($email_address, "phat hien array (closed orders) " . count($my_closed_orders_res['result']['data']['closed_orders']));

        for ($order_cnt=0; $order_cnt<count($my_closed_orders_res['result']['data']['closed_orders']); $order_cnt++) {
          unset($target_order);
          $target_order = $my_closed_orders_res['result']['data']['closed_orders'][$order_cnt];
          if (isset($target_order)) {

            if (  (isset($target_order['order_id'])) && (isset($target_order['type'])) && (isset($target_order['instrument_id']))  && (isset($target_order['quantity']))  ) {
              _log($email_address, $target_order['order_id'] . ", " . $target_order['type'] . ", " . $target_order['instrument_id'] . ", " . $target_order['quantity']);
              ///////////////////////////////////////////////////////////
              if (!in_array(trim($target_order['order_id']), $db_order_id_arr)) {

                if ($target_order['type'] == 'market') {
                  unset($tx_item);
                  $tx_item = array();
                  $tx_item['type'] = "Exchange";
                  $found_instrument = 0;
                  $tx_item['instrument_id'] = $target_order['instrument_id'];

                  if ($target_order['instrument_id'] == 'BTCUSD') {
                    $tx_item['currency'] = 'BTC';
                    $found_instrument = 1;
                  } else if ($target_order['instrument_id'] == 'USDTUSD') {
                    $tx_item['currency'] = 'USDT';
                    $found_instrument = 1;
                  } else if ($target_order['instrument_id'] == 'USDCUSD') {
                    $tx_item['currency'] = 'USDC';
                    $found_instrument = 1;
                  }
                  $tx_item['amount'] = $target_order['quantity'];

                  if ($target_order['side'] == 'sell') {
                    $tx_item['side'] = 'Sell';
                  } else if ($target_order['side'] == 'buy'){
                    $tx_item['side'] = 'Buy';
                  }

                  if (!is_null($target_order['created_at'])) {
                    $tx_item['created_date'] = date('Y/m/d H:i:s', ($target_order['created_at'] / 1000) - 32400);
                  }
                  if (!is_null($target_order['updated_at'])) {
                    $tx_item['updated_date'] = date('Y/m/d H:i:s', ($target_order['updated_at'] / 1000) - 32400);
                  }
                  if (!is_null($target_order['order_id'])) {
                    $tx_item['order_id'] = $target_order['order_id'];
                  }

                  if ($found_instrument == 1) {
                    _log($email_address, "found_instrument cho " . $target_order['order_id']);
                    $tx_history_usd_amount = 0;
                    if (($target_order['status'] == 'completed') || ($target_order['status'] == 'completely_filled') || ($target_order['status'] == 'partially_filled')) {
                      if ($target_order['side'] == 'sell') {
                        $tx_history_usd_amount = format_fiat(number_format(decimal_notation($target_order['quantity']) * $target_order['price'], 10, '.', ','), 2);
                      } else if ($target_order['side'] == 'buy'){
                        $tx_history_usd_amount = format_fiat(number_format(decimal_notation($target_order['quantity']) * $target_order['price'], 10, '.', ','), 2);
                      }
                      //$tx_item[] = "<span style=\"font-weight: 900\">COMPLETED</span>";
                      $tx_item['tx_amount'] = $tx_history_usd_amount;
                      $tx_item['status'] = "COMPLETED";
                    } else if ($target_order['status'] == 'rejected') {
                      $tx_item['tx_amount'] = $tx_history_usd_amount;
                      $tx_item['status'] = "FAILED";
                    } else {
                      $tx_item['tx_amount'] = $tx_history_usd_amount;
                      $tx_item['status'] = "FAILED";
                    }
                    $my_closed_orders_arr[] = $tx_item;
                  }
                }

              } else {
                _log($email_address, "found in db : " . $target_order['order_id']);
              }
              ///////////////////////////////////////////////////////////

            } else {
              _log($email_address, "api call /api/v4//trade/orders/closed/ ERROR: all fields are empty");

            }

          } else {
            _log($email_address, "api call /api/v4/wallet/transaction/history ERROR: target_order is empty");

          }
        }
        $my_closed_orders_info['my_closed_orders'] = $my_closed_orders_arr;

      } else {
        _log($email_address, "api call //api/v4//trade/orders/closed/ERROR: is not array");
        $my_closed_orders_info['error'] = 'data.closed_orders_is_not_array';
        $my_closed_orders_info['raw_error'] = $raw_res_body;
      }


    } else {
      $my_closed_orders_info['error'] = 'ng_http_response_code';
      $my_closed_orders_info['raw_error'] = $raw_res_body;
      $my_closed_orders_info['http_code'] = $my_closed_orders_res['http_code'];
    }
    ///////////////////////////////////////////////////
    return $my_closed_orders_info;
  }

  if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {


    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!($data)) {

      switch (json_last_error()) {
        case JSON_ERROR_DEPTH:
          _log("", 'Reached the maximum stack depth');
          break;
        case JSON_ERROR_STATE_MISMATCH:
          _log("", 'Incorrect discharges or mismatch mode');
          break;
        case JSON_ERROR_CTRL_CHAR:
          _log("", 'Incorrect control character');
          break;
        case JSON_ERROR_SYNTAX:
          _log("", 'Syntax error or JSON invalid');
          break;
        case JSON_ERROR_UTF8:
          _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
          break;
        default:
          _log("", 'Unknown error');
          break;
      }

      _log("", 'A non-empty request body is required.');
      header('Content-Type: application/json');
      http_response_code(400);
      $ret_rs['result'] = 'failed';
      $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
      echo json_encode($ret_rs);
      die();

    } else {
      unset($errors);
      $errors = array();

      //email_address
      if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
        $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
        $errors[] = $error_obj;
      }
      //auth_token
      if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
        $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
        $errors[] = $error_obj;
      }

      if (count($errors) == 0) {
        $errors_sub = array();
        require_once '../include/common.php';
        ////////////////////////////////////////////////////
        //receive POST params
        $email_address = mysqli_real_escape_string($dbhandle, trim($data['email_address']));
        $private_key = mysqli_real_escape_string($dbhandle, trim($data['auth_token']));
        $report_type = mysqli_real_escape_string($dbhandle, trim($data['type']));
        $status = mysqli_real_escape_string($dbhandle, trim($data['status']));
        $currency = mysqli_real_escape_string($dbhandle, strtoupper(trim($data['currency'])));
        $report_type_arr = explode(",", $report_type);
        $status_arr = explode(",", $status);
        $currency_arr = explode(",", $currency);

        for($i = 0; $i < count($report_type_arr); ++$i) {
          $report_type_arr[$i] = trim($report_type_arr[$i]);
          if($report_type_arr[$i] == 1){
            $report_type_arr[$i] = "deposit";
          }else if($report_type_arr[$i] == 2){
            $report_type_arr[$i] = "withdrawal";
          }else if($report_type_arr[$i] == 3){
            $report_type_arr[$i] = "Exchange";
          }
        }
        _log($email_address, $report_type);
        _log($email_address, json_encode($report_type_arr));
        for($i = 0; $i < count($status_arr); ++$i) {
          $status_arr[$i] = trim($status_arr[$i]);
          if($status_arr[$i] == 1){
            $status_arr[$i] = "COMPLETED";
          }else if($status_arr[$i] == 2){
            $status_arr[$i] = "FAILED";
          }else if($status_arr[$i] == 3){
            $status_arr[$i] = "NEW";
          }else if($status_arr[$i] == 4){
            $status_arr[$i] = "PENDING";
          }
        }
        for($i = 0; $i < count($currency_arr); ++$i) {
          $currency_arr[$i] = trim($currency_arr[$i]);
        }

        $allow_access_api = 0;

        $my_db_private_key = '';
        $my_db_auth_token = '';
        $sql_check_signin = "select a.* from cryptocash_merchant_user_signin a, cryptocash_shift_user_ids b where a.email_address = '$email_address' AND a.merchant='" . $req_partner['partner'] . "' AND a.email_address = b.shift_email_address";
        //_log($sql_check_signin);
        $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
        if (mysqli_num_rows($rs_check_signin) == 1) { //allow access API
          $allow_access_api = 1;
          while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
            $my_db_private_key = trim($row_signin['private_key']);
            $my_db_auth_token = trim($row_signin['auth_token']);
          }
        }

        if ($allow_access_api == 1) {
          if ($private_key != $my_db_private_key) {
            @mysqli_close($dbhandle);
            header('Content-Type: application/json');
            http_response_code(500);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 6, 'errorMessage' => 'Unauthorized.');
            echo json_encode($ret_rs);
            die();
          } else {
            $db_order_id_arr = array();
            $tx_history_ret_arr = array();
            $authorization_value = "Bearer " . $my_db_auth_token;
            /////////////////////////////////////////////////////////////////////////////
            //get wallet transaction history list
            $my_wallet_transaction_history = get_wallet_transaction_history($authorization_value);
            if ($my_wallet_transaction_history['error'] != '') {
              if ($my_wallet_transaction_history['error'] == 'ng_http_response_code') {
                $error_message = 'Unauthorized';
                $res_code = 200;
                $error_code = 5;
                if (($my_wallet_transaction_history['http_code'] == "401") || ($my_wallet_transaction_history['http_code'] == "401 Unauthorized")) {
                  _log($email_address, "/api/v4/wallet/transaction/history error " . $my_wallet_transaction_history['http_code']);
                  $res_code = 401;
                } else {
                  if (($my_wallet_transaction_history['http_code'] == "500") || ($my_wallet_transaction_history['http_code'] == "500 Internal Server Error") || ($my_wallet_transaction_history['http_code'] == "503 Service Unavailable")) {
                    if ($my_wallet_transaction_history['http_code'] == "503 Service Unavailable") {
                      $error_code = 6;
                      $error_message = 'system is under maintenance.';
                      $res_code = 503;
                    }
                    if (($my_wallet_transaction_history['http_code'] == "500") || ($my_wallet_transaction_history['http_code'] == "500 Internal Server Error")) {
                      $res_code = 401;
                    }

                    _log($email_address, "/api/v4/wallet/transaction/history error " . $my_wallet_transaction_history['http_code']);
                  } else {
                    _log($email_address, "/api/v4/wallet/transaction/history error unknown error code");
                    $error_code = 6;
                    $error_message = 'system is under maintenance fuck you !.';
                    $res_code = 500;
                  }
                }
                @mysqli_close($dbhandle);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
                header('Content-Type: application/json');
                if ($res_code != 200) {
                  http_response_code($res_code);
                }
                echo json_encode($ret_rs);
                die();
              } else if ($my_wallet_transaction_history['error'] == 'data.payments_is_not_array') {
                _log($email_address, "/api/v4/wallet/transaction/history ERROR: is not array");
                @mysqli_close($dbhandle);
                header('Content-Type: application/json');
                http_response_code(500);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'error occurred. please contact administrator for help.');
                echo json_encode($ret_rs);
                die();
              }
            } else {
              $my_wallet_transactions_from_api = $my_wallet_transaction_history['wallet_transction_history_list'];
              if (count($my_wallet_transactions_from_api) > 0) {
                for ($u=0; $u<count($my_wallet_transactions_from_api); $u++) {
                  $tx_history_ret_arr[] = $my_wallet_transactions_from_api[$u];
                }
              }

              //get old deposit history (before v.4)
              if ($req_partner['partner'] == 'XEXON') {
                $allowed_coins = array("BTC", "USDT");
              } else if ($req_partner['partner'] == 'BOS') {
                $allowed_coins = array("BTC", "USDT", "USDC");
              }
              $sql_wallet_tx_history = "SELECT * from cryptocash_wallet_transaction_history WHERE email_address='$email_address' ORDER BY created_dt DESC";
              $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
              if (mysqli_connect_errno() == 0) {
                mysqli_query($dbhandle, "set names utf8;");

                $rs_wallet_tx_history = mysqli_query($dbhandle, $sql_wallet_tx_history);
                while ($row_wallet_tx_history = mysqli_fetch_array($rs_wallet_tx_history, MYSQLI_ASSOC)) {
                  if (in_array($row_wallet_tx_history['coin'], $allowed_coins)) {

                    if ($row_wallet_tx_history['transaction_type'] == 'deposit') {
                      $shift_tx_obj = array('payment_id' => 'old_deposit', 'status' => '', 'type' => 'deposit', 'currency' => '', 'address' => '', 'amount' => '', 'crypto_transaction_id' => '', 'created_date' => '', 'crypto_network' => '');//status
                      $shift_tx_obj['status'] = trim($row_wallet_tx_history['status']);
                      //currency_id
                      $shift_tx_obj['currency'] = strtoupper(trim($row_wallet_tx_history['coin']));
                      //amount
                      $shift_tx_obj['amount'] = $row_wallet_tx_history['amount'] + 0;
                      //created_at
                      $shift_tx_obj['created_date'] = str_replace("-","/", $row_wallet_tx_history['created_dt']);
                      //txid
                      $shift_tx_obj['txid'] = $row_wallet_tx_history['amount'];

                      if (floatval($shift_tx_obj['amount']) > 0)
                        $tx_history_ret_arr[] = $shift_tx_obj;

                    } else if ($row_wallet_tx_history['transaction_type'] == 'withdraw') {
                      //if (in_array($email_address, $people)) {
                      $shift_tx_obj = array('payment_id' => 'old_withdraw', 'status' => '', 'type' => 'withdrawal', 'currency' => '', 'address' => '', 'amount' => '', 'crypto_transaction_id' => '', 'created_date' => '', 'crypto_network' => '');//status
                      $shift_tx_obj['status'] = trim($row_wallet_tx_history['status']);
                      //currency_id
                      $shift_tx_obj['currency'] = strtoupper(trim($row_wallet_tx_history['coin']));
                      //amount
                      $shift_tx_obj['amount'] = $row_wallet_tx_history['amount'] + 0;
                      //address
                      $shift_tx_obj['address'] = $row_wallet_tx_history['withdraw_to_address'];
                      //created_at
                      $shift_tx_obj['created_date'] = str_replace("-","/", $row_wallet_tx_history['created_dt']);

                      $tx_history_ret_arr[] = $shift_tx_obj;
                    }
                  }
                }
              }
            }
            $my_used_sites = "'API_OLD', '" . $req_partner['partner'] . "'";
            $sql_closed_orders = "SELECT * from cryptocash_exchange_history WHERE email_address='$email_address' AND created_from IN ($my_used_sites)";

            $rs_closed_orders = mysqli_query($dbhandle, $sql_closed_orders);
            while ($row_closed_order = mysqli_fetch_array($rs_closed_orders, MYSQLI_ASSOC)) {

              if (trim($row_closed_order['shift_order_id']) != '') {
                $db_order_id_arr[] = trim($row_closed_order['shift_order_id']);
              }

              if (trim($row_closed_order['currency']) != '') {
                unset($tx_item);
                $tx_item = array();
                $tx_item['type'] = "Exchange";
                $tx_item['currency'] = trim($row_closed_order['currency']);
                $tx_item['amount'] = floatval($row_closed_order['amount']);
                $tx_item['tx_amount'] = floatval($row_closed_order['usd_amount']);
                if ($row_closed_order['type'] == 'sell') {
                  $tx_item['side'] = 'Sell';
                } else if ($row_closed_order['type'] == 'buy'){
                  $tx_item['side'] = 'Buy';
                }
                if (($row_closed_order['status'] == 'completely_filled') || ($row_closed_order['status'] == 'partially_filled')) {
                  $tx_item['status'] = "COMPLETED";
                } else if ($row_closed_order['status'] == 'rejected') {
                  $tx_item['status'] = "FAILED";
                }
                $tx_item['created_date'] = date('Y/m/d H:i:s', strtotime($row_closed_order['date']) - 32400); //change to UTC
                $tx_item['order_id'] = trim($row_closed_order['shift_order_id']);
                $tx_history_ret_arr[] = $tx_item;
              }
            }
            @mysqli_close($dbhandle);

            //get closed order list
            $my_closed_orders_history = get_my_closed_orders($authorization_value);
            if ($my_closed_orders_history['error'] != '') {
              if ($my_closed_orders_history['error'] == 'ng_http_response_code') {
                $error_message = 'Unauthorized';
                $res_code = 200;
                $error_code = 5;
                if (($my_closed_orders_history['http_code'] == "401") || ($my_closed_orders_history['http_code'] == "401 Unauthorized")) {
                  _log($email_address, "/api/v4//trade/orders/closed/ error " . $my_closed_orders_history['http_code']);
                  $res_code = 401;
                } else {
                  if (($my_closed_orders_history['http_code'] == "500") || ($my_closed_orders_history['http_code'] == "500 Internal Server Error") || ($my_closed_orders_history['http_code'] == "503 Service Unavailable")) {
                    //if (($statistics_res['http_code'] == "500") || ($statistics_res['http_code'] == "500 Internal Server Error")) {
                    //	$error_message = 'invalid auth_token';
                    //}
                    if ($my_closed_orders_history['http_code'] == "503 Service Unavailable") {
                      $error_code = 6;
                      $error_message = 'system is under maintenance.';
                      $res_code = 503;
                    }
                    if (($my_closed_orders_history['http_code'] == "500") || ($my_closed_orders_history['http_code'] == "500 Internal Server Error")) {
                      $res_code = 401;
                    }

                    _log($email_address, "/api/v4//trade/orders/closed/ error " . $my_closed_orders_history['http_code']);
                  } else {
                    _log($email_address, "/api/v4//trade/orders/closed/ error unknown error code");
                    $error_code = 6;
                    $error_message = 'system is under maintenance fuck you !.';
                    $res_code = 500;
                  }
                }
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
                header('Content-Type: application/json');
                if ($res_code != 200) {
                  http_response_code($res_code);
                }
                echo json_encode($ret_rs);
                die();
              } else if ($my_closed_orders_history['error'] == 'data.closed_orders_is_not_array') {
                _log($email_address, "/api/v4//trade/orders/closed/ ERROR: is not array");
                @mysqli_close($dbhandle);
                header('Content-Type: application/json');
                http_response_code(500);
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'error occurred. please contact administrator for help.');
                echo json_encode($ret_rs);
                die();
              }
            } else {
              $closed_orders_from_api = $my_closed_orders_history['my_closed_orders'];
              _log($email_address, "tong so closed order = " . count($closed_orders_from_api));
              if (count($closed_orders_from_api) > 0) {
                for ($v=0; $v<count($closed_orders_from_api); $v++) {
                  $tx_history_ret_arr[] = $closed_orders_from_api[$v];
                }
              }
            }

            //old code here...
            if ($report_type) {
              $tx_history_ret_arr = array_filter($tx_history_ret_arr, function($item) use ($report_type_arr) {
                return in_array($item['type'], $report_type_arr);
              });
              $tx_history_ret_arr = array_values($tx_history_ret_arr);
            }
            if ($status) {
              $tx_history_ret_arr = array_filter($tx_history_ret_arr, function($item) use ($status_arr) {
                return in_array($item['status'], $status_arr);
              });
              $tx_history_ret_arr = array_values($tx_history_ret_arr);
            }
            if ($currency) {
              $tx_history_ret_arr = array_filter($tx_history_ret_arr, function($item) use ($currency_arr) {
                return in_array($item['currency'], $currency_arr);
              });
              $tx_history_ret_arr = array_values($tx_history_ret_arr);
            }

            $dates = array_column($tx_history_ret_arr, 'created_date');
            array_multisort($dates, SORT_DESC, $tx_history_ret_arr);

            $ret_rs['result'] = 'success';
            $ret_rs['email_address'] = $email_address;
            $ret_rs['reportResponse'] = $tx_history_ret_arr;
            echo json_encode($ret_rs);
            die();
            /////////////////////////////////////////////////////////////////////////////
          }
        } else {
          @mysqli_close($dbhandle);
          header('Content-Type: application/json');
          http_response_code(500);
          $ret_rs['result'] = 'failed';
          $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'you must sign in to use this API.');
          echo json_encode($ret_rs);
          die();
        }
      } else {
        @mysqli_close($dbhandle);
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = $errors;
        header('Content-Type: application/json');
        echo json_encode($ret_rs);
        die();
      }
    }
  } else {
    @mysqli_close($dbhandle);
    header('HTTP/1.0 403 Forbidden');
    die();
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
  http_response_code(405);
  die();
}
?>