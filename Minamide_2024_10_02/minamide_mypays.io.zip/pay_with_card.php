<?php
global $baseUrl;
include 'includes/header.php';
?>
<!-- Necessary js start-->
<script src="<?php echo $baseUrl; ?>assets/js/auth.js"></script>
<!-- Necessary js end -->

<!-- Container start -->
<div class="main-content container d-flex justify-content-center">
  <div class="col-md-6 col-lg-6">
    <h3 class="text-center mt-4 mb-4">Pay With Card</h3>

    <!-- Start pay section -->
    <div class="card blue-boarder mt-4 mb-4">
      <div class="card-header bg-primary-opacity">
        <div class="panel-list">
          <div class="panel-list-left font-weight-bold fs-6">
            Purchase USDT
          </div>
        </div>
      </div>

      <div class="card-body justify-content-center align-content-center">
        <form id="payForm" novalidate>
          <div class="form-group">
            <label for="amount" class="form-label">Amount <span class="text-red">*</span></label>
            <input type="text" class="form-control" id="amount" name="amount" placeholder="Enter amount" required>
            <div class="invalid-feedback">
              Amount required.
            </div>
          </div>
          <div class="form-group">
            <label for="product_name" class="form-label">Product Name <span class="text-red">*</span></label>
            <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Enter product name" required>
            <div class="invalid-feedback">
              Product name required.
            </div>
          </div>
          <div class="form-group">
            <label for="email" class="form-label">Email Address <span class="text-red">*</span></label>
            <input type="text" class="form-control" id="email" name="email" placeholder="Enter email address" required>
            <div class="invalid-feedback">
              Email address required.
            </div>
          </div>
          <div class="form-group">
            <label for="name" class="form-label">Name <span class="text-gray">(optional)</span></label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Enter name of user">
          </div>
          <div class="text-center">
            <button class="btn btn-primary" type="submit" id="btnPay">
              <span class="spinner-anim spinner-border spinner-border-sm text-white" role="status" style="display: none"></span>
              <i class="fa fa-credit-card-alt"></i>&nbsp
              <span class="spinner-text">Pay with Card</span>
            </button>
          </div>
        </form>
      </div>
    </div>
    <!-- End pay section -->
  </div>
</div>
<!-- Container end -->

<script>
  $(document).ready(function() {

    $('#payForm').on('submit', function(event) {
      event.preventDefault();

      // Validation
      const form = $(this);
      if (this.checkValidity() === false) {
        event.stopPropagation();
        form.addClass('was-validated');
        return;
      }

      // Perform AJAX submission
      disableWithSpinner('btnPay', 'Please wait...');
      let email = $('#email').val();
      let amount = $('#amount').val();
      let product_name = $('#product_name').val();
      let name = $('#name').val();
      $.ajax({
        url: API_URL + 'kaiserApi.php',
        type: 'POST',
        data: JSON.stringify({
          action: 'prepayment',
          amount: amount,
          product_name: product_name,
          email: email,
          name: name,
        }),
        contentType: 'application/json',
        success: function(response) {
          const respData = JSON.parse( response );
          if (respData.success === true) {
            window.location.href = respData.body;
          } else {
            showToast(respData.message + respData.body);
            enableWithSpinner('btnPay', 'Pay with Card');
          }
        },
        error: function(error) {
          console.log('An error occurred:', error);
          enableWithSpinner('btnPay', 'Pay with Card');
        }
      });
    });
  });
</script>
<?php include 'includes/footer.php'; ?>
