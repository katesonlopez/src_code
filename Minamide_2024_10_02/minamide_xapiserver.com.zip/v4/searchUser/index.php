<?php

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
ini_set('memory_limit','200M');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
		
	//global $fh;
	if ($email == "") {
		$fh2 = fopen(dirname(__FILE__) . "/log/search_user.log" , 'a');
	} else {
		$fh2 = fopen(dirname(__FILE__) . "/log/" . $email . ".log" , 'a');
	}		
	$fline = date('[Ymd H:i:s] ') . $line."\n";
	fwrite($fh2, $fline);
	fclose($fh2);
	//echo date('[Ymd H:i:s] ').$line."\n";
	//@ob_flush(); 
	//flush();
	
}
	
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$partner = "";
	$allowed_deposit_currency_arr = array('USDT');
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	
	foreach (getallheaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			/*
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_freelancer) {
				$found = 7;
				$coin = 'USDT';
				$partner = "UltimoCasino";
				break;
			} else if ($value == $apikey_bos) {
				$found = 8;
				$coin = 'USDT';
				$partner = "BOS";
				break;
			}
			*/
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
					
				}
			} else {
				_log("", "not found in db");
			}
		}
	}
	//@mysqli_close($dbhandle);
	

	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}


	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	//_log("bat dau xu ly...");
	//if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==6) || ($found==7) || ($found==8)) {
	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

		
		
		//$failed_rs = array('result' => 'failed', 'errorMessage' => 'A non-empty request body is required.', 'errorCode' => 1);
		
		//echo "apikey accepted<br/>go ahead to check content...<br/>------------------------<br/>";
		//echo "payment_id: " . $payment_id . "<br/>";
		$json = file_get_contents('php://input');
		if (!empty($json)) {
			$data = json_decode($json, true);
			if (!($data)) {
			
				switch (json_last_error()) {
					case JSON_ERROR_DEPTH:
						//$failed_rs['error'] = 'Reached the maximum stack depth';
						_log("", 'Reached the maximum stack depth');
						break;
					case JSON_ERROR_STATE_MISMATCH:
						//$failed_rs['error'] = 'Incorrect discharges or mismatch mode';
						_log("", 'Incorrect discharges or mismatch mode');
						break;
					case JSON_ERROR_CTRL_CHAR:
						//$failed_rs['error'] = 'Incorrect control character';
						_log("", 'Incorrect control character');
						break;
					case JSON_ERROR_SYNTAX:
						//$failed_rs['error'] = 'Syntax error or JSON invalid';
						_log("", 'Syntax error or JSON invalid');
						break;
					case JSON_ERROR_UTF8:
						//$failed_rs['error'] = 'Invalid UTF-8 characters, possibly invalid encoding';
						_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
						break;
					default:
						//$failed_rs['error'] = 'Unknown error';
						_log("", 'Unknown error');
						break;
				}
				
				
				//throw new Exception($error);
				//_log($failed_rs['error']);
				_log("", 'A non-empty request body is required.');
				header('Content-Type: application/json');
				http_response_code(500);
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'invalid JSON request data');
				echo json_encode($ret_rs);
				die();

				
				
			}
		}
		
		
		
		
			/*
			unset($errors);
			$errors = array();
			
			//email
			if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
				$errors[] = $error_obj;
			}
			
			
			//auth_token
			if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
				$error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
				$errors[] = $error_obj;
			}
			*/
			
						
			
			//if (count($errors) == 0) {
				
								
				//proceed to shift api
				require_once '../include/common.php';
				//require_once '../include/dbconfig.php';
				
				////////////////////////////////////////////////////
				_log("", "search user started...");
				//$filters = array('email_address' => '', 'bank_account_number' => '', 'card_number' => '', 'cellphone_number' => '');
				//gender
				$filters = array();
				//status
				if (!empty($data['status'])) {
					$filters['status'] = trim($data['status']);
				}
				if (!empty($data['payment_status'])) {
					$filters['payment_status'] = trim($data['payment_status']);
				}
				if (!empty($data['title'])) {
					$filters['title'] = trim($data['title']);
				}
				//full name
				if (!empty($data['full_name'])) {
					$filters['full_name'] = trim($data['full_name']);
				}
				//email
				if (!empty($data['email_address'])) {
					$filters['email_address'] = trim($data['email_address']);
				}
				//marriage_status
				if (!empty($data['marriage_status'])) {
					$filters['marriage_status'] = trim($data['marriage_status']);
				}
				//occupation
				if (!empty($data['occupation'])) {
					$filters['occupation'] = trim($data['occupation']);
				}
				//nationality
				if (!empty($data['nationality'])) {
					$filters['nationality'] = trim($data['nationality']);
				}
				//birthday
				if (!empty($data['birthday'])) {
					$tmp_birthday = trim($data['birthday']);
					if (strpos($tmp_birthday, "/") !== false) {
						$filters['birthday'] = str_replace("/", "-", $tmp_birthday);
					} else {
						$filters['birthday'] = $tmp_birthday;
					}
				}
				//id card number
				if (!empty($data['id_card_number'])) {
					$filters['id_card_number'] = trim($data['id_card_number']);
				}
				//id card type
				if (!empty($data['id_card_type'])) {
					$filters['id_card_type'] = trim($data['id_card_type']);
					if (intval($filters['id_card_type'])==1) {
						$filters['id_card_type'] = "passport";
					} else if (intval($filters['id_card_type'])==2) {
						$filters['id_card_type'] = "driving_license";
					}
				}
				//id card issued date
				if (!empty($data['id_card_issued_date'])) {
					$tmp_id_card_issued_date = trim($data['id_card_issued_date']);
					if (strpos($tmp_id_card_issued_date, "/") !== false) {
						$filters['id_card_issued_date'] = str_replace("/", "-", $tmp_id_card_issued_date);
					} else {
						$filters['id_card_issued_date'] = $tmp_id_card_issued_date;
					}
				}
				//id card expired date
				if (!empty($data['id_card_expired_date'])) {
					$tmp_id_card_expired_date = trim($data['id_card_expired_date']);
					if (strpos($tmp_id_card_expired_date, "/") !== false) {
						$filters['id_card_expired_date'] = str_replace("/", "-", $tmp_id_card_expired_date);
					} else {
						$filters['id_card_expired_date'] = $tmp_id_card_expired_date;
					}
				}
				//id card issuer
				if (!empty($data['id_card_issuer'])) {
					$filters['id_card_issuer'] = trim($data['id_card_issuer']);
				}
				//residence address
				if (!empty($data['residence_address'])) {
					$filters['residence_address'] = trim($data['residence_address']);
				}
				//city
				if (!empty($data['city'])) {
					$filters['city'] = trim($data['city']);
				}
				//prefecture
				if (!empty($data['prefecture'])) {
					$filters['prefecture'] = trim($data['prefecture']);
				}
				//postal code
				if (!empty($data['postal_code'])) {
					$filters['postal_code'] = trim($data['postal_code']);
				}
				//country
				if (!empty($data['country'])) {
					$filters['country'] = trim($data['country']);
				}
				//bank_account_number
				if (!empty($data['bank_account_number'])) {
					$filters['bank_account_number'] = trim($data['bank_account_number']);
				}		
				//card_number
				if (!empty($data['card_number'])) {
					$filters['card_number'] = trim($data['card_number']);
				}
				//cellphone_number
				if (!empty($data['cellphone_number'])) {
					$filters['cellphone_number'] = trim($data['cellphone_number']);
				}
				//signup_from_date
				if (!empty($data['signup_from_date'])) {
					$tmp_signup_from_date = trim($data['signup_from_date']);
					if (strpos($tmp_signup_from_date, "/") !== false) {
						$filters['signup_from_date'] = str_replace("/", "-", $tmp_signup_from_date);
					} else {
						$filters['signup_from_date'] = $tmp_signup_from_date;
					}
				}
				//signup_to_date
				if (!empty($data['signup_to_date'])) {
					$tmp_signup_to_date = trim($data['signup_to_date']);
					if (strpos($tmp_signup_to_date, "/") !== false) {
						$filters['signup_to_date'] = str_replace("/", "-", $tmp_signup_to_date);
					} else {
						$filters['signup_to_date'] = $tmp_signup_from_date;
					}
				}
				//kyc_request_from_date
				if (!empty($data['kyc_request_from_date'])) {
					$tmp_kyc_request_from_date = trim($data['kyc_request_from_date']);
					if (strpos($tmp_kyc_request_from_date, "/") !== false) {
						$filters['kyc_request_from_date'] = str_replace("/", "-", $tmp_kyc_request_from_date);
					} else {
						$filters['kyc_request_from_date'] = $tmp_kyc_request_from_date;
					}
				}
				//kyc_request_to_date
				if (!empty($data['kyc_request_to_date'])) {
					$tmp_kyc_request_to_date = trim($data['kyc_request_to_date']);
					if (strpos($tmp_signup_to_date, "/") !== false) {
						$filters['kyc_request_to_date'] = str_replace("/", "-", $tmp_kyc_request_to_date);
					} else {
						$filters['kyc_request_to_date'] = $tmp_kyc_request_to_date;
					}
				}
				//bank_card_issued_from_date
				if (!empty($data['bank_card_issued_from_date'])) {
					$tmp_bank_card_issued_from_date = trim($data['bank_card_issued_from_date']);
					if (strpos($tmp_bank_card_issued_from_date, "/") !== false) {
						$filters['bank_card_issued_from_date'] = str_replace("/", "-", $tmp_bank_card_issued_from_date);
					} else {
						$filters['bank_card_issued_from_date'] = $tmp_bank_card_issued_from_date;
					}
				}
				//bank_card_issued_to_date
				if (!empty($data['bank_card_issued_to_date'])) {
					$tmp_bank_card_issued_to_date = trim($data['bank_card_issued_to_date']);
					if (strpos($tmp_bank_card_issued_to_date, "/") !== false) {
						$filters['bank_card_issued_to_date'] = str_replace("/", "-", $tmp_bank_card_issued_to_date);
					} else {
						$filters['bank_card_issued_to_date'] = $tmp_bank_card_issued_to_date;
					}
				}
				//card was activated from date
				if (!empty($data['card_was_activated_from_date'])) {
					$tmp_card_was_activated_from_date = trim($data['card_was_activated_from_date']);
					if (strpos($tmp_card_was_activated_from_date, "/") !== false) {
						$filters['card_was_activated_from_date'] = str_replace("/", "-", $tmp_card_was_activated_from_date);
					} else {
						$filters['card_was_activated_from_date'] = $tmp_card_was_activated_from_date;
					}
				}
				//card was activated to date
				if (!empty($data['card_was_activated_to_date'])) {
					$tmp_card_was_activated_to_date = trim($data['card_was_activated_to_date']);
					if (strpos($tmp_card_was_activated_to_date, "/") !== false) {
						$filters['card_was_activated_to_date'] = str_replace("/", "-", $tmp_card_was_activated_to_date);
					} else {
						$filters['card_was_activated_to_date'] = $tmp_card_was_activated_from_date;
					}
				}
				//all actions last updated date from
				if (!empty($data['updated_on_from_date'])) {
					$tmp_updated_on_from_date = trim($data['updated_on_from_date']);
					if (strpos($tmp_updated_on_from_date, "/") !== false) {
						$filters['updated_on_from_date'] = str_replace("/", "-", $tmp_updated_on_from_date);
					} else {
						$filters['updated_on_from_date'] = $tmp_updated_on_from_date;
					}
				}
				//all actions last updated date to
				if (!empty($data['updated_on_to_date'])) {
					$tmp_updated_on_to_date = trim($data['updated_on_to_date']);
					if (strpos($tmp_updated_on_to_date, "/") !== false) {
						$filters['updated_on_to_date'] = str_replace("/", "-", $tmp_updated_on_to_date);
					} else {
						$filters['updated_on_to_date'] = $tmp_updated_on_to_date;
					}
				}
				//bank card provider
				if (!empty($data['bank_card_provider'])) {
					$filters['bank_card_provider'] = trim($data['bank_card_provider']);
				}
				//$post_data = array();
				//$post_data['exchange'] = "PLUSQO";
				//$post_data['refreshToken'] = $auth_refresh_token;
								
				//$refresh_token_res = api_call('/authentication/user_authentication/refreshAccessToken', 0, '', $post_data, '');
				//if ($refresh_token_res['result']['result'] == 'success') {
					
					//$signin_user_data = array();
					
					//$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
					//if (mysqli_connect_errno() == 0) {
						//mysqli_query($dbhandle, "set names utf8;");
						$allow_access_api = 0;
						
						
						
								_log("", "vao toi day rui");
								$user_info_arr = array();
								$where_query = "";
								$user_type = "";
								//////////////////////////////////////////////////////////////////////////////////////////
								//$sql_user_info = "SELECT * from (SELECT a.email as shift_email, a.given_name, a.sur_name, a.middle_name, a.country as shift_country, a.add_dt as shift_add_dt, a.shift_update_dt, a.admin_update_dt, a.kyc_upload_dt, a.admin_action, a.admin_process_kyc_dt, a.admin_process_card_activate_dt, a.admin_process_card_load_dt, a.affiliation, a.created_from, b.*, c.debit_card_id, c.acc_no, c.debit_card_num, c.debit_card_name, c.status as card_status, c.has_paid_fee, c.payment_method, c.amount_fee_fiat, c.amount_fee_crypto, c.has_sent_document_postal, c.activation_deny_message, c.card_issuance_deny_message, c.secondary_address, c.secondary_country, c.secondary_district, c.secondary_province, c.secondary_postal_code, c.card_provider, c.selfie_with_card_file, c.send_data_step_one, c.send_data_step_two, c.card_active_local_approved, c.card_selfie_uploaded FROM cryptocash_users_profile a LEFT JOIN cryptocash_jdb_profile b ON a.email = b.email_address LEFT JOIN cryptocash_jdb_debit_card c ON b.profile_id = c.profile_id ORDER BY a.shift_update_dt DESC) AS dataset WHERE dataset.shift_email='$reg_email_address' ORDER BY dataset.shift_update_dt DESC LIMIT 1";
								
								$sql_signup_head = "SELECT * from (SELECT a.email as shift_email, a.given_name, a.sur_name, a.middle_name, a.country as shift_country, a.add_dt as shift_add_dt, a.shift_update_dt, a.admin_update_dt, a.kyc_upload_dt, a.admin_action, a.admin_process_kyc_dt, a.admin_process_card_activate_dt, a.admin_process_card_load_dt, a.affiliation, a.created_from as created_from_one, b.*, c.debit_card_id, c.acc_no, c.debit_card_num, c.debit_card_name, c.status as card_status, c.has_paid_fee, c.payment_method, c.amount_fee_fiat, c.amount_fee_crypto, c.has_sent_document_postal, c.activation_deny_message, c.card_issuance_deny_message, c.secondary_address, c.secondary_country, c.secondary_district, c.secondary_province, c.secondary_postal_code, c.card_provider, c.selfie_with_card_file, c.send_data_step_one, c.send_data_step_two, c.card_active_local_approved, c.card_selfie_uploaded FROM cryptocash_users_profile a LEFT JOIN cryptocash_jdb_profile b ON ((a.email = b.email_address) AND (a.created_from = b.created_from)) LEFT JOIN cryptocash_jdb_debit_card c ON ((b.profile_id = c.profile_id) AND (b.created_from = c.created_from)) ORDER BY a.shift_update_dt DESC) AS dataset ";
								
								if (!empty($filters['payment_status'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.has_paid_fee='" . $filters['payment_status'] . "'";
									} else  {
										$where_query  .= " dataset.has_paid_fee='" . $filters['payment_status'] . "'";
									}
								}
								if (!empty($filters['title'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.gender='" . $filters['title'] . "'";
									} else  {
										$where_query  .= " dataset.gender='" . $filters['title'] . "'";
									}
								}
								if (!empty($filters['full_name'])) {
									if ($where_query != "") {
										$where_query  .= " AND ((dataset.name_romaji LIKE '%" . $filters['full_name'] . "%') OR (dataset.shift_full_name LIKE '%" . $filters['full_name'] . "%'))";
									} else  {
										$where_query  .= " ((dataset.name_romaji LIKE '%" . $filters['full_name']. "%') OR (dataset.shift_full_name LIKE '%" . $filters['full_name'] . "%'))";
									}
								}								
								if (!empty($filters['email_address'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.shift_email LIKE '%" . $filters['email_address'] . "%'";
									} else  {
										$where_query  .= " dataset.shift_email LIKE '%" . $filters['email_address'] . "%'";
									}
								}
								if (!empty($filters['marriage_status'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.marriage_status='" . $filters['marriage_status'] . "'";
									} else  {
										$where_query  .= " dataset.marriage_status='" . $filters['marriage_status'] . "'";
									}
								}
								if (!empty($filters['occupation'])) {
									if (strtolower($filters['occupation']) == "other") { 
										if ($where_query != "") {
											$where_query  .= " AND dataset.occupation NOT IN ('CEO', 'Director', 'Employee', 'Housewife', 'Student')";
										} else  {
											$where_query  .= " dataset.occupation NOT IN ('CEO', 'Director', 'Employee', 'Housewife', 'Student')";
										}
									} else {
										if ($where_query != "") {
											$where_query  .= " AND dataset.occupation LIKE '%" . $filters['occupation'] . "%'";
										} else  {
											$where_query  .= " dataset.occupation LIKE '%" . $filters['occupation'] . "%'";
										}
									}
								}
								if (!empty($filters['nationality'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.nationality = '" . $filters['nationality'] . "'";
									} else  {
										$where_query  .= " dataset.nationality = '" . $filters['nationality'] . "'";
									}
								}
								if (!empty($filters['birthday'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.date_of_birth = '" . $filters['birthday'] . "'";
									} else  {
										$where_query  .= " dataset.date_of_birth = '" . $filters['birthday'] . "'";
									}
								}
								if (!empty($filters['id_card_number'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.id_card_number LIKE '%" . $filters['id_card_number'] . "%'" ;
									} else  {
										$where_query  .= " dataset.id_card_number LIKE '%" . $filters['id_card_number'] . "%'" ;
									}
								}
								if (!empty($filters['id_card_type'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.id_card_type LIKE '%" . $filters['id_card_type'] . "%'" ;
									} else  {
										$where_query  .= " dataset.id_card_type LIKE '%" . $filters['id_card_type'] . "%'" ;
									}
								}
								if (!empty($filters['id_card_issued_date'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.id_card_issued_dt = '" . $filters['id_card_issued_date'] . "'";
									} else  {
										$where_query  .= " dataset.id_card_issued_dt = '" . $filters['id_card_issued_date'] . "'";
									}
								}
								if (!empty($filters['id_card_expired_date'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.id_card_expired_dt = '" . $filters['id_card_expired_date'] . "'";
									} else  {
										$where_query  .= " dataset.id_card_expired_dt = '" . $filters['id_card_expired_date'] . "'";
									}
								}
								if (!empty($filters['id_card_issuer'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.id_card_issuer = '" . $filters['id_card_issuer'] . "'";
									} else  {
										$where_query  .= " dataset.id_card_issuer = '" . $filters['id_card_issuer'] . "'";
									}
								}
								if (!empty($filters['residence_address'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.residence_address LIKE '%" . $filters['residence_address'] . "%'";
									} else  {
										$where_query  .= " dataset.residence_address LIKE '%" . $filters['residence_address'] . "%'";
									}
								}
								if (!empty($filters['city'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.district LIKE '%" . $filters['city'] . "%'";
									} else  {
										$where_query  .= " dataset.district LIKE '%" . $filters['city'] . "%'";
									}
								}
								if (!empty($filters['prefecture'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.province LIKE '%" . $filters['prefecture'] . "%'";
									} else  {
										$where_query  .= " dataset.province LIKE '%" . $filters['prefecture'] . "%'";
									}
								}
								if (!empty($filters['postal_code'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.postal_code LIKE '%" . $filters['postal_code'] . "%'";
									} else  {
										$where_query  .= " dataset.postal_code LIKE '%" . $filters['postal_code'] . "%'";
									}
								}
								if (!empty($filters['country'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.country = '" . $filters['country'] . "'";
									} else  {
										$where_query  .= " dataset.country = '" . $filters['country'] . "'";
									}
								}
								
								if (!empty($filters['cellphone_number'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.cellphone_number LIKE '%" . $filters['cellphone_number'] . "%'";
									} else  {
										$where_query  .= " dataset.cellphone_number LIKE '%" . $filters['cellphone_number'] . "%'";
									}
								}
								
								//sign up date								
								if ((!empty($filters['signup_from_date'])) && (!empty($filters['signup_to_date']))) {
									if ($where_query != "") {
										$where_query  .= " AND date(dataset.shift_add_dt) >= '" . $filters['signup_from_date'] . "' AND date(dataset.shift_add_dt) <= '" . $filters['signup_to_date'] . "'";
									} else  {
										$where_query  .= " date(dataset.shift_add_dt) >= '" . $filters['signup_from_date'] . "' AND date(dataset.shift_add_dt) <= '" . $filters['signup_from_date'] . "'";
									}
								} else {
									if (!empty($filters['signup_from_date'])) {
										if ($where_query != "") {
											$where_query  .= " AND date(dataset.shift_add_dt) >= '" . $filters['signup_from_date'] . "'";
										} else  {
											$where_query  .= " date(dataset.shift_add_dt) >= '" . $filters['signup_from_date'] . "'";
										}
									} else if (!empty($filters['signup_to_date'])) {
										if ($where_query != "") {
											$where_query  .= " AND date(dataset.shift_add_dt) <= '" . $filters['signup_to_date'] . "'";
										} else  {
											$where_query  .= " date(dataset.shift_add_dt) <= '" . $filters['signup_to_date'] . "'";
										}
									}
								}
								
								//kyc request date								
								if ((!empty($filters['kyc_request_from_date'])) && (!empty($filters['kyc_request_to_date']))) {
									if ($where_query != "") {
										$where_query  .= " AND date(dataset.kyc_upload_dt) >= '" . $filters['kyc_request_from_date'] . "' AND date(dataset.kyc_upload_dt) <= '" . $filters['kyc_request_to_date'] . "'";
									} else  {
										$where_query  .= " date(dataset.kyc_upload_dt) >= '" . $filters['kyc_request_from_date'] . "' AND date(dataset.kyc_upload_dt) <= '" . $filters['kyc_request_to_date'] . "'";
									}
								} else {
									if (!empty($filters['kyc_request_from_date'])) {
										if ($where_query != "") {
											$where_query  .= " AND date(dataset.kyc_upload_dt) >= '" . $filters['kyc_request_from_date'] . "'";
										} else  {
											$where_query  .= " date(dataset.kyc_upload_dt) >= '" . $filters['kyc_request_from_date'] . "'";
										}
									} else if (!empty($filters['kyc_request_to_date'])) { 
										if ($where_query != "") {
											$where_query  .= " AND date(dataset.kyc_upload_dt) <= '" . $filters['kyc_request_to_date'] . "'";
										} else  {
											$where_query  .= " date(dataset.kyc_upload_dt) <= '" . $filters['kyc_request_to_date'] . "'";
										}
									}
								}
								
								//bank card issued date
								if ((!empty($filters['bank_card_issued_from_date'])) && (!empty($filters['bank_card_issued_to_date']))) {
									if ($where_query != "") {
										$where_query  .= " AND date(dataset.admin_process_kyc_dt) >= '" . $filters['bank_card_issued_from_date'] . "' AND date(dataset.admin_process_kyc_dt) <= '" . $filters['bank_card_issued_to_date'] . "'";
									} else  {
										$where_query  .= " date(dataset.admin_process_kyc_dt) >= '" . $filters['bank_card_issued_from_date'] . "' AND date(dataset.admin_process_kyc_dt) <= '" . $filters['bank_card_issued_to_date'] . "'";
									}
								} else {
									if (!empty($filters['bank_card_issued_from_date'])) {
										if ($where_query != "") {
											$where_query  .= " AND date(dataset.admin_process_kyc_dt) >= '" . $filters['bank_card_issued_from_date'] . "'";
										} else  {
											$where_query  .= " date(dataset.admin_process_kyc_dt) >= '" . $filters['bank_card_issued_from_date'] . "'";
										}
									} else if (!empty($filters['bank_card_issued_to_date'])) { 
										if ($where_query != "") {
											$where_query  .= " AND date(dataset.admin_process_kyc_dt) <= '" . $filters['bank_card_issued_to_date'] . "'";
										} else  {
											$where_query  .= " date(dataset.admin_process_kyc_dt) <= '" . $filters['bank_card_issued_to_date'] . "'";
										}
									}
								}
								
								//card was activated date
								if ((!empty($filters['card_was_activated_from_date'])) && (!empty($filters['card_was_activated_to_date']))) {
									if ($where_query != "") {
										$where_query  .= " AND date(dataset.admin_process_card_activate_dt) >= '" . $filters['card_was_activated_from_date'] . "' AND date(dataset.admin_process_card_activate_dt) <= '" . $filters['card_was_activated_to_date'] . "'";
									} else  {
										$where_query  .= " date(dataset.admin_process_card_activate_dt) >= '" . $filters['card_was_activated_from_date'] . "' AND date(dataset.admin_process_card_activate_dt) <= '" . $filters['card_was_activated_to_date'] . "'";
									}
								} else {
									if (!empty($filters['card_was_activated_from_date'])) {
										if ($where_query != "") {
											$where_query  .= " AND date(dataset.admin_process_card_activate_dt) >= '" . $filters['card_was_activated_from_date'] . "'";
										} else  {
											$where_query  .= " date(dataset.admin_process_card_activate_dt) >= '" . $filters['card_was_activated_from_date'] . "'";
										}
									} else if (!empty($filters['card_was_activated_to_date'])) {
										if ($where_query != "") {
											$where_query  .= " AND date(dataset.admin_process_card_activate_dt) <= '" . $filters['card_was_activated_to_date'] . "'";
										} else  {
											$where_query  .= " date(dataset.admin_process_card_activate_dt) <= '" . $filters['card_was_activated_to_date'] . "'";
										}
									}
								}
								
								//all actions last updated date
								if ((!empty($filters['updated_on_from_date'])) && (!empty($filters['updated_on_to_date']))) {
									if ($where_query != "") {
										$where_query  .= " AND date(dataset.shift_update_dt) >= '" . $filters['updated_on_from_date'] . "' AND date(dataset.shift_update_dt) <= '" . $filters['updated_on_to_date'] . "'";
									} else  {
										$where_query  .= " date(dataset.shift_update_dt) >= '" . $filters['updated_on_from_date'] . "' AND date(dataset.shift_update_dt) <= '" . $filters['updated_on_to_date'] . "'";
									}
								} else {
									if (!empty($filters['updated_on_from_date'])) {
										if ($where_query != "") {
											$where_query  .= " AND date(dataset.shift_update_dt) >= '" . $filters['updated_on_from_date'] . "'";
										} else  {
											$where_query  .= " date(dataset.shift_update_dt) >= '" . $filters['updated_on_from_date'] . "'";
										}
									} else if (!empty($filters['updated_on_to_date'])) {
										if ($where_query != "") {
											$where_query  .= " AND date(dataset.shift_update_dt) <= '" . $filters['updated_on_to_date'] . "'";
										} else  {
											$where_query  .= " date(dataset.shift_update_dt) <= '" . $filters['updated_on_to_date'] . "'";
										}
									}
								}
								
								if (!empty($filters['bank_account_number'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.acc_no LIKE '%" . $filters['bank_account_number'] . "%'";
									} else  {
										$where_query  .= " dataset.acc_no LIKE '%" . $filters['bank_account_number'] . "%'";
									}
								}
								
								if (!empty($filters['card_number'])) {
									if ($where_query != "") {
										$where_query  .= " AND dataset.debit_card_num LIKE '%" . $filters['card_number'] . "%'";
									} else  {
										$where_query  .= " dataset.debit_card_num LIKE '%" . $filters['card_number'] . "%'";
									}
								}
								if (!empty($filters['bank_card_provider'])) {
				
									if ($where_query != "") {
										$where_query  .= " AND dataset.card_provider = '" . $filters['bank_card_provider'] . "'";
									} else  {
										$where_query  .= " dataset.card_provider = '" . $filters['bank_card_provider'] . "'";
									}
								}
													
								
								if ($where_query != "") {
									_log("", "setup search query ok !");
									$sql_user_info = $sql_signup_head .  " WHERE " . $where_query . " ORDER BY dataset.shift_update_dt DESC";
								} else {
									_log("", "setup search query failed !");
									//$sql_user_info = "SELECT a.email as shift_email, a.given_name, a.sur_name, a.shift_full_name, a.country as shift_country, a.add_dt as shift_add_dt, a.shift_update_dt, a.admin_update_dt, a.kyc_upload_dt, a.admin_action, a.admin_process_kyc_dt, a.admin_process_card_activate_dt, a.admin_process_card_load_dt, a.affiliation, b.*, c.debit_card_id, c.acc_no, c.debit_card_num, c.debit_card_name, c.status as card_status, c.has_paid_fee, c.payment_method, c.amount_fee_fiat, c.amount_fee_crypto, c.has_sent_document_postal, c.activation_deny_message, c.card_issuance_deny_message, c.secondary_address, c.secondary_country, c.secondary_district, c.secondary_province, c.secondary_postal_code, c.card_provider, c.selfie_with_card_file, c.send_data_step_one, c.send_data_step_two, c.card_active_local_approved FROM cryptocash_users_profile a LEFT JOIN cryptocash_jdb_profile b ON a.email = b.email_address LEFT JOIN cryptocash_jdb_debit_card c ON b.profile_id = c.profile_id ORDER BY a.shift_update_dt DESC";
									
									$sql_user_info = "SELECT a.email as shift_email, a.given_name, a.sur_name, a.middle_name, a.country as shift_country, a.add_dt as shift_add_dt, a.shift_update_dt, a.admin_update_dt, a.kyc_upload_dt, a.admin_action, a.admin_process_kyc_dt, a.admin_process_card_activate_dt, a.admin_process_card_load_dt, a.affiliation, a.created_from as created_from_one, b.*, c.debit_card_id, c.acc_no, c.debit_card_num, c.debit_card_name, c.status as card_status, c.has_paid_fee, c.payment_method, c.amount_fee_fiat, c.amount_fee_crypto, c.has_sent_document_postal, c.activation_deny_message, c.card_issuance_deny_message, c.secondary_address, c.secondary_country, c.secondary_district, c.secondary_province, c.secondary_postal_code, c.card_provider, c.selfie_with_card_file, c.send_data_step_one, c.send_data_step_two, c.card_active_local_approved, c.card_selfie_uploaded FROM cryptocash_users_profile a LEFT JOIN cryptocash_jdb_profile b ON a.email = b.email_address LEFT JOIN cryptocash_jdb_debit_card c ON b.profile_id = c.profile_id ORDER BY a.shift_update_dt DESC";
								}
								
								$rs_user_info = mysqli_query($dbhandle, $sql_user_info);
								_log("", $sql_user_info);
								
								
								while ($row_user_info = mysqli_fetch_array($rs_user_info, MYSQLI_ASSOC)) {
									$my_profile_id = '';
									$has_paid_fee = '';
									$my_debit_card_id = '';
									$has_sent_document_postal = '';
									$my_card_status = '';									
									$kyc_pdf_file_created = '';
									$card_selfie_uploaded = '';
									$selfie_with_card_file = '';
									$send_data_step_one = '';
									$card_active_local_approved = '';
									$send_data_step_two = '';
									$shift_country = '';
									$shift_email = '';
									unset($cur_user_info);
									$cur_user_info = array();									
									$cur_user_info['email_address'] = (is_null($row_user_info['email_address']))?'':$row_user_info['email_address'];
									$shift_email = (is_null($row_user_info['shift_email']))?'':$row_user_info['shift_email'];
									$cur_user_info['given_name'] = (is_null($row_user_info['given_name']))?'':$row_user_info['given_name'];
									$cur_user_info['middle_name'] = (is_null($row_user_info['middle_name']))?'':$row_user_info['middle_name'];
									$cur_user_info['sur_name'] = (is_null($row_user_info['sur_name']))?'':$row_user_info['sur_name'];
									$cur_user_info['signup_datetime'] = (is_null($row_user_info['shift_add_dt']))?'':$row_user_info['shift_add_dt'];
									
									if ($cur_user_info['signup_datetime'] != '') {
										$shift_add_tm = strtotime($cur_user_info['signup_datetime']) - 32400; //change to UTC
										$cur_user_info['signup_datetime'] = date('Y/m/d H:i:s', $shift_add_tm);
										
									}
									
									$cur_user_info['last_update_datetime'] = (is_null($row_user_info['shift_update_dt']))?'':$row_user_info['shift_update_dt'];
									if ($cur_user_info['last_update_datetime'] != '') {
										$shift_update_tm = strtotime($cur_user_info['last_update_datetime']) - 32400; //change to UTC
										$cur_user_info['last_update_datetime'] = date('Y/m/d H:i:s', $shift_update_tm);
										
									}
									
									$cur_user_info['submit_kyc_document_datetime'] = (is_null($row_user_info['kyc_upload_dt']))?'':$row_user_info['kyc_upload_dt'];
									if ($cur_user_info['submit_kyc_document_datetime'] != '') {
										$kyc_upload_dt_tm = strtotime($cur_user_info['submit_kyc_document_datetime']) - 32400; //change to UTC
										$cur_user_info['submit_kyc_document_datetime'] = date('Y/m/d H:i:s', $kyc_upload_dt_tm);
										
									}
									$cur_user_info['card_was_issued_datetime'] = (is_null($row_user_info['admin_process_kyc_dt']))?'':$row_user_info['admin_process_kyc_dt'];
									if ($cur_user_info['card_was_issued_datetime'] != '') {
										$admin_process_kyc_tm = strtotime($cur_user_info['card_was_issued_datetime']) - 32400; //change to UTC
										$cur_user_info['card_was_issued_datetime'] = date('Y/m/d H:i:s', $admin_process_kyc_tm);
										
									}
									$cur_user_info['card_was_activated_datetime'] = (is_null($row_user_info['admin_process_card_activate_dt']))?'':$row_user_info['admin_process_card_activate_dt'];
									if ($cur_user_info['card_was_activated_datetime'] != '') {
										$admin_process_card_activate_tm = strtotime($cur_user_info['card_was_activated_datetime']) - 32400; //change to UTC
										$cur_user_info['card_was_activated_datetime'] = date('Y/m/d H:i:s', $admin_process_card_activate_tm);
										
									}
									
									$shift_country = (is_null($row_user_info['shift_country']))?'':$row_user_info['shift_country'];
									$cur_user_info['affiliation'] = (is_null($row_user_info['affiliation']))?'':$row_user_info['affiliation'];
									$my_profile_id = (is_null($row_user_info['profile_id']))?'':$row_user_info['profile_id'];
									$cur_user_info['title'] = (is_null($row_user_info['gender']))?'':$row_user_info['gender'];
									if (intval($cur_user_info['title'])==1) {
										$cur_user_info['title'] = "Mr.";
									} else if (intval($cur_user_info['title'])==2) { 
										$cur_user_info['title'] = "Ms.";
									}
									$cur_user_info['name'] = (is_null($row_user_info['name_romaji']))?'':$row_user_info['name_romaji'];
									$cur_user_info['card_emboss_name'] = (is_null($row_user_info['name_on_card']))?'':$row_user_info['name_on_card'];
									$cur_user_info['marriage_status'] = (is_null($row_user_info['marriage_status']))?'':$row_user_info['marriage_status'];
									if (intval($cur_user_info['marriage_status'])==1) {
										$cur_user_info['marriage_status'] = "Single";
									} else if (intval($cur_user_info['marriage_status'])==2) { 
										$cur_user_info['marriage_status'] = "Married";
									}
									$cur_user_info['occupation'] =  (is_null($row_user_info['occupation']))?'':$row_user_info['occupation'];
									$cur_user_info['country'] = (is_null($row_user_info['country']))?'':$row_user_info['country'];
									$cur_user_info['nationality'] = (is_null($row_user_info['nationality']))?'':$row_user_info['nationality'];
									$cur_user_info['date_of_birth'] = (is_null($row_user_info['date_of_birth']))?'':$row_user_info['date_of_birth'];
									if ($cur_user_info['date_of_birth'] != '') {
										$cur_user_info['date_of_birth'] = str_replace("-","/",$cur_user_info['date_of_birth']);
									}									
									$cur_user_info['place_of_birth'] = (is_null($row_user_info['place_of_birth']))?'':$row_user_info['place_of_birth'];
									$cur_user_info['id_card_number'] = (is_null($row_user_info['id_card_number']))?'':$row_user_info['id_card_number'];
									$cur_user_info['id_card_issued_date'] = (is_null($row_user_info['id_card_issued_dt']))?'':$row_user_info['id_card_issued_dt'];
									if ($cur_user_info['id_card_issued_date'] != '') {
										$cur_user_info['id_card_issued_date'] = str_replace("-","/",$cur_user_info['id_card_issued_date']);
									}
									$cur_user_info['id_card_expired_date'] =(is_null($row_user_info['id_card_expired_dt']))?'':$row_user_info['id_card_expired_dt'];
									if ($cur_user_info['id_card_expired_date'] != '') {
										$cur_user_info['id_card_expired_date'] = str_replace("-","/",$cur_user_info['id_card_expid_card_expired_dateired_dt']);
									}
									$cur_user_info['id_card_issuer'] = (is_null($row_user_info['id_card_issuer']))?'':$row_user_info['id_card_issuer'];
									$cur_user_info['id_card_type'] = (is_null($row_user_info['id_card_type']))?'':$row_user_info['id_card_type'];
									if ($cur_user_info['id_card_type'] == "passport") {
										$cur_user_info['id_card_type'] = "Passport";
									} else if ($cur_user_info['id_card_type'] == "driving_license") {
										$cur_user_info['id_card_type'] = "ID card";
									}
									$cur_user_info['address'] = (is_null($row_user_info['residence_address']))?'':$row_user_info['residence_address'];
									$cur_user_info['district'] = (is_null($row_user_info['district']))?'':$row_user_info['district'];
									$cur_user_info['province'] = (is_null($row_user_info['province']))?'':$row_user_info['province'];
									$cur_user_info['postal_code'] = (is_null($row_user_info['postal_code']))?'':$row_user_info['postal_code'];
									$cur_user_info['cellphone_country_code'] = (is_null($row_user_info['cellphone_country_code']))?'':$row_user_info['cellphone_country_code'];
									if ( strpos($cur_user_info['cellphone_country_code'], "_") !== false ) {
										$cellphone_country_code_arr = explode("_", $cur_user_info['cellphone_country_code']);
										if ($cellphone_country_code_arr[1] == "ca") {
											$cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
										} else if ($cellphone_country_code_arr[1] == "44") {
											$cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0] . " 44";
										} else if ($cellphone_country_code_arr[1] == "34") {
											$cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0] . " 34";
										} else if ($cellphone_country_code_arr[1] == "97") {
											$cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0] . " 97";
										} else if ($cellphone_country_code_arr[1] == "ca") {
											$cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
										} else if ($cellphone_country_code_arr[1] == "kaz") {
											$cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
										} else if ($cellphone_country_code_arr[1] == "swa") {
											$cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
										} else if ($cellphone_country_code_arr[1] == "1") {
											$cur_user_info['cellphone_country_code'] = $cellphone_country_code_arr[0];
										}
									}
									$cur_user_info['cellphone_number'] = (is_null($row_user_info['cellphone_number']))?'':$row_user_info['cellphone_number'];
									
									$cur_user_info['profile_added_date'] = (is_null($row_user_info['added_dt']))?'':$row_user_info['added_dt'];
									if ($cur_user_info['profile_added_date'] != '') {
										$profile_added_tm = strtotime($cur_user_info['profile_added_date']) - 32400; //change to UTC
										$cur_user_info['profile_added_date'] = date('Y/m/d H:i:s', $profile_added_tm);
										
									}
									$cur_user_info['profile_updated_date'] = (is_null($row_user_info['update_dt']))?'':$row_user_info['update_dt'];
									if ($cur_user_info['profile_updated_date'] != '') {
										$profile_updated_tm = strtotime($cur_user_info['profile_updated_date']) - 32400; //change to UTC
										$cur_user_info['profile_updated_date'] = date('Y/m/d H:i:s', $profile_updated_tm);
										
									}
									$cur_user_info['profile_status'] = (is_null($row_user_info['status']))?'':$row_user_info['status'];
									$cur_user_info['kyc_deny_message'] = (is_null($row_user_info['application_deny_message']))?'':$row_user_info['application_deny_message'];
									$cur_user_info['kyc_deny_message'] = addslashes($cur_user_info['kyc_deny_message']);
									//$cur_user_info['signature_one_filename'] = (is_null($row_user_info['signature_one_filename']))?'':$row_user_info['signature_one_filename'];
									//$cur_user_info['signature_two_filename'] = (is_null($row_user_info['signature_two_filename']))?'':$row_user_info['signature_two_filename'];
									$my_debit_card_id = (is_null($row_user_info['debit_card_id']))?'':$row_user_info['debit_card_id'];
									$cur_user_info['bank_account_number'] = (is_null($row_user_info['acc_no']))?'':$row_user_info['acc_no'];
									$cur_user_info['card_number'] =  (is_null($row_user_info['debit_card_num']))?'':$row_user_info['debit_card_num'];
									$my_card_status =  (is_null($row_user_info['card_status']))?'':$row_user_info['card_status'];
									$has_paid_fee =  (is_null($row_user_info['has_paid_fee']))?'':$row_user_info['has_paid_fee'];
									$cur_user_info['payment_method'] = (is_null($row_user_info['payment_method']))?'':strtoupper($row_user_info['payment_method']);
									$cur_user_info['amount_fee_fiat'] = (is_null($row_user_info['amount_fee_fiat']))?'':$row_user_info['amount_fee_fiat'];
									$cur_user_info['amount_fee_crypto'] = (is_null($row_user_info['amount_fee_crypto']))?'':$row_user_info['amount_fee_crypto'];
									//_log($cur_user_info['shift_email'] . "amount_fee_fiat = " . $cur_user_info['amount_fee_fiat'] . " / amount_fee_crypto = " . $cur_user_info['amount_fee_crypto'] );
									/*if ($cur_user_info['payment_method']=='BTC') {
										$cur_user_info['total_fee_paid_text'] = $cur_user_info['amount_fee_crypto'] . " BTC";
									} else if ($cur_user_info['payment_method']=='USDT') {
										$cur_user_info['total_fee_paid_text'] = $cur_user_info['amount_fee_crypto'] . " USDT";
									} else if ($cur_user_info['payment_method']=='USD') {
										$cur_user_info['total_fee_paid_text'] = $cur_user_info['amount_fee_fiat'] . " USD";
									}*/
									$has_sent_document_postal = (is_null($row_user_info['has_sent_document_postal']))?'':$row_user_info['has_sent_document_postal'];
									$cur_user_info['card_activation_deny_message'] = (is_null($row_user_info['activation_deny_message']))?'':$row_user_info['activation_deny_message'];
									$cur_user_info['card_issuance_deny_message'] = (is_null($row_user_info['card_issuance_deny_message']))?'':$row_user_info['card_issuance_deny_message'];
									
									if (($row_user_info['secondary_address'] != "") && ($row_user_info['secondary_district'] != "") && ($row_user_info['secondary_province'] != "") && ($row_user_info['secondary_country'] != "")) {
										//$secondary_residence_address = $row_user_info['secondary_address'] . ", " . $row_user_info['secondary_district'] . ", " . $row_user_info['secondary_province'] . ", " . $row_user_info['secondary_postal_code'] . ", " . $row_user_info['secondary_country'];
										//$cur_user_info['secondary_address'] = $secondary_residence_address;
										$cur_user_info['secondary_address'] = array('address' => $row_user_info['secondary_address'], 'district' => $row_user_info['secondary_district'], 'province' => $row_user_info['secondary_province'], 'postal_code' => $row_user_info['secondary_postal_code'], 'country' => $row_user_info['secondary_country']);
									} else {
										$cur_user_info['secondary_address'] = "";
									}									
									
									$cur_user_info['card_provider'] = (is_null($row_user_info['card_provider']))?'':$row_user_info['card_provider'];
									if ($cur_user_info['card_provider'] == "visa") {
										$cur_user_info['card_provider'] = "VISA";
									} else if ($cur_user_info['card_provider'] == "unionpay") {
										$cur_user_info['card_provider'] = "UNIONPAY";
									}
									$selfie_with_card_file = (is_null($row_user_info['selfie_with_card_file']))?'':$row_user_info['selfie_with_card_file'];
									$send_data_step_one = (is_null($row_user_info['send_data_step_one']))?'':$row_user_info['send_data_step_one'];
									$send_data_step_two = (is_null($row_user_info['send_data_step_two']))?'':$row_user_info['send_data_step_two'];
									$card_active_local_approved = (is_null($row_user_info['card_active_local_approved']))?'':$row_user_info['card_active_local_approved'];
									//break;
									
									$cur_user_info['kyc_file_url'] = '';
									$kyc_pdf_file_created = (is_null($row_user_info['kyc_pdf_file_created']))?'':intval($row_user_info['kyc_pdf_file_created']);
									if ($kyc_pdf_file_created == 1) {
										$application_form_final_pdfex = '/var/www/dashboard.ultimopay.io/html/jdb/data/upload/application_final_signed_' . $my_profile_id . '.pdf';
										$cur_user_info['kyc_file_url'] = 'https://dashboard.ultimopay.io/jdb/data/upload/application_final_signed_' . $my_profile_id . '.pdf?t=' . time();
									}
									$cur_user_info['kyc_status'] = 'not yet';
									if (intval($has_paid_fee) == 1) {
										$cur_user_info['payment_status'] = 'done';
									} else {
										$cur_user_info['payment_status'] = 'not yet';
									}
									$card_selfie_uploaded = (is_null($row_user_info['card_selfie_uploaded']))?'':intval($row_user_info['card_selfie_uploaded']);
									$cur_user_info['card_status'] = 'not yet';
									$cur_user_info['card_activation_status'] = 'not yet';
									$cur_user_info['group'] = (is_null($row_user_info['created_from_one']))?'':$row_user_info['created_from_one'];
									
									
									//////////////////////////////////////////////////////////////////////////
									if ($my_profile_id != '') {
										
										
										
										/////////////////////////////////////////////////////////////////////////////////////////
										if ($my_debit_card_id != '') {
											
											//////////////////////////////////////////////////////////////////////////////////////

											if (intval($has_sent_document_postal) == 1) {
												$has_sent_document_postal_cnt++;
											}
											
											//$cur_user_info['debit_card_overall_status'] = 0;
											
											//_log($debit_card['email_address'] . " / status=" . $debit_card['status'] . " / deny=" . $profile['application_deny_message'] . " / paid=" . $debit_card['has_paid_fee'] . " / send_data_step_one=" . $debit_card['send_data_step_one'] . " / send_data_step_two=" . $debit_card['send_data_step_two'] . " / card_active_local_approved=" . $debit_card['card_active_local_approved']);
											if ($cur_user_info['card_number'] != '') {
												$card_had_data_cnt++;
											}
											if (intval($my_card_status) == 1) {
												//_log("phat hien !");
												//$cur_user_info['debit_card_overall_status'] = 10;
												//$cur_user_info['debit_card_overall_status_text'] = "Card was activated";
												//$card_activated_cnt++;
												//$activated_card_arr[] = $debit_card;
												$cur_user_info['kyc_status'] = 'approved';
												$cur_user_info['card_status'] = 'issued';
												$cur_user_info['card_activation_status'] = 'approved';
											} else {
												if (trim($my_profile_id) == '') {
													//$cur_signup_user['debit_card_overall_status'] = 1; //just sign up
												} else {
													if (intval($cur_user_info['profile_status']) <= 0) {
														_log($reg_email_address, "vao day chou...");
														if ($cur_user_info['kyc_deny_message'] != '') {							
															//$cur_user_info['debit_card_overall_status'] = 2;
															//$cur_user_info['debit_card_overall_status_text'] = "Card Issuance declined (not pass KYC)";
															
															$cur_user_info['kyc_status'] = 'declined';
															$cur_user_info['card_status'] = 'not yet';
															$cur_user_info['card_activation_status'] = 'not yet';
														} else {
															/*
															//check whether 
															$application_form_final_pdfex = '/var/www/dashboard.ultimopay.io/html/jdb/data/upload/application_final_signed_' . $my_profile_id . '.pdf';
															$application_form_1_pdfex = '/var/www/dashboard.ultimopay.io/html/jdb/data/upload/application_form_1_signed_' . $my_profile_id . 'chuyendoi.pdf';
															$application_form_2_p1_pdfex = '/var/www/dashboard.ultimopay.io/html/jdb/data/upload/application_form_2_p1_signed_' . $my_profile_id . 'chuyendoi.pdf';
															$application_form_2_p2_pdfex = '/var/www/dashboard.ultimopay.io/html/jdb/data/upload/application_form_2_p2_signed_' . $my_profile_id . 'chuyendoi.pdf';
															$application_form_2_p3_pdfex = '/var/www/dashboard.ultimopay.io/html/jdb/data/upload/application_form_2_p3_signed_' . $my_profile_id . 'chuyendoi.pdf';
															$application_form_2_p4_pdfex = '/var/www/dashboard.ultimopay.io/html/jdb/data/upload/application_form_2_p4_signed_' . $my_profile_id . 'chuyendoi.pdf';
															
															if (!file_exists($application_form_final_pdfex)) {
																_log($reg_email_address, "vao day la sai nha");
																$parts_pdf_cnt = 0;
																if (file_exists($application_form_1_pdfex))
																	$parts_pdf_cnt++;
																
																if (file_exists($application_form_2_p1_pdfex))
																	$parts_pdf_cnt++;
																
																if (file_exists($application_form_2_p2_pdfex))
																	$parts_pdf_cnt++;
																
																if (file_exists($application_form_2_p3_pdfex))
																	$parts_pdf_cnt++;
																
																if (file_exists($application_form_2_p4_pdfex))
																	$parts_pdf_cnt++;
																
																if ($parts_pdf_cnt == 0) {
																	$cur_user_info['debit_card_overall_status'] = 3;
																	$cur_user_info['debit_card_overall_status_text'] = "completed profile";
																	//$profile_completed_cnt++;
																	$cur_user_info['kyc_status'] = 'not yet';
																	$cur_user_info['card_status'] = 'not yet';
																	$cur_user_info['card_activation_status'] = 'not yet';
																} else {
																	if ($parts_pdf_cnt == 5) { //pdf ok, next is upload photos for KYC
																		$cur_user_info['debit_card_overall_status'] = 4;
																		$cur_user_info['debit_card_overall_status_text'] = "n/a";
																		$cur_user_info['kyc_status'] = 'not yet';
																		$cur_user_info['card_status'] = 'not yet';
																		$cur_user_info['card_activation_status'] = 'not yet';
																	} else {
																		$cur_user_info['debit_card_overall_status'] = 5;
																		$cur_user_info['debit_card_overall_status_text'] = "n/a";
																		$cur_user_info['kyc_status'] = 'not yet';
																		$cur_user_info['card_status'] = 'not yet';
																		$cur_user_info['card_activation_status'] = 'not yet';
																	}
																}
															} else {
																_log($reg_email_address, "vao day la ok ne");
																$cur_user_info['debit_card_overall_status'] = 6;
																$cur_user_info['debit_card_overall_status_text'] = "KYC document uploaded (pending review)";
																//$documents_uploaded_cnt++;
																$cur_user_info['kyc_status'] = 'pending';
																
																//$cur_user_info['profile_updated_dt_ex'] = date('Y-m-d', strtotime($cur_user_info['profile_updated_dt']));
																
															}
															*/
															if ($kyc_pdf_file_created == 1) {
																$cur_user_info['kyc_status'] = 'pending';
																$cur_user_info['card_status'] = 'not yet';
																$cur_user_info['card_activation_status'] = 'not yet';
															} else {
																$cur_user_info['kyc_status'] = 'not yet';
																$cur_user_info['card_status'] = 'not yet';
																$cur_user_info['card_activation_status'] = 'not yet';
															}
														}
													} else {
														if (intval($cur_user_info['profile_status']) == 1) { //approved, next is fee payment
															$documents_uploaded_cnt++;
															
															if ($my_debit_card_id != '') {
																if (intval($has_paid_fee) == 0) { //not paid									
																	//$cur_user_info['debit_card_overall_status'] = 7;
																	//$cur_user_info['debit_card_overall_status_text'] = "Still not pay Fee";
																	//$kyc_approved_cnt++;
																	$cur_user_info['kyc_status'] = 'approved';
																	$cur_user_info['card_status'] = 'not yet';
																	$cur_user_info['card_activation_status'] = 'not yet';
																} else if (intval($has_paid_fee) == 1) { //paid
																	
																	//$selfie_with_card_file = $card_selfie_uploaded;
																	//if ($cur_user_info['selfie_with_card_file'] != '') {
																	//	if (file_exists("/var/www/dashboard.ultimopay.io/html/jdb/data/upload/" . $cur_user_info['selfie_with_card_file'])) {
																	//		$selfie_with_card_file = 1;
																	//	}
																	//}
																	if ($cur_user_info['card_number'] == '') {										
																		
																		if (intval($send_data_step_one) == 0) { //chua gui data cho JDB
																			//$payments_completed_cnt++;
																			//$cur_user_info['debit_card_overall_status'] = 8; //paid fee, wait for data sending by admin
																			//$cur_user_info['debit_card_overall_status_text'] = "has paid fee (card creation in progress)";
																			$cur_user_info['kyc_status'] = 'approved';
																			$cur_user_info['card_status'] = 'processing';
																			$cur_user_info['card_activation_status'] = 'not yet';
																		} else {
																			//if ($cur_user_info['card_issuance_deny_message'] == '') {
																			//	$pending_update_card_info_cnt++;
																			//}											
																			//$cur_user_info['debit_card_overall_status'] = 9; //sent to JDB, wait //for result to update
																			//$cur_user_info['debit_card_overall_status_text'] = "has paid fee (card creation in progress)";
																			$cur_user_info['kyc_status'] = 'approved';
																			$cur_user_info['card_status'] = 'processing';
																			$cur_user_info['card_activation_status'] = 'not yet';
																		}
																		
																		if ($card_selfie_uploaded == 0) {
																			//todo
																		} else {
																			if ($cur_user_info['card_activation_deny_message'] != '') {
																				if (intval($card_active_local_approved) == 0) { //deny by company
																					//$cur_user_info['debit_card_overall_status'] = 15;
																					//$cur_user_info['debit_card_overall_status_text'] = "Card Activation declined (Selfie photo was declined)";
																				} else { //deny by JDB
																					//$cur_user_info['debit_card_overall_status'] = 15;
																					//$cur_user_info['debit_card_overall_status_text'] = "Card Activation declined (Selfie photo was declined)";
																				}
																				
																			} else {
																				if (intval($card_active_local_approved) == 0) { //card active requests
																					$card_active_request_cnt++;
																					//$cur_user_info['debit_card_overall_status'] = 11;
																					//$cur_user_info['debit_card_overall_status_text'] = "requested card activation";
																					$cur_user_info['kyc_status'] = 'approved';
																					$cur_user_info['card_status'] = 'issued';
																					$cur_user_info['card_activation_status'] = 'pending';
																				} else {
																					//$card_active_local_approved_cnt++;
																					if (intval($send_data_step_two) == 0) { //chua gui data cho JDB	
																						//$pending_send_activate_request_cnt++;
																						//$cur_user_info['debit_card_overall_status'] = 12; 
																						////$cur_user_info['debit_card_overall_status_text'] = "Card Activation is under review (selfie photo has been accepted)";
																						//$cur_user_info['debit_card_overall_status_text'] = "requested card activation (being processed)";
																						$cur_user_info['kyc_status'] = 'approved';
																						$cur_user_info['card_status'] = 'issued';
																						$cur_user_info['card_activation_status'] = 'pending';
																					} else {
																						//$pending_update_activate_result_cnt++;
																						//$cur_user_info['debit_card_overall_status'] = 13;
																						////$cur_user_info['debit_card_overall_status_text'] = "Card Activation is under review (selfie photo has been accepted)";
																						//$cur_user_info['debit_card_overall_status_text'] = "requested card activation (being processed)";
																						$cur_user_info['kyc_status'] = 'approved';
																						$cur_user_info['card_status'] = 'issued';
																						$cur_user_info['card_activation_status'] = 'pending';
																					}
																				}		
																			}
																																			
																		}							
																	} else {
																		//_log($cur_user_info['email_address'] . " day ne");
																		//$card_had_data_cnt++;
																		if ($card_selfie_uploaded == 0) {
																			//$still_not_request_activate_cnt++;
																			//$cur_user_info['debit_card_overall_status'] = 14;
																			//$cur_user_info['debit_card_overall_status_text'] = "still not activate card";
																			$cur_user_info['kyc_status'] = 'approved';
																			$cur_user_info['card_status'] = 'issued';
																			$cur_user_info['card_activation_status'] = 'not yet';
																		} else {
																			if ($cur_user_info['card_activation_deny_message'] != '') {
																				if (intval($card_active_local_approved) == 0) { //deny by company
																					//$cur_user_info['debit_card_overall_status'] = 15;
																					//$cur_user_info['debit_card_overall_status_text'] = "Card Activation declined (Selfie photo was declined)";
																					$cur_user_info['kyc_status'] = 'approved';
																					$cur_user_info['card_status'] = 'issued';
																					$cur_user_info['card_activation_status'] = 'declined';
																				} else { //deny by JDB
																					//$cur_user_info['debit_card_overall_status'] = 15;
																					//$cur_user_info['debit_card_overall_status_text'] = "Card Activation declined (Selfie photo was declined)";
																					$cur_user_info['kyc_status'] = 'approved';
																					$cur_user_info['card_status'] = 'issued';
																					$cur_user_info['card_activation_status'] = 'declined';
																				}
																			} else {
																				if (intval($card_active_local_approved) == 0) { //card active requests
																					//$card_active_request_cnt++;
																					//$cur_user_info['debit_card_overall_status'] = 11; 
																					//$cur_user_info['debit_card_overall_status_text'] = "requested card activation";
																					
																					$cur_user_info['kyc_status'] = 'approved';
																					$cur_user_info['card_status'] = 'issued';
																					$cur_user_info['card_activation_status'] = 'pending';
																				} else {
																					//$card_active_local_approved_cnt++;
																					if (intval($send_data_step_two) == 0) { //chua gui data cho JDB	
																						//$pending_send_activate_request_cnt++;
																						//$cur_user_info['debit_card_overall_status'] = 12; 
																						//$cur_user_info['debit_card_overall_status_text'] = "requested card activation (being processed)";
																						$cur_user_info['kyc_status'] = 'approved';
																						$cur_user_info['card_status'] = 'issued';
																						$cur_user_info['card_activation_status'] = 'pending';
																					} else {
																						//$pending_update_activate_result_cnt++;
																						//$cur_user_info['debit_card_overall_status'] = 13;
																						//$cur_user_info['debit_card_overall_status_text'] = "requested card activation (being processed)";
																						$cur_user_info['kyc_status'] = 'approved';
																						$cur_user_info['card_status'] = 'issued';
																						$cur_user_info['card_activation_status'] = 'pending';
																					}
																				}		
																			}																											
																		}
																	}
																}
															}
														}
													}
												}
											}
											/*
											$debit_card_arr[] = $debit_card;
											if ($debit_card['debit_card_overall_status'] == 6) {
												$check_kyc_arr[] = $debit_card;
											} else if ($debit_card['debit_card_overall_status'] == 11) {
												$check_activates_arr[] = $debit_card;
											}
											*/
												
											//////////////////////////////////////////////////////////////////////////////////////
										}
										
										/////////////////////////////////////////////////////////////////////////////////////////
										
										
									} else {
										//_log($reg_email_address, "chua dang ky phat hanh the");
										//$cur_user_info['debit_card_overall_status'] = 1; //just sign up
										//$cur_user_info['debit_card_overall_status_text'] = "sign up";
										$cur_user_info['email_address'] = $shift_email;
										$cur_user_info['country'] = $shift_country;
										$cur_user_info['kyc_status'] = 'not yet';
										$cur_user_info['card_status'] = 'not yet';
										$cur_user_info['card_activation_status'] = 'not yet';
										
									}
									
									if (!empty($filters['status'])) {
										if (intval($filters['status']) == 1) { //sign up only
											if ($my_profile_id == '') {
												$user_info_arr[] = $cur_user_info;
											}											
										} else if (intval($filters['status']) == 2) { //signed up and completed profile only
											if ($kyc_pdf_file_created == 0) {
												$user_info_arr[] = $cur_user_info;
											}
										} else if (intval($filters['status']) == 3) { //kyc request
											if ($kyc_pdf_file_created == 1) {
												$user_info_arr[] = $cur_user_info;
											}
										} else if (intval($filters['status']) == 4) { //kyc declined
											if (($cur_user_info['kyc_status'] == 'declined') && ($cur_user_info['card_status'] == 'not yet') && ($cur_user_info['card_activation_status'] == 'not yet')) {
												$user_info_arr[] = $cur_user_info;
											}
										} else if (intval($filters['status']) == 5) { //kyc approved only (still not pay fee)
											if (($cur_user_info['kyc_status'] == 'approved') && ($cur_user_info['card_status'] == 'not yet') && ($cur_user_info['card_activation_status'] == 'not yet')) {
												$user_info_arr[] = $cur_user_info;
											}
										} else if (intval($filters['status']) == 6) { //kyc approved and card issuance is under processing (has paid fee)
											if (($cur_user_info['kyc_status'] == 'approved') && ($cur_user_info['card_status'] == 'processing') && ($cur_user_info['card_activation_status'] == 'not yet')) {
												$user_info_arr[] = $cur_user_info;
											}
										} else if (intval($filters['status']) == 7) { //card has been issued (still not activate)
											if (($cur_user_info['kyc_status'] == 'approved') && ($cur_user_info['card_status'] == 'issued') && ($cur_user_info['card_activation_status'] == 'not yet')) {
												$user_info_arr[] = $cur_user_info;
											}
										} else if (intval($filters['status']) == 8) { //request card activation
											if (($cur_user_info['kyc_status'] == 'approved') && ($cur_user_info['card_status'] == 'issued') && ($cur_user_info['card_activation_status'] == 'pending')) {
												$user_info_arr[] = $cur_user_info;
											}
										} else if (intval($filters['status']) == 8) { //card activation declined
											if (($cur_user_info['kyc_status'] == 'approved') && ($cur_user_info['card_status'] == 'issued') && ($cur_user_info['card_activation_status'] == 'declined')) {
												$user_info_arr[] = $cur_user_info;
											}
										} else if (intval($filters['status']) == 9) { //card activation approved
											if (($cur_user_info['kyc_status'] == 'approved') && ($cur_user_info['card_status'] == 'issued') && ($cur_user_info['card_activation_status'] == 'approved')) {
												$user_info_arr[] = $cur_user_info;
											}
										}
									} else {
										$user_info_arr[] = $cur_user_info;
									}
									
									
									//////////////////////////////////////////////////////////////////////////
									
								}
								
								/*
								//get charges data
								$total_charge_completed = 0;
								$total_charge_uncompleted = 0;
								$card_loads = array();
								$sql_charges = "SELECT * from `cryptocash_jdb_card_charges` WHERE `cryptocash_jdb_card_charges`.`email`='$reg_email_address' AND `cryptocash_jdb_card_charges`.`debit_card_id`=" . $my_debit_card_id . " ORDER BY `cryptocash_jdb_card_charges`.`created_dt` DESC";
								_log($reg_email_address, $sql_charges);
								$rs_charges = mysqli_query($dbhandle, $sql_charges);
								$charges_cnt = mysqli_num_rows($rs_charges);
								if ($charges_cnt > 0) {
									
									while ($row_charge = mysqli_fetch_array($rs_charges, MYSQLI_ASSOC)) {
										unset($charge_item);
										$charge_item = array();
										$charge_item['datetime'] = $row_charge['created_dt'];
										$charge_item['datetime'] = date('Y/m/d H:i:s', strtotime($charge_item['datetime']) - 32400);
										$charge_item['account_number'] = $row_charge['jdb_account_num'];
										$charge_item['card_number'] = $cur_user_info['card_number'];
										$charge_item['amount'] = $row_charge['amount'];
										$charge_item['type'] = (trim($row_charge['load_type']) == '')?'load':$row_charge['load_type'];
										if (intval($row_charge['status']) == 1) {
											$charge_item['status'] = 'completed';
										} else if (intval($row_charge['status']) == 2) {
											$charge_item['status'] = 'pending';
										}
										if (trim($charge_item['card_load_deny_message']) !='') {
											$charge_item['status'] = 'declined';
											$charge_item['message'] = trim($charge_item['card_load_deny_message']);
										}
										$card_loads[] = $charge_item;
										//$total_charge = $row_charge['total_charge'];
										//$total_charge = format_fiat(number_format($total_charge, 10, '.', ','), 2);
									}
								}
								$cur_user_info['card_loads'] = $card_loads;
								*/
								@mysqli_close($dbhandle);
								$ret_rs['result'] = 'success';
								//$ret_rs['email_address'] = $reg_email_address;
								$ret_rs['usersInfoResponse'] = $user_info_arr;					
								header('Content-Type: application/json');
								echo json_encode($ret_rs);
								die();
								//////////////////////////////////////////////////////////////////////////////////////////
								
							
							
							
							
						
						
						
						
					
						
						
					//} else {			
					//	_log($reg_email_address, "could not connect db !");
						
					//}
					
					
					//header('Content-Type: application/json');
					//echo json_encode($ret_rs);
					//die();
					
					
					
				//} else {
				//	_log($reg_email_address . " : " . $refresh_token_res['result']['message']);
				//	$ret_rs['result'] = 'failed';
				//	$ret_rs['error'] = array('errorCode' => 4, 'errorMessage' => 'failed to refresh auth_token');
				//	header('Content-Type: application/json');
				//	echo json_encode($ret_rs);
				//	die();
				//}
				
				
			//} else {
			//	$ret_rs['result'] = 'failed';
			//	$ret_rs['error'] = $errors[0];
			//	_log("", $ret_rs['error']['errorMessage']);	
			//	header('Content-Type: application/json');
			//	echo json_encode($ret_rs);
			//	die();
			//}
				
			
		

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>