
@extends('layouts/contentLayoutMaster')

@section('title', 'mypays.io')

@section('content')
<style>
  .iframe-container {
    padding: 20px;
    width: calc(100%);
  }
  iframe {
    border: 1px solid lightgray;
    height: 100%;
    width: 100%;
  }
</style>
{{-- Iframe view starts --}}
<section id="iframe-view" class="data-list-view-header">
  {{-- Iframe starts --}}
  <div class="iframe-container">
    <iframe src="http://localhost/minamide/mypays.io/">
    </iframe>
  </div>
  {{-- Iframe ends --}}
</section>
{{-- Iframe view end --}}
@endsection

@section('page-script')
<script>
  let base_url = '<?php echo url(""); ?>';
  $(document).ready(function(){

    $('.iframe-container').css('height', $(window).height()*1 - $('.header-navbar-shadow').innerHeight()*1 - $('.footer').innerHeight()*1 - 10);

    $(window).resize(function (){
      $('.iframe-container').css('height', $(window).height()*1 - $('.header-navbar-shadow').innerHeight()*1 - $('.footer').innerHeight()*1 - 10);
    });
  });
</script>
@endsection
