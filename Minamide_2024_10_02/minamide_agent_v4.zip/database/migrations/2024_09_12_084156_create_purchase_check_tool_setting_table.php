<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePurchaseCheckToolSettingTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchase_check_tool_setting_partner', function (Blueprint $table) {
          $table->increments('id'); // Primary Key
          $table->string('partner_name'); // Partner Name
          $table->string('other')->nullable(); //
          $table->double('fee_percent', 8, 2); // Fee Percent (e.g., 10.50)
          $table->timestamps(); // Created_at and Updated_at fields
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchase_check_tool_setting');
    }
}
