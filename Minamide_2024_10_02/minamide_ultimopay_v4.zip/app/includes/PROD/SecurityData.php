<?php

namespace App\includes\PROD;

class SecurityData
{
    /**
     * JWE Key Id.
     *
     * @var string
     */
    public static $EncryptionKeyId = "19f84b5655f04e25a99b09f1ee2fac78";

    /**
     * Access Token.
     *
     * @var string
     */
    public static $AccessToken = "1f066ffa3ffd49f6ab415a2b0ff86472";

    /**
     * Token Type - Used in JWS and JWE header.
     *
     * @var string
     */
    public static $TokenType = "JWT";

    /**
     * JWS (JSON Web Signature) Signature Algorithm - This parameter identifies the cryptographic algorithm used to
     * secure the JWS.
     *
     * @var string
     */
    public static $JWSAlgorithm = "PS256";

    /**
     * JWE (JSON Web Encryption) Key Encryption Algorithm - This parameter identifies the cryptographic algorithm
     * used to secure the JWE.
     *
     * @var string
     */
    public static $JWEAlgorithm = "RSA-OAEP";

    /**
     * JWE (JSON Web Encryption) Content Encryption Algorithm - This parameter identifies the content encryption
     * algorithm used on the plaintext to produce the encrypted ciphertext.
     *
     * @var string
     */
    public static $JWEEncrptionAlgorithm = "A128CBC-HS256";

    /**
     * Merchant Signing Private Key is used to cryptographically sign and create the request JWS.
     *
     * @var string
     */
    public static $MerchantSigningPrivateKey = "MIIJQQIBADANBgkqhkiG9w0BAQEFAASCCSswggknAgEAAoICAQDOd8G5o+15Kb+kOYQ42woxSk7sYEdLU4mHzkL8/hPllLoG5hnNk3mAzgkiX9bO/8JBw6LU5dw8WbfhjGEvmfQBQIjAd0CeXouNhwx3kcU8kt3rhAfRsh7qf0CQowHSABIHobXMRLrmxr934L8n7jYJOa2ws7/5mnT0d5fCYMnjnLbcgx8aNL4WO/FfLXqW0plEaMf1zPzmVexTfcp0OPfynQaauVJmSOwpa5I43V+T3Ub74Cq4RYavrk2bt0JfkH+OxcWtpsdtSGiHe7ArnoXRZ3GVpxZykWOCfPGE+QoscVOFv/f0HqVQquE9AdGBd0XFVj6aJpf9dBvJ9fTc9Kga8cmLUTMaBBPhLtq2/MDxo5b0kcKiaZaVPfplATH+krcw/8/aNYO+69xN78Xv5Hu+EaN13L5OiHzYFDCmqA3CGk15ztyKPYkdDjTq2dGM0kck167IMh4PKeYB5EjCSKlN2VHkWrkto3J1mhP5p/elm+01upC3zmNYgwsvKYhc9l4a72EVvw/55KQ8PZ3h5ZqGy4eo6+J6HCjkTE7Lnnh5ZuDUbmaPGREsLF/7/fK6z191SipPiLEGSoC4NUOinXuHvQxiK82eTOunQM+pqdnEjSRJDJvG/LE1yqelepQ8n0s4Wey/tzV/5pYcRvX3tZCOnOAw1M4Q28p5FCdN4LNmuQIDAQABAoICAFmSeukexReblRiaG1LPNEzOAA9sdYGobDIOueEoGVmwfEQh72/QWxYWTMAs8/Q54PzG8w2J61IDWlLvo/oSwFkKtklJcy9BtSlhPXdiNj9hOAXE8d93dxIkws386f1BKpFFBqnn523XK5nGVyfroGXAMCpI0TBoYfTtLVmWw/+LLYndGNE1sIHU35J7GIP2OagEDTwGAnGrNSvDluF1FZyboxHc9HKLkGkn0ff5kk2D4hfD2MS45QWyiNjVWGY9Ohmmk2wSvtIaZ77fWj6SN1vxlMVoB8UMbi9eJSmbIV7Gi4WrEtdFtFKaz7y33TxdkldaYy5dL/M1PBkSK3jwazz9qmCe5zJpd5jRgAgv24sHFRQL++0/+0Wr7ZO87JtwJHSz/9i6przZ0UVZ56oLFFK12kC1uA3afbI38vLu1eLGGDnzpmTd+Uj4wseupwXAYTCQGAeiXXTyKsvOhtaxLN3XMijkQApOpHKlbkkF+J31svKiDGsDguhBNFB73DHcU81isVzx/SrQ/jXCLdGoxbE0Sk4dY+YG36toyrQun/zy7Q0QwPrxDJhsIHRtem8P0Ge/YSpc5OLDEuoxTZBZ4CPt36QBSiR1BATbrHvF2VJhlHJylNtDaiXnKIyZDzdaHLPvXtgH1AnsGNxfx1/POY8/iuhxzbqWlq5iCFHplegBAoIBAQDuiwnIKmp8sajS5DmqScFLOgkexzFgt9mtV2v/Yr98LopquVJiEHMduo4gvzDbpbkOdo2r97Ic1x+beDQD8JL3Wp6t4vKPvjagIdAVFTT8VDKe4NgSfn3/3JMVoCtCNp+/O3lhNWYANjTV3GL63bzZmLHx9XWxV+kR9gDIbbL6LEmmldeYU0qsd3rW720WnMzr86IX3cljXPaaN5aDEhByLshaU6WjWCVZrXw+mpaBb+Xa3tlw8hm8C49p1JrJCb62aCk56YpkxWL52lQIq3XoKsSacCQxYqiqQNabj8fIIA3sFVtP81UeCbo/9lUy3X9aDWjGJlGVbRGFUVhlYduRAoIBAQDdk86Gg7QiBGofhVAWW5MmFYIhJ5XznbWX9F8Nnp81E3vdFBxnjU3RLI+8LlP4klRxjhcnw9d2ot50EF9SEA9VtDApwnvV29ZGyJ63ozyKiqLU5DK7KmDDLZxkLBKPIbm8A7Ba9wsSLNOfLz8xDFT3MW60lxtcc3yok/EBw6ujHNdGyc4vJU2PrxJca7h1djeM7S4WjqwDzVk8DEkxHbKwm5LMD1lg6OoTchkMkoS8ATZC/LcVKNA/mqPuOiUB9sZzYH7zfgeGZf9q9kagRUh+4WwuG2BOf+GJJjvpklrTPg46YsdQiCp+eZQVXwIb5e135CQkpC2WmLa20y+qgDSpAoIBAB1mG12FBLy7dJAROp4nGuB3lZoqeIZwAi7f4FqIRAs8/SgsEOAvINDgJhYZGh9n7EfBCrLQAy6UwLt7dAWsR6CelYHev4BBtB/GKwv+IhqbEeYM1fRpjIPVHneC1vIBI20BGnOFjj2mcJqO39AFNfonXH7yfn/N0ta4193bzzwP6z/RpdGLKl/ZFdWZintH9eV6kFaaqfBKC8Zz5WPf/RDlfSHMv1RDT88el3pruPLY5J416tyFqfBICHPFlRID1nJKohIWG01SGmGqq8Kpxw1HABX8jilb/GeHOCvR65BZiv22oBtZZPsfvcmWRWfQbpqdnnUVUea1m3wvy1IrXlECggEANgEBVA2jiKr0xovychCNs7mIRtZkGMU2bju0MxiXCxOdm8t8BM0Oy02GFsJf2vSnOin8gMedqx+VAkq/QLwDUMsi9fqdvgjfl87ryCwz5DxX5XVc2/s/LDLgrBWFzHbW0vk/MVyGyT49sc2NJEIyLzFQHxm5JHZNSrUMB3cOTSoJWgpzg1AfMEbmPbpPcemHLoTcN8k8KY0SE62W5S6sz5iLVcrj6Ne7vVOQwVywlzXgaME5SiHxZ58kFzr6rBjeU16Qcn4kDWCsuQAfRI6+VZZRjIdFmLxYVtoHvizakCPOyfIrS/h0CvFM40yNsgj/MLpdCMUvC0ZbOgIM2wx2SQKCAQA/rSc3Kexl9R8VTY74aLQ9qQ3ZFO4hUqH0hfpvLXoYWB5jMyyzh8da8ZbY8fHzll2VR8Q0YqLEGFqZby9oVx4ToRp2wouCMfo4Ocu3kqrCiNDLsK07m1ebGvTHeFG3B+WfzIWAdlMakkJ6HfQQ34Cnty5TQHwB9SgA6W0KP9VpqcOdbWmsiBLi9v90l7DgTXacQY5+4Qw+gteVXn6S9lLRn0g0aXcI756rB51n97NVRgZaIks936di01tTnzMGASDX18FFNZeLyUWZZDFCdC2iuos7s6O7X1vS/6//n7xsptTS3w+mAeqYlXZEtIYLf6fLyUbLFqD1LZWQZAL5KEWV";
    /**
     * PACO Encryption Public Key is used to cryptographically encrypt and create the request JWE.
     *
     * @var string
     */
    public static $PacoEncryptionPublicKey = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA6ZLups2K0iYEMxQqgASX8gY6tWhNVCp08YuDgjCsOVrGVgUHD0dh0TWFNJ7Lq2Jp0SOsGgi54+hrjwPOL2CCZxw8pKUlL57UksoD9oWUrK/KkSvEAwPU4cZqzxIXyhBcZb8O96iN4WQJILkRTg+DXLkML6qisO496fPGIs+vCoc87toucy5O9fRfaYSjcqjreyi8JDkvVJM/BeNtOEM2a0b/lcWa67RH+tN97H25k+Qez7QthLru6oBfWBgD6iIwhV+ICqLWHmp6fQ+DHQk/o+OO3yFiY9OAvMiy8MOTinvkBlFwYgYNznG3/w0Xh8U5vtudUXPDNUO6ddf4y99+6LlWDiKgJn/Th93YUg+gFH4LUJHyPrSY2JuC+Q8kksp2xyiZDTHGzi96kturwrqCui6TytCHcU4UB0VRMR+M7VRl3S2YPhcxv5U8Fh2PITqydZE5vv1Va06qhegjOlSZnEUl2xKPm5k/u+UHvUP/oq04fQLTlYqyA3JYDCe4z5Ea2SOgjeVl+qTatWYzmkUXyCONLZ4UaRrgbYCp0nCPHoTFgRQdChu8ezDbnYY9IW7cT/s2fEi5N7X1XrQttiEP4rbn0y0qVYYjN86+elfhtYGHidZTUSUS5RSTHqOkj59p5LIGwFF9iTXzCjfUqq8clnfOk76qSLY1+Kj+SMMe6Z8CAwEAAQ==";
    /**
     * PACO Signing Public Key is used to cryptographically verify the response JWS signature.
     *
     * @var string
     */
    public static $PacoSigningPublicKey = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAr0XW6QacR8GilY4nZrJZW40wnFeYu7h9aXUSqxCP6djurCWZmLqnrsYWP7/HR8WOulYPHTVpfqJesTOdVqPgY6p10H811oRbJG9jvsG8j8kn/Bk8b2wZ9qelNqdNJMDbR5WUyaytaDWW6QdI4+clqjFfwCOw76noDSe+R4pDSzgMiyCk5R4m2ECT1fv/4Axz2bvLN+DRTg5DPPIMLWpA87lgjxeaDlGyJqZCbkJozW7JX0AJVc0X7YR9kzbiTi3LVOInSKY+VHT8yCARIdvXtKc6+IWSbVQqgpNIBB8GN0OvU8xedjPNCMGZnnMtgd7XLTf/okyadbdNLAqQLTbDs/5HnIVx8FyfgiOS/zsim5ivi3ljVAW3T3ePGjkY0q1DMzr5iJ4m/WTL2d1TArlfHyQhkSpFpQPOO+pJyVQqttHJo99vMirQogdSx4lIu//aod0yJyJLpjCeiqb2Fz3Qk0AZ4S78QKeeGsxTRchTP6Wsb6okaZd+cFi6z8qbP0z/Y3xRZO7vOLB/whkqS+pMVKBQ42YzgQPRzbXXmgCkf1nCqgrD9bnIB5ovdRGfDXW86GKY8XwGVjb4BoMvql+HsbonKHAO+eGfQulpB5YfQGQU3ZXdMdfCLAk8FuqemH4k7S7diLzVvRCuisHsEx6qJ4ewxzNCvW7OGVinTR9NSQUCAwEAAQ==";
    /**
     * Merchant Decryption Private Key used to cryptographically decrypt the response JWE.
     * @var string
     */
    public static $MerchantDecryptionPrivateKey = "MIIJQQIBADANBgkqhkiG9w0BAQEFAASCCSswggknAgEAAoICAQDZ1BhClDpNFwa64WimPWY2XRGF8/r9McN7T+WMvMvKJBQ3uHGXr51M7HICLKemcKVMpZ3H1oSojMoIjo8KKKaKDi2sR41+9X5aa/Mu71Wy+7eQG+gVKmaPbPb0xUWDr4e6/3VcTfPeyPRZt64ygqQNjUjaiOxIXD0DZf/vtJDJj2eCiV6pToYIplzUxfOBixBhnXD0TXR2WGRnpNW70IQNxJApDRHmXaC1sM64ZfMW/Y8gqqhvBL09E2S8qhNa1jgofnqrQgwBP8zaoTbmMO8U0i4jATQaDgRX8Or2X81PGL4YuS6UpQHe1alAvt7p6h+uhThGd9iDjaPP/FGsy9XoLmBaZPW4b7ILC1PxpSYaC4dPMFoqZzUPUdZ+qh1FBzBf04+R7lvCXHf7uRZueMBP9FhQuGhHMGKfDCVJzw36jQbLBXbYpswEIspco9hL3aH33VdPfwoa54h8fj/i1kroO70bbsvbzqQbjg+WoPChrjSC1LYLuCPk+1GJNxkeGYZzTtvawTPEVvjinoedigL1Z6eNIeDAMCeRg7LojhDipxZKRfrG24BIQ57RBSCcajFfu02bmBD8f5nyex7hpF0RZa0zjKVXrSjEFsaz4fsJRolEFKIxON65XxNU0Sn6V8Zoif2VzAb8c+0vG3wZxaX/2yvRhhfsGz9uh8/O5gKBYwIDAQABAoICADbZNvqcxElhAOrRkz44u6H4sU7fblWO0EAekBht+Yp+pzCYmtGtAJi7+MEfaV95gcXY9e+5zlF6keyxqMbQEY81nr6AjdpoClbOU79/uD6HL2N0A25A7O40a8KaYbSU4EJvzKdfYYa5Zv2oSI6jYpee+bc9PvHBeAOBDX7YIpT+LPwrhtBu20UWTs2swnHeCFPsBuMdFbQu8ak/UiomiPnGgt4zUkyFStA1Ivg/g4RIeF+rWRoLQXM9jOIMmS8IPb/EiTLSQJ+X5wcuDNrNe4Xsnn1l8i6VVPanzSIYYWQHQOaMynPXUK9BcYrCBPM1ZqDVHqRvzO7jHVpjmFVARi3nf4XB6dDWb7Fna2Lp+kxZ8IVzmyrOCBSL7+NIdfMV3+SCN24EyYsKXnEdTzS1JSk/kqGaLRH8iskH+yME0yqXO7CVQsILRcN30/mlRdiYhFEFdp2CUvip/Z8Pk+WQwuehJO2EbgTpeEbJ4uB6YhSP0Mk58apgVKXMvKVzONHyH74wYerL6YnEX4t3qmS/V67yHEiQspQbeQhUkkPQMNEkN5m1OHBGhqZHR/Q+E2eInOmRuyl0N7Jqu4F2bhUPDx7OFUmzS2F9vSfewk1LsZoqFcfOfnwHpkYdKnKMPkuVNVWu/m+EbXl8BlC3HnNsBq0PFoHymVHVZwNX0TsSfQ4xAoIBAQDv8g1ANBUFt2ib3ZGyosnd7K5s9EidikPgNKkylmjXccW0KOVqB3yt9lm2Pvh03e5Y1FHN1sBtkWaI+DD40KgF1keQ0G9OjeMeVeL6PeDnD09FWJTJRbrdsD8PAdF0HxTA47PqQvDaVY7x+eb/7l3DX6y1UjisYq+RSUdjJbhUqSFZEJaOlqk83SQ6Niipn8Is8Nsf2ofEaGvANl3oeWIMT3uIzHGTgz0HBLHzg1i1OovKI7WEjN3F/mT+ILomi7jkQEg0EhNji/VJvWmnCJrg6j4oWgmsgygYSbHHh/BUmBaLKa5n55ZsSi7+/0+zBfc4328hJsileO4HteS7lwEdAoIBAQDoZzUzKMo5ag2lV97bEbBbUteN3hp8VdXGg5hW1jO3ETBSCY9BaWdorHUemv1wyhzHe2oJ1TFZ165O7MNz0gqqFwsmqNekwdM9fYsMjgJd+F7ou1MZC2kdQ0vX4U/UZ1Q1T2NWzxQ6QNTeNRw7usP3KLdNS55k2NlOUZHo09NPH6ZplVrheV5GnHG8ztwDSSIjDWdvl6EaiFOggqXZnREEYSJ/d4hV/4N3NSMp8dFfskGkVKKKhBw0iTaFmB2rXKgxr5FUNvtLtllGEXL32osCHrL0KHffuKaZtn94clqgiIgZwcbE0SamfuezwTm62XphhYzaO9AMrOS7+TrevoR/AoIBABR5Otg3mXObarmh9kSfz0m4YEm7rlaC7be7xpQicV+wvYXZ13lsmh7d3lnGlbyjEytRMom1wUWYGn+lbchNRYj597FLl7PEN5TnDy77CK2uiL0KCegCoyc3WqoVJaIa5NJwm3FptNNsaX4MLMG5vRZmm339Pgi3gvOKpSS4mzneFJJc7/vKrzYaSHUPGfkfQJpFEu1s4BjKMCd+fBTSBqO2RHwvtaE4mYR3yhdVJcSQ8kyVL2/X9TRnuIZWlIulcGlJct++ixj7YDqihtlRyqVWV2dqB1lI96ra3uh/mOoe8A1/yPnksNkcm1X2wv4rjCS2K+1QOd6kqurNgm7fO6ECggEAaqHgQQb4Mnu8ox68PBvTpTNPf+JmmKHxolIC9eT2eYrDdwC34DVyow5t9or6umOh7M1ti/Fr4WMasU/lJiE7j2tfTG+v8gKU3+PYhvwpjeBF+9bne9hGdIzKIdVZgYWfl45DcDM3frr8cLBBsg4xmBfwcuC9Xlw46Lx4jDGVBPrqqgtDVa0QWqmxbgYj4MYPibG+we76lmfypvULD9wHUNEYuQ+pWHwSYAHbjoVLofLyN2o14gRXxKsofweapWOwMIvzzIYlq0mRkJq0+5Aks+ZOCcT/q4DXwDOCLUua1YmPmPHWN7wXVdFokouX52mdw105kXBcN1Sk5rKmFkmoFQKCAQAuD+4xFLeL9wTtQhgmYSVWVB8geMjeJmVA2Ee74zDGwLBZYh2KWb8TgsHBYlDOCR7hYMAEjHCJLmjn9YK4g6XH52KlzrZAY9oiPqxmM+OjztOE39M+JrSJsDVw3Pcn6erBH2mHH2UWh/MJphWPAGPoSe9V+PQsp/sCJBrhUn8l6QBwHjR0h76FY2otrgEuee85uzZWbuv3l5jYRPatUtjHrJTsA+VmJgQfH6UA8G7x4HtoRkL6CMPbM789Ez0baxuaGq37Xyf9Z6kKyqTGqHHpSEfrMwzhIAYABpV0HEG68XZRjW3H/VL2oqukt5MdECtwhmbNmEEJlNr3q/i3CZ+j";
}
