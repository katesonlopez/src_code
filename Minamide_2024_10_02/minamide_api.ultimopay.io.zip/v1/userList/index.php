<?php
mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
ini_set('memory_limit','100M');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
	//global $fh;
	if ($email == "") {
		$fh2 = fopen("/var/www/api.ultimopay.io/v1/userList/log/user_list.log" , 'a');
	} else {
		$fh2 = fopen("/var/www/api.ultimopay.io/v1/userList/log/" . $email . ".log" , 'a');
	}		
	$fline = date('[Ymd H:i:s] ') . $line."\n";
	fwrite($fh2, $fline);
	fclose($fh2);
	//echo date('[Ymd H:i:s] ').$line."\n";
	//@ob_flush(); 
	//flush();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		
	
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		_log("", "ket noi thanh cong");
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$allowed_deposit_currency_arr = array('USDT');
	$allowed_deposit_usdt_network_arr = array('ETHEREUM_ERC20', 'TRON_TRC20', 'BNB_SMART_CHAIN_BEP20');
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	$supported_partners = array();
	
	foreach (getAllHeaders() as $name => $value) {
		//echo "$name: $value\n";
		if ($name == 'Authorization') {
			/*
			if ($value == $apikey) {
				$found=1;
				break;
			} else if ($value == $apikey2) {
				$found = 2;
				break;
			} else if ($value == $apikey3) {
				$found = 3;
				break;
			} else if ($value == $apikey4) {
				$found = 4;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey4_sanbox) {
				$found = 4;
				$sandbox = 1;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_skynet) {
				$found = 5;
				$coin = 'BTC';
				break;
			} else if ($value == $apikey_sabong) {
				$found = 6;
				$coin = 'USDT';
				break;
			} else if ($value == $apikey_freelancer) {
				$found = 7;
				$coin = 'USDT';
				break;
			}
			*/
			$req_api_key = trim($value);			
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];	
					$supported_partners[] = strtoupper(trim($row_partner['partner']));					
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;						
						//break;
					}
					
				}
			} else {
				_log("", "not found in db");
			}
		}
	}
	@mysqli_close($dbhandle);
	

	function isValidPassword($password) {
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}


	/*
	function format_coin($in_amount) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function format_fiat($in_amount, $float_point) {
		
		$in_amount_temp = "" . $in_amount;									
		$dotpos = strpos($in_amount_temp,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($in_amount_temp,0, $dotpos);
			$p2 = substr($in_amount_temp,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > $float_point) {
				$p2_final =	substr($p2, 0, $float_point);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $in_amount_temp;
		}
		return $amount_final;
	}

	function common_uuid()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}
	*/
	/**
	 * Checks if the given string is an address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isAddress($address) {
		if (!preg_match('/^(0x)?[0-9a-f]{40}$/i',$address)) {
			// Check if it has the basic requirements of an address
			return false;
		} elseif (preg_match('/^(0x)?[0-9a-f]{40}$/',$address) || preg_match('/^(0x)?[0-9A-F]{40}$/',$address)) {
			// If it's all small caps or all all caps, return true
			return true;
		} else {
			// Otherwise check each case
			return isChecksumAddress($address);
		}
	}
	*/
	/**
	 * Checks if the given string is a checksummed address
	 *
	 * @param String $address the given HEX adress
	 * @return Boolean
	*/
	/*
	function isChecksumAddress($address) {
		// Check each case
		$address = str_replace('0x','',$address);
		//$addressHash = hash('sha3',strtolower($address));
		$addressHash = hash('sha3-256', strtolower($address));
		$addressArray=str_split($address);
		$addressHashArray=str_split($addressHash);

		for($i = 0; $i < 40; $i++ ) {
			// The nth letter should be uppercase if the nth digit of casemap is 1
			if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
				return false;
			}
		}
		
		return true;
	}
	*/

	/**
	 * @example truncate(-1.49999, 2); // returns -1.49
	 * @example truncate(.49999, 3); // returns 0.499
	 * @param float $val
	 * @param int f
	 * @return float
	 */
	 /*
	function truncate($val, $f="0")
	{
		if(($p = strpos($val, '.')) !== false) {
			$val = floatval(substr($val, 0, $p + 1 + $f));
		}
		return $val;
	}


	function my_number($val) {
		$tmp_val = "" . $val;									
		$dotpos = strpos($tmp_val,".",0);
		if ( $dotpos !== false ) {
			$p1 = substr($tmp_val,0, $dotpos);
			$p2 = substr($tmp_val,$dotpos + 1);
			$p2_len = strlen($p2);
			if ($p2_len > 8) {
				$p2_final =	substr($p2, 0, 8);	
			} else {
				$p2_final = $p2;		
			}
			$amount_final = $p1 . "." . $p2_final;
		} else {
			$amount_final = $tmp_val;
		}
		return $amount_final;
	}
	*/
	//_log("bat dau xu ly...");
	//if (($found==1) || ($found==2) || ($found==3) || ($found==4) || ($found==5) || ($found==7)) {
	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {


		
		unset($errors);
		$errors = array();
		$the_merchant = '';
		$ret_user_list = array();
					
		//merchant
		if ((!isset($_GET['merchant'])) || (empty($_GET['merchant']))) {
			$error_obj = array('errorCode' => 1, 'errorMessage' => 'merchant parameter is required.');
			$errors[] = $error_obj;
		} else {
			$the_merchant = trim(strtoupper(urldecode($_GET['merchant'])));
			if (!in_array($the_merchant, $supported_partners)) {
				$error_obj = array('errorCode' => 2, 'errorMessage' => 'unsupported merchant');
				$errors[] = $error_obj;
			}
			
		}
		
		
		if (count($errors) == 0) {
			
			require_once '../include/common.php';
			//require_once '../include/dbconfig.php';
			
			
			
			$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
			if (mysqli_connect_errno() == 0) {
				
				mysqli_query($dbhandle, "set names utf8;");
				
				
				//if (($found == 6) || ($found == 7)) {
				//	$merchant = 'UltimoCasino';
				//}
				$sql_user_list = "SELECT a.email AS profile_email, a.given_name, a.sur_name, a.add_dt AS profile_added_dt, a.country, a.created_from, a.merchants_has_signed_in, b.*, c.* FROM cryptocash_users_profile a LEFT JOIN cryptocash_shift_wallet b ON a.email = b.shift_login_email LEFT JOIN cryptocash_users_2fa c ON shift_login_email = c.email WHERE b.shift_account_currency='USDT' AND ((a.created_from LIKE '%" . $req_partner['partner'] . "%') OR (a.merchants_has_signed_in LIKE '%" . $req_partner['partner'] . "%')) ORDER BY a.add_dt DESC";
				$rs_user_list = mysqli_query($dbhandle, $sql_user_list);
				if (mysqli_num_rows($rs_user_list) > 0) { 
				
					//$cur_time = time();
					//$cur_time_utc = $cur_time - 32400;
					while ($row_user_list = mysqli_fetch_array($rs_user_list, MYSQLI_ASSOC)) {
						$cur_user_item = array();
						$cur_user_item['email_address'] =  (!empty($row_user_list['profile_email']))?trim($row_user_list['profile_email']):'';
						$user_given_name =  (!empty($row_user_list['given_name']))?trim($row_user_list['given_name']):'';
						$user_sur_name =  (!empty($row_user_list['sur_name']))?trim($row_user_list['sur_name']):'';
						$cur_user_item['full_name'] = $user_given_name . " " . $user_sur_name;
						$cur_user_item['full_name'] = trim($cur_user_item['full_name']);
						$cur_user_item['country'] =  (!empty($row_user_list['country']))?trim($row_user_list['country']):'';						
						$profile_added_dt =  (!empty($row_user_list['profile_added_dt']))?trim($row_user_list['profile_added_dt']):'';
						$tx_added_dt_utc = '';
						if ($profile_added_dt != '') {
							$profile_added_dt_tm = strtotime($profile_added_dt) - 32400;
							$y_utc = date('Y', $profile_added_dt_tm);
							$m_utc = date('m', $profile_added_dt_tm);	
							$d_utc = date('d', $profile_added_dt_tm);
							$giophutgiay_utc = date('H:i:s', $profile_added_dt_tm);
							$tx_added_dt_utc =  $y_utc . "-" . $m_utc . "-" . $d_utc . "T" . $giophutgiay_utc . "Z";
						}
						$cur_user_item['signup_dt'] = $tx_added_dt_utc;
						$usdt_wallet_balance =  (!empty($row_user_list['balance']))?trim($row_user_list['balance']):0;
						if ($usdt_wallet_balance == 0)
							$usdt_wallet_balance = number_format(0, 8, '.', ',');
						
						$cur_user_item['wallet'] = array('currency' => 'USDT', 'balance' => $usdt_wallet_balance);
						$ret_user_list[] = $cur_user_item;
						
					}					
					
				}
				
				
			} else {
				_log("", "could not connect db !");
				//@mysqli_close($dbhandle);
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'system is under maintenance.');
				header('Content-Type: application/json');
				echo json_encode($ret_rs);
				die();
			}
			
			
			@mysqli_close($dbhandle);	
			$ret_rs['result'] = 'success';
			$ret_rs['merchant'] = $req_partner['partner'];
			if (count($ret_user_list) > 0) {
				$ret_rs['userListResponse'] = $ret_user_list;									
				
			} else {
				$ret_rs['userListResponse'] = array();
			}
			
			header('Content-Type: application/json');
			echo json_encode($ret_rs);
			die();
			
		} else {
			$ret_rs['result'] = 'failed';
			$ret_rs['error'] = $errors[0];
			_log("", $ret_rs['error']['errorMessage']);	
			header('Content-Type: application/json');
			echo json_encode($ret_rs);
			die();
		}
				
		

	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405); 
	die();
}
	
   


?>