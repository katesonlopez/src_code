import React, { useEffect } from "react";

const OneTimeNotification = ({ showModal, closeModal }) => {
  useEffect(() => {
    if (showModal) {
      document.getElementById("boostrapModalLunch").click();
    }
  }, [showModal]);

  return (
    <div className="d-flex justify-content-center align-items-center">
      <button
        type="button"
        className="btn btn-primary"
        data-bs-toggle="modal"
        data-bs-target="#notificationModal"
        id="boostrapModalLunch"
        hidden={true}
      >
        Launch demo modal
      </button>

      <div
        className="modal fade"
        id="notificationModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
        data-bs-backdrop="static"
      >
        <div className="modal-dialog" style={{ zIndex: 1001 }}>
          <div className="modal-content">
            <div className="modal-header bg-info text-white">
              <h5 className="modal-title" id="exampleModalLabel">
                Important Notices:
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body p-4">
              <h4 className=" fw-bold mb-2 center text-center">
                Notice of a routine maintenance <br />
                {/* <sub className="">(Wednesday, 02 Oct 2024 13:30 - 04 Oct 2024 13:30 (UTC))</sub> */}
              </h4>
              {/* <p className="mt-3 mb-2">
                Bos is going to execute a routine maintenance soon.
              </p>
              <p className="mb-2">
                The maintenance will be started from:  <br/><strong className="ms-4">Friday, 20 Sep 2024 02:00 UTC</strong><br/>
                Estimated to be completed on or before: <br/><strong className="ms-4">Friday, 20 Sep 2024 02:30 UTC</strong><br/>
              </p> */}
              <p className="">
                We are currently undergoing system maintenance. This maintenance
                is expected to take 24-48 hours. All dashboard services will be
                unavailable during this maintenance time.
                <br />
                We are sorry for this inconvenience.
                <br />
              </p>
              <p className="text-end me-4">
                Bos Team
                <br />
              </p>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-info text-white"
                data-bs-dismiss="modal"
              >
                I understand
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OneTimeNotification;
