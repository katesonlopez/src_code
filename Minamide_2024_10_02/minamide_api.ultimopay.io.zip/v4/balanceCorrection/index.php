<?php

require_once("../include/cognito.php");
require_once("../include/graphQL_api.php");
require_once("../include/from_ultimopay_db.php");

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding ( "UTF-8" );
date_default_timezone_set('Asia/Tokyo');
if (!function_exists('getallheaders'))  {
    function getallheaders()
    {
        if (!is_array($_SERVER)) {
            return array();
        }

        $headers = array();
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(
                    ' ', '-', ucwords(
                    strtolower(
                        str_replace(
                            '_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

function _log($email, $line) {
    // Determine the log file path based on the operating system
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // Windows
        if ($email == "") {
            $logFilePath = 'C:' . DIRECTORY_SEPARATOR . '_balanceCorrection.log';
        } else {
            $logFilePath = 'C:' . DIRECTORY_SEPARATOR . $email . '_balanceCorrection.log';
        }
    } else {
        // Non-Windows (e.g., Unix/Linux)
        if ($email == "") {
            $logFilePath = '/var/www/api.ultimopay.io/v4/balanceCorrection/log/balanceCorrection.log';
        } else {
            $logFilePath = '/var/www/api.ultimopay.io/v4/balanceCorrection/log/' . $email . '.log';
        }
    }

    // Open the log file for appending (or create it if it doesn't exist)
    $fh2 = fopen($logFilePath, 'a');

    if ($fh2) {
        $fLine = date('[Ymd H:i:s] ') . $line . "\n";

        // Write the log line to the file
        fwrite($fh2, $fLine);

        // Close the log file
        fclose($fh2);
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../include/dbconfig.php';
    $dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (mysqli_connect_errno() != 0) {
        header('Content-Type: application/json');
        http_response_code(500);
        $ret_rs['result'] = 'failed';
        $ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
        echo json_encode($ret_rs);
        die();
    } else {
        _log("", "ket noi thanh cong");
        mysqli_query($dbhandle, "set names utf8;");
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
    $clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
    $clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
    $clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
    $clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
    $clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
    $clientSecret4 = 'climbpot api access key';
    $clientSecret4_sandbox = 'climbpot (sandbox) api access key';
    $apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
    $apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
    $apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
    $apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
    $apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
    $apikey5 = 'ApiKey ' . base64_encode(''/*$clientId5*/ . ':' . ''/*$clientSecret5*/);
    $apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
    $apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
    $apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
    $apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
    $found = 0;
    $coin = 'USDT';
    $sandbox = 0;
    $partner = "";
    $allowed_deposit_currency_arr = array('USDT');
    $req_api_key = "";
    $req_partner = array('partner' => '', 'api_key' => '', 'website' => '');

    foreach (getallheaders() as $name => $value) {
        if ($name == 'Authorization') {
            $req_api_key = trim($value);
            $get_partner_sql = "SELECT * FROM cryptocash_partner_master";
            $partner_rs = mysqli_query($dbhandle, $get_partner_sql);
            if (mysqli_num_rows($partner_rs) > 0) {
                while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
                    $cur_api_key = "Bearer " . $row_partner['api_key'];
                    if ($req_api_key == $cur_api_key) {
                        $req_partner['partner'] = trim($row_partner['partner']);
                        $req_partner['api_key'] = trim($row_partner['api_key']);
                        $req_partner['website'] = trim($row_partner['website']);
                        $selected_api_key = $req_api_key;
                        break;
                    }
                }
            } else {
                _log("", "not found in db");
            }
        }
    }

    function isValidPassword($password) {
        if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
            return FALSE;
        return TRUE;
    }

    if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

        $json = file_get_contents('php://input');
        $strJSON = preg_replace('/\: *([0-9]+\.?[0-9e+\-]*)/', ':"\\1"', $json);
        $data = json_decode($strJSON, true );
        if (!($data)) {

            switch (json_last_error()) {
                case JSON_ERROR_DEPTH:
                    _log("", 'Reached the maximum stack depth');
                    break;
                case JSON_ERROR_STATE_MISMATCH:
                    _log("", 'Incorrect discharges or mismatch mode');
                    break;
                case JSON_ERROR_CTRL_CHAR:
                    _log("", 'Incorrect control character');
                    break;
                case JSON_ERROR_SYNTAX:
                    _log("", 'Syntax error or JSON invalid');
                    break;
                case JSON_ERROR_UTF8:
                    _log("", 'Invalid UTF-8 characters, possibly invalid encoding');
                    break;
                default:
                    _log("", 'Unknown error');
                    break;
            }

            _log("", 'A non-empty request body is required.');
            header('Content-Type: application/json');
            http_response_code(400);
            $ret_rs['result'] = 'failed';
            $ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'A non-empty request body is required.');
            echo json_encode($ret_rs);
            die();

        } else {
            unset($errors);
            $errors = array();

            //email
            if ((!isset($data['email_address'])) || (empty($data['email_address']))) {
                $error_obj = array('errorCode' => 2, 'errorMessage' => 'email_address parameter is required.');
                $errors[] = $error_obj;
            }

            //auth_token
            if ((!isset($data['auth_token'])) || (empty($data['auth_token']))) {
                $error_obj = array('errorCode' => 3, 'errorMessage' => 'auth_token parameter is required.');
                $errors[] = $error_obj;
            }

            //amount
            if ((!isset($data['amount'])) || (empty($data['amount']))) {
                $error_obj = array('errorCode' => 4, 'errorMessage' => 'amount parameter is required.');
                $errors[] = $error_obj;
            }

            //comment
            if ((!isset($data['comment'])) || (empty($data['comment']))) {
                $error_obj = array('errorCode' => 5, 'errorMessage' => 'comment parameter is required.');
                $errors[] = $error_obj;
            }

            //currency
            if ((!isset($data['currency'])) || (empty($data['currency']))) {
                $error_obj = array('errorCode' => 6, 'errorMessage' => 'currency parameter is required.');
                $errors[] = $error_obj;
            }

            //version
            if ((!isset($data['version'])) || (empty($data['version']))) {
                $error_obj = array('errorCode' => 14, 'errorMessage' => 'version parameter is required.');
                $errors[] = $error_obj;
            }
            else if( $data['version'] != "sec.2.0.0.1"){
                $error_obj = array('errorCode' => 15, 'errorMessage' => 'Provided invalid version parameter value.');
                $errors[] = $error_obj;
            }

            if (count($errors) == 0) {

                $errors_sub = array();

                //proceed to shift api
                require_once '../include/common.php';
                ////////////////////////////////////////////////////
                //receive POST params
                $reg_email_address = trim($data['email_address']);
                $private_key = trim($data['auth_token']);
                $amount = trim($data['amount']);
                $currency = trim($data['currency']);
                $comment = trim($data['comment']);
                _log($reg_email_address, "balance correction started...");

                $allow_access_api = 0;
                $my_db_private_key = '';
                $my_db_auth_token = '';
                $my_db_sigin_dt = '';
                $my_db_token_refresh_dt = '';
                $my_db_shift_user_id = '';
                $my_currency_wallet = array('currency' => '', 'user_id' => '', 'account_id' => '');
                $my_debit_card_info = array('debit_card_id' => '', 'acc_no' => '', 'card_num' => '');

                $sql_check_signin = "select a.*, b.*, c.debit_card_id, c.acc_no, c.debit_card_num 
                                        from cryptocash_merchant_user_signin a, cryptocash_shift_wallet b, cryptocash_jdb_debit_card c 
                                        where a.email_address = '$reg_email_address' 
                                          AND a.merchant='" . $req_partner['partner'] . "' 
                                          AND a.email_address = b.shift_login_email";
                _log($reg_email_address, $sql_check_signin);
                $rs_check_signin = mysqli_query($dbhandle, $sql_check_signin);
                if (mysqli_num_rows($rs_check_signin) > 0) { //allow access API
                    $allow_access_api = 1;
                    while ($row_signin = mysqli_fetch_array($rs_check_signin, MYSQLI_ASSOC)) {
                        $my_db_auth_token = trim($row_signin['auth_token']);
                        $my_db_sigin_dt = $row_signin['signin_dt'];
                        $my_db_token_refresh_dt = $row_signin['token_refresh_dt'];
                        $my_db_private_key = trim($row_signin['private_key']);
                        if ($my_db_shift_user_id == '') {
                            $my_db_shift_user_id = trim($row_signin['shift_user_sub_id']);
                        }
                        if (strtoupper(trim($row_signin['shift_account_currency'])) == $currency) {
                            $my_currency_wallet['currency'] = strtoupper(trim($row_signin['shift_account_currency']));
                            $my_currency_wallet['user_id'] = trim($row_signin['shift_user_sub_id']);
                            $my_currency_wallet['account_id'] = trim($row_signin['shift_account_id']);
                        }
                        if (($my_debit_card_info['acc_no'] == '') && ($my_debit_card_info['card_num'] == '')) {
                            $my_debit_card_info['debit_card_id'] = trim($row_signin['debit_card_id']);
                            $my_debit_card_info['acc_no'] = trim($row_signin['acc_no']);
                            $my_debit_card_info['card_num'] = trim($row_signin['debit_card_num']);
                        }
                    }
                }

                if ($allow_access_api == 1) {

                    if ($private_key != $my_db_private_key) {
                        @mysqli_close($dbhandle);
                        header('Content-Type: application/json');
                        http_response_code(500);
                        $ret_rs['result'] = 'failed';
                        $ret_rs['error'] = array('errorCode' => 8, 'errorMessage' => 'Unauthorized.');
                        echo json_encode($ret_rs);
                        die();
                    }
                    else {
                        if (($my_debit_card_info['acc_no'] == '') || ($my_debit_card_info['card_num'] == '')) {
                            @mysqli_close($dbhandle);
                            header('Content-Type: application/json');
                            http_response_code(500);
                            $ret_rs['result'] = 'failed';
                            $ret_rs['email_address'] = $reg_email_address;
                            $ret_rs['error'] = array('errorCode' => 9, 'errorMessage' => 'Balance correction failed: no debit card data found for this user.');
                            echo json_encode($ret_rs);
                            die();
                        } else {

                            // Todo get admin authToken
                            $adminAuthToken = '';
                            _log($reg_email_address, "::try call getAdminAuthToken api...");
                            $admin_auth_res = _cognito_getAdminAuthToken();
                            if ($admin_auth_res['data'] != null) {
                                _log($reg_email_address, "::call getAdminAuthToken api success.");
                                $adminAuthToken = $admin_auth_res['data'];
                                _log($reg_email_address, $adminAuthToken);
                            }
                            else {
                                _log($reg_email_address, "::failed getting admin auth token!");
                                @mysqli_close($dbhandle);
                                header('Content-Type: application/json');
                                http_response_code(500);
                                $ret_rs['result'] = 'failed';
                                $ret_rs['error'] = array('errorCode' => 10, 'errorMessage' => 'error occurred. please contact administrator for help.');
                                echo json_encode($ret_rs);
                                die();
                            }

                            // Todo get user's info
                            $user_id = _ultimopay_db_get_user_id($dbhandle, $reg_email_address);
                            _log($reg_email_address, "::try call _ultimopay_db_get_user_id api...");
                            if ( $user_id == null ) {
                                _log($reg_email_address, "::_ultimopay_db_get_user_id execution failed.");
                                $error_code = 11;
                                $error_message = 'There is no registered user in shift with '.$reg_email_address;

                                @mysqli_close($dbhandle);
                                header('Content-Type: application/json');
                                http_response_code(400);
                                $ret_rs['result'] = 'failed';
                                $ret_rs['error'] = array('errorCode' => $error_code, 'errorMessage' => $error_message);
                                echo json_encode($ret_rs);
                                die();
                            }

                            // Todo change user's balance
                            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            _log($reg_email_address, "::Configurator Account logged in successful. Try execute balancecorrection...");
                            _log($reg_email_address, "userId: ".$user_id);
                            _log($reg_email_address, "currency: ".$currency);
                            _log($reg_email_address, "amount: ".$amount);
                            _log($reg_email_address, "comment: ".$comment);

                            //execute balance correction here
                            $balance_correction_res = _shift_balanceCorrection(
                                $adminAuthToken,
                                $user_id,
                                $currency,
                                $amount,
                                'manual',
                                $comment
                            );
                            if (($balance_correction_res['http_code'] == "200") || ($balance_correction_res['http_code'] == "200 OK")) {
                                _log($reg_email_address , "::executed balanceCorrection successful.");
                                @mysqli_close($dbhandle);
                                $ret_rs['result'] = 'success';
                                $ret_rs['email_address'] = $reg_email_address;
                                header('Content-Type: application/json');
                            }
                            else  {
                                _log($reg_email_address, "::balanceCorrection execution failed");

                                $error_message = $balance_correction_res['message'];
                                $error_code = 13;

                                @mysqli_close($dbhandle);
                                header('Content-Type: application/json');
                                http_response_code(400);
                                $ret_rs['result'] = 'failed';
                                $ret_rs['error'] = array(
                                    'errorCode' => $error_code,
                                    'errorMessage' => $error_message);
                            }
                            echo json_encode($ret_rs);
                            die();
                        }
                    }
                }
                else {
                    @mysqli_close($dbhandle);
                    header('Content-Type: application/json');
                    http_response_code(500);
                    $ret_rs['result'] = 'failed';
                    $ret_rs['error'] = array('errorCode' => 7, 'errorMessage' => 'you must sign in to use this API.');
                    echo json_encode($ret_rs);
                    die();
                }
            }
            else {
                $ret_rs['result'] = 'failed';
                $ret_rs['error'] = $errors[0];
                _log("", $ret_rs['error']['errorMessage']);
                header('Content-Type: application/json');
                echo json_encode($ret_rs);
                die();
            }
        }
    }
    else {
        header('HTTP/1.0 403 Forbidden');
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
    http_response_code(405);
    die();
}
