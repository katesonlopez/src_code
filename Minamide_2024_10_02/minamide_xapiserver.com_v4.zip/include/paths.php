<?php
define("ULTIMOPAY_WEB_ROOT", "/usr/share/nginx/dev-dash.ultimopay.io");
define("XEXON_WEB_ROOT", "/usr/share/nginx/dev-dash.xexon.io");
define("XEXON_DASHBOARD_URL", "https://dashboard.xexon.io/");
define("ULTIMOPAY_DASHBOARD_URL", "https://dashboard.ultimopay.io/");
?><?php
