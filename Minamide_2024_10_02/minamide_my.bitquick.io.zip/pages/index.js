import Link from "next/link";
import { useRouter } from "next/router";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { userService, alertService, constService } from "/services";
import Main from "./layout/Main";
import Swal from "sweetalert2";
import { useState, useEffect, useRef } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import cookie from "js-cookie";

export default function login() {
  const router = useRouter();
  const [showNewField, setShowNewField] = useState(false);
  const input2faRef = useRef(null);
  const [isLoad, setisLoad] = useState(false);
  const [showModal, setShowModal] = useState(true);
  const [isDisabled, setIsDisabled] = useState(constService.IsMaintenance);
  const validationSchema = Yup.object().shape({
    email_address: Yup.string()
      .email("Please enter a valid email address")
      .required("Email is required"),
    password: Yup.string()
      .required("No password provided.")
      .notOneOf(["http", "script"], "Invalid input")
      .matches(/^(?![<>]).*$/, "Invalid input")
  });
  const formOptions = {
    resolver: yupResolver(validationSchema),
    defaultValues: {
      two_fa_code: "",
      all_error: "",
      auth_token: ""
    }
  };
  const { register, handleSubmit, formState, setError } = useForm(formOptions);
  const { errors } = formState;

  // Clear all storage variables
  const clearLocalStorage = () => {
    if (typeof window !== "undefined") {
      window.localStorage.clear();
    }
  };

  useEffect(() => {
    let mainForm = document.querySelector(`.main-frm`);
    console.log(mainForm);
  }, []);

  useEffect(() => {
    // Clear all storage variables
    clearLocalStorage();

    // Focus to 2FA input
    if (showNewField && input2faRef.current) {
      input2faRef.current.focus();
    }
  }, [showNewField]);

  useEffect(() => {
    setShowModal(true);
  }, []);

  async function onSubmit(user) {
    localStorage.setItem("beforeSignIn", JSON.stringify(user));

    setisLoad(true);
    user.user_check = 1;
    if (input2faRef.current) user.two_fa_code = input2faRef.current.value;

    return userService
      .runApi("signin/", user)
      .then((res) => {
        if (res.data.result === "success") {
          userService
            .runApi("check2FA/", res.data.signinResponse)
            .then((d) => {
              user.fee_group_id = process.env.NEXT_PUBLIC_FEE_GROUP_ID;
              user.limit_group_id = process.env.NEXT_PUBLIC_LIMIT_GROUP_ID;
              user.auth_token = res.data.signinResponse.auth_token;
              user.expires_second = process.env.NEXT_PUBLIC_SESSION_EXPIRE_TIME;
              user.kloginTime = Date().toLocaleString();

              localStorage.setItem("lastAccessTime", user.kloginTime);
              localStorage.setItem(
                "full_expires_second",
                res.data.signinResponse.expires_in ?? 3600
              );
              localStorage.setItem("loginTime", user.kloginTime);
              localStorage.setItem("expires_second", user.expires_second);

              if (d.data["2FAStatus"].status === "enabled") {
                setShowNewField(true);
                if (input2faRef.current)
                  user.two_fa_code = input2faRef.current.value;

                return userService.runApi("check2FAcode/", user).then((i) => {
                  if (i.data.result === "success") {
                    if (i.data["2FA_code_is_valid"]) {
                      setisLoad(true);

                      return userService
                        .runApi("changeUserSystemGroup/", user)
                        .then((i) => {
                          localStorage.setItem("user", JSON.stringify({ res }));
                          cookie.set("user", JSON.stringify({ res }), {
                            path: "/"
                          });
                          router.push({
                            pathname: "user/dashboard"
                          });
                        });
                    } else {
                      setError("two_fa_code", { message: "Invalid 2FA Code" });
                      toast.error("Invalid 2FA Code", {
                        position: toast.POSITION.TOP_RIGHT
                      });
                      setisLoad(false);
                    }
                  } else if (i.data.result === "failed") {
                    setisLoad(false);
                  }
                });
              } else {
                setisLoad(true);
                return userService
                  .runApi("changeUserSystemGroup/", user)
                  .then((i) => {
                    localStorage.setItem("user", JSON.stringify({ res }));
                    cookie.set("user", JSON.stringify({ res }), { path: "/" });
                    router.push({
                      pathname: "user/dashboard"
                    });
                  });
              }
            })
            .catch((d) => {
              setisLoad(true);
              return userService
                .runApi("changeUserSystemGroup/", user)
                .then((i) => {
                  localStorage.setItem("user", JSON.stringify({ res }));
                  localStorage.setItem("loginTime", user.kloginTime);
                  localStorage.setItem("expires_second", user.expires_second);
                  localStorage.setItem("lastAccessTime", user.kloginTime);
                  localStorage.setItem(
                    "full_expires_second",
                    res.data.signinResponse.expires_in ?? 3600
                  );
                  cookie.set("user", JSON.stringify({ res }), { path: "/" });
                  router.push({
                    pathname: "user/dashboard"
                  });
                });
            });
        } else if (res.data.result === "failed") {
          setisLoad(false);
          if (res.data.error.errorCode === 4) {
            Swal.fire({
              title: "Error",
              text: "Invalid Credentials",
              icon: "error"
            });
          } else if (res.data.error.errorCode === 8) {
            setError("email_address", { message: res.data.error.errorMessage });
          } else if (res.data.error.errorCode !== 5) {
            Swal.fire({
              title: "Error",
              text: res.data.error.errorMessage,
              icon: "error"
            });
          } else {
            Swal.fire({
              title: "Notice",
              text: "You did not complete the previous signup process. Please complete the final step.",
              icon: "warning"
            }).then(function (result) {
              const expiration = new Date().getTime() + 5 * 60 * 1000;
              return userService.runApi(`resendSignupCode/`, user).then((d) => {
                router.push({
                  pathname: "/verify-signup"
                });
                localStorage.setItem(
                  "verification-token",
                  JSON.stringify({ res, expiration })
                );
              });
            });
          }
        }
      })
      .catch(alertService.error);
  }

  return (
    <Main page="SIGN UP">
      {/*<OneTimeNotification showModal={showModal} closeModal={() => setShowModal(false)} />*/}
      <section className="height-con ">
        <div className="container relative">
          <div className="crow login-main">
            <div className="col-sm-6 m-auto col-frm">
              <div className="main-frm signup-frm">
                <h1 className="mt-4 pt-4">SIGN IN</h1>
                <form className="p-4" onSubmit={handleSubmit(onSubmit)}>
                  {showNewField && (
                    <div
                      className="alert alert-success mb-3"
                      style={{
                        fontWeight: "normal",
                        wordBreak: "break-all",
                        fontSize: "small"
                      }}
                    >
                      Please enter 2-FA Code that started by{" "}
                      <b className="font-800">BitQuick</b> in your Google
                      Authenticator mobile app
                    </div>
                  )}
                  <div className="invalid-feedback">
                    {errors.all_error?.message}
                  </div>
                  <div className="mb-4">
                    <label
                      htmlFor="exampleInputEmail1"
                      className="form-label"
                      style={{ color: "#1962A6" }}
                    >
                      Email Address
                    </label>
                    <input
                      type="email"
                      name="email_address"
                      {...register("email_address")}
                      className={`input m w-input ${
                        errors.email_address ? "is-invalid" : ""
                      }`}
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                      placeholder="Email Address"
                    />
                    <div className="invalid-feedback">
                      {errors.email_address?.message}
                    </div>
                  </div>
                  <div className="mb-4">
                    <label
                      htmlFor="exampleInputPassword1"
                      className="form-label"
                      style={{ color: "#1962A6" }}
                    >
                      Password
                    </label>
                    <input
                      type="password"
                      name="password"
                      {...register("password")}
                      className={`input m w-input ${
                        errors.password ? "is-invalid" : ""
                      }`}
                      id="exampleInputPassword1"
                      placeholder="Enter Password"
                    />
                    <div className="invalid-feedback">
                      {errors.password?.message}
                    </div>
                  </div>
                  {showNewField && (
                    <div className="mb-4">
                      <label
                        htmlFor="exampleInputNewField"
                        className="form-label"
                      >
                        2FA Code
                      </label>
                      <input
                        type="text"
                        name="two_fa_code"
                        {...register("two_fa_code")}
                        className={`form-control ${
                          errors.two_fa_code ? "is-invalid" : ""
                        }`}
                        id="exampleInputNewField"
                        placeholder="Enter 2FA Code"
                        ref={input2faRef}
                      />
                      <div className="invalid-feedback">
                        {errors.two_fa_code?.message}
                      </div>
                    </div>
                  )}
                  <div className="mt-5 mb-4 text-center">
                    <button
                      disabled={
                        isDisabled ? true : formState.isSubmitting || isLoad
                      }
                      className="btn cstm-submit py-2 w-100"
                    >
                      {formState.isSubmitting || isLoad ? (
                        <span className="spinner-border spinner-border-sm mr-1"></span>
                      ) : (
                        ""
                      )}
                      <font>Sign In</font>
                      {/* <img
                        src="assets/img/right.png"
                        width="30px;"
                        class="inline-block"
                      /> */}
                    </button>
                  </div>
                  <div
                    className="mt-2 mb-2 text-center"
                    style={{ color: "#1962A6", fontWeight: "bold" }}
                  >
                    <font className="user">New User ?</font> &nbsp;
                    <Link
                      href="/register"
                      className="font-800 text-decoration-underline"
                      style={{ color: "#fff", fontSize: "14px" }}
                    >
                      SIGN UP
                    </Link>
                  </div>
                  <div className="mb-4 text-center">
                    <Link
                      className="forgot font-800 text-decoration-underline"
                      href="/forgot-password"
                      style={{ color: "#fff" }}
                    >
                      Forgot Your Password ?
                    </Link>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="sign-bg">
          <div className="bg-img">
            {/*<img src="/assets/img/bg.png" width="100%" style={{opacity: 0.7}} alt="background"/>*/}
          </div>
        </div>
      </section>
    </Main>
  );
}
