(self.webpackChunkpaco_angular_payment_page = self.webpackChunkpaco_angular_payment_page || []).push([[461], {
  2523: (G, ce, it) => {
    "use strict";
    const Ue = ":";
    Error;
    const Ae = function (a, ...f) {
      if (Ae.translate) {
        const E = Ae.translate(a, f);
        a = E[0], f = E[1]
      }
      let p = pe(a[0], a.raw[0]);
      for (let E = 1; E < a.length; E++) p += f[E - 1] + pe(a[E], a.raw[E]);
      return p
    }, vt = ":";

    function pe(a, f) {
      return f.charAt(0) === vt ? a.substring(function de(a, f) {
        for (let p = 1, E = 1; p < a.length; p++, E++) if ("\\" === f[E]) E++; else if (a[p] === Ue) return p;
        throw new Error(`Unterminated $localize metadata block in "${f}".`)
      }(a, f) + 1) : a
    }

    globalThis.$localize = Ae, it(6935), it(2195), it(6207)
  }, 6207: () => {
    !function () {
      "use strict";
      !function () {
        if (void 0 === window.Reflect || void 0 === window.customElements || window.customElements.polyfillWrapFlushCallback) return;
        const G = HTMLElement;
        window.HTMLElement = function () {
          return Reflect.construct(G, [], this.constructor)
        }, HTMLElement.prototype = G.prototype, HTMLElement.prototype.constructor = HTMLElement, Object.setPrototypeOf(HTMLElement, G)
      }()
    }()
  }, 2195: () => {
    !function (G, ce) {
      "use strict";

      function it() {
        var t = Ve.splice(0, Ve.length);
        for (l = 0; t.length;) t.shift().call(null, t.shift())
      }

      function Ue(t, u) {
        for (var n = 0, s = t.length; n < s; n++) rt(t[n], u)
      }

      function ze(t) {
        return function (u) {
          te(u) && (rt(u, t), ne.length && Ue(u.querySelectorAll(ne), t))
        }
      }

      function tt(t) {
        var u = $.call(t, "is"), n = t.nodeName.toUpperCase(), s = ge.call(K, u ? b + u.toUpperCase() : E + n);
        return u && -1 < s && !nt(n, u) ? -1 : s
      }

      function nt(t, u) {
        return -1 < ne.indexOf(t + '[is="' + u + '"]')
      }

      function Lt(t) {
        var u = t.currentTarget, n = t.attrChange, s = t.attrName, e = t.target, h = t[Tt] || 2, T = t[gt] || 3;
        !Oe || e && e !== u || !u[De] || "style" === s || t.prevValue === t.newValue && ("" !== t.newValue || n !== h && n !== T) || u[De](s, n === h ? null : t.prevValue, n === T ? null : t.newValue)
      }

      function ct(t) {
        var u = ze(t);
        return function (n) {
          Ve.push(u, n.target), l && clearTimeout(l), l = setTimeout(it, 1)
        }
      }

      function at(t) {
        Fe && (Fe = !1, t.currentTarget.removeEventListener(f, at)), ne.length && Ue((t.target || z).querySelectorAll(ne), t.detail === Me ? Me : Ie), R && function Re() {
          for (var t, u = 0, n = J.length; u < n; u++) ke.contains(t = J[u]) || (n--, J.splice(u--, 1), rt(t, Me))
        }()
      }

      function Et(t, u) {
        var n = this;
        U.call(n, t, u), Xe.call(n, {target: n})
      }

      function lt(t, u, n) {
        var s = u.apply(t, n), e = tt(s);
        return -1 < e && Je(s, Q[e]), n.pop() && ne.length && function et(t) {
          for (var u, n = 0, s = t.length; n < s; n++) Je(u = t[n], Q[tt(u)])
        }(s.querySelectorAll(ne)), s
      }

      function be(t, u) {
        se(t, u), ht ? ht.observe(t, C) : (W && (t.setAttribute = Et, t[Se] = Ye(t), t[Te](p, Xe)), t[Te](a, Lt)), t[pe] && Oe && (t.created = !0, t[pe](), t.created = !1)
      }

      function Ge(t) {
        throw new Error("A " + t + " type is already registered")
      }

      function rt(t, u) {
        var n, s, e = tt(t);
        -1 < e && !S.call(t, "TEMPLATE") && (Ke(t, Q[e]), e = 0, u !== Ie || t[Ie] ? u !== Me || t[Me] || (t[Ie] = !1, t[Me] = !0, s = "disconnected", e = 1) : (t[Me] = !1, t[Ie] = !0, s = "connected", e = 1, R && ge.call(J, t) < 0 && J.push(t)), e && (n = t[u + Le] || t[s + Le]) && n.call(t))
      }

      function we() {
      }

      function Y(t, u, n) {
        var s = n && n[mt] || "", e = u.prototype, h = ee(e), T = u.observedAttributes || le, v = {prototype: h};
        y(h, pe, {
          value: function () {
            if (H) H = !1; else if (!this[m]) {
              this[m] = !0, new u(this), e[pe] && e[pe].call(this);
              var g = A[x.get(u)];
              (!d || g.create.length > 1) && ae(this)
            }
          }
        }), y(h, De, {
          value: function (g) {
            -1 < ge.call(T, g) && e[De] && e[De].apply(this, arguments)
          }
        }), e[Ae] && y(h, yt, {value: e[Ae]}), e[vt] && y(h, Mt, {value: e[vt]}), s && (v[mt] = s), t = t.toUpperCase(), A[t] = {
          constructor: u,
          create: s ? [s, B(t)] : [t]
        }, x.set(u, t), z[Ce](t.toLowerCase(), v), ut(t), k[t].r()
      }

      function qe(t) {
        var u = A[t.toUpperCase()];
        return u && u.constructor
      }

      function je(t) {
        return "string" == typeof t ? t : t && t.is || ""
      }

      function ae(t) {
        for (var u, n = t[De], s = n ? t.attributes : le, e = s.length; e--;) n.call(t, (u = s[e]).name || u.nodeName, null, u.value || u.nodeValue)
      }

      function ut(t) {
        return (t = t.toUpperCase()) in k || (k[t] = {}, k[t].p = new w(function (u) {
          k[t].r = u
        })), k[t].p
      }

      function We() {
        o && delete G.customElements, Ne(G, "customElements", {
          configurable: !0,
          value: new we
        }), Ne(G, "CustomElementRegistry", {configurable: !0, value: we});
        for (var t = ft.get(/^HTML[A-Z]*[a-z]/), u = t.length; u--; function (n) {
          var s = G[n];
          if (s) {
            G[n] = function (e) {
              var h, T;
              return e || (e = this), e[m] || (H = !0, h = A[x.get(e.constructor)], (e = (T = d && 1 === h.create.length) ? Reflect.construct(s, le, h.constructor) : z.createElement.apply(z, h.create))[m] = !0, H = !1, T || ae(e)), e
            }, G[n].prototype = s.prototype;
            try {
              s.prototype.constructor = G[n]
            } catch {
              Ne(s, m, {value: G[n]})
            }
          }
        }(t[u])) ;
        z.createElement = function (n, s) {
          var e = je(s);
          return e ? V.call(this, n, B(e)) : V.call(this, n)
        }, I || (ie = !0, z[Ce](""))
      }

      var z = G.document, ye = G.Object, ft = function (t) {
        var u, n, s, e, h = /^[A-Z]+[a-z]/, v = function (N, M) {
          (M = M.toLowerCase()) in g || (g[N] = (g[N] || []).concat(M), g[M] = g[M.toUpperCase()] = N)
        }, g = (ye.create || ye)(null), L = {};
        for (n in t) for (e in t[n]) for (g[e] = s = t[n][e], u = 0; u < s.length; u++) g[s[u].toLowerCase()] = g[s[u].toUpperCase()] = e;
        return L.get = function (N) {
          return "string" == typeof N ? g[N] || (h.test(N) ? [] : "") : function (N) {
            var M, F = [];
            for (M in g) N.test(M) && F.push(M);
            return F
          }(N)
        }, L.set = function (N, M) {
          return h.test(N) ? v(N, M) : v(M, N), L
        }, L
      }({
        collections: {
          HTMLAllCollection: ["all"],
          HTMLCollection: ["forms"],
          HTMLFormControlsCollection: ["elements"],
          HTMLOptionsCollection: ["options"]
        },
        elements: {
          Element: ["element"],
          HTMLAnchorElement: ["a"],
          HTMLAppletElement: ["applet"],
          HTMLAreaElement: ["area"],
          HTMLAttachmentElement: ["attachment"],
          HTMLAudioElement: ["audio"],
          HTMLBRElement: ["br"],
          HTMLBaseElement: ["base"],
          HTMLBodyElement: ["body"],
          HTMLButtonElement: ["button"],
          HTMLCanvasElement: ["canvas"],
          HTMLContentElement: ["content"],
          HTMLDListElement: ["dl"],
          HTMLDataElement: ["data"],
          HTMLDataListElement: ["datalist"],
          HTMLDetailsElement: ["details"],
          HTMLDialogElement: ["dialog"],
          HTMLDirectoryElement: ["dir"],
          HTMLDivElement: ["div"],
          HTMLDocument: ["document"],
          HTMLElement: ["element", "abbr", "address", "article", "aside", "b", "bdi", "bdo", "cite", "code", "command", "dd", "dfn", "dt", "em", "figcaption", "figure", "footer", "header", "i", "kbd", "mark", "nav", "noscript", "rp", "rt", "ruby", "s", "samp", "section", "small", "strong", "sub", "summary", "sup", "u", "var", "wbr"],
          HTMLEmbedElement: ["embed"],
          HTMLFieldSetElement: ["fieldset"],
          HTMLFontElement: ["font"],
          HTMLFormElement: ["form"],
          HTMLFrameElement: ["frame"],
          HTMLFrameSetElement: ["frameset"],
          HTMLHRElement: ["hr"],
          HTMLHeadElement: ["head"],
          HTMLHeadingElement: ["h1", "h2", "h3", "h4", "h5", "h6"],
          HTMLHtmlElement: ["html"],
          HTMLIFrameElement: ["iframe"],
          HTMLImageElement: ["img"],
          HTMLInputElement: ["input"],
          HTMLKeygenElement: ["keygen"],
          HTMLLIElement: ["li"],
          HTMLLabelElement: ["label"],
          HTMLLegendElement: ["legend"],
          HTMLLinkElement: ["link"],
          HTMLMapElement: ["map"],
          HTMLMarqueeElement: ["marquee"],
          HTMLMediaElement: ["media"],
          HTMLMenuElement: ["menu"],
          HTMLMenuItemElement: ["menuitem"],
          HTMLMetaElement: ["meta"],
          HTMLMeterElement: ["meter"],
          HTMLModElement: ["del", "ins"],
          HTMLOListElement: ["ol"],
          HTMLObjectElement: ["object"],
          HTMLOptGroupElement: ["optgroup"],
          HTMLOptionElement: ["option"],
          HTMLOutputElement: ["output"],
          HTMLParagraphElement: ["p"],
          HTMLParamElement: ["param"],
          HTMLPictureElement: ["picture"],
          HTMLPreElement: ["pre"],
          HTMLProgressElement: ["progress"],
          HTMLQuoteElement: ["blockquote", "q", "quote"],
          HTMLScriptElement: ["script"],
          HTMLSelectElement: ["select"],
          HTMLShadowElement: ["shadow"],
          HTMLSlotElement: ["slot"],
          HTMLSourceElement: ["source"],
          HTMLSpanElement: ["span"],
          HTMLStyleElement: ["style"],
          HTMLTableCaptionElement: ["caption"],
          HTMLTableCellElement: ["td", "th"],
          HTMLTableColElement: ["col", "colgroup"],
          HTMLTableElement: ["table"],
          HTMLTableRowElement: ["tr"],
          HTMLTableSectionElement: ["thead", "tbody", "tfoot"],
          HTMLTemplateElement: ["template"],
          HTMLTextAreaElement: ["textarea"],
          HTMLTimeElement: ["time"],
          HTMLTitleElement: ["title"],
          HTMLTrackElement: ["track"],
          HTMLUListElement: ["ul"],
          HTMLUnknownElement: ["unknown", "vhgroupv", "vkeygen"],
          HTMLVideoElement: ["video"]
        },
        nodes: {
          Attr: ["node"],
          Audio: ["audio"],
          CDATASection: ["node"],
          CharacterData: ["node"],
          Comment: ["#comment"],
          Document: ["#document"],
          DocumentFragment: ["#document-fragment"],
          DocumentType: ["node"],
          HTMLDocument: ["#document"],
          Image: ["img"],
          Option: ["option"],
          ProcessingInstruction: ["node"],
          ShadowRoot: ["#shadow-root"],
          Text: ["#text"],
          XMLDocument: ["xml"]
        }
      });
      "object" != typeof ce && (ce = {type: ce || "auto"});
      var Ve, Xe, ot, Ye, ht, dt, Ke, Je, de, t, u, n, s, e, Ce = "registerElement", Pe = 1e5 * G.Math.random() | 0,
        Se = "__" + Ce + Pe, Te = "addEventListener", Ie = "attached", Le = "Callback", Me = "detached", mt = "extends",
        De = "attributeChanged" + Le, yt = Ie + Le, Ae = "connected" + Le, vt = "disconnected" + Le,
        pe = "created" + Le, Mt = Me + Le, Tt = "ADDITION", gt = "REMOVAL", a = "DOMAttrModified",
        f = "DOMContentLoaded", p = "DOMSubtreeModified", E = "<", b = "=", P = /^[A-Z][._A-Z0-9]*-[-._A-Z0-9]*$/,
        me = ["ANNOTATION-XML", "COLOR-PROFILE", "FONT-FACE", "FONT-FACE-SRC", "FONT-FACE-URI", "FONT-FACE-FORMAT", "FONT-FACE-NAME", "MISSING-GLYPH"],
        K = [], Q = [], ne = "", ke = z.documentElement, ge = K.indexOf || function (t) {
          for (var u = this.length; u-- && this[u] !== t;) ;
          return u
        }, Ze = ye.prototype, st = Ze.hasOwnProperty, ve = Ze.isPrototypeOf, Ne = ye.defineProperty, le = [],
        $e = ye.getOwnPropertyDescriptor, kt = ye.getOwnPropertyNames, wt = ye.getPrototypeOf, _t = ye.setPrototypeOf,
        r = !!ye.__proto__, m = "__dreCEv1", o = G.customElements,
        d = !/^force/.test(ce.type) && !!(o && o.define && o.get && o.whenDefined), _ = ye.create || ye,
        O = G.Map || function () {
          var t, u = [], n = [];
          return {
            get: function (s) {
              return n[ge.call(u, s)]
            }, set: function (s, e) {
              (t = ge.call(u, s)) < 0 ? n[u.push(s) - 1] = e : n[t] = e
            }
          }
        }, w = G.Promise || function (t) {
          function u(h) {
            for (s = !0; n.length;) n.shift()(h)
          }

          var n = [], s = !1, e = {
            catch: function () {
              return e
            }, then: function (h) {
              return n.push(h), s && setTimeout(u, 1), e
            }
          };
          return t(u), e
        }, H = !1, A = _(null), k = _(null), x = new O, B = function (t) {
          return t.toLowerCase()
        }, ee = ye.create || function t(u) {
          return u ? (t.prototype = u, new t) : this
        }, se = _t || (r ? function (t, u) {
          return t.__proto__ = u, t
        } : kt && $e ? function () {
          function t(u, n) {
            for (var s, e = kt(n), h = 0, T = e.length; h < T; h++) st.call(u, s = e[h]) || Ne(u, s, $e(n, s))
          }

          return function (u, n) {
            do {
              t(u, n)
            } while ((n = wt(n)) && !ve.call(n, u));
            return u
          }
        }() : function (t, u) {
          for (var n in u) t[n] = u[n];
          return t
        }), ue = G.MutationObserver || G.WebKitMutationObserver, _e = G.HTMLAnchorElement,
        q = (G.HTMLElement || G.Element || G.Node).prototype, R = !ve.call(q, ke), y = R ? function (t, u, n) {
          return t[u] = n.value, t
        } : Ne, te = R ? function (t) {
          return 1 === t.nodeType
        } : function (t) {
          return ve.call(q, t)
        }, J = R && [], fe = q.attachShadow, re = q.cloneNode, S = q.closest || function (t) {
          for (var u = this; u && u.nodeName !== t;) u = u.parentNode;
          return u
        }, oe = q.dispatchEvent, $ = q.getAttribute, Z = q.hasAttribute, D = q.removeAttribute, U = q.setAttribute,
        Ee = z.createElement, he = z.importNode, V = Ee,
        C = ue && {attributes: !0, characterData: !0, attributeOldValue: !0}, i = ue || function (t) {
          W = !1, ke.removeEventListener(a, i)
        }, l = 0, I = Ce in z && !/^force-all/.test(ce.type), j = !0, ie = !1, W = !0, Fe = !0, Oe = !0;
      if (ue && ((de = z.createElement("div")).innerHTML = "<div><div></div></div>", new ue(function (t, u) {
        if (t[0] && "childList" == t[0].type && !t[0].removedNodes[0].childNodes.length) {
          var n = (de = $e(q, "innerHTML")) && de.set;
          n && Ne(q, "innerHTML", {
            set: function (s) {
              for (; this.lastChild;) this.removeChild(this.lastChild);
              n.call(this, s)
            }
          })
        }
        u.disconnect(), de = null
      }).observe(de, {childList: !0, subtree: !0}), de.innerHTML = ""), I || (_t || r ? (Ke = function (t, u) {
        ve.call(u, t) || be(t, u)
      }, Je = be) : (Ke = function (t, u) {
        t[Se] || (t[Se] = ye(!0), be(t, u))
      }, Je = Ke), R ? (W = !1, t = $e(q, Te), u = t.value, n = function (h) {
        var T = new CustomEvent(a, {bubbles: !0});
        T.attrName = h, T.prevValue = $.call(this, h), T.newValue = null, T[gt] = T.attrChange = 2, D.call(this, h), oe.call(this, T)
      }, s = function (h, T) {
        var v = Z.call(this, h), g = v && $.call(this, h), L = new CustomEvent(a, {bubbles: !0});
        U.call(this, h, T), L.attrName = h, L.prevValue = v ? g : null, L.newValue = T, v ? L.MODIFICATION = L.attrChange = 1 : L[Tt] = L.attrChange = 0, oe.call(this, L)
      }, e = function (h) {
        var T, v = h.currentTarget, g = v[Se], L = h.propertyName;
        g.hasOwnProperty(L) && (g = g[L], (T = new CustomEvent(a, {bubbles: !0})).attrName = g.name, T.prevValue = g.value || null, T.newValue = g.value = v[L] || null, null == T.prevValue ? T[Tt] = T.attrChange = 0 : T.MODIFICATION = T.attrChange = 1, oe.call(v, T))
      }, t.value = function (h, T, v) {
        h === a && this[De] && this.setAttribute !== s && (this[Se] = {
          className: {
            name: "class",
            value: this.className
          }
        }, this.setAttribute = s, this.removeAttribute = n, u.call(this, "propertychange", e)), u.call(this, h, T, v)
      }, Ne(q, Te, t)) : ue || (ke[Te](a, i), ke.setAttribute(Se, 1), ke.removeAttribute(Se), W && (Xe = function (t) {
        var u, n, s, e = this;
        if (e === t.target) {
          for (s in u = e[Se], e[Se] = n = Ye(e), n) {
            if (!(s in u)) return ot(0, e, s, u[s], n[s], Tt);
            if (n[s] !== u[s]) return ot(1, e, s, u[s], n[s], "MODIFICATION")
          }
          for (s in u) if (!(s in n)) return ot(2, e, s, u[s], n[s], gt)
        }
      }, ot = function (t, u, n, s, e, h) {
        var T = {attrChange: t, currentTarget: u, attrName: n, prevValue: s, newValue: e};
        T[h] = t, Lt(T)
      }, Ye = function (t) {
        for (var u, n, s = {}, e = t.attributes, h = 0, T = e.length; h < T; h++) "setAttribute" !== (n = (u = e[h]).name) && (s[n] = u.value);
        return s
      })), z[Ce] = function (t, u) {
        if (n = t.toUpperCase(), j && (j = !1, ue ? (ht = function (g, L) {
          function N(M, F) {
            for (var X = 0, xe = M.length; X < xe; F(M[X++])) ;
          }

          return new ue(function (M) {
            for (var F, X, xe, He = 0, pt = M.length; He < pt; He++) "childList" === (F = M[He]).type ? (N(F.addedNodes, g), N(F.removedNodes, L)) : (X = F.target, Oe && X[De] && "style" !== F.attributeName && (xe = $.call(X, F.attributeName)) !== F.oldValue && X[De](F.attributeName, F.oldValue, xe))
          })
        }(ze(Ie), ze(Me)), (dt = function (g) {
          return ht.observe(g, {childList: !0, subtree: !0}), g
        })(z), fe && (q.attachShadow = function () {
          return dt(fe.apply(this, arguments))
        })) : (Ve = [], z[Te]("DOMNodeInserted", ct(Ie)), z[Te]("DOMNodeRemoved", ct(Me))), z[Te](f, at), z[Te]("readystatechange", at), z.importNode = function (g, L) {
          switch (g.nodeType) {
            case 1:
              return lt(z, he, [g, !!L]);
            case 11:
              for (var N = z.createDocumentFragment(), M = g.childNodes, F = M.length, X = 0; X < F; X++) N.appendChild(z.importNode(M[X], !!L));
              return N;
            default:
              return re.call(g, !!L)
          }
        }, q.cloneNode = function (g) {
          return lt(this, re, [!!g])
        }), ie) return ie = !1;
        if (-2 < ge.call(K, b + n) + ge.call(K, E + n) && Ge(t), !P.test(n) || -1 < ge.call(me, n)) throw new Error("The type " + t + " is invalid");
        var n, s, e = function () {
          return T ? z.createElement(v, n) : z.createElement(v)
        }, h = u || Ze, T = st.call(h, mt), v = T ? u[mt].toUpperCase() : n;
        return T && -1 < ge.call(K, E + v) && Ge(v), s = K.push((T ? b : E) + n) - 1, ne = ne.concat(ne.length ? "," : "", T ? v + '[is="' + t.toLowerCase() + '"]' : v), e.prototype = Q[s] = st.call(h, "prototype") ? h.prototype : ee(q), ne.length && Ue(z.querySelectorAll(ne), Ie), e
      }, z.createElement = V = function (t, u) {
        var n = je(u), s = n ? Ee.call(z, t, B(n)) : Ee.call(z, t), e = "" + t,
          h = ge.call(K, (n ? b : E) + (n || e).toUpperCase()), T = -1 < h;
        return n && (s.setAttribute("is", n = n.toLowerCase()), T && (T = nt(e.toUpperCase(), n))), Oe = !z.createElement.innerHTMLHelper, T && Je(s, Q[h]), s
      }), addEventListener("beforeunload", function () {
        delete z.createElement, delete z.importNode, delete z[Ce]
      }, !1), we.prototype = {
        constructor: we, define: d ? function (t, u, n) {
          if (n) Y(t, u, n); else {
            var s = t.toUpperCase();
            A[s] = {constructor: u, create: [s]}, x.set(u, s), o.define(t, u)
          }
        } : Y, get: d ? function (t) {
          return o.get(t) || qe(t)
        } : qe, whenDefined: d ? function (t) {
          return w.race([o.whenDefined(t), ut(t)])
        } : ut
      }, !o || /^force/.test(ce.type)) We(); else if (!ce.noBuiltIn) try {
        !function (t, u, n) {
          var s = new RegExp("^<a\\s+is=('|\")" + n + "\\1></a>$");
          if (u[mt] = "a", (t.prototype = ee(_e.prototype)).constructor = t, G.customElements.define(n, t, u), !s.test(z.createElement("a", {is: n}).outerHTML) || !s.test((new t).outerHTML)) throw u
        }(function t() {
          return Reflect.construct(_e, [], t)
        }, {}, "document-register-element-a" + Pe)
      } catch {
        We()
      }
      if (!ce.noBuiltIn) try {
        if (Ee.call(z, "a", "a").outerHTML.indexOf("is") < 0) throw{}
      } catch {
        B = function (u) {
          return {is: u.toLowerCase()}
        }
      }
    }(window)
  }, 6935: () => {
    "use strict";
    const G = globalThis;

    function ce(r) {
      return (G.__Zone_symbol_prefix || "__zone_symbol__") + r
    }

    const et = Object.getOwnPropertyDescriptor, ze = Object.defineProperty, tt = Object.getPrototypeOf,
      nt = Object.create, Lt = Array.prototype.slice, ct = "addEventListener", at = "removeEventListener", Et = ce(ct),
      lt = ce(at), be = "true", Re = "false", Ge = ce("");

    function rt(r, c) {
      return Zone.current.wrap(r, c)
    }

    function we(r, c, m, o, d) {
      return Zone.current.scheduleMacroTask(r, c, m, o, d)
    }

    const Y = ce, qe = typeof window < "u", je = qe ? window : void 0, ae = qe && je || globalThis,
      ut = "removeAttribute";

    function We(r, c) {
      for (let m = r.length - 1; m >= 0; m--) "function" == typeof r[m] && (r[m] = rt(r[m], c + "_" + m));
      return r
    }

    function ye(r) {
      return !r || !1 !== r.writable && !("function" == typeof r.get && typeof r.set > "u")
    }

    const ft = typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope,
      Ve = !("nw" in ae) && typeof ae.process < "u" && "[object process]" === ae.process.toString(),
      Xe = !Ve && !ft && !(!qe || !je.HTMLElement),
      ot = typeof ae.process < "u" && "[object process]" === ae.process.toString() && !ft && !(!qe || !je.HTMLElement),
      Ye = {}, ht = Y("enable_beforeunload"), dt = function (r) {
        if (!(r = r || ae.event)) return;
        let c = Ye[r.type];
        c || (c = Ye[r.type] = Y("ON_PROPERTY" + r.type));
        const m = this || r.target || ae, o = m[c];
        let d;
        return Xe && m === je && "error" === r.type ? (d = o && o.call(this, r.message, r.filename, r.lineno, r.colno, r.error), !0 === d && r.preventDefault()) : (d = o && o.apply(this, arguments), "beforeunload" === r.type && ae[ht] && "string" == typeof d ? r.returnValue = d : null != d && !d && r.preventDefault()), d
      };

    function Ke(r, c, m) {
      let o = et(r, c);
      if (!o && m && et(m, c) && (o = {enumerable: !0, configurable: !0}), !o || !o.configurable) return;
      const d = Y("on" + c + "patched");
      if (r.hasOwnProperty(d) && r[d]) return;
      delete o.writable, delete o.value;
      const _ = o.get, O = o.set, w = c.slice(2);
      let H = Ye[w];
      H || (H = Ye[w] = Y("ON_PROPERTY" + w)), o.set = function (A) {
        let k = this;
        !k && r === ae && (k = ae), k && ("function" == typeof k[H] && k.removeEventListener(w, dt), O && O.call(k, null), k[H] = A, "function" == typeof A && k.addEventListener(w, dt, !1))
      }, o.get = function () {
        let A = this;
        if (!A && r === ae && (A = ae), !A) return null;
        const k = A[H];
        if (k) return k;
        if (_) {
          let x = _.call(this);
          if (x) return o.set.call(this, x), "function" == typeof A[ut] && A.removeAttribute(c), x
        }
        return null
      }, ze(r, c, o), r[d] = !0
    }

    function Je(r, c, m) {
      if (c) for (let o = 0; o < c.length; o++) Ke(r, "on" + c[o], m); else {
        const o = [];
        for (const d in r) "on" == d.slice(0, 2) && o.push(d);
        for (let d = 0; d < o.length; d++) Ke(r, o[d], m)
      }
    }

    const de = Y("originalInstance");

    function Ce(r) {
      const c = ae[r];
      if (!c) return;
      ae[Y(r)] = c, ae[r] = function () {
        const d = We(arguments, r);
        switch (d.length) {
          case 0:
            this[de] = new c;
            break;
          case 1:
            this[de] = new c(d[0]);
            break;
          case 2:
            this[de] = new c(d[0], d[1]);
            break;
          case 3:
            this[de] = new c(d[0], d[1], d[2]);
            break;
          case 4:
            this[de] = new c(d[0], d[1], d[2], d[3]);
            break;
          default:
            throw new Error("Arg list too long.")
        }
      }, Te(ae[r], c);
      const m = new c(function () {
      });
      let o;
      for (o in m) "XMLHttpRequest" === r && "responseBlob" === o || function (d) {
        "function" == typeof m[d] ? ae[r].prototype[d] = function () {
          return this[de][d].apply(this[de], arguments)
        } : ze(ae[r].prototype, d, {
          set: function (_) {
            "function" == typeof _ ? (this[de][d] = rt(_, r + "." + d), Te(this[de][d], _)) : this[de][d] = _
          }, get: function () {
            return this[de][d]
          }
        })
      }(o);
      for (o in c) "prototype" !== o && c.hasOwnProperty(o) && (ae[r][o] = c[o])
    }

    function Pe(r, c, m) {
      let o = r;
      for (; o && !o.hasOwnProperty(c);) o = tt(o);
      !o && r[c] && (o = r);
      const d = Y(c);
      let _ = null;
      if (o && (!(_ = o[d]) || !o.hasOwnProperty(d)) && (_ = o[d] = o[c], ye(o && et(o, c)))) {
        const w = m(_, d, c);
        o[c] = function () {
          return w(this, arguments)
        }, Te(o[c], _)
      }
      return _
    }

    function Se(r, c, m) {
      let o = null;

      function d(_) {
        const O = _.data;
        return O.args[O.cbIdx] = function () {
          _.invoke.apply(this, arguments)
        }, o.apply(O.target, O.args), _
      }

      o = Pe(r, c, _ => function (O, w) {
        const H = m(O, w);
        return H.cbIdx >= 0 && "function" == typeof w[H.cbIdx] ? we(H.name, w[H.cbIdx], H, d) : _.apply(O, w)
      })
    }

    function Te(r, c) {
      r[Y("OriginalDelegate")] = c
    }

    let Ie = !1, Le = !1;

    function mt() {
      if (Ie) return Le;
      Ie = !0;
      try {
        const r = je.navigator.userAgent;
        (-1 !== r.indexOf("MSIE ") || -1 !== r.indexOf("Trident/") || -1 !== r.indexOf("Edge/")) && (Le = !0)
      } catch {
      }
      return Le
    }

    function De(r) {
      return "function" == typeof r
    }

    function yt(r) {
      return "number" == typeof r
    }

    let Ae = !1;
    if (typeof window < "u") try {
      const r = Object.defineProperty({}, "passive", {
        get: function () {
          Ae = !0
        }
      });
      window.addEventListener("test", r, r), window.removeEventListener("test", r, r)
    } catch {
      Ae = !1
    }
    const vt = {useG: !0}, pe = {}, Mt = {}, Tt = new RegExp("^" + Ge + "(\\w+)(true|false)$"),
      gt = Y("propagationStopped");

    function a(r, c) {
      const m = (c ? c(r) : r) + Re, o = (c ? c(r) : r) + be, d = Ge + m, _ = Ge + o;
      pe[r] = {}, pe[r][Re] = d, pe[r][be] = _
    }

    function f(r, c, m, o) {
      const d = o && o.add || ct, _ = o && o.rm || at, O = o && o.listeners || "eventListeners",
        w = o && o.rmAll || "removeAllListeners", H = Y(d), A = "." + d + ":", k = "prependListener", x = "." + k + ":",
        B = function (R, y, te) {
          if (R.isRemoved) return;
          const J = R.callback;
          let fe;
          "object" == typeof J && J.handleEvent && (R.callback = S => J.handleEvent(S), R.originalDelegate = J);
          try {
            R.invoke(R, y, [te])
          } catch (S) {
            fe = S
          }
          const re = R.options;
          return re && "object" == typeof re && re.once && y[_].call(y, te.type, R.originalDelegate ? R.originalDelegate : R.callback, re), fe
        };

      function ee(R, y, te) {
        if (!(y = y || r.event)) return;
        const J = R || y.target || r, fe = J[pe[y.type][te ? be : Re]];
        if (fe) {
          const re = [];
          if (1 === fe.length) {
            const S = B(fe[0], J, y);
            S && re.push(S)
          } else {
            const S = fe.slice();
            for (let oe = 0; oe < S.length && (!y || !0 !== y[gt]); oe++) {
              const $ = B(S[oe], J, y);
              $ && re.push($)
            }
          }
          if (1 === re.length) throw re[0];
          for (let S = 0; S < re.length; S++) {
            const oe = re[S];
            c.nativeScheduleMicroTask(() => {
              throw oe
            })
          }
        }
      }

      const se = function (R) {
        return ee(this, R, !1)
      }, ue = function (R) {
        return ee(this, R, !0)
      };

      function _e(R, y) {
        if (!R) return !1;
        let te = !0;
        y && void 0 !== y.useG && (te = y.useG);
        const J = y && y.vh;
        let fe = !0;
        y && void 0 !== y.chkDup && (fe = y.chkDup);
        let re = !1;
        y && void 0 !== y.rt && (re = y.rt);
        let S = R;
        for (; S && !S.hasOwnProperty(d);) S = tt(S);
        if (!S && R[d] && (S = R), !S || S[H]) return !1;
        const oe = y && y.eventNameToString, $ = {}, Z = S[H] = S[d], D = S[Y(_)] = S[_], U = S[Y(O)] = S[O],
          Ee = S[Y(w)] = S[w];
        let he;
        y && y.prepend && (he = S[Y(y.prepend)] = S[y.prepend]);
        const ie = te ? function (e) {
          if (!$.isExisting) return Z.call($.target, $.eventName, $.capture ? ue : se, $.options)
        } : function (e) {
          return Z.call($.target, $.eventName, e.invoke, $.options)
        }, W = te ? function (e) {
          if (!e.isRemoved) {
            const h = pe[e.eventName];
            let T;
            h && (T = h[e.capture ? be : Re]);
            const v = T && e.target[T];
            if (v) for (let g = 0; g < v.length; g++) if (v[g] === e) {
              v.splice(g, 1), e.isRemoved = !0, e.removeAbortListener && (e.removeAbortListener(), e.removeAbortListener = null), 0 === v.length && (e.allRemoved = !0, e.target[T] = null);
              break
            }
          }
          if (e.allRemoved) return D.call(e.target, e.eventName, e.capture ? ue : se, e.options)
        } : function (e) {
          return D.call(e.target, e.eventName, e.invoke, e.options)
        }, Oe = y && y.diff ? y.diff : function (e, h) {
          const T = typeof h;
          return "function" === T && e.callback === h || "object" === T && e.originalDelegate === h
        }, t = Zone[Y("UNPATCHED_EVENTS")], u = r[Y("PASSIVE_EVENTS")], s = function (e, h, T, v, g = !1, L = !1) {
          return function () {
            const N = this || r;
            let M = arguments[0];
            y && y.transferEventName && (M = y.transferEventName(M));
            let F = arguments[1];
            if (!F) return e.apply(this, arguments);
            if (Ve && "uncaughtException" === M) return e.apply(this, arguments);
            let X = !1;
            if ("function" != typeof F) {
              if (!F.handleEvent) return e.apply(this, arguments);
              X = !0
            }
            if (J && !J(e, F, N, arguments)) return;
            const xe = Ae && !!u && -1 !== u.indexOf(M), He = function n(e) {
              if ("object" == typeof e && null !== e) {
                const h = {...e};
                return e.signal && (h.signal = e.signal), h
              }
              return e
            }(function V(e, h) {
              return !Ae && "object" == typeof e && e ? !!e.capture : Ae && h ? "boolean" == typeof e ? {
                capture: e,
                passive: !0
              } : e ? "object" == typeof e && !1 !== e.passive ? {...e, passive: !0} : e : {passive: !0} : e
            }(arguments[2], xe)), pt = He?.signal;
            if (pt?.aborted) return;
            if (t) for (let Qe = 0; Qe < t.length; Qe++) if (M === t[Qe]) return xe ? e.call(N, M, F, He) : e.apply(this, arguments);
            const Ot = !!He && ("boolean" == typeof He || He.capture), Rt = !(!He || "object" != typeof He) && He.once,
              At = Zone.current;
            let Ht = pe[M];
            Ht || (a(M, oe), Ht = pe[M]);
            const Pt = Ht[Ot ? be : Re];
            let Nt, bt = N[Pt], St = !1;
            if (bt) {
              if (St = !0, fe) for (let Qe = 0; Qe < bt.length; Qe++) if (Oe(bt[Qe], F)) return
            } else bt = N[Pt] = [];
            const It = N.constructor.name, Dt = Mt[It];
            Dt && (Nt = Dt[M]), Nt || (Nt = It + h + (oe ? oe(M) : M)), $.options = He, Rt && ($.options.once = !1), $.target = N, $.capture = Ot, $.eventName = M, $.isExisting = St;
            const Ct = te ? vt : void 0;
            Ct && (Ct.taskData = $), pt && ($.options.signal = void 0);
            const Be = At.scheduleEventTask(Nt, F, Ct, T, v);
            if (pt) {
              $.options.signal = pt;
              const Qe = () => Be.zone.cancelTask(Be);
              e.call(pt, "abort", Qe, {once: !0}), Be.removeAbortListener = () => pt.removeEventListener("abort", Qe)
            }
            return $.target = null, Ct && (Ct.taskData = null), Rt && ($.options.once = !0), !Ae && "boolean" == typeof Be.options || (Be.options = He), Be.target = N, Be.capture = Ot, Be.eventName = M, X && (Be.originalDelegate = F), L ? bt.unshift(Be) : bt.push(Be), g ? N : void 0
          }
        };
        return S[d] = s(Z, A, ie, W, re), he && (S[k] = s(he, x, function (e) {
          return he.call($.target, $.eventName, e.invoke, $.options)
        }, W, re, !0)), S[_] = function () {
          const e = this || r;
          let h = arguments[0];
          y && y.transferEventName && (h = y.transferEventName(h));
          const T = arguments[2], v = !!T && ("boolean" == typeof T || T.capture), g = arguments[1];
          if (!g) return D.apply(this, arguments);
          if (J && !J(D, g, e, arguments)) return;
          const L = pe[h];
          let N;
          L && (N = L[v ? be : Re]);
          const M = N && e[N];
          if (M) for (let F = 0; F < M.length; F++) {
            const X = M[F];
            if (Oe(X, g)) return M.splice(F, 1), X.isRemoved = !0, 0 !== M.length || (X.allRemoved = !0, e[N] = null, v || "string" != typeof h) || (e[Ge + "ON_PROPERTY" + h] = null), X.zone.cancelTask(X), re ? e : void 0
          }
          return D.apply(this, arguments)
        }, S[O] = function () {
          const e = this || r;
          let h = arguments[0];
          y && y.transferEventName && (h = y.transferEventName(h));
          const T = [], v = p(e, oe ? oe(h) : h);
          for (let g = 0; g < v.length; g++) {
            const L = v[g];
            T.push(L.originalDelegate ? L.originalDelegate : L.callback)
          }
          return T
        }, S[w] = function () {
          const e = this || r;
          let h = arguments[0];
          if (h) {
            y && y.transferEventName && (h = y.transferEventName(h));
            const T = pe[h];
            if (T) {
              const L = e[T[Re]], N = e[T[be]];
              if (L) {
                const M = L.slice();
                for (let F = 0; F < M.length; F++) {
                  const X = M[F];
                  this[_].call(this, h, X.originalDelegate ? X.originalDelegate : X.callback, X.options)
                }
              }
              if (N) {
                const M = N.slice();
                for (let F = 0; F < M.length; F++) {
                  const X = M[F];
                  this[_].call(this, h, X.originalDelegate ? X.originalDelegate : X.callback, X.options)
                }
              }
            }
          } else {
            const T = Object.keys(e);
            for (let v = 0; v < T.length; v++) {
              const L = Tt.exec(T[v]);
              let N = L && L[1];
              N && "removeListener" !== N && this[w].call(this, N)
            }
            this[w].call(this, "removeListener")
          }
          if (re) return this
        }, Te(S[d], Z), Te(S[_], D), Ee && Te(S[w], Ee), U && Te(S[O], U), !0
      }

      let q = [];
      for (let R = 0; R < m.length; R++) q[R] = _e(m[R], o);
      return q
    }

    function p(r, c) {
      if (!c) {
        const _ = [];
        for (let O in r) {
          const w = Tt.exec(O);
          let H = w && w[1];
          if (H && (!c || H === c)) {
            const A = r[O];
            if (A) for (let k = 0; k < A.length; k++) _.push(A[k])
          }
        }
        return _
      }
      let m = pe[c];
      m || (a(c), m = pe[c]);
      const o = r[m[Re]], d = r[m[be]];
      return o ? d ? o.concat(d) : o.slice() : d ? d.slice() : []
    }

    function E(r, c) {
      const m = r.Event;
      m && m.prototype && c.patchMethod(m.prototype, "stopImmediatePropagation", o => function (d, _) {
        d[gt] = !0, o && o.apply(d, _)
      })
    }

    const P = Y("zoneTask");

    function me(r, c, m, o) {
      let d = null, _ = null;
      m += o;
      const O = {};

      function w(A) {
        const k = A.data;
        k.args[0] = function () {
          return A.invoke.apply(this, arguments)
        };
        const x = d.apply(r, k.args);
        return yt(x) ? k.handleId = x : (k.handle = x, k.isRefreshable = De(x.refresh)), A
      }

      function H(A) {
        const {handle: k, handleId: x} = A.data;
        return _.call(r, k ?? x)
      }

      d = Pe(r, c += o, A => function (k, x) {
        if (De(x[0])) {
          const B = {
            isRefreshable: !1,
            isPeriodic: "Interval" === o,
            delay: "Timeout" === o || "Interval" === o ? x[1] || 0 : void 0,
            args: x
          }, ee = x[0];
          x[0] = function () {
            try {
              return ee.apply(this, arguments)
            } finally {
              const {handle: te, handleId: J, isPeriodic: fe, isRefreshable: re} = B;
              !fe && !re && (J ? delete O[J] : te && (te[P] = null))
            }
          };
          const se = we(c, x[0], B, w, H);
          if (!se) return se;
          const {handleId: ue, handle: _e, isRefreshable: q, isPeriodic: R} = se.data;
          if (ue) O[ue] = se; else if (_e && (_e[P] = se, q && !R)) {
            const y = _e.refresh;
            _e.refresh = function () {
              const {zone: te, state: J} = se;
              return "notScheduled" === J ? (se._state = "scheduled", te._updateTaskCount(se, 1)) : "running" === J && (se._state = "scheduling"), y.call(this)
            }
          }
          return _e ?? ue ?? se
        }
        return A.apply(r, x)
      }), _ = Pe(r, m, A => function (k, x) {
        const B = x[0];
        let ee;
        yt(B) ? (ee = O[B], delete O[B]) : (ee = B?.[P], ee ? B[P] = null : ee = B), ee?.type ? ee.cancelFn && ee.zone.cancelTask(ee) : A.apply(r, x)
      })
    }

    function ke(r, c, m) {
      if (!m || 0 === m.length) return c;
      const o = m.filter(_ => _.target === r);
      if (!o || 0 === o.length) return c;
      const d = o[0].ignoreProperties;
      return c.filter(_ => -1 === d.indexOf(_))
    }

    function ge(r, c, m, o) {
      r && Je(r, ke(r, c, m), o)
    }

    function Ze(r) {
      return Object.getOwnPropertyNames(r).filter(c => c.startsWith("on") && c.length > 2).map(c => c.substring(2))
    }

    function $e(r, c, m, o, d) {
      const _ = Zone.__symbol__(o);
      if (c[_]) return;
      const O = c[_] = c[o];
      c[o] = function (w, H, A) {
        return H && H.prototype && d.forEach(function (k) {
          const x = `${m}.${o}::` + k, B = H.prototype;
          try {
            if (B.hasOwnProperty(k)) {
              const ee = r.ObjectGetOwnPropertyDescriptor(B, k);
              ee && ee.value ? (ee.value = r.wrapWithCurrentZone(ee.value, x), r._redefineProperty(H.prototype, k, ee)) : B[k] && (B[k] = r.wrapWithCurrentZone(B[k], x))
            } else B[k] && (B[k] = r.wrapWithCurrentZone(B[k], x))
          } catch {
          }
        }), O.call(c, w, H, A)
      }, r.attachOriginToPatched(c[o], O)
    }

    const _t = function Ue() {
      const r = globalThis, c = !0 === r[ce("forceDuplicateZoneCheck")];
      if (r.Zone && (c || "function" != typeof r.Zone.__symbol__)) throw new Error("Zone already loaded.");
      return r.Zone ??= function it() {
        const r = G.performance;

        function c(V) {
          r && r.mark && r.mark(V)
        }

        function m(V, C) {
          r && r.measure && r.measure(V, C)
        }

        c("Zone");
        let o = (() => {
          class V {
            static#e = this.__symbol__ = ce;

            static assertZonePatched() {
              if (G.Promise !== $.ZoneAwarePromise) throw new Error("Zone.js has detected that ZoneAwarePromise `(window|global).Promise` has been overwritten.\nMost likely cause is that a Promise polyfill has been loaded after Zone.js (Polyfilling Promise api is not necessary when zone.js is loaded. If you must load one, do so before loading zone.js.)")
            }

            static get root() {
              let i = V.current;
              for (; i.parent;) i = i.parent;
              return i
            }

            static get current() {
              return D.zone
            }

            static get currentTask() {
              return U
            }

            static __load_patch(i, l, I = !1) {
              if ($.hasOwnProperty(i)) {
                const j = !0 === G[ce("forceDuplicateZoneCheck")];
                if (!I && j) throw Error("Already loaded patch: " + i)
              } else if (!G["__Zone_disable_" + i]) {
                const j = "Zone:" + i;
                c(j), $[i] = l(G, V, Z), m(j, j)
              }
            }

            get parent() {
              return this._parent
            }

            get name() {
              return this._name
            }

            constructor(i, l) {
              this._parent = i, this._name = l ? l.name || "unnamed" : "<root>", this._properties = l && l.properties || {}, this._zoneDelegate = new _(this, this._parent && this._parent._zoneDelegate, l)
            }

            get(i) {
              const l = this.getZoneWith(i);
              if (l) return l._properties[i]
            }

            getZoneWith(i) {
              let l = this;
              for (; l;) {
                if (l._properties.hasOwnProperty(i)) return l;
                l = l._parent
              }
              return null
            }

            fork(i) {
              if (!i) throw new Error("ZoneSpec required!");
              return this._zoneDelegate.fork(this, i)
            }

            wrap(i, l) {
              if ("function" != typeof i) throw new Error("Expecting function got: " + i);
              const I = this._zoneDelegate.intercept(this, i, l), j = this;
              return function () {
                return j.runGuarded(I, this, arguments, l)
              }
            }

            run(i, l, I, j) {
              D = {parent: D, zone: this};
              try {
                return this._zoneDelegate.invoke(this, i, l, I, j)
              } finally {
                D = D.parent
              }
            }

            runGuarded(i, l = null, I, j) {
              D = {parent: D, zone: this};
              try {
                try {
                  return this._zoneDelegate.invoke(this, i, l, I, j)
                } catch (ie) {
                  if (this._zoneDelegate.handleError(this, ie)) throw ie
                }
              } finally {
                D = D.parent
              }
            }

            runTask(i, l, I) {
              if (i.zone != this) throw new Error("A task can only be run in the zone of creation! (Creation: " + (i.zone || _e).name + "; Execution: " + this.name + ")");
              const j = i, {type: ie, data: {isPeriodic: W = !1, isRefreshable: Fe = !1} = {}} = i;
              if (i.state === q && (ie === oe || ie === S)) return;
              const Oe = i.state != te;
              Oe && j._transitionTo(te, y);
              const t = U;
              U = j, D = {parent: D, zone: this};
              try {
                ie == S && i.data && !W && !Fe && (i.cancelFn = void 0);
                try {
                  return this._zoneDelegate.invokeTask(this, j, l, I)
                } catch (u) {
                  if (this._zoneDelegate.handleError(this, u)) throw u
                }
              } finally {
                const u = i.state;
                if (u !== q && u !== fe) if (ie == oe || W || Fe && u === R) Oe && j._transitionTo(y, te, R); else {
                  const n = j._zoneDelegates;
                  this._updateTaskCount(j, -1), Oe && j._transitionTo(q, te, q), Fe && (j._zoneDelegates = n)
                }
                D = D.parent, U = t
              }
            }

            scheduleTask(i) {
              if (i.zone && i.zone !== this) {
                let I = this;
                for (; I;) {
                  if (I === i.zone) throw Error(`can not reschedule task to ${this.name} which is descendants of the original zone ${i.zone.name}`);
                  I = I.parent
                }
              }
              i._transitionTo(R, q);
              const l = [];
              i._zoneDelegates = l, i._zone = this;
              try {
                i = this._zoneDelegate.scheduleTask(this, i)
              } catch (I) {
                throw i._transitionTo(fe, R, q), this._zoneDelegate.handleError(this, I), I
              }
              return i._zoneDelegates === l && this._updateTaskCount(i, 1), i.state == R && i._transitionTo(y, R), i
            }

            scheduleMicroTask(i, l, I, j) {
              return this.scheduleTask(new O(re, i, l, I, j, void 0))
            }

            scheduleMacroTask(i, l, I, j, ie) {
              return this.scheduleTask(new O(S, i, l, I, j, ie))
            }

            scheduleEventTask(i, l, I, j, ie) {
              return this.scheduleTask(new O(oe, i, l, I, j, ie))
            }

            cancelTask(i) {
              if (i.zone != this) throw new Error("A task can only be cancelled in the zone of creation! (Creation: " + (i.zone || _e).name + "; Execution: " + this.name + ")");
              if (i.state === y || i.state === te) {
                i._transitionTo(J, y, te);
                try {
                  this._zoneDelegate.cancelTask(this, i)
                } catch (l) {
                  throw i._transitionTo(fe, J), this._zoneDelegate.handleError(this, l), l
                }
                return this._updateTaskCount(i, -1), i._transitionTo(q, J), i.runCount = -1, i
              }
            }

            _updateTaskCount(i, l) {
              const I = i._zoneDelegates;
              -1 == l && (i._zoneDelegates = null);
              for (let j = 0; j < I.length; j++) I[j]._updateTaskCount(i.type, l)
            }
          }

          return V
        })();
        const d = {
          name: "",
          onHasTask: (V, C, i, l) => V.hasTask(i, l),
          onScheduleTask: (V, C, i, l) => V.scheduleTask(i, l),
          onInvokeTask: (V, C, i, l, I, j) => V.invokeTask(i, l, I, j),
          onCancelTask: (V, C, i, l) => V.cancelTask(i, l)
        };

        class _ {
          get zone() {
            return this._zone
          }

          constructor(C, i, l) {
            this._taskCounts = {
              microTask: 0,
              macroTask: 0,
              eventTask: 0
            }, this._zone = C, this._parentDelegate = i, this._forkZS = l && (l && l.onFork ? l : i._forkZS), this._forkDlgt = l && (l.onFork ? i : i._forkDlgt), this._forkCurrZone = l && (l.onFork ? this._zone : i._forkCurrZone), this._interceptZS = l && (l.onIntercept ? l : i._interceptZS), this._interceptDlgt = l && (l.onIntercept ? i : i._interceptDlgt), this._interceptCurrZone = l && (l.onIntercept ? this._zone : i._interceptCurrZone), this._invokeZS = l && (l.onInvoke ? l : i._invokeZS), this._invokeDlgt = l && (l.onInvoke ? i : i._invokeDlgt), this._invokeCurrZone = l && (l.onInvoke ? this._zone : i._invokeCurrZone), this._handleErrorZS = l && (l.onHandleError ? l : i._handleErrorZS), this._handleErrorDlgt = l && (l.onHandleError ? i : i._handleErrorDlgt), this._handleErrorCurrZone = l && (l.onHandleError ? this._zone : i._handleErrorCurrZone), this._scheduleTaskZS = l && (l.onScheduleTask ? l : i._scheduleTaskZS), this._scheduleTaskDlgt = l && (l.onScheduleTask ? i : i._scheduleTaskDlgt), this._scheduleTaskCurrZone = l && (l.onScheduleTask ? this._zone : i._scheduleTaskCurrZone), this._invokeTaskZS = l && (l.onInvokeTask ? l : i._invokeTaskZS), this._invokeTaskDlgt = l && (l.onInvokeTask ? i : i._invokeTaskDlgt), this._invokeTaskCurrZone = l && (l.onInvokeTask ? this._zone : i._invokeTaskCurrZone), this._cancelTaskZS = l && (l.onCancelTask ? l : i._cancelTaskZS), this._cancelTaskDlgt = l && (l.onCancelTask ? i : i._cancelTaskDlgt), this._cancelTaskCurrZone = l && (l.onCancelTask ? this._zone : i._cancelTaskCurrZone), this._hasTaskZS = null, this._hasTaskDlgt = null, this._hasTaskDlgtOwner = null, this._hasTaskCurrZone = null;
            const I = l && l.onHasTask;
            (I || i && i._hasTaskZS) && (this._hasTaskZS = I ? l : d, this._hasTaskDlgt = i, this._hasTaskDlgtOwner = this, this._hasTaskCurrZone = this._zone, l.onScheduleTask || (this._scheduleTaskZS = d, this._scheduleTaskDlgt = i, this._scheduleTaskCurrZone = this._zone), l.onInvokeTask || (this._invokeTaskZS = d, this._invokeTaskDlgt = i, this._invokeTaskCurrZone = this._zone), l.onCancelTask || (this._cancelTaskZS = d, this._cancelTaskDlgt = i, this._cancelTaskCurrZone = this._zone))
          }

          fork(C, i) {
            return this._forkZS ? this._forkZS.onFork(this._forkDlgt, this.zone, C, i) : new o(C, i)
          }

          intercept(C, i, l) {
            return this._interceptZS ? this._interceptZS.onIntercept(this._interceptDlgt, this._interceptCurrZone, C, i, l) : i
          }

          invoke(C, i, l, I, j) {
            return this._invokeZS ? this._invokeZS.onInvoke(this._invokeDlgt, this._invokeCurrZone, C, i, l, I, j) : i.apply(l, I)
          }

          handleError(C, i) {
            return !this._handleErrorZS || this._handleErrorZS.onHandleError(this._handleErrorDlgt, this._handleErrorCurrZone, C, i)
          }

          scheduleTask(C, i) {
            let l = i;
            if (this._scheduleTaskZS) this._hasTaskZS && l._zoneDelegates.push(this._hasTaskDlgtOwner), l = this._scheduleTaskZS.onScheduleTask(this._scheduleTaskDlgt, this._scheduleTaskCurrZone, C, i), l || (l = i); else if (i.scheduleFn) i.scheduleFn(i); else {
              if (i.type != re) throw new Error("Task is missing scheduleFn.");
              se(i)
            }
            return l
          }

          invokeTask(C, i, l, I) {
            return this._invokeTaskZS ? this._invokeTaskZS.onInvokeTask(this._invokeTaskDlgt, this._invokeTaskCurrZone, C, i, l, I) : i.callback.apply(l, I)
          }

          cancelTask(C, i) {
            let l;
            if (this._cancelTaskZS) l = this._cancelTaskZS.onCancelTask(this._cancelTaskDlgt, this._cancelTaskCurrZone, C, i); else {
              if (!i.cancelFn) throw Error("Task is not cancelable");
              l = i.cancelFn(i)
            }
            return l
          }

          hasTask(C, i) {
            try {
              this._hasTaskZS && this._hasTaskZS.onHasTask(this._hasTaskDlgt, this._hasTaskCurrZone, C, i)
            } catch (l) {
              this.handleError(C, l)
            }
          }

          _updateTaskCount(C, i) {
            const l = this._taskCounts, I = l[C], j = l[C] = I + i;
            if (j < 0) throw new Error("More tasks executed then were scheduled.");
            0 != I && 0 != j || this.hasTask(this._zone, {
              microTask: l.microTask > 0,
              macroTask: l.macroTask > 0,
              eventTask: l.eventTask > 0,
              change: C
            })
          }
        }

        class O {
          constructor(C, i, l, I, j, ie) {
            if (this._zone = null, this.runCount = 0, this._zoneDelegates = null, this._state = "notScheduled", this.type = C, this.source = i, this.data = I, this.scheduleFn = j, this.cancelFn = ie, !l) throw new Error("callback is not defined");
            this.callback = l;
            const W = this;
            this.invoke = C === oe && I && I.useG ? O.invokeTask : function () {
              return O.invokeTask.call(G, W, this, arguments)
            }
          }

          static invokeTask(C, i, l) {
            C || (C = this), Ee++;
            try {
              return C.runCount++, C.zone.runTask(C, i, l)
            } finally {
              1 == Ee && ue(), Ee--
            }
          }

          get zone() {
            return this._zone
          }

          get state() {
            return this._state
          }

          cancelScheduleRequest() {
            this._transitionTo(q, R)
          }

          _transitionTo(C, i, l) {
            if (this._state !== i && this._state !== l) throw new Error(`${this.type} '${this.source}': can not transition to '${C}', expecting state '${i}'${l ? " or '" + l + "'" : ""}, was '${this._state}'.`);
            this._state = C, C == q && (this._zoneDelegates = null)
          }

          toString() {
            return this.data && typeof this.data.handleId < "u" ? this.data.handleId.toString() : Object.prototype.toString.call(this)
          }

          toJSON() {
            return {
              type: this.type,
              state: this.state,
              source: this.source,
              zone: this.zone.name,
              runCount: this.runCount
            }
          }
        }

        const w = ce("setTimeout"), H = ce("Promise"), A = ce("then");
        let B, k = [], x = !1;

        function ee(V) {
          if (B || G[H] && (B = G[H].resolve(0)), B) {
            let C = B[A];
            C || (C = B.then), C.call(B, V)
          } else G[w](V, 0)
        }

        function se(V) {
          0 === Ee && 0 === k.length && ee(ue), V && k.push(V)
        }

        function ue() {
          if (!x) {
            for (x = !0; k.length;) {
              const V = k;
              k = [];
              for (let C = 0; C < V.length; C++) {
                const i = V[C];
                try {
                  i.zone.runTask(i, null, null)
                } catch (l) {
                  Z.onUnhandledError(l)
                }
              }
            }
            Z.microtaskDrainDone(), x = !1
          }
        }

        const _e = {name: "NO ZONE"}, q = "notScheduled", R = "scheduling", y = "scheduled", te = "running",
          J = "canceling", fe = "unknown", re = "microTask", S = "macroTask", oe = "eventTask", $ = {}, Z = {
            symbol: ce,
            currentZoneFrame: () => D,
            onUnhandledError: he,
            microtaskDrainDone: he,
            scheduleMicroTask: se,
            showUncaughtError: () => !o[ce("ignoreConsoleErrorUncaughtError")],
            patchEventTarget: () => [],
            patchOnProperties: he,
            patchMethod: () => he,
            bindArguments: () => [],
            patchThen: () => he,
            patchMacroTask: () => he,
            patchEventPrototype: () => he,
            isIEOrEdge: () => !1,
            getGlobalObjects: () => {
            },
            ObjectDefineProperty: () => he,
            ObjectGetOwnPropertyDescriptor: () => {
            },
            ObjectCreate: () => {
            },
            ArraySlice: () => [],
            patchClass: () => he,
            wrapWithCurrentZone: () => he,
            filterProperties: () => [],
            attachOriginToPatched: () => he,
            _redefineProperty: () => he,
            patchCallbacks: () => he,
            nativeScheduleMicroTask: ee
          };
        let D = {parent: null, zone: new o(null, null)}, U = null, Ee = 0;

        function he() {
        }

        return m("Zone", "Zone"), o
      }(), r.Zone
    }();
    (function wt(r) {
      (function Ne(r) {
        r.__load_patch("ZoneAwarePromise", (c, m, o) => {
          const d = Object.getOwnPropertyDescriptor, _ = Object.defineProperty, w = o.symbol, H = [],
            A = !1 !== c[w("DISABLE_WRAPPING_UNCAUGHT_PROMISE_REJECTION")], k = w("Promise"), x = w("then"),
            B = "__creationTrace__";
          o.onUnhandledError = n => {
            if (o.showUncaughtError()) {
              const s = n && n.rejection;
              s ? console.error("Unhandled Promise rejection:", s instanceof Error ? s.message : s, "; Zone:", n.zone.name, "; Task:", n.task && n.task.source, "; Value:", s, s instanceof Error ? s.stack : void 0) : console.error(n)
            }
          }, o.microtaskDrainDone = () => {
            for (; H.length;) {
              const n = H.shift();
              try {
                n.zone.runGuarded(() => {
                  throw n.throwOriginal ? n.rejection : n
                })
              } catch (s) {
                se(s)
              }
            }
          };
          const ee = w("unhandledPromiseRejectionHandler");

          function se(n) {
            o.onUnhandledError(n);
            try {
              const s = m[ee];
              "function" == typeof s && s.call(this, n)
            } catch {
            }
          }

          function ue(n) {
            return n && n.then
          }

          function _e(n) {
            return n
          }

          function q(n) {
            return W.reject(n)
          }

          const R = w("state"), y = w("value"), te = w("finally"), J = w("parentPromiseValue"),
            fe = w("parentPromiseState"), re = "Promise.then", S = null, oe = !0, $ = !1, Z = 0;

          function D(n, s) {
            return e => {
              try {
                V(n, s, e)
              } catch (h) {
                V(n, !1, h)
              }
            }
          }

          const U = function () {
            let n = !1;
            return function (e) {
              return function () {
                n || (n = !0, e.apply(null, arguments))
              }
            }
          }, Ee = "Promise resolved with itself", he = w("currentTaskTrace");

          function V(n, s, e) {
            const h = U();
            if (n === e) throw new TypeError(Ee);
            if (n[R] === S) {
              let T = null;
              try {
                ("object" == typeof e || "function" == typeof e) && (T = e && e.then)
              } catch (v) {
                return h(() => {
                  V(n, !1, v)
                })(), n
              }
              if (s !== $ && e instanceof W && e.hasOwnProperty(R) && e.hasOwnProperty(y) && e[R] !== S) i(e), V(n, e[R], e[y]); else if (s !== $ && "function" == typeof T) try {
                T.call(e, h(D(n, s)), h(D(n, !1)))
              } catch (v) {
                h(() => {
                  V(n, !1, v)
                })()
              } else {
                n[R] = s;
                const v = n[y];
                if (n[y] = e, n[te] === te && s === oe && (n[R] = n[fe], n[y] = n[J]), s === $ && e instanceof Error) {
                  const g = m.currentTask && m.currentTask.data && m.currentTask.data[B];
                  g && _(e, he, {configurable: !0, enumerable: !1, writable: !0, value: g})
                }
                for (let g = 0; g < v.length;) l(n, v[g++], v[g++], v[g++], v[g++]);
                if (0 == v.length && s == $) {
                  n[R] = Z;
                  let g = e;
                  try {
                    throw new Error("Uncaught (in promise): " + function O(n) {
                      return n && n.toString === Object.prototype.toString ? (n.constructor && n.constructor.name || "") + ": " + JSON.stringify(n) : n ? n.toString() : Object.prototype.toString.call(n)
                    }(e) + (e && e.stack ? "\n" + e.stack : ""))
                  } catch (L) {
                    g = L
                  }
                  A && (g.throwOriginal = !0), g.rejection = e, g.promise = n, g.zone = m.current, g.task = m.currentTask, H.push(g), o.scheduleMicroTask()
                }
              }
            }
            return n
          }

          const C = w("rejectionHandledHandler");

          function i(n) {
            if (n[R] === Z) {
              try {
                const s = m[C];
                s && "function" == typeof s && s.call(this, {rejection: n[y], promise: n})
              } catch {
              }
              n[R] = $;
              for (let s = 0; s < H.length; s++) n === H[s].promise && H.splice(s, 1)
            }
          }

          function l(n, s, e, h, T) {
            i(n);
            const v = n[R], g = v ? "function" == typeof h ? h : _e : "function" == typeof T ? T : q;
            s.scheduleMicroTask(re, () => {
              try {
                const L = n[y], N = !!e && te === e[te];
                N && (e[J] = L, e[fe] = v);
                const M = s.run(g, void 0, N && g !== q && g !== _e ? [] : [L]);
                V(e, !0, M)
              } catch (L) {
                V(e, !1, L)
              }
            }, e)
          }

          const j = function () {
          }, ie = c.AggregateError;

          class W {
            static toString() {
              return "function ZoneAwarePromise() { [native code] }"
            }

            static resolve(s) {
              return s instanceof W ? s : V(new this(null), oe, s)
            }

            static reject(s) {
              return V(new this(null), $, s)
            }

            static withResolvers() {
              const s = {};
              return s.promise = new W((e, h) => {
                s.resolve = e, s.reject = h
              }), s
            }

            static any(s) {
              if (!s || "function" != typeof s[Symbol.iterator]) return Promise.reject(new ie([], "All promises were rejected"));
              const e = [];
              let h = 0;
              try {
                for (let g of s) h++, e.push(W.resolve(g))
              } catch {
                return Promise.reject(new ie([], "All promises were rejected"))
              }
              if (0 === h) return Promise.reject(new ie([], "All promises were rejected"));
              let T = !1;
              const v = [];
              return new W((g, L) => {
                for (let N = 0; N < e.length; N++) e[N].then(M => {
                  T || (T = !0, g(M))
                }, M => {
                  v.push(M), h--, 0 === h && (T = !0, L(new ie(v, "All promises were rejected")))
                })
              })
            }

            static race(s) {
              let e, h, T = new this((L, N) => {
                e = L, h = N
              });

              function v(L) {
                e(L)
              }

              function g(L) {
                h(L)
              }

              for (let L of s) ue(L) || (L = this.resolve(L)), L.then(v, g);
              return T
            }

            static all(s) {
              return W.allWithCallback(s)
            }

            static allSettled(s) {
              return (this && this.prototype instanceof W ? this : W).allWithCallback(s, {
                thenCallback: h => ({
                  status: "fulfilled",
                  value: h
                }), errorCallback: h => ({status: "rejected", reason: h})
              })
            }

            static allWithCallback(s, e) {
              let h, T, v = new this((M, F) => {
                h = M, T = F
              }), g = 2, L = 0;
              const N = [];
              for (let M of s) {
                ue(M) || (M = this.resolve(M));
                const F = L;
                try {
                  M.then(X => {
                    N[F] = e ? e.thenCallback(X) : X, g--, 0 === g && h(N)
                  }, X => {
                    e ? (N[F] = e.errorCallback(X), g--, 0 === g && h(N)) : T(X)
                  })
                } catch (X) {
                  T(X)
                }
                g++, L++
              }
              return g -= 2, 0 === g && h(N), v
            }

            constructor(s) {
              const e = this;
              if (!(e instanceof W)) throw new Error("Must be an instanceof Promise.");
              e[R] = S, e[y] = [];
              try {
                const h = U();
                s && s(h(D(e, oe)), h(D(e, $)))
              } catch (h) {
                V(e, !1, h)
              }
            }

            get [Symbol.toStringTag]() {
              return "Promise"
            }

            get [Symbol.species]() {
              return W
            }

            then(s, e) {
              let h = this.constructor?.[Symbol.species];
              (!h || "function" != typeof h) && (h = this.constructor || W);
              const T = new h(j), v = m.current;
              return this[R] == S ? this[y].push(v, T, s, e) : l(this, v, T, s, e), T
            }

            catch(s) {
              return this.then(null, s)
            }

            finally(s) {
              let e = this.constructor?.[Symbol.species];
              (!e || "function" != typeof e) && (e = W);
              const h = new e(j);
              h[te] = te;
              const T = m.current;
              return this[R] == S ? this[y].push(T, h, s, s) : l(this, T, h, s, s), h
            }
          }

          W.resolve = W.resolve, W.reject = W.reject, W.race = W.race, W.all = W.all;
          const Fe = c[k] = c.Promise;
          c.Promise = W;
          const Oe = w("thenPatched");

          function t(n) {
            const s = n.prototype, e = d(s, "then");
            if (e && (!1 === e.writable || !e.configurable)) return;
            const h = s.then;
            s[x] = h, n.prototype.then = function (T, v) {
              return new W((L, N) => {
                h.call(this, L, N)
              }).then(T, v)
            }, n[Oe] = !0
          }

          return o.patchThen = t, Fe && (t(Fe), Pe(c, "fetch", n => function u(n) {
            return function (s, e) {
              let h = n.apply(s, e);
              if (h instanceof W) return h;
              let T = h.constructor;
              return T[Oe] || t(T), h
            }
          }(n))), Promise[m.__symbol__("uncaughtPromiseErrors")] = H, W
        })
      })(r), function le(r) {
        r.__load_patch("toString", c => {
          const m = Function.prototype.toString, o = Y("OriginalDelegate"), d = Y("Promise"), _ = Y("Error"),
            O = function () {
              if ("function" == typeof this) {
                const k = this[o];
                if (k) return "function" == typeof k ? m.call(k) : Object.prototype.toString.call(k);
                if (this === Promise) {
                  const x = c[d];
                  if (x) return m.call(x)
                }
                if (this === Error) {
                  const x = c[_];
                  if (x) return m.call(x)
                }
              }
              return m.call(this)
            };
          O[o] = m, Function.prototype.toString = O;
          const w = Object.prototype.toString;
          Object.prototype.toString = function () {
            return "function" == typeof Promise && this instanceof Promise ? "[object Promise]" : w.call(this)
          }
        })
      }(r), function kt(r) {
        r.__load_patch("util", (c, m, o) => {
          const d = Ze(c);
          o.patchOnProperties = Je, o.patchMethod = Pe, o.bindArguments = We, o.patchMacroTask = Se;
          const _ = m.__symbol__("BLACK_LISTED_EVENTS"), O = m.__symbol__("UNPATCHED_EVENTS");
          c[O] && (c[_] = c[O]), c[_] && (m[_] = m[O] = c[_]), o.patchEventPrototype = E, o.patchEventTarget = f, o.isIEOrEdge = mt, o.ObjectDefineProperty = ze, o.ObjectGetOwnPropertyDescriptor = et, o.ObjectCreate = nt, o.ArraySlice = Lt, o.patchClass = Ce, o.wrapWithCurrentZone = rt, o.filterProperties = ke, o.attachOriginToPatched = Te, o._redefineProperty = Object.defineProperty, o.patchCallbacks = $e, o.getGlobalObjects = () => ({
            globalSources: Mt,
            zoneSymbolEventNames: pe,
            eventNames: d,
            isBrowser: Xe,
            isMix: ot,
            isNode: Ve,
            TRUE_STR: be,
            FALSE_STR: Re,
            ZONE_SYMBOL_PREFIX: Ge,
            ADD_EVENT_LISTENER_STR: ct,
            REMOVE_EVENT_LISTENER_STR: at
          })
        })
      }(r)
    })(_t), function ve(r) {
      r.__load_patch("legacy", c => {
        const m = c[r.__symbol__("legacyPatch")];
        m && m()
      }), r.__load_patch("timers", c => {
        const m = "set", o = "clear";
        me(c, m, o, "Timeout"), me(c, m, o, "Interval"), me(c, m, o, "Immediate")
      }), r.__load_patch("requestAnimationFrame", c => {
        me(c, "request", "cancel", "AnimationFrame"), me(c, "mozRequest", "mozCancel", "AnimationFrame"), me(c, "webkitRequest", "webkitCancel", "AnimationFrame")
      }), r.__load_patch("blocking", (c, m) => {
        const o = ["alert", "prompt", "confirm"];
        for (let d = 0; d < o.length; d++) Pe(c, o[d], (O, w, H) => function (A, k) {
          return m.current.run(O, c, k, H)
        })
      }), r.__load_patch("EventTarget", (c, m, o) => {
        (function ne(r, c) {
          c.patchEventPrototype(r, c)
        })(c, o), function Q(r, c) {
          if (Zone[c.symbol("patchEventTarget")]) return;
          const {
            eventNames: m,
            zoneSymbolEventNames: o,
            TRUE_STR: d,
            FALSE_STR: _,
            ZONE_SYMBOL_PREFIX: O
          } = c.getGlobalObjects();
          for (let H = 0; H < m.length; H++) {
            const A = m[H], B = O + (A + _), ee = O + (A + d);
            o[A] = {}, o[A][_] = B, o[A][d] = ee
          }
          const w = r.EventTarget;
          w && w.prototype && c.patchEventTarget(r, c, [w && w.prototype])
        }(c, o);
        const d = c.XMLHttpRequestEventTarget;
        d && d.prototype && o.patchEventTarget(c, o, [d.prototype])
      }), r.__load_patch("MutationObserver", (c, m, o) => {
        Ce("MutationObserver"), Ce("WebKitMutationObserver")
      }), r.__load_patch("IntersectionObserver", (c, m, o) => {
        Ce("IntersectionObserver")
      }), r.__load_patch("FileReader", (c, m, o) => {
        Ce("FileReader")
      }), r.__load_patch("on_property", (c, m, o) => {
        !function st(r, c) {
          if (Ve && !ot || Zone[r.symbol("patchEvents")]) return;
          const m = c.__Zone_ignore_on_properties;
          let o = [];
          if (Xe) {
            const d = window;
            o = o.concat(["Document", "SVGElement", "Element", "HTMLElement", "HTMLBodyElement", "HTMLMediaElement", "HTMLFrameSetElement", "HTMLFrameElement", "HTMLIFrameElement", "HTMLMarqueeElement", "Worker"]);
            const _ = function Me() {
              try {
                const r = je.navigator.userAgent;
                if (-1 !== r.indexOf("MSIE ") || -1 !== r.indexOf("Trident/")) return !0
              } catch {
              }
              return !1
            }() ? [{target: d, ignoreProperties: ["error"]}] : [];
            ge(d, Ze(d), m && m.concat(_), tt(d))
          }
          o = o.concat(["XMLHttpRequest", "XMLHttpRequestEventTarget", "IDBIndex", "IDBRequest", "IDBOpenDBRequest", "IDBDatabase", "IDBTransaction", "IDBCursor", "WebSocket"]);
          for (let d = 0; d < o.length; d++) {
            const _ = c[o[d]];
            _ && _.prototype && ge(_.prototype, Ze(_.prototype), m)
          }
        }(o, c)
      }), r.__load_patch("customElements", (c, m, o) => {
        !function K(r, c) {
          const {isBrowser: m, isMix: o} = c.getGlobalObjects();
          (m || o) && r.customElements && "customElements" in r && c.patchCallbacks(c, r.customElements, "customElements", "define", ["connectedCallback", "disconnectedCallback", "adoptedCallback", "attributeChangedCallback", "formAssociatedCallback", "formDisabledCallback", "formResetCallback", "formStateRestoreCallback"])
        }(c, o)
      }), r.__load_patch("XHR", (c, m) => {
        !function A(k) {
          const x = k.XMLHttpRequest;
          if (!x) return;
          const B = x.prototype;
          let se = B[Et], ue = B[lt];
          if (!se) {
            const Z = k.XMLHttpRequestEventTarget;
            if (Z) {
              const D = Z.prototype;
              se = D[Et], ue = D[lt]
            }
          }
          const _e = "readystatechange", q = "scheduled";

          function R(Z) {
            const D = Z.data, U = D.target;
            U[O] = !1, U[H] = !1;
            const Ee = U[_];
            se || (se = U[Et], ue = U[lt]), Ee && ue.call(U, _e, Ee);
            const he = U[_] = () => {
              if (U.readyState === U.DONE) if (!D.aborted && U[O] && Z.state === q) {
                const C = U[m.__symbol__("loadfalse")];
                if (0 !== U.status && C && C.length > 0) {
                  const i = Z.invoke;
                  Z.invoke = function () {
                    const l = U[m.__symbol__("loadfalse")];
                    for (let I = 0; I < l.length; I++) l[I] === Z && l.splice(I, 1);
                    !D.aborted && Z.state === q && i.call(Z)
                  }, C.push(Z)
                } else Z.invoke()
              } else !D.aborted && !1 === U[O] && (U[H] = !0)
            };
            return se.call(U, _e, he), U[o] || (U[o] = Z), oe.apply(U, D.args), U[O] = !0, Z
          }

          function y() {
          }

          function te(Z) {
            const D = Z.data;
            return D.aborted = !0, $.apply(D.target, D.args)
          }

          const J = Pe(B, "open", () => function (Z, D) {
            return Z[d] = 0 == D[2], Z[w] = D[1], J.apply(Z, D)
          }), re = Y("fetchTaskAborting"), S = Y("fetchTaskScheduling"), oe = Pe(B, "send", () => function (Z, D) {
            if (!0 === m.current[S] || Z[d]) return oe.apply(Z, D);
            {
              const U = {target: Z, url: Z[w], isPeriodic: !1, args: D, aborted: !1},
                Ee = we("XMLHttpRequest.send", y, U, R, te);
              Z && !0 === Z[H] && !U.aborted && Ee.state === q && Ee.invoke()
            }
          }), $ = Pe(B, "abort", () => function (Z, D) {
            const U = function ee(Z) {
              return Z[o]
            }(Z);
            if (U && "string" == typeof U.type) {
              if (null == U.cancelFn || U.data && U.data.aborted) return;
              U.zone.cancelTask(U)
            } else if (!0 === m.current[re]) return $.apply(Z, D)
          })
        }(c);
        const o = Y("xhrTask"), d = Y("xhrSync"), _ = Y("xhrListener"), O = Y("xhrScheduled"), w = Y("xhrURL"),
          H = Y("xhrErrorBeforeScheduled")
      }), r.__load_patch("geolocation", c => {
        c.navigator && c.navigator.geolocation && function z(r, c) {
          const m = r.constructor.name;
          for (let o = 0; o < c.length; o++) {
            const d = c[o], _ = r[d];
            if (_) {
              if (!ye(et(r, d))) continue;
              r[d] = (w => {
                const H = function () {
                  return w.apply(this, We(arguments, m + "." + d))
                };
                return Te(H, w), H
              })(_)
            }
          }
        }(c.navigator.geolocation, ["getCurrentPosition", "watchPosition"])
      }), r.__load_patch("PromiseRejectionEvent", (c, m) => {
        function o(d) {
          return function (_) {
            p(c, d).forEach(w => {
              const H = c.PromiseRejectionEvent;
              if (H) {
                const A = new H(d, {promise: _.promise, reason: _.rejection});
                w.invoke(A)
              }
            })
          }
        }

        c.PromiseRejectionEvent && (m[Y("unhandledPromiseRejectionHandler")] = o("unhandledrejection"), m[Y("rejectionHandledHandler")] = o("rejectionhandled"))
      }), r.__load_patch("queueMicrotask", (c, m, o) => {
        !function b(r, c) {
          c.patchMethod(r, "queueMicrotask", m => function (o, d) {
            Zone.current.scheduleMicroTask("queueMicrotask", d[0])
          })
        }(c, o)
      })
    }(_t)
  }
}, G => {
  G(G.s = 2523)
}]);