import React from 'react';

function NotAccess() {
  return <h1>Access Denied</h1>;
}

export default NotAccess;
