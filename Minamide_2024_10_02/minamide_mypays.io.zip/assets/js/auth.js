let AUTH_API_URL = '';

$(document).ready(function() {
  AUTH_API_URL = $('#base_url').val() + 'extAPIs/auth.php'
  checkAuth();
});

function checkAuth(){

  const jwt = localStorage.getItem('jwt');
  const auth_token = localStorage.getItem('auth_token');

  $.ajax({
    url: AUTH_API_URL,
    type: 'POST',
    data: JSON.stringify({
      action: 'checkAuth',
      jwt: jwt,
      auth_token: auth_token
    }),
    contentType: 'application/json',
    success: function(response) {
      const resp = JSON.parse( response );
      if (resp.result === 'success') {
        $('.authenticated').show();
        $('.unauthenticated').hide();
        $('.username').show();
        $('.auth_username').text(resp.emailAddress);
      } else {
        $('.authenticated').hide();
        $('.unauthenticated').show();
        $('.username').hide();
        console.log('An error occurred:', resp.error.errorMessage);
        logout();
      }
    },
    error: function(error) {
      $('.authenticated').hide();
      $('.unauthenticated').show();
      $('.username').hide();
      console.log('An error occurred:', error);
      logout();
    }
  });
}
