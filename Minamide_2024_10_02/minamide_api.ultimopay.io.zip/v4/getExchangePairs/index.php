<?php
header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get');
header("Access-Control-Max-Age", "3600");
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , x-requested-with, authorization, Authorization');
header("Access-Control-Allow-Credentials", "true");

mb_internal_encoding("UTF-8");
date_default_timezone_set('Asia/Tokyo');
ini_set('memory_limit', '200M');
if (!function_exists('getallheaders')) {
	function getallheaders()
	{
		if (!is_array($_SERVER)) {
			return array();
		}
		$headers = array();
		foreach ($_SERVER as $name => $value) {
			if (substr($name, 0, 5) == 'HTTP_') {
				$headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
			}
		}
		return $headers;
	}
}

function _log($email, $line)
{
	if ($email == "") {
		$fh2 = fopen("/var/www/api.ultimopay.io/v4/getExchangePairs/log/debug.log", 'a');
	} else {
		$fh2 = fopen("/var/www/api.ultimopay.io/v4/getExchangePairs/log/" . $email . ".log", 'a');
	}
	$fline = date('[Ymd H:i:s] ') . $line . "\n";
	fwrite($fh2, $fline);
	fclose($fh2);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	require_once '../include/dbconfig.php';
	$dbhandle = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	if (mysqli_connect_errno() != 0) {
		header('Content-Type: application/json');
		http_response_code(500);
		$ret_rs['result'] = 'failed';
		$ret_rs['error'] = array('errorCode' => 999, 'errorMessage' => 'System is under maintenance.');
		echo json_encode($ret_rs);
		die();
	} else {
		mysqli_query($dbhandle, "set names utf8;");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$clientId = '7effc5f3-a336-4b91-97c3-75971e04093b';
	$clientId3 = '03452b1a-d750-4876-ab6b-cc2c89cbef8f';
	$clientId4 = '0340bcfa-d750-0598-ab6b-cc2c89cbe0a2';
	$clientSecret = 'this is the top secret key for youscasino, powered by xbuy.io';
	$clientSecret2 = 'Alpha gaming website api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret3 = 'casino-wonder.com api key is powered by xbuy.io';
	$clientSecret4 = 'climbpot api access key';
	$clientSecret4_sandbox = 'climbpot (sandbox) api access key';
	$apikey = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret);
	$apikey2 = 'ApiKey ' . base64_encode($clientId . ':' . $clientSecret2);
	$apikey3 = 'ApiKey ' . base64_encode($clientId3 . ':' . $clientSecret3);
	$apikey4 = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4);
	$apikey4_sanbox = 'ApiKey ' . base64_encode($clientId4 . ':' . $clientSecret4_sandbox);
	//$apikey5 = 'ApiKey ' . base64_encode($clientId5 . ':' . $clientSecret5);
	$apikey_skynet = "ApiKey rGuxu1rgg5I5cU60e0FMGno5b6lkWkPlTd3zo22tZPjachUycM1djb4xY80t7eOwAmTn1o8LFqRHGXF5vBljzL8bpadBh4pUpVG9fGEwWOEEy9KvlbvlWYJSBv8xlkF5";
	$apikey_sabong = "Bearer byFVJHO7yQziaD5Tm3QHobGZIKqw4QTvDqEIuT0dt5fUkD3uIK3GSTGtfYygqh0IuYb4nf3m9WGCuUyoWWUrBm6eb58lJSvfjfsmxUIYFFojrevGwY7md21RQekenPVe";
	$apikey_bos = "Bearer wMJp7yUs99raXoYB7JhryHUMrDaTyspibwmUowceb9RD28V5dtsbRE2PJOpSicdmS0AQQz91Df8pAYyQxJGtjfgJJ0zJfjcPXBvWUfiTfyjJFO5p3vC5sKe6FW1uju56";
	$apikey_freelancer = "Bearer XdIaOXxGJzseHV7DDOdeKoCxjaEe6O1jLxl9ANhT7BOrnXb9uht9QiV4Mipkz710JmBsBaKppbUQ0iH3Y3wwFWjGmdh54c8fRWR5ZMfVVEb0soh8jJla3GgpEbn4Z4G1";
	$found = 0;
	$coin = 'USDT';
	$sandbox = 0;
	$partner = "";
	$allowed_deposit_currency_arr = array('USDT');
	$req_api_key = "";
	$req_partner = array('partner' => '', 'api_key' => '', 'website' => '');
	foreach (getallheaders() as $name => $value) {
		if ($name == 'Authorization') {
			$req_api_key = trim($value);
			$get_partner_sql = "SELECT * FROM cryptocash_partner_master";
			$partner_rs = mysqli_query($dbhandle, $get_partner_sql);
			if (mysqli_num_rows($partner_rs) > 0) {
				while ($row_partner = mysqli_fetch_array($partner_rs, MYSQLI_ASSOC)) {
					$cur_api_key = "Bearer " . $row_partner['api_key'];
					if ($req_api_key == $cur_api_key) {
						$req_partner['partner'] = trim($row_partner['partner']);
						$req_partner['api_key'] = trim($row_partner['api_key']);
						$req_partner['website'] = trim($row_partner['website']);
						$selected_api_key = $req_api_key;
						break;
					}
				}
			} else {
				_log("", "not found in db");
			}
		}
	}

	function isValidPassword($password)
	{
		if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
			return FALSE;
		return TRUE;
	}

	if (($req_partner['partner'] != '') && ($req_partner['api_key'] != '') && ($req_partner['website'] != '')) {

		$json = file_get_contents('php://input');
		if (!empty($json)) {
			$data = json_decode($json, true);
			if (!($data)) {

				switch (json_last_error()) {
					case JSON_ERROR_DEPTH:
						_log("", 'Reached the maximum stack depth');
						break;
					case JSON_ERROR_STATE_MISMATCH:
						_log("", 'Incorrect discharges or mismatch mode');
						break;
					case JSON_ERROR_CTRL_CHAR:
						_log("", 'Incorrect control character');
						break;
					case JSON_ERROR_SYNTAX:
						_log("", 'Syntax error or JSON invalid');
						break;
					case JSON_ERROR_UTF8:
						_log("", 'Invalid UTF-8 characters, possibly invalid encoding');
						break;
					default:
						_log("", 'Unknown error');
						break;
				}

				_log("", 'A non-empty request body is required.');
				header('Content-Type: application/json');
				http_response_code(500);
				$ret_rs['result'] = 'failed';
				$ret_rs['error'] = array('errorCode' => 1, 'errorMessage' => 'invalid JSON request data');
				echo json_encode($ret_rs);
				die();
			}
		}

		require_once '../include/common.php';
		_log("", "get info started...");
		$filters_pair_id_arr = [];
		$filters_status_arr = [];
		$filters_partner = '';
		//pair_id
		if (!empty($data['pair_id'])) {
			$filters_pair_id = mysqli_real_escape_string($dbhandle, trim($data['pair_id']));
			$filters_pair_id_arr = explode(",", $filters_pair_id);
		}
		//status
		if (!empty($data['status'])) {
			$filters_status = mysqli_real_escape_string($dbhandle, trim($data['status']));
			$filters_status_arr = explode(",", $filters_status);
		}
		//partner
		if (!empty($data['partner'])) {
			$filters_partner = trim($data['partner']);
		} else {
			$filters_partner = trim($req_partner['partner']);
		}
		$filters_partner = mysqli_real_escape_string($dbhandle, $filters_partner);

		_log("", "vao toi day rui");

		$sql = "SELECT * FROM `cryptocash_supported_exchange_pairs` WHERE `partner` = '$filters_partner'";
		if (count($filters_pair_id_arr) > 0) {
			$sql .= " AND (";
			foreach ($filters_pair_id_arr as $i => $val) {
				if ($i != 0) {
					$sql .= " OR";
				}
				$val = trim($val);
				$sql .= " pair_id = '$val'";
			}
			$sql .= " )";
		}
		if (count($filters_status_arr) > 0) {
			$sql .= " AND (";
			foreach ($filters_status_arr as $i => $val) {
				if ($i != 0) {
					$sql .= " OR";
				}
				$val = trim($val);
				$sql .= " status = '$val'";
			}
			$sql .= " )";
		}
		$sql .= " ORDER BY `pair_id` ASC";
		$rs_data = mysqli_query($dbhandle, $sql);
		_log("", $sql);

		$res_arr = [];
		while ($row_data = mysqli_fetch_array($rs_data, MYSQLI_ASSOC)) {
			$cur_data = [];
			foreach ($row_data as $key => $val) {
				$cur_data[$key] = $row_data[$key] ?? '';
			}
			$res_arr[] = $cur_data;
		}

		@mysqli_close($dbhandle);
		$ret_rs['result'] = 'success';
		$ret_rs['response'] = $res_arr;
		header('Content-Type: application/json');
		echo json_encode($ret_rs);
		//////////////////////////////////////////////////////////////////////////////////////////
	} else {
		header('HTTP/1.0 403 Forbidden');
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
} else {
	http_response_code(405);
	die();
}
