<?php $__env->startSection('content'); ?>
  <div class="row justify-content-center">
    <h5 class="text-secondary mb-3 text-center break-all">https://api.kaiserpayment.com/api/non_ui_payment</h5>

    <div class="col-12">
      <div class="error-box card border-danger mb-3 col-12 p-0" style="display: none">
        <div class="card-header bg-danger text-white">Payment Unsuccessful</div>
        <div class="card-body text-danger">
          <p>Payment was unsuccessful.</p>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="tile col-12 col-lg-6 mb-3">
          <div class="card">
            <div class="card-header">Parameters of JDB Non-UI Payment API</div>
            <div class="card-body">
              <form class="row">
                <?php echo csrf_field(); ?>
                <div class="col-md-6">
                  <div class="col-md-12">
                    <div class="mb-3">
                      <label for="amount" class="form-label">Amount <span class="text-red">*</span></label>
                      <input type="text" class="form-control" id="amount" name="amount" placeholder="Enter amount" required value="0.01">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="mb-3">
                      <label for="product_name" class="form-label">Product Name <span class="text-red">*</span></label>
                      <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Enter product name" required value="PACK001-0.01">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="mb-3">
                      <label for="email" class="form-label">Email</label>
                      <input type="text" class="form-control" id="email" name="email" placeholder="Enter email address" value="">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="mb-3">
                      <label for="name" class="form-label">Name</label>
                      <input type="text" class="form-control" id="name" name="name" placeholder="Enter name of user">
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="col-md-12">
                    <div class="mb-3">
                      <label for="card_number_action" class="form-label">Card Number <span class="text-red">*</span></label>
                      <input class="form-control" id="card_number_action" name="card_number_action" type="text" placeholder="**** **** **** ****" required value="454382XXXXXX7103">
                      <input id="card_number" name="card_number" type="hidden" value="4543821798937103">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="mb-3">
                      <label for="card_expiry" class="form-label">Card Expiry Month and Year <span class="text-red">*</span></label>
                      <input type="password" class="form-control" id="card_expiry" name="card_expiry" placeholder="Enter card expiry as MMYY format" required value="0325">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="mb-3">
                      <label for="cvv_code" class="form-label">CVV Code <span class="text-red">*</span></label>
                      <input type="password" class="form-control" id="cvv_code" name="cvv_code" placeholder="Enter CVV code" required value="669">
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div class="card-footer">
              <div class="button-container">
                <button type="button" class="non-ui-payment-1 btn btn-primary w-100">
                  <span class="spinner-anim spinner-border spinner-border-sm text-white" role="status" style="display: none"></span>
                  <span class="spinner-text">Call API 3DS Mode 1</span>
                </button>
                <button type="button" class="non-ui-payment-2 btn btn-success w-100">
                  <span class="spinner-anim spinner-border spinner-border-sm text-white" role="status" style="display: none"></span>
                  <span class="spinner-text">Call API 3DS Mode 2</span>
                </button>
              </div>
            </div>
          </div>
          <div class="card mt-3">
            <div class="card-header">3D Secure Authentication Window Iframe</div>
            <div class="card-body iframe-card">
              
            </div>
          </div>
        </div>

        <div class="tile col-12 col-lg-6 mb-3">
          <div class="card">
            <div class="card-header">API Response</div>
            <div class="card-body api-response wrap-text" style="min-height: 200px; overflow-y: auto;">
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="<?php echo e(asset('js/http_code.jquery.com_jquery-3.6.0.js', config('env') == 'local')); ?>"></script>
    <script src="<?php echo e(asset('js/3ds_additional_proc.js', config('env') == 'local')); ?>"></script>

    <script>
      $(document).ready(function(){
        let apiResponseContainer = $(".api-response");
        $('.error-box').hide();

        $('.non-ui-payment-1').click(function (){
          $('.non-ui-payment-1 .spinner-anim').show();
          $('.non-ui-payment-1').attr('disabled', true);
          $('.error-box').hide();
          $(".api-response").html('');

          let dataToSend = {
            amount: $('#amount').val(),
            product_name: $('#product_name').val(),
            email: $('#email').val(),
            name: $('#name').val(),
            card_number: $('#card_number').val(),
            card_expiry: $('#card_expiry').val(),
            cvv_code: $('#cvv_code').val(),
          };

          $.ajax({
            url: window.location.origin + '/api/non_ui_payment',
            type: 'POST',
            data: JSON.stringify(dataToSend),
            contentType: 'application/json',
            headers: {
              'Authorization': API_KEY
            },
            success: function(response) {
              let formattedJSON = JSON.stringify(response, null, 2);
              apiResponseContainer.html(
                '<pre class="wrap-text">' + formattedJSON + '</pre>'
              );
              $('.non-ui-payment-1 .spinner-anim').hide();
              $('.non-ui-payment-1').removeAttr('disabled');

              if( response['code'] !== 200 ){
                apiResponseContainer.removeClass('text-danger').removeClass('text-success').addClass('text-danger');

                if( response['code'] === 202 ){
                  $('.error-box').show();
                  $('.error-box .card-header').html(response['message']);
                  $('.error-box .card-body').html('');

                  let encodedChallengeHtml = response['body']['challengeHtml'];
                  let challengeHtml = decodeBase64(encodedChallengeHtml);
                  apiResponseContainer.append('<pre><code>' + escapeHtml(challengeHtml) + '</code></pre>');

                  encodedChallengeHtml = response['body']['paymentIncompleteResult']['ChallengeHtml'];
                  challengeHtml = decodeBase64(encodedChallengeHtml);
                  apiResponseContainer.append('<pre><code>' + escapeHtml(challengeHtml) + '</code></pre>');

                  // Create a new iframe element
                  const iframeHtml = '<iframe id="threeDSIframe" class="border-info" style="display: block; margin: 0 auto; width: 100%; height: 500px;"></iframe>';
                  $('.iframe-card').html(iframeHtml);

                  // get iframe object
                  let iframeObj = $('#threeDSIframe');

                  // After the iframe is cleared, load the new content
                  setTimeout(function() {
                    let iframe = iframeObj[0];
                    let doc = iframe.contentDocument || iframe.contentWindow.document;
                    doc.open();
                    doc.write(challengeHtml);
                    doc.close();

                    // Update the language attribute dynamically
                    $(iframe).on('load', function() {
                      let head = doc.head || doc.getElementsByTagName('head')[0];
                      let html = doc.documentElement; // Get the <html> element

                      // Set the lang attribute to 'en'
                      html.setAttribute('lang', 'en');

                      // Create and insert the <meta charset="UTF-8"> tag
                      let metaCharset = doc.createElement('meta');
                      metaCharset.setAttribute('charset', 'UTF-8');
                      head.insertBefore(metaCharset, head.firstChild);
                    });
                  }, 100);  // Small delay to ensure the iframe is cleared
                }
                else{
                  $('.error-box').show();
                  $('.error-box .card-header').html(response['message']);
                  if (typeof response['body'] === 'object') {
                    $('.error-box .card-body').html(
                      '<pre>' + JSON.stringify(response['body'], null, 4) + '</pre>'
                    );
                  } else {
                    $('.error-box .card-body').html(response['body']);
                  }
                }
              }
              else{
                apiResponseContainer.removeClass('text-danger').removeClass('text-success').addClass('text-success');
              }
            },
            error: function(xhr/*, textStatus, errorThrown*/) {
              let formattedJSON = JSON.stringify(xhr.responseJSON, null, 2);
              apiResponseContainer.html('<pre>' + formattedJSON + '</pre>');
              apiResponseContainer.removeClass('text-danger').removeClass('text-success').addClass('text-danger');

              $('.error-box').show();
              $('.error-box .card-header').html(xhr.responseJSON.message);
              $('.error-box .card-body').html(xhr.responseJSON.body);

              $('.non-ui-payment-1 .spinner-anim').hide();
              $('.non-ui-payment-1').removeAttr('disabled');
            }
          });
        });

        $('.non-ui-payment-2').click(function (){
          $('.non-ui-payment-2 .spinner-anim').show();
          $('.non-ui-payment-2').attr('disabled', true);
          $('.error-box').hide();

          // Create a new iframe element
          const iframeHtml = '<iframe id="threeDSIframe" class="border-info" style="display: block; margin: 0 auto; width: 100%; height: 0;"></iframe>';
          $('.iframe-card').html(iframeHtml);
          apiResponseContainer.html('');

          let dataToSend = {
            amount: $('#amount').val(),
            product_name: $('#product_name').val(),
            email: $('#email').val(),
            name: $('#name').val(),
            card_number: $('#card_number').val(),
            card_expiry: $('#card_expiry').val(),
            cvv_code: $('#cvv_code').val(),
          };

          $.ajax({
            url: window.location.origin + '/api/non_ui_payment',
            type: 'POST',
            data: JSON.stringify(dataToSend),
            contentType: 'application/json',
            headers: {
              'Authorization': API_KEY
            },
            success: function(response) {
              let formattedJSON = JSON.stringify(response, null, 2);
              apiResponseContainer.html(
                '<pre class="wrap-text">' + formattedJSON + '</pre>'
              );
              $('.non-ui-payment-2 .spinner-anim').hide();
              $('.non-ui-payment-2').removeAttr('disabled');

              if( response['code'] !== 200 ){
                apiResponseContainer.removeClass('text-danger').removeClass('text-success').addClass('text-danger');

                if( response['code'] === 202 ){
                  const rawCreq = response['body']['paymentIncompleteResult']['rawCreq'];
                  const threeDSSessionData = response['body']['paymentIncompleteResult']['threeDSSessionData'];
                  const acsUrl = response['body']['paymentIncompleteResult']['acsURL'];

                  // Create a form element
                  const form = document.createElement('form');
                  form.method = 'POST';
                  form.action = acsUrl;

                  // Add CSRF token input
                  const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                  const csrfInput = document.createElement('input');
                  csrfInput.type = 'hidden';
                  csrfInput.name = '_token';
                  csrfInput.value = csrfToken;
                  form.appendChild(csrfInput);

                  // Add cReq input
                  const cReqInput = document.createElement('input');
                  cReqInput.type = 'hidden';
                  cReqInput.name = 'creq';
                  cReqInput.value = rawCreq;
                  form.appendChild(cReqInput);

                  // Add threeDSSessionData input
                  const threeDSSessionDataInput = document.createElement('input');
                  threeDSSessionDataInput.type = 'hidden';
                  threeDSSessionDataInput.name = 'threeDSSessionData';
                  threeDSSessionDataInput.value = threeDSSessionData;
                  form.appendChild(threeDSSessionDataInput);

                  // Append the form to the body and submit it
                  document.body.appendChild(form);
                  form.submit();
                }
                else{
                  $('.error-box').show();
                  $('.error-box .card-header').html(response['message']);
                  if (typeof response['body'] === 'object') {
                    $('.error-box .card-body').html(
                      '<pre>' + JSON.stringify(response['body'], null, 4) + '</pre>'
                    );
                  } else {
                    $('.error-box .card-body').html(response['body']);
                  }
                }
              }
              else{
                apiResponseContainer.removeClass('text-danger').removeClass('text-success').addClass('text-success');
              }
            },
            error: function(xhr/*, textStatus, errorThrown*/) {
              let formattedJSON = JSON.stringify(xhr.responseJSON, null, 2);
              apiResponseContainer.html('<pre>' + formattedJSON + '</pre>');
              apiResponseContainer.removeClass('text-danger').removeClass('text-success').addClass('text-danger');

              $('.error-box').show();
              $('.error-box .card-header').html(xhr.responseJSON.message);
              $('.error-box .card-body').html(xhr.responseJSON.body);

              $('.non-ui-payment-2 .spinner-anim').hide();
              $('.non-ui-payment-2').removeAttr('disabled');
            }
          });
        });

        initCardNumberControl();
      });

      function initCardNumberControl(){
        let previousValue = '';

        $('#card_number_action').on('input', function() {
          let currentValue = $(this).val();
          let position = getChanges(previousValue, currentValue);

          let maskedValue = maskNumber($('#card_number').val());
          previousValue = maskedValue;

          $(this).val(maskedValue);
          setCursorAtPosition($(this), position);
        });

        function getChanges(oldValue, newValue) {
          let position = -1;
          let cardNumber = $('#card_number');
          let cardValue = cardNumber.val();
          let maxLength = Math.max(oldValue.length, newValue.length);

          for (let i = 0; i < maxLength; i++) {
            let oldChar = oldValue[i] || '';
            let newChar = newValue[i] || '';

            if (oldChar !== newChar) {
              if (oldChar === undefined) {
                let updatedValue = cardValue.slice(0, i) + newChar + cardValue.slice(i);
                cardNumber.val(updatedValue);
                if( position === -1 )
                  position = i;
              } else if (newChar === undefined) {
                let updatedValue = cardValue.slice(0, i) + cardValue.slice(i + 1);
                cardNumber.val(updatedValue);
                if( position === -1 )
                  position = i;
              } else {
                cardValue = cardValue.slice(0, i) + newChar + cardValue.slice(i + 1);
                if( position === -1 )
                  position = i;
              }
            }
          }

          cardNumber.val(cardValue);
          return position;
        }
      }

      function maskNumber(number) {
        let maskLength = 6; // The length after which the masking starts

        if (number.length > maskLength) {
          for( let i = 6; i < 12; i++ ){
            if( number.length <= i )
              break;
            number = number.slice(0, i) + 'X' + number.slice(i + 1);
          }
        }

        return number;
      }

      function setCursorAtPosition( obj, position) {
        // Ensure the position is valid
        if ((position) < 0 || (position) > obj.val().length) {
          console.error('Invalid position', position, obj.val().length);
          return;
        }

        // Set the cursor position
        obj.focus(); // Ensure the input field is focused
        obj[0].setSelectionRange(position + 1, position + 1);
      }

      function escapeHtml(html) {
        return html
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#039;");
      }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Minamide\minamide_api.kaiserpayment.com\resources\views/pages/non_ui_payment.blade.php ENDPATH**/ ?>