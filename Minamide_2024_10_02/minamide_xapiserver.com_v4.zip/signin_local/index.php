<?php
// Enable error logging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// CORS headers for all requests
header('Access-Control-Allow-Origin: http://localhost:8000');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, X-Requested-With, Authorization');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 3600'); // Cache for 1 hour

// Log request method for debugging
error_log("Request method: " . $_SERVER['REQUEST_METHOD']);

// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(200);  // Ensure HTTP 200 OK is returned
  exit();
}

// Set Content-Type header to JSON
header('Content-Type: application/json');

$response = [
    "result" => "success",
    "signinResponse" => [
        "shift_user_sub_id" => "6f391948-feda-4012-9af0-47bea2147574",
        "email_address" => "minamide@optlynx.com",
        "auth_token" => "p4ZJ_JTBi1oJ8OQK7MDYGVTjYLCTfZn_hhoTjpmC5x-DQ2pMvsud8Lf-RfUBuy.BmuFc8XGy4ypmtxcrg_rmXBwFo-Ew1yJaJvrmHoSseRP5wySyfW-rhW4xGYF8mJkW",
        "expires_in" => 3600,
        "wallet" => [
            ["currency" => "BCH", "balance" => "600.10000000"],
            ["currency" => "BTC", "balance" => "1.01429827"],
            ["currency" => "BUSD", "balance" => "0.00000000"],
            ["currency" => "ETH", "balance" => "0.10000000"],
            ["currency" => "LTC", "balance" => "0.00000000"],
            ["currency" => "SOL", "balance" => "1.10000000"],
            ["currency" => "USD", "balance" => "1,631.86164034"],
            ["currency" => "USDC", "balance" => "40.12345670"],
            ["currency" => "USDT", "balance" => "11,000.00000000"],
            ["currency" => "XRP", "balance" => "0.00000000"]
        ]
    ]
];

// Output the JSON response
echo json_encode($response);
exit;
