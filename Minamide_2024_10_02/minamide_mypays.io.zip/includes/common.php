<?php
function getBaseUrl() {
  // Determine the protocol
  if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    $protocol = "https://";
  } elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $protocol = "https://";
  } elseif (!empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] === 'on') {
    $protocol = "https://";
  } else {
    $protocol = "http://";
  }

  // Get the domain name
  $domainName = $_SERVER['HTTP_HOST'];

  // Get the path
  $path = rtrim(dirname($_SERVER['PHP_SELF']), '/\\') . '/';

  // Return the full base URL
  return $protocol . $domainName . $path;
}

