This is a starter template for [Learn Next.js](https://nextjs.org/learn).

### #1: Install nvm-setup.exe

#### Download and execute nvm-setup.ext

### #2: After install nvm, just install node.js using the nvm.

#### nvm install 16.17

### #3: Use nvm

#### nvm use 16.17

### #4: Check node and npm version and install npm

#### node --version

#### npm --version

### #5: In node or react or next project, install and update npm

#### npm i --legacy-peer-deps

### #6: Set policy

#### Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

### #7: Test

#### npm run dev
