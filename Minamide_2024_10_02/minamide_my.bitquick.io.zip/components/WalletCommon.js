import Link from 'next/link'
import {useRouter} from 'next/router';
import {toUsNumber, truncateFloat} from "./Utils/calc";
import {useEffect, useState} from "react";

function WalletCommon({wallet, id, user}) {
  const router = useRouter();
  const path = router.asPath.split('/');
  const balanceWithoutCommas = wallet.data.balance.replace(/,/g, '');
  const [isMobile, setIsMobile] = useState(0);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768 ? 1 : 0);
    };

    window.addEventListener('resize', handleResize);
    handleResize();
  }, []);

  return (
    <>
      <div className="container-fluid px-4 inner-coin-bnr">
        <div className="row">
          <div className="col-md-6 inner-coin">
            <h1>
            <span
              className={wallet.data.currency === 'USDT' ? 'revert-svc' : ''}
              dangerouslySetInnerHTML={{__html: wallet.icon.replace('%height%', 50).replace('%width%', 50)}}></span>
              <font className="ms-3">{wallet.title}</font>
              <br/>
              {(wallet.data.currency === 'USDT' || wallet.data.currency === 'USD') ?
                <p className="mb-0">{toUsNumber(truncateFloat(balanceWithoutCommas, wallet.float))}</p> :
                <p className="mb-0">{toUsNumber(truncateFloat(balanceWithoutCommas, wallet.float))}</p>
              }
              <div className="coin-unit">{wallet.data.currency}</div>
            </h1>
          </div>
          <div className="col-md-5">
            <div className="">
              <div className="row p-3 pt-0 pb-0 amount-box">
                <div className="col-sm-6 mb-2 pe-1">
                  <Link href={`/user/deposit/` + id} className={`button primary depo-lbl ${isMobile ? "top-round" : "left-top-round"} ${path[2] === `deposit` ? `outline` : `primary-self-outline`}`}>
                    DEPOSIT
                  </Link>
                </div>
                <div className="col-sm-6 mb-2 ps-1">
                  <Link href={`/user/withdraw/` + id} className={`button primary depo-lbl ${isMobile ? "" : "right-top-round"} ${path[2] === `withdraw` ? `outline` : `primary-self-outline`}`}>
                    WITHDRAW
                  </Link>
                </div>
                <div className="col-sm-6 mb-2 pe-1">
                  <Link href={`/user/buy/` + id} className={`button primary depo-lbl ${isMobile ? "" : "left-bottom-round"} ${path[2] === `buy` ? `outline` : `primary-self-outline`}`}>
                    BUY
                  </Link>
                </div>
                <div className="col-sm-6 mb-2 ps-1">
                  <Link href={`/user/sell/` + id} className={`button primary depo-lbl ${isMobile ? "bottom-round" : "right-bottom-round"} ${path[2] === `sell` ? `outline` : `primary-self-outline`}`}>
                    SELL
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default WalletCommon;
