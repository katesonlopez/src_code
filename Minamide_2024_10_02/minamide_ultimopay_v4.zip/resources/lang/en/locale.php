<?php

return [
    "Dashboard" => "Dashboard",
    "Starter kit" => "Starter kit",
    "2 Columns" => "2 Columns",
    "Fixed Navbar" => "Fixed Navbar",
    "Floating Navbar" => "Floating Navbar",
    "Fixed Layout" => "Fixed Layout",
    "Raise Support" => "Raise Support",
    "Documentation" => "Documentation"
];